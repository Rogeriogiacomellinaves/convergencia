
package br.com.tim.mapreduce.tramit.step1;

import br.com.tim.mapreduce.model.BAT509Order;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

import java.io.IOException;

public class MapperOrdem extends org.apache.hadoop.mapreduce.Mapper<Writable,Text,TramitStep1Key,TramitStep1Value> {

	private TramitStep1Key outkey;
	private TramitStep1Value outValue;
	private BAT509Order input;
	
	@Override
	protected void map(Writable key, Text value, Context context) throws IOException, InterruptedException {
		input.parse(value.toString());
		outkey.setNroOrdem(input.getNumeroOrdem());
		outkey.setTipo(TypeStep1.ORDEM);
		outValue.setOrdem(input);
		context.write(outkey,outValue);

	}

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		super.setup(context);
		this.outkey = new TramitStep1Key();
		this.outValue = new TramitStep1Value();
		this.input = new BAT509Order();
	}

	@Override
	protected void cleanup(Context context) throws IOException, InterruptedException {
		super.cleanup(context);
		this.clear();
	}

	private void clear(){
	   this.outValue.clear();
	}

}