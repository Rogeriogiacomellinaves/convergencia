package br.com.tim.mapreduce.refactoring.model;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.io.Writable;

import br.com.tim.utils.CommonsConstants;

public class Wfmtoa implements Writable {
	
	private String acoordStatus;
	private String acoordX;
	private String acoordY;
	private String deliveryWindowStart;
	private String endTime;
	private String apptNumber;
	private String serviceWindowEnd;
	private String serviceWindowStart;
	private String slaWindowEnd;
	private String slaWindowStart;
	private String ctimeDeliveredEnd;
	private String ctimeDeliveredStart;
	private String etaEndTime;
	private String eta;
	private String astatus;
	private String atimeOfAssignment;
	private String atimeOfBooking;
	private String aTsid;
	private String atype;
	private String activityWorkskills;
	private String aworktype;
	private String aworkzone;
	private String queueDate;
	private String timeZoneName;
	private String timeZone;
	private String aid;
	private String caddress;
	private String xaCaddress;
	private String ccell;
	private String cphone;
	private String cname;
	private String cstate;
	private String customerNumber;
	private String czip;
	private String externalId;
	private String firstManualOperation;
	private String parent;
	private String pname;
	private String positionInRoute;
	private String aTimeOfBooking;
	private String xaAcAbrDownSt;
	private String xaAcAbrDownVal;
	private String xaAcAbrUpSt;
	private String xaAcAbrUpVal;
	private String xaAcBitrtSt;
	private String xaAcBitrtVal;
	private String xaAcCpeCard;
	private String xaAcFlP1Voip;
	private String xaAcFlP2Voip;
	private String xaAcKl0;
	private String xaAcMsg;
	private String xaAcType;
	private String xaAccServiceId;
	private String xaAccessTechnology;
	private String xaAcertAaaNrmSt;
	private String xaAcertAtnSt;
	private String xaAcertAtnVal;
	private String xaAcertBrasAuthSt;
	private String xaAcertDslParamsSt;
	private String xaAcertDslProfile;
	private String xaAcertemprIp;
	private String xaAcertFlag;
	private String xaAcertPortSyncSt;
	private String xaAcertSnrSt;
	private String xaAcertSnrVal;
	private String xaAcgGponParams;
	private String xaAcgOltRxst;
	private String xaAcgOltRxval;
	private String xaAcgOnt;
	private String xaAcgOntLinkst;
	private String xaAcgOntLinkval;
	private String xaAcgOntRxst;
	private String xaAcgOntRxval;
	private String xaAcgProfile;
	private String xaActivityComment;
	private String xaActivityOrigin;
	private String xaAcvP1InConf;
	private String xaAcvP1Msg;
	private String xaAcvP1SswConf;
	private String xaAcvP1SswReg;
	private String xaAcvP2InConf;
	private String xaAcvP2Msg;
	private String xaAcvP2SswConf;
	private String xaAcvP2SswReg;
	private String xaAddrRef;
	private String xaAddressChangeFlag;
	private String xaBaNotDoneReason;
	private String xaBaVoipBbNotDoneReason;
	private String xaBaVoipNotDoneReason;
	private String xaBoxSecDestination;
	private String xaCaddress2;
	private String xaCancelReason;
	private String xaCardType;
	private String xaCaseId;
	private String xaCaseReason1;
	private String xaCaseReason2;
	private String xaCaseReason3;
	private String xaCbaNotDoneReason;
	private String xaCdoe;
	private String xaCdoeAddress;
	private String xaCdoePowerRef;
	private String xaCdoiPowerRef;
	private String xaChangeTech;
	private String xaClassification;
	private String xaCompletionCode;
	private String xaCorpAcl;
	private String xaCorpAtivitDate;
	private String xaCorpBuildDate;
	private String xaCorpCancelReason;
	private String xaCorpChecklist;
	private String xaCorpCompletionCode;
	private String xaCorpCountry;
	private String xaCorpCustomerContactAttempts;
	private String xaCorpCustomerPort;
	private String xaCorpCvlan;
	private String xaCorpDeliveryDeadline;
	private String xaCorpDownUpInd;
	private String xaCorpEquipModel;
	private String xaCorpFiberActivationDate;
	private String xaCorpFiberApproachDate;
	private String xaCorpFiberFusionDate;
	private String xaCorpFiberInstallDate;
	private String xaCorpGl;
	private String xaCorpMaksen1;
	private String xaCorpMaksen2;
	private String xaCorpMsanBras;
	private String xaCorpMsanCircuit;
	private String xaCorpMsanModel;
	private String xaCorpMsanSpazio;
	private String xaCorpMsanSwitch;
	private String xaCorpNotDoneReason;
	private String xaCorpPopA;
	private String xaCorpProjId;
	private String xaCorpProjectManager;
	private String xaCorpProjectManagerEmail;
	private String xaCorpProjectManagerPhone;
	private String xaCorpProvider;
	private String xaCorpSalesContact;
	private String xaCorpSalesContactPhone;
	private String xaCorpScheduledDate;
	private String xaCorpSerialNr;
	private String xaCorpSvlan;
	private String xaCorpTechContact;
	private String xaCorpTechContactPhone;
	private String xaCorpWoPivNr;
	private String xaCpeModel;
	private String xaCpeVendor;
	private String xaCrcDescription;
	private String xaCustomerContact;
	private String xaCustomerContactTwo;
	private String xaCustomerType;
	private String xaDistanceTerminalToAddress;
	private String xaEquipIdentification;
	private String xaExtWifi1;
	private String xaExtWifi2;
	private String xaExtWifi3;
	private String xaExtenderSerialNumber;
	private String xaExtenderWifi;
	private String xaFirstRoutingTime;
	private String xaGponOltRx;
	private String xaGponOntRx;
	private String xaGpsValidation;
	private String xaIdLote;
	private String xaIpWan;
	private String xaKeepFacilities;
	private String xaKeepMsan;
	private String xaLetterResponsableId;
	private String xaMeasureKl0;
	private String xaMeasureTrainDb;
	private String xaMeasureTrainRate;
	private String xaModemReused;
	private String xaModemSerialNumber;
	private String xaModemSerieNumber;
	private String xaMsanDestination;
	private String xaMsanDistance;
	private String xaNotDoneReason;
	private String xaNotDoneReasonCus;
	private String xaNttCaixaEmenda1;
	private String xaNttCaixaEmenda2;
	private String xaNttCustomerAddress;
	private String xaNttCustomerAddress2;
	private String xaNttDateNocCommunication;
	private String xaNttEquipmentId;
	private String xaNttEquipmentIdB;
	private String xaNttEquipmentSite;
	private String xaNttEquipmentSiteB;
	private String xaNttEquipmentType;
	private String xaNttFocableProblemSource;
	private String xaNttInterventionType;
	private String xaNttJobType;
	private String xaNttNotDoneReason;
	private String xaNttNotDoneReasonEquip;
	private String xaNttNotDoneReasonFocable;
	private String xaNttOsOpenDate;
	private String xaNttRingCable;
	private String xaNttSubcontractor;
	private String xaNttSuspReasonEquip;
	private String xaNttSuspReasonFocable;
	private String xaOcComments;
	private String xaOldCpeModel;
	private String xaOltPort;
	private String xaOntId;
	private String xaOntModel;
	private String xaOntOltMessage;
	private String xaOntSerialNumber;
	private String xaPairManeuverDestination;
	private String xaParentFaultId;
	private String xaPhone3;
	private String xaPhoneNumberTwo;
	private String xaPiAccessRestritions;
	private String xaPiActivateGmg;
	private String xaPiAffectedTrail;
	private String xaPiAlarmEndDate;
	private String xaPiAlarmManualEnd;
	private String xaPiAlarmManualInit;
	private String xaPiAlarmSugestDate;
	private String xaPiAlarmType;
	private String xaPiAmfAccompName;
	private String xaPiAmfAddress;
	private String xaPiAmfAvailability;
	private String xaPiAmfCustomerInCall;
	private String xaPiAmfDatetime;
	private String xaPiAmfDesignation;
	private String xaPiAmfEmail;
	private String xaPiAmfFailLocation;
	private String xaPiAmfOperator;
	private String xaPiAmfScheduleDate;
	private String xaPiAmfSite;
	private String xaPiAmfTel;
	private String xaPiAmfTimInCall;
	private String xaPiAmfVisitReason;
	private String xaPiArea;
	private String xaPiAssociatedNtts;
	private String xaPiAttendanceSeg;
	private String xaPiBo;
	private String xaPiBoDate;
	private String xaPiBoNotInformedReason;
	private String xaPiBoNumber;
	private String xaPiBreaking;
	private String xaPiBscRnc;
	private String xaPiCfPositionFiber;
	private String xaPiCfReceptionLevel;
	private String xaPiCircuitInfo;
	private String xaPiClaimant;
	private String xaPiCloseNote;
	private String xaPiCm;
	private String xaPiColabName;
	private String xaPiCompany;
	private String xaPiCompanyCosite;
	private String xaPiContract;
	private String xaPiCreateDate;
	private String xaPiCriticalElement;
	private String xaPiCsfNameTelTechAutorization;
	private String xaPiCsfSolution;
	private String xaPiCustomerFinalName;
	private String xaPiCustomerName;
	private String xaPiDefectResponsible;
	private String xaPiDelayReason;
	private String xaPiDependentsPerTx;
	private String xaPiDistance;
	private String xaPiEndId;
	private String xaPiEnergyCode;
	private String xaPiEnergyProtocol;
	private String xaPiEquipAlarm;
	private String xaPiFailCause;
	private String xaPiFailDescription;
	private String xaPiFailSolution;
	private String xaPiFailType;
	private String xaPiFcfArea;
	private String xaPiFcfMaterial;
	private String xaPiFcfOpenStretch;
	private String xaPiFcfQttBox;
	private String xaPiFcfRing;
	private String xaPiGmgDesc;
	private String xaPiGmgDistance;
	private String xaPiGmgEnd;
	private String xaPiGmgOwner;
	private String xaPiGmgPower;
	private String xaPiGmgStart;
	private String xaPiGmgStatus;
	private String xaPiHoliday;
	private String xaPiIdTicketCa;
	private String xaPiImpact;
	private String xaPiIndustrialBuildings;
	private String xaPiInfraAlarm;
	private String xaPiInterruptionService;
	private String xaPiInvChanged;
	private String xaPiIsocColabName;
	private String xaPiLlCircuit;
	private String xaPiLlEndDate;
	private String xaPiLlFailCause;
	private String xaPiLlHasenergy;
	private String xaPiLlHastest;
	private String xaPiLlInitDate;
	private String xaPiLlProviderName;
	private String xaPiMsc;
	private String xaPiMscBsc;
	private String xaPiMsgTicketCa;
	private String xaPiNeImpact;
	private String xaPiNeInfo;
	private String xaPiNeName;
	private String xaPiNeObs;
	private String xaPiNeType;
	private String xaPiNeighborhood;
	private String xaPiNetwork;
	private String xaPiNetworkElement;
	private String xaPiNttStatus;
	private String xaPiNttUserRule;
	private String xaPiObs;
	private String xaPiOp;
	private String xaPiOpeningNote;
	private String xaPiOrigin;
	private String xaPiPartnerCompany;
	private String xaPiPortalSolution;
	private String xaPiPowerDistCompany;
	private String xaPiPqClassification;
	private String xaPiPriority;
	private String xaPiRejectionNote;
	private String xaPiRelatedTickets;
	private String xaPiRelatedTrail;
	private String xaPiResponsable;
	private String xaPiRestartDate;
	private String xaPiSecTicket;
	private String xaPiSecurityCompany;
	private String xaPiSendGmg;
	private String xaPiSiteAutonomy;
	private String xaPiSiteImpact;
	private String xaPiSiteOwner;
	private String xaPiSolutionDescription;
	private String xaPiSpare;
	private String xaPiStEndDate;
	private String xaPiStInitDate;
	private String xaPiStartAlarmDatetime;
	private String xaPiSubArea;
	private String xaPiSuspendNote;
	private String xaPiSuspendReason;
	private String xaPiTdmaCosite;
	private String xaPiTestsDone;
	private String xaPiTheft;
	private String xaPiTicketTitl;
	private String xaPiToBeExecuted;
	private String xaPiTotalDependents;
	private String xaPiTramReason;
	private String xaPiTravelType;
	private String xaPiUmtsCosite;
	private String xaPiUser;
	private String xaPiVandalism;
	private String xaPiWorkDiary;
	private String xaPortManeuverDestination;
	private String xaPort1TnTemporary;
	private String xaPort1VoipProductName;
	private String xaPort1VoipServiceId;
	private String xaPort1VoipTn;
	private String xaPort2TnTemporary;
	private String xaPort2VoipProductName;
	private String xaPort2VoipServiceId;
	private String xaPort2VoipTn;
	private String xaPowerMeasuredCdoe;
	private String xaPowerMeasuredCdoi;
	private String xaPowerMeasuredOnt;
	private String xaPrimOpticalCable;
	private String xaPrimaryNetworkCable;
	private String xaPrimaryNetworkMsan;
	private String xaPrimaryNetworkMsanAddress;
	private String xaPrimaryNetworkPort;
	private String xaProductId;
	private String xaProductName;
	private String xaProductSpeed;
	private String xaReturnedModemSerial;
	private String xaRoutingFlag;
	private String xaRoutingFlagTime;
	private String xaSecOpticalCable;
	private String xaSecondaryNetworkBox;
	private String xaSecondaryNetworkBoxAddress;
	private String xaSecondaryNetworkBoxPort;
	private String xaSecondaryNetworkBoxPowerLevel;
	private String xaSecondaryNetworkBoxTrf;
	private String xaSecondaryNetworkBoxType;
	private String xaSecondaryNetworkCabinet;
	private String xaSecondaryNetworkCabinetAdd;
	private String xaSecondaryNetworkCabinetTrf;
	private String xaSecondaryNetworkCabinetTyp;
	private String xaSecondaryNetworkCable;
	private String xaSecondaryNetworkInternalBox;
	private String xaSecondaryNetworkInternalBoxPlace;
	private String xaSecondaryNetworkInternalBoxPort;
	private String xaSecondaryNetworkInternalBoxPwLev;
	private String xaSecondaryNetworkOntPowerLevel;
	private String xaSecondaryNetworkPort;
	private String xaSerialExtWifi1;
	private String xaSerialExtWifi2;
	private String xaSerialExtWifi3;
	private String xaServiceId;
	private String xaSignalService;
	private String xaSuspendComment;
	private String xaSuspendReason;
	private String xaSyndicateContact;
	private String xaSyndicateContactTwo;
	private String xaSyndicateName;
	private String xaTemperature;
	private String xaTtCauseCode;
	private String xaTtNotDoneReason;
	private String xaTtVoipNotDoneReason;
	private String xaTypeOrder;
	private String xaUploadDateLetter;
	private String xaVlan2Ip;
	private String xaVoipProductId;
	private String xaVoipValidation;
	private String rowId;
	private String loteid;
	private String arquivo;
	private String arquivots;
	private String currentdate;
	
	
	
	
	public Wfmtoa() {
		this.clean();
	}

	public void parseLineFromTable(String text) {
		
		if (!StringUtils.isEmpty(text)) {
			String[] cols = text.split(CommonsConstants.FILE_SPLIT_REGEX, -1);
			int i = 0;
			this.acoordStatus = cols[i++];
			this.acoordX = cols[i++];
			this.acoordY = cols[i++];
			this.deliveryWindowStart = cols[i++];
			this.endTime = cols[i++];
			this.apptNumber = cols[i++];
			this.serviceWindowEnd = cols[i++];
			this.serviceWindowStart = cols[i++];
			this.slaWindowEnd = cols[i++];
			this.slaWindowStart = cols[i++];
			this.ctimeDeliveredEnd = cols[i++];
			this.ctimeDeliveredStart = cols[i++];
			this.etaEndTime = cols[i++];
			this.eta = cols[i++];
			this.astatus = cols[i++];
			this.atimeOfAssignment = cols[i++];
			this.atimeOfBooking = cols[i++];
			this.aTsid = cols[i++];
			this.atype = cols[i++];
			this.activityWorkskills = cols[i++];
			this.aworktype = cols[i++];
			this.aworkzone = cols[i++];
			this.queueDate = cols[i++];
			this.timeZoneName = cols[i++];
			this.timeZone = cols[i++];
			this.aid = cols[i++];
			this.caddress = cols[i++];
			this.xaCaddress = cols[i++];
			this.ccell = cols[i++];
			this.cphone = cols[i++];
			this.cname = cols[i++];
			this.cstate = cols[i++];
			this.customerNumber = cols[i++];
			this.czip = cols[i++];
			this.externalId = cols[i++];
			this.firstManualOperation = cols[i++];
			this.parent = cols[i++];
			this.pname = cols[i++];
			this.positionInRoute = cols[i++];
			this.aTimeOfBooking = cols[i++];
			this.xaAcAbrDownSt = cols[i++];
			this.xaAcAbrDownVal = cols[i++];
			this.xaAcAbrUpSt = cols[i++];
			this.xaAcAbrUpVal = cols[i++];
			this.xaAcBitrtSt = cols[i++];
			this.xaAcBitrtVal = cols[i++];
			this.xaAcCpeCard = cols[i++];
			this.xaAcFlP1Voip = cols[i++];
			this.xaAcFlP2Voip = cols[i++];
			this.xaAcKl0 = cols[i++];
			this.xaAcMsg = cols[i++];
			this.xaAcType = cols[i++];
			this.xaAccServiceId = cols[i++];
			this.xaAccessTechnology = cols[i++];
			this.xaAcertAaaNrmSt = cols[i++];
			this.xaAcertAtnSt = cols[i++];
			this.xaAcertAtnVal = cols[i++];
			this.xaAcertBrasAuthSt = cols[i++];
			this.xaAcertDslParamsSt = cols[i++];
			this.xaAcertDslProfile = cols[i++];
			this.xaAcertemprIp = cols[i++];
			this.xaAcertFlag = cols[i++];
			this.xaAcertPortSyncSt = cols[i++];
			this.xaAcertSnrSt = cols[i++];
			this.xaAcertSnrVal = cols[i++];
			this.xaAcgGponParams = cols[i++];
			this.xaAcgOltRxst = cols[i++];
			this.xaAcgOltRxval = cols[i++];
			this.xaAcgOnt = cols[i++];
			this.xaAcgOntLinkst = cols[i++];
			this.xaAcgOntLinkval = cols[i++];
			this.xaAcgOntRxst = cols[i++];
			this.xaAcgOntRxval = cols[i++];
			this.xaAcgProfile = cols[i++];
			this.xaActivityComment = cols[i++];
			this.xaActivityOrigin = cols[i++];
			this.xaAcvP1InConf = cols[i++];
			this.xaAcvP1Msg = cols[i++];
			this.xaAcvP1SswConf = cols[i++];
			this.xaAcvP1SswReg = cols[i++];
			this.xaAcvP2InConf = cols[i++];
			this.xaAcvP2Msg = cols[i++];
			this.xaAcvP2SswConf = cols[i++];
			this.xaAcvP2SswReg = cols[i++];
			this.xaAddrRef = cols[i++];
			this.xaAddressChangeFlag = cols[i++];
			this.xaBaNotDoneReason = cols[i++];
			this.xaBaVoipBbNotDoneReason = cols[i++];
			this.xaBaVoipNotDoneReason = cols[i++];
			this.xaBoxSecDestination = cols[i++];
			this.xaCaddress2 = cols[i++];
			this.xaCancelReason = cols[i++];
			this.xaCardType = cols[i++];
			this.xaCaseId = cols[i++];
			this.xaCaseReason1 = cols[i++];
			this.xaCaseReason2 = cols[i++];
			this.xaCaseReason3 = cols[i++];
			this.xaCbaNotDoneReason = cols[i++];
			this.xaCdoe = cols[i++];
			this.xaCdoeAddress = cols[i++];
			this.xaCdoePowerRef = cols[i++];
			this.xaCdoiPowerRef = cols[i++];
			this.xaChangeTech = cols[i++];
			this.xaClassification = cols[i++];
			this.xaCompletionCode = cols[i++];
			this.xaCorpAcl = cols[i++];
			this.xaCorpAtivitDate = cols[i++];
			this.xaCorpBuildDate = cols[i++];
			this.xaCorpCancelReason = cols[i++];
			this.xaCorpChecklist = cols[i++];
			this.xaCorpCompletionCode = cols[i++];
			this.xaCorpCountry = cols[i++];
			this.xaCorpCustomerContactAttempts = cols[i++];
			this.xaCorpCustomerPort = cols[i++];
			this.xaCorpCvlan = cols[i++];
			this.xaCorpDeliveryDeadline = cols[i++];
			this.xaCorpDownUpInd = cols[i++];
			this.xaCorpEquipModel = cols[i++];
			this.xaCorpFiberActivationDate = cols[i++];
			this.xaCorpFiberApproachDate = cols[i++];
			this.xaCorpFiberFusionDate = cols[i++];
			this.xaCorpFiberInstallDate = cols[i++];
			this.xaCorpGl = cols[i++];
			this.xaCorpMaksen1 = cols[i++];
			this.xaCorpMaksen2 = cols[i++];
			this.xaCorpMsanBras = cols[i++];
			this.xaCorpMsanCircuit = cols[i++];
			this.xaCorpMsanModel = cols[i++];
			this.xaCorpMsanSpazio = cols[i++];
			this.xaCorpMsanSwitch = cols[i++];
			this.xaCorpNotDoneReason = cols[i++];
			this.xaCorpPopA = cols[i++];
			this.xaCorpProjId = cols[i++];
			this.xaCorpProjectManager = cols[i++];
			this.xaCorpProjectManagerEmail = cols[i++];
			this.xaCorpProjectManagerPhone = cols[i++];
			this.xaCorpProvider = cols[i++];
			this.xaCorpSalesContact = cols[i++];
			this.xaCorpSalesContactPhone = cols[i++];
			this.xaCorpScheduledDate = cols[i++];
			this.xaCorpSerialNr = cols[i++];
			this.xaCorpSvlan = cols[i++];
			this.xaCorpTechContact = cols[i++];
			this.xaCorpTechContactPhone = cols[i++];
			this.xaCorpWoPivNr = cols[i++];
			this.xaCpeModel = cols[i++];
			this.xaCpeVendor = cols[i++];
			this.xaCrcDescription = cols[i++];
			this.xaCustomerContact = cols[i++];
			this.xaCustomerContactTwo = cols[i++];
			this.xaCustomerType = cols[i++];
			this.xaDistanceTerminalToAddress = cols[i++];
			this.xaEquipIdentification = cols[i++];
			this.xaExtWifi1 = cols[i++];
			this.xaExtWifi2 = cols[i++];
			this.xaExtWifi3 = cols[i++];
			this.xaExtenderSerialNumber = cols[i++];
			this.xaExtenderWifi = cols[i++];
			this.xaFirstRoutingTime = cols[i++];
			this.xaGponOltRx = cols[i++];
			this.xaGponOntRx = cols[i++];
			this.xaGpsValidation = cols[i++];
			this.xaIdLote = cols[i++];
			this.xaIpWan = cols[i++];
			this.xaKeepFacilities = cols[i++];
			this.xaKeepMsan = cols[i++];
			this.xaLetterResponsableId = cols[i++];
			this.xaMeasureKl0 = cols[i++];
			this.xaMeasureTrainDb = cols[i++];
			this.xaMeasureTrainRate = cols[i++];
			this.xaModemReused = cols[i++];
			this.xaModemSerialNumber = cols[i++];
			this.xaModemSerieNumber = cols[i++];
			this.xaMsanDestination = cols[i++];
			this.xaMsanDistance = cols[i++];
			this.xaNotDoneReason = cols[i++];
			this.xaNotDoneReasonCus = cols[i++];
			this.xaNttCaixaEmenda1 = cols[i++];
			this.xaNttCaixaEmenda2 = cols[i++];
			this.xaNttCustomerAddress = cols[i++];
			this.xaNttCustomerAddress2 = cols[i++];
			this.xaNttDateNocCommunication = cols[i++];
			this.xaNttEquipmentId = cols[i++];
			this.xaNttEquipmentIdB = cols[i++];
			this.xaNttEquipmentSite = cols[i++];
			this.xaNttEquipmentSiteB = cols[i++];
			this.xaNttEquipmentType = cols[i++];
			this.xaNttFocableProblemSource = cols[i++];
			this.xaNttInterventionType = cols[i++];
			this.xaNttJobType = cols[i++];
			this.xaNttNotDoneReason = cols[i++];
			this.xaNttNotDoneReasonEquip = cols[i++];
			this.xaNttNotDoneReasonFocable = cols[i++];
			this.xaNttOsOpenDate = cols[i++];
			this.xaNttRingCable = cols[i++];
			this.xaNttSubcontractor = cols[i++];
			this.xaNttSuspReasonEquip = cols[i++];
			this.xaNttSuspReasonFocable = cols[i++];
			this.xaOcComments = cols[i++];
			this.xaOldCpeModel = cols[i++];
			this.xaOltPort = cols[i++];
			this.xaOntId = cols[i++];
			this.xaOntModel = cols[i++];
			this.xaOntOltMessage = cols[i++];
			this.xaOntSerialNumber = cols[i++];
			this.xaPairManeuverDestination = cols[i++];
			this.xaParentFaultId = cols[i++];
			this.xaPhone3 = cols[i++];
			this.xaPhoneNumberTwo = cols[i++];
			this.xaPiAccessRestritions = cols[i++];
			this.xaPiActivateGmg = cols[i++];
			this.xaPiAffectedTrail = cols[i++];
			this.xaPiAlarmEndDate = cols[i++];
			this.xaPiAlarmManualEnd = cols[i++];
			this.xaPiAlarmManualInit = cols[i++];
			this.xaPiAlarmSugestDate = cols[i++];
			this.xaPiAlarmType = cols[i++];
			this.xaPiAmfAccompName = cols[i++];
			this.xaPiAmfAddress = cols[i++];
			this.xaPiAmfAvailability = cols[i++];
			this.xaPiAmfCustomerInCall = cols[i++];
			this.xaPiAmfDatetime = cols[i++];
			this.xaPiAmfDesignation = cols[i++];
			this.xaPiAmfEmail = cols[i++];
			this.xaPiAmfFailLocation = cols[i++];
			this.xaPiAmfOperator = cols[i++];
			this.xaPiAmfScheduleDate = cols[i++];
			this.xaPiAmfSite = cols[i++];
			this.xaPiAmfTel = cols[i++];
			this.xaPiAmfTimInCall = cols[i++];
			this.xaPiAmfVisitReason = cols[i++];
			this.xaPiArea = cols[i++];
			this.xaPiAssociatedNtts = cols[i++];
			this.xaPiAttendanceSeg = cols[i++];
			this.xaPiBo = cols[i++];
			this.xaPiBoDate = cols[i++];
			this.xaPiBoNotInformedReason = cols[i++];
			this.xaPiBoNumber = cols[i++];
			this.xaPiBreaking = cols[i++];
			this.xaPiBscRnc = cols[i++];
			this.xaPiCfPositionFiber = cols[i++];
			this.xaPiCfReceptionLevel = cols[i++];
			this.xaPiCircuitInfo = cols[i++];
			this.xaPiClaimant = cols[i++];
			this.xaPiCloseNote = cols[i++];
			this.xaPiCm = cols[i++];
			this.xaPiColabName = cols[i++];
			this.xaPiCompany = cols[i++];
			this.xaPiCompanyCosite = cols[i++];
			this.xaPiContract = cols[i++];
			this.xaPiCreateDate = cols[i++];
			this.xaPiCriticalElement = cols[i++];
			this.xaPiCsfNameTelTechAutorization = cols[i++];
			this.xaPiCsfSolution = cols[i++];
			this.xaPiCustomerFinalName = cols[i++];
			this.xaPiCustomerName = cols[i++];
			this.xaPiDefectResponsible = cols[i++];
			this.xaPiDelayReason = cols[i++];
			this.xaPiDependentsPerTx = cols[i++];
			this.xaPiDistance = cols[i++];
			this.xaPiEndId = cols[i++];
			this.xaPiEnergyCode = cols[i++];
			this.xaPiEnergyProtocol = cols[i++];
			this.xaPiEquipAlarm = cols[i++];
			this.xaPiFailCause = cols[i++];
			this.xaPiFailDescription = cols[i++];
			this.xaPiFailSolution = cols[i++];
			this.xaPiFailType = cols[i++];
			this.xaPiFcfArea = cols[i++];
			this.xaPiFcfMaterial = cols[i++];
			this.xaPiFcfOpenStretch = cols[i++];
			this.xaPiFcfQttBox = cols[i++];
			this.xaPiFcfRing = cols[i++];
			this.xaPiGmgDesc = cols[i++];
			this.xaPiGmgDistance = cols[i++];
			this.xaPiGmgEnd = cols[i++];
			this.xaPiGmgOwner = cols[i++];
			this.xaPiGmgPower = cols[i++];
			this.xaPiGmgStart = cols[i++];
			this.xaPiGmgStatus = cols[i++];
			this.xaPiHoliday = cols[i++];
			this.xaPiIdTicketCa = cols[i++];
			this.xaPiImpact = cols[i++];
			this.xaPiIndustrialBuildings = cols[i++];
			this.xaPiInfraAlarm = cols[i++];
			this.xaPiInterruptionService = cols[i++];
			this.xaPiInvChanged = cols[i++];
			this.xaPiIsocColabName = cols[i++];
			this.xaPiLlCircuit = cols[i++];
			this.xaPiLlEndDate = cols[i++];
			this.xaPiLlFailCause = cols[i++];
			this.xaPiLlHasenergy = cols[i++];
			this.xaPiLlHastest = cols[i++];
			this.xaPiLlInitDate = cols[i++];
			this.xaPiLlProviderName = cols[i++];
			this.xaPiMsc = cols[i++];
			this.xaPiMscBsc = cols[i++];
			this.xaPiMsgTicketCa = cols[i++];
			this.xaPiNeImpact = cols[i++];
			this.xaPiNeInfo = cols[i++];
			this.xaPiNeName = cols[i++];
			this.xaPiNeObs = cols[i++];
			this.xaPiNeType = cols[i++];
			this.xaPiNeighborhood = cols[i++];
			this.xaPiNetwork = cols[i++];
			this.xaPiNetworkElement = cols[i++];
			this.xaPiNttStatus = cols[i++];
			this.xaPiNttUserRule = cols[i++];
			this.xaPiObs = cols[i++];
			this.xaPiOp = cols[i++];
			this.xaPiOpeningNote = cols[i++];
			this.xaPiOrigin = cols[i++];
			this.xaPiPartnerCompany = cols[i++];
			this.xaPiPortalSolution = cols[i++];
			this.xaPiPowerDistCompany = cols[i++];
			this.xaPiPqClassification = cols[i++];
			this.xaPiPriority = cols[i++];
			this.xaPiRejectionNote = cols[i++];
			this.xaPiRelatedTickets = cols[i++];
			this.xaPiRelatedTrail = cols[i++];
			this.xaPiResponsable = cols[i++];
			this.xaPiRestartDate = cols[i++];
			this.xaPiSecTicket = cols[i++];
			this.xaPiSecurityCompany = cols[i++];
			this.xaPiSendGmg = cols[i++];
			this.xaPiSiteAutonomy = cols[i++];
			this.xaPiSiteImpact = cols[i++];
			this.xaPiSiteOwner = cols[i++];
			this.xaPiSolutionDescription = cols[i++];
			this.xaPiSpare = cols[i++];
			this.xaPiStEndDate = cols[i++];
			this.xaPiStInitDate = cols[i++];
			this.xaPiStartAlarmDatetime = cols[i++];
			this.xaPiSubArea = cols[i++];
			this.xaPiSuspendNote = cols[i++];
			this.xaPiSuspendReason = cols[i++];
			this.xaPiTdmaCosite = cols[i++];
			this.xaPiTestsDone = cols[i++];
			this.xaPiTheft = cols[i++];
			this.xaPiTicketTitl = cols[i++];
			this.xaPiToBeExecuted = cols[i++];
			this.xaPiTotalDependents = cols[i++];
			this.xaPiTramReason = cols[i++];
			this.xaPiTravelType = cols[i++];
			this.xaPiUmtsCosite = cols[i++];
			this.xaPiUser = cols[i++];
			this.xaPiVandalism = cols[i++];
			this.xaPiWorkDiary = cols[i++];
			this.xaPortManeuverDestination = cols[i++];
			this.xaPort1TnTemporary = cols[i++];
			this.xaPort1VoipProductName = cols[i++];
			this.xaPort1VoipServiceId = cols[i++];
			this.xaPort1VoipTn = cols[i++];
			this.xaPort2TnTemporary = cols[i++];
			this.xaPort2VoipProductName = cols[i++];
			this.xaPort2VoipServiceId = cols[i++];
			this.xaPort2VoipTn = cols[i++];
			this.xaPowerMeasuredCdoe = cols[i++];
			this.xaPowerMeasuredCdoi = cols[i++];
			this.xaPowerMeasuredOnt = cols[i++];
			this.xaPrimOpticalCable = cols[i++];
			this.xaPrimaryNetworkCable = cols[i++];
			this.xaPrimaryNetworkMsan = cols[i++];
			this.xaPrimaryNetworkMsanAddress = cols[i++];
			this.xaPrimaryNetworkPort = cols[i++];
			this.xaProductId = cols[i++];
			this.xaProductName = cols[i++];
			this.xaProductSpeed = cols[i++];
			this.xaReturnedModemSerial = cols[i++];
			this.xaRoutingFlag = cols[i++];
			this.xaRoutingFlagTime = cols[i++];
			this.xaSecOpticalCable = cols[i++];
			this.xaSecondaryNetworkBox = cols[i++];
			this.xaSecondaryNetworkBoxAddress = cols[i++];
			this.xaSecondaryNetworkBoxPort = cols[i++];
			this.xaSecondaryNetworkBoxPowerLevel = cols[i++];
			this.xaSecondaryNetworkBoxTrf = cols[i++];
			this.xaSecondaryNetworkBoxType = cols[i++];
			this.xaSecondaryNetworkCabinet = cols[i++];
			this.xaSecondaryNetworkCabinetAdd = cols[i++];
			this.xaSecondaryNetworkCabinetTrf = cols[i++];
			this.xaSecondaryNetworkCabinetTyp = cols[i++];
			this.xaSecondaryNetworkCable = cols[i++];
			this.xaSecondaryNetworkInternalBox = cols[i++];
			this.xaSecondaryNetworkInternalBoxPlace = cols[i++];
			this.xaSecondaryNetworkInternalBoxPort = cols[i++];
			this.xaSecondaryNetworkInternalBoxPwLev = cols[i++];
			this.xaSecondaryNetworkOntPowerLevel = cols[i++];
			this.xaSecondaryNetworkPort = cols[i++];
			this.xaSerialExtWifi1 = cols[i++];
			this.xaSerialExtWifi2 = cols[i++];
			this.xaSerialExtWifi3 = cols[i++];
			this.xaServiceId = cols[i++];
			this.xaSignalService = cols[i++];
			this.xaSuspendComment = cols[i++];
			this.xaSuspendReason = cols[i++];
			this.xaSyndicateContact = cols[i++];
			this.xaSyndicateContactTwo = cols[i++];
			this.xaSyndicateName = cols[i++];
			this.xaTemperature = cols[i++];
			this.xaTtCauseCode = cols[i++];
			this.xaTtNotDoneReason = cols[i++];
			this.xaTtVoipNotDoneReason = cols[i++];
			this.xaTypeOrder = cols[i++];
			this.xaUploadDateLetter = cols[i++];
			this.xaVlan2Ip = cols[i++];
			this.xaVoipProductId = cols[i++];
			this.xaVoipValidation = cols[i++];
			this.rowId = cols[i++];
			this.loteid = cols[i++];
			this.arquivo = cols[i++];
			this.arquivots = cols[i++];
			this.currentdate = cols[i++];
		}
	}
	
	public String toString() {
		StringBuilder sb = new StringBuilder();
		
		sb.append(this.acoordStatus).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.acoordX).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.acoordY).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.deliveryWindowStart).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.endTime).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.apptNumber).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.serviceWindowEnd).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.serviceWindowStart).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.slaWindowEnd).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.slaWindowStart).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.ctimeDeliveredEnd).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.ctimeDeliveredStart).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.etaEndTime).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.eta).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.astatus).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.atimeOfAssignment).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.atimeOfBooking).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.aTsid).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.atype).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.activityWorkskills).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.aworktype).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.aworkzone).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.queueDate).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.timeZoneName).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.timeZone).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.aid).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.caddress).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCaddress).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.ccell).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.cphone).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.cname).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.cstate).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.customerNumber).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.czip).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.externalId).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.firstManualOperation).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.parent).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.pname).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.positionInRoute).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.aTimeOfBooking).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcAbrDownSt).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcAbrDownVal).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcAbrUpSt).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcAbrUpVal).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcBitrtSt).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcBitrtVal).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcCpeCard).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcFlP1Voip).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcFlP2Voip).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcKl0).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcMsg).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcType).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAccServiceId).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAccessTechnology).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcertAaaNrmSt).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcertAtnSt).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcertAtnVal).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcertBrasAuthSt).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcertDslParamsSt).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcertDslProfile).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcertemprIp).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcertFlag).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcertPortSyncSt).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcertSnrSt).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcertSnrVal).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcgGponParams).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcgOltRxst).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcgOltRxval).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcgOnt).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcgOntLinkst).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcgOntLinkval).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcgOntRxst).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcgOntRxval).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcgProfile).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaActivityComment).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaActivityOrigin).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcvP1InConf).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcvP1Msg).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcvP1SswConf).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcvP1SswReg).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcvP2InConf).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcvP2Msg).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcvP2SswConf).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAcvP2SswReg).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAddrRef).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaAddressChangeFlag).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaBaNotDoneReason).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaBaVoipBbNotDoneReason).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaBaVoipNotDoneReason).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaBoxSecDestination).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCaddress2).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCancelReason).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCardType).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCaseId).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCaseReason1).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCaseReason2).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCaseReason3).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCbaNotDoneReason).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCdoe).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCdoeAddress).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCdoePowerRef).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCdoiPowerRef).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaChangeTech).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaClassification).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCompletionCode).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpAcl).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpAtivitDate).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpBuildDate).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpCancelReason).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpChecklist).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpCompletionCode).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpCountry).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpCustomerContactAttempts).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpCustomerPort).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpCvlan).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpDeliveryDeadline).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpDownUpInd).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpEquipModel).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpFiberActivationDate).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpFiberApproachDate).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpFiberFusionDate).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpFiberInstallDate).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpGl).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpMaksen1).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpMaksen2).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpMsanBras).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpMsanCircuit).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpMsanModel).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpMsanSpazio).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpMsanSwitch).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpNotDoneReason).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpPopA).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpProjId).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpProjectManager).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpProjectManagerEmail).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpProjectManagerPhone).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpProvider).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpSalesContact).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpSalesContactPhone).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpScheduledDate).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpSerialNr).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpSvlan).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpTechContact).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpTechContactPhone).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCorpWoPivNr).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCpeModel).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCpeVendor).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCrcDescription).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCustomerContact).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCustomerContactTwo).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaCustomerType).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaDistanceTerminalToAddress).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaEquipIdentification).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaExtWifi1).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaExtWifi2).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaExtWifi3).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaExtenderSerialNumber).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaExtenderWifi).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaFirstRoutingTime).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaGponOltRx).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaGponOntRx).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaGpsValidation).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaIdLote).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaIpWan).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaKeepFacilities).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaKeepMsan).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaLetterResponsableId).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaMeasureKl0).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaMeasureTrainDb).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaMeasureTrainRate).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaModemReused).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaModemSerialNumber).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaModemSerieNumber).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaMsanDestination).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaMsanDistance).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaNotDoneReason).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaNotDoneReasonCus).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaNttCaixaEmenda1).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaNttCaixaEmenda2).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaNttCustomerAddress).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaNttCustomerAddress2).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaNttDateNocCommunication).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaNttEquipmentId).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaNttEquipmentIdB).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaNttEquipmentSite).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaNttEquipmentSiteB).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaNttEquipmentType).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaNttFocableProblemSource).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaNttInterventionType).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaNttJobType).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaNttNotDoneReason).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaNttNotDoneReasonEquip).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaNttNotDoneReasonFocable).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaNttOsOpenDate).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaNttRingCable).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaNttSubcontractor).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaNttSuspReasonEquip).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaNttSuspReasonFocable).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaOcComments).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaOldCpeModel).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaOltPort).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaOntId).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaOntModel).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaOntOltMessage).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaOntSerialNumber).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPairManeuverDestination).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaParentFaultId).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPhone3).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPhoneNumberTwo).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiAccessRestritions).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiActivateGmg).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiAffectedTrail).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiAlarmEndDate).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiAlarmManualEnd).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiAlarmManualInit).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiAlarmSugestDate).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiAlarmType).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiAmfAccompName).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiAmfAddress).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiAmfAvailability).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiAmfCustomerInCall).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiAmfDatetime).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiAmfDesignation).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiAmfEmail).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiAmfFailLocation).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiAmfOperator).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiAmfScheduleDate).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiAmfSite).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiAmfTel).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiAmfTimInCall).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiAmfVisitReason).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiArea).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiAssociatedNtts).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiAttendanceSeg).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiBo).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiBoDate).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiBoNotInformedReason).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiBoNumber).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiBreaking).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiBscRnc).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiCfPositionFiber).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiCfReceptionLevel).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiCircuitInfo).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiClaimant).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiCloseNote).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiCm).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiColabName).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiCompany).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiCompanyCosite).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiContract).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiCreateDate).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiCriticalElement).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiCsfNameTelTechAutorization).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiCsfSolution).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiCustomerFinalName).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiCustomerName).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiDefectResponsible).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiDelayReason).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiDependentsPerTx).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiDistance).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiEndId).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiEnergyCode).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiEnergyProtocol).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiEquipAlarm).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiFailCause).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiFailDescription).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiFailSolution).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiFailType).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiFcfArea).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiFcfMaterial).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiFcfOpenStretch).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiFcfQttBox).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiFcfRing).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiGmgDesc).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiGmgDistance).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiGmgEnd).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiGmgOwner).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiGmgPower).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiGmgStart).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiGmgStatus).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiHoliday).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiIdTicketCa).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiImpact).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiIndustrialBuildings).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiInfraAlarm).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiInterruptionService).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiInvChanged).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiIsocColabName).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiLlCircuit).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiLlEndDate).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiLlFailCause).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiLlHasenergy).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiLlHastest).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiLlInitDate).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiLlProviderName).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiMsc).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiMscBsc).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiMsgTicketCa).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiNeImpact).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiNeInfo).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiNeName).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiNeObs).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiNeType).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiNeighborhood).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiNetwork).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiNetworkElement).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiNttStatus).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiNttUserRule).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiObs).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiOp).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiOpeningNote).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiOrigin).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiPartnerCompany).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiPortalSolution).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiPowerDistCompany).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiPqClassification).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiPriority).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiRejectionNote).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiRelatedTickets).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiRelatedTrail).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiResponsable).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiRestartDate).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiSecTicket).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiSecurityCompany).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiSendGmg).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiSiteAutonomy).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiSiteImpact).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiSiteOwner).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiSolutionDescription).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiSpare).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiStEndDate).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiStInitDate).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiStartAlarmDatetime).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiSubArea).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiSuspendNote).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiSuspendReason).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiTdmaCosite).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiTestsDone).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiTheft).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiTicketTitl).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiToBeExecuted).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiTotalDependents).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiTramReason).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiTravelType).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiUmtsCosite).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiUser).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiVandalism).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPiWorkDiary).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPortManeuverDestination).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPort1TnTemporary).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPort1VoipProductName).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPort1VoipServiceId).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPort1VoipTn).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPort2TnTemporary).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPort2VoipProductName).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPort2VoipServiceId).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPort2VoipTn).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPowerMeasuredCdoe).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPowerMeasuredCdoi).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPowerMeasuredOnt).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPrimOpticalCable).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPrimaryNetworkCable).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPrimaryNetworkMsan).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPrimaryNetworkMsanAddress).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaPrimaryNetworkPort).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaProductId).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaProductName).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaProductSpeed).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaReturnedModemSerial).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaRoutingFlag).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaRoutingFlagTime).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaSecOpticalCable).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaSecondaryNetworkBox).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaSecondaryNetworkBoxAddress).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaSecondaryNetworkBoxPort).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaSecondaryNetworkBoxPowerLevel).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaSecondaryNetworkBoxTrf).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaSecondaryNetworkBoxType).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaSecondaryNetworkCabinet).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaSecondaryNetworkCabinetAdd).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaSecondaryNetworkCabinetTrf).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaSecondaryNetworkCabinetTyp).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaSecondaryNetworkCable).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaSecondaryNetworkInternalBox).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaSecondaryNetworkInternalBoxPlace).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaSecondaryNetworkInternalBoxPort).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaSecondaryNetworkInternalBoxPwLev).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaSecondaryNetworkOntPowerLevel).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaSecondaryNetworkPort).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaSerialExtWifi1).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaSerialExtWifi2).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaSerialExtWifi3).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaServiceId).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaSignalService).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaSuspendComment).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaSuspendReason).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaSyndicateContact).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaSyndicateContactTwo).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaSyndicateName).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaTemperature).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaTtCauseCode).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaTtNotDoneReason).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaTtVoipNotDoneReason).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaTypeOrder).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaUploadDateLetter).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaVlan2Ip).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaVoipProductId).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.xaVoipValidation).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.rowId).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.loteid).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.arquivo).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.arquivots).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		sb.append(this.currentdate).append(CommonsConstants.FILE_FIELD_SEPARATOR);
		
		return sb.toString();
	}
	
	public void clean() {
		this.acoordStatus = "";
		this.acoordX = "";
		this.acoordY = "";
		this.deliveryWindowStart = "";
		this.endTime = "";
		this.apptNumber = "";
		this.serviceWindowEnd = "";
		this.serviceWindowStart = "";
		this.slaWindowEnd = "";
		this.slaWindowStart = "";
		this.ctimeDeliveredEnd = "";
		this.ctimeDeliveredStart = "";
		this.etaEndTime = "";
		this.eta = "";
		this.astatus = "";
		this.atimeOfAssignment = "";
		this.atimeOfBooking = "";
		this.aTsid = "";
		this.atype = "";
		this.activityWorkskills = "";
		this.aworktype = "";
		this.aworkzone = "";
		this.queueDate = "";
		this.timeZoneName = "";
		this.timeZone = "";
		this.aid = "";
		this.caddress = "";
		this.xaCaddress = "";
		this.ccell = "";
		this.cphone = "";
		this.cname = "";
		this.cstate = "";
		this.customerNumber = "";
		this.czip = "";
		this.externalId = "";
		this.firstManualOperation = "";
		this.parent = "";
		this.pname = "";
		this.positionInRoute = "";
		this.aTimeOfBooking = "";
		this.xaAcAbrDownSt = "";
		this.xaAcAbrDownVal = "";
		this.xaAcAbrUpSt = "";
		this.xaAcAbrUpVal = "";
		this.xaAcBitrtSt = "";
		this.xaAcBitrtVal = "";
		this.xaAcCpeCard = "";
		this.xaAcFlP1Voip = "";
		this.xaAcFlP2Voip = "";
		this.xaAcKl0 = "";
		this.xaAcMsg = "";
		this.xaAcType = "";
		this.xaAccServiceId = "";
		this.xaAccessTechnology = "";
		this.xaAcertAaaNrmSt = "";
		this.xaAcertAtnSt = "";
		this.xaAcertAtnVal = "";
		this.xaAcertBrasAuthSt = "";
		this.xaAcertDslParamsSt = "";
		this.xaAcertDslProfile = "";
		this.xaAcertemprIp = "";
		this.xaAcertFlag = "";
		this.xaAcertPortSyncSt = "";
		this.xaAcertSnrSt = "";
		this.xaAcertSnrVal = "";
		this.xaAcgGponParams = "";
		this.xaAcgOltRxst = "";
		this.xaAcgOltRxval = "";
		this.xaAcgOnt = "";
		this.xaAcgOntLinkst = "";
		this.xaAcgOntLinkval = "";
		this.xaAcgOntRxst = "";
		this.xaAcgOntRxval = "";
		this.xaAcgProfile = "";
		this.xaActivityComment = "";
		this.xaActivityOrigin = "";
		this.xaAcvP1InConf = "";
		this.xaAcvP1Msg = "";
		this.xaAcvP1SswConf = "";
		this.xaAcvP1SswReg = "";
		this.xaAcvP2InConf = "";
		this.xaAcvP2Msg = "";
		this.xaAcvP2SswConf = "";
		this.xaAcvP2SswReg = "";
		this.xaAddrRef = "";
		this.xaAddressChangeFlag = "";
		this.xaBaNotDoneReason = "";
		this.xaBaVoipBbNotDoneReason = "";
		this.xaBaVoipNotDoneReason = "";
		this.xaBoxSecDestination = "";
		this.xaCaddress2 = "";
		this.xaCancelReason = "";
		this.xaCardType = "";
		this.xaCaseId = "";
		this.xaCaseReason1 = "";
		this.xaCaseReason2 = "";
		this.xaCaseReason3 = "";
		this.xaCbaNotDoneReason = "";
		this.xaCdoe = "";
		this.xaCdoeAddress = "";
		this.xaCdoePowerRef = "";
		this.xaCdoiPowerRef = "";
		this.xaChangeTech = "";
		this.xaClassification = "";
		this.xaCompletionCode = "";
		this.xaCorpAcl = "";
		this.xaCorpAtivitDate = "";
		this.xaCorpBuildDate = "";
		this.xaCorpCancelReason = "";
		this.xaCorpChecklist = "";
		this.xaCorpCompletionCode = "";
		this.xaCorpCountry = "";
		this.xaCorpCustomerContactAttempts = "";
		this.xaCorpCustomerPort = "";
		this.xaCorpCvlan = "";
		this.xaCorpDeliveryDeadline = "";
		this.xaCorpDownUpInd = "";
		this.xaCorpEquipModel = "";
		this.xaCorpFiberActivationDate = "";
		this.xaCorpFiberApproachDate = "";
		this.xaCorpFiberFusionDate = "";
		this.xaCorpFiberInstallDate = "";
		this.xaCorpGl = "";
		this.xaCorpMaksen1 = "";
		this.xaCorpMaksen2 = "";
		this.xaCorpMsanBras = "";
		this.xaCorpMsanCircuit = "";
		this.xaCorpMsanModel = "";
		this.xaCorpMsanSpazio = "";
		this.xaCorpMsanSwitch = "";
		this.xaCorpNotDoneReason = "";
		this.xaCorpPopA = "";
		this.xaCorpProjId = "";
		this.xaCorpProjectManager = "";
		this.xaCorpProjectManagerEmail = "";
		this.xaCorpProjectManagerPhone = "";
		this.xaCorpProvider = "";
		this.xaCorpSalesContact = "";
		this.xaCorpSalesContactPhone = "";
		this.xaCorpScheduledDate = "";
		this.xaCorpSerialNr = "";
		this.xaCorpSvlan = "";
		this.xaCorpTechContact = "";
		this.xaCorpTechContactPhone = "";
		this.xaCorpWoPivNr = "";
		this.xaCpeModel = "";
		this.xaCpeVendor = "";
		this.xaCrcDescription = "";
		this.xaCustomerContact = "";
		this.xaCustomerContactTwo = "";
		this.xaCustomerType = "";
		this.xaDistanceTerminalToAddress = "";
		this.xaEquipIdentification = "";
		this.xaExtWifi1 = "";
		this.xaExtWifi2 = "";
		this.xaExtWifi3 = "";
		this.xaExtenderSerialNumber = "";
		this.xaExtenderWifi = "";
		this.xaFirstRoutingTime = "";
		this.xaGponOltRx = "";
		this.xaGponOntRx = "";
		this.xaGpsValidation = "";
		this.xaIdLote = "";
		this.xaIpWan = "";
		this.xaKeepFacilities = "";
		this.xaKeepMsan = "";
		this.xaLetterResponsableId = "";
		this.xaMeasureKl0 = "";
		this.xaMeasureTrainDb = "";
		this.xaMeasureTrainRate = "";
		this.xaModemReused = "";
		this.xaModemSerialNumber = "";
		this.xaModemSerieNumber = "";
		this.xaMsanDestination = "";
		this.xaMsanDistance = "";
		this.xaNotDoneReason = "";
		this.xaNotDoneReasonCus = "";
		this.xaNttCaixaEmenda1 = "";
		this.xaNttCaixaEmenda2 = "";
		this.xaNttCustomerAddress = "";
		this.xaNttCustomerAddress2 = "";
		this.xaNttDateNocCommunication = "";
		this.xaNttEquipmentId = "";
		this.xaNttEquipmentIdB = "";
		this.xaNttEquipmentSite = "";
		this.xaNttEquipmentSiteB = "";
		this.xaNttEquipmentType = "";
		this.xaNttFocableProblemSource = "";
		this.xaNttInterventionType = "";
		this.xaNttJobType = "";
		this.xaNttNotDoneReason = "";
		this.xaNttNotDoneReasonEquip = "";
		this.xaNttNotDoneReasonFocable = "";
		this.xaNttOsOpenDate = "";
		this.xaNttRingCable = "";
		this.xaNttSubcontractor = "";
		this.xaNttSuspReasonEquip = "";
		this.xaNttSuspReasonFocable = "";
		this.xaOcComments = "";
		this.xaOldCpeModel = "";
		this.xaOltPort = "";
		this.xaOntId = "";
		this.xaOntModel = "";
		this.xaOntOltMessage = "";
		this.xaOntSerialNumber = "";
		this.xaPairManeuverDestination = "";
		this.xaParentFaultId = "";
		this.xaPhone3 = "";
		this.xaPhoneNumberTwo = "";
		this.xaPiAccessRestritions = "";
		this.xaPiActivateGmg = "";
		this.xaPiAffectedTrail = "";
		this.xaPiAlarmEndDate = "";
		this.xaPiAlarmManualEnd = "";
		this.xaPiAlarmManualInit = "";
		this.xaPiAlarmSugestDate = "";
		this.xaPiAlarmType = "";
		this.xaPiAmfAccompName = "";
		this.xaPiAmfAddress = "";
		this.xaPiAmfAvailability = "";
		this.xaPiAmfCustomerInCall = "";
		this.xaPiAmfDatetime = "";
		this.xaPiAmfDesignation = "";
		this.xaPiAmfEmail = "";
		this.xaPiAmfFailLocation = "";
		this.xaPiAmfOperator = "";
		this.xaPiAmfScheduleDate = "";
		this.xaPiAmfSite = "";
		this.xaPiAmfTel = "";
		this.xaPiAmfTimInCall = "";
		this.xaPiAmfVisitReason = "";
		this.xaPiArea = "";
		this.xaPiAssociatedNtts = "";
		this.xaPiAttendanceSeg = "";
		this.xaPiBo = "";
		this.xaPiBoDate = "";
		this.xaPiBoNotInformedReason = "";
		this.xaPiBoNumber = "";
		this.xaPiBreaking = "";
		this.xaPiBscRnc = "";
		this.xaPiCfPositionFiber = "";
		this.xaPiCfReceptionLevel = "";
		this.xaPiCircuitInfo = "";
		this.xaPiClaimant = "";
		this.xaPiCloseNote = "";
		this.xaPiCm = "";
		this.xaPiColabName = "";
		this.xaPiCompany = "";
		this.xaPiCompanyCosite = "";
		this.xaPiContract = "";
		this.xaPiCreateDate = "";
		this.xaPiCriticalElement = "";
		this.xaPiCsfNameTelTechAutorization = "";
		this.xaPiCsfSolution = "";
		this.xaPiCustomerFinalName = "";
		this.xaPiCustomerName = "";
		this.xaPiDefectResponsible = "";
		this.xaPiDelayReason = "";
		this.xaPiDependentsPerTx = "";
		this.xaPiDistance = "";
		this.xaPiEndId = "";
		this.xaPiEnergyCode = "";
		this.xaPiEnergyProtocol = "";
		this.xaPiEquipAlarm = "";
		this.xaPiFailCause = "";
		this.xaPiFailDescription = "";
		this.xaPiFailSolution = "";
		this.xaPiFailType = "";
		this.xaPiFcfArea = "";
		this.xaPiFcfMaterial = "";
		this.xaPiFcfOpenStretch = "";
		this.xaPiFcfQttBox = "";
		this.xaPiFcfRing = "";
		this.xaPiGmgDesc = "";
		this.xaPiGmgDistance = "";
		this.xaPiGmgEnd = "";
		this.xaPiGmgOwner = "";
		this.xaPiGmgPower = "";
		this.xaPiGmgStart = "";
		this.xaPiGmgStatus = "";
		this.xaPiHoliday = "";
		this.xaPiIdTicketCa = "";
		this.xaPiImpact = "";
		this.xaPiIndustrialBuildings = "";
		this.xaPiInfraAlarm = "";
		this.xaPiInterruptionService = "";
		this.xaPiInvChanged = "";
		this.xaPiIsocColabName = "";
		this.xaPiLlCircuit = "";
		this.xaPiLlEndDate = "";
		this.xaPiLlFailCause = "";
		this.xaPiLlHasenergy = "";
		this.xaPiLlHastest = "";
		this.xaPiLlInitDate = "";
		this.xaPiLlProviderName = "";
		this.xaPiMsc = "";
		this.xaPiMscBsc = "";
		this.xaPiMsgTicketCa = "";
		this.xaPiNeImpact = "";
		this.xaPiNeInfo = "";
		this.xaPiNeName = "";
		this.xaPiNeObs = "";
		this.xaPiNeType = "";
		this.xaPiNeighborhood = "";
		this.xaPiNetwork = "";
		this.xaPiNetworkElement = "";
		this.xaPiNttStatus = "";
		this.xaPiNttUserRule = "";
		this.xaPiObs = "";
		this.xaPiOp = "";
		this.xaPiOpeningNote = "";
		this.xaPiOrigin = "";
		this.xaPiPartnerCompany = "";
		this.xaPiPortalSolution = "";
		this.xaPiPowerDistCompany = "";
		this.xaPiPqClassification = "";
		this.xaPiPriority = "";
		this.xaPiRejectionNote = "";
		this.xaPiRelatedTickets = "";
		this.xaPiRelatedTrail = "";
		this.xaPiResponsable = "";
		this.xaPiRestartDate = "";
		this.xaPiSecTicket = "";
		this.xaPiSecurityCompany = "";
		this.xaPiSendGmg = "";
		this.xaPiSiteAutonomy = "";
		this.xaPiSiteImpact = "";
		this.xaPiSiteOwner = "";
		this.xaPiSolutionDescription = "";
		this.xaPiSpare = "";
		this.xaPiStEndDate = "";
		this.xaPiStInitDate = "";
		this.xaPiStartAlarmDatetime = "";
		this.xaPiSubArea = "";
		this.xaPiSuspendNote = "";
		this.xaPiSuspendReason = "";
		this.xaPiTdmaCosite = "";
		this.xaPiTestsDone = "";
		this.xaPiTheft = "";
		this.xaPiTicketTitl = "";
		this.xaPiToBeExecuted = "";
		this.xaPiTotalDependents = "";
		this.xaPiTramReason = "";
		this.xaPiTravelType = "";
		this.xaPiUmtsCosite = "";
		this.xaPiUser = "";
		this.xaPiVandalism = "";
		this.xaPiWorkDiary = "";
		this.xaPortManeuverDestination = "";
		this.xaPort1TnTemporary = "";
		this.xaPort1VoipProductName = "";
		this.xaPort1VoipServiceId = "";
		this.xaPort1VoipTn = "";
		this.xaPort2TnTemporary = "";
		this.xaPort2VoipProductName = "";
		this.xaPort2VoipServiceId = "";
		this.xaPort2VoipTn = "";
		this.xaPowerMeasuredCdoe = "";
		this.xaPowerMeasuredCdoi = "";
		this.xaPowerMeasuredOnt = "";
		this.xaPrimOpticalCable = "";
		this.xaPrimaryNetworkCable = "";
		this.xaPrimaryNetworkMsan = "";
		this.xaPrimaryNetworkMsanAddress = "";
		this.xaPrimaryNetworkPort = "";
		this.xaProductId = "";
		this.xaProductName = "";
		this.xaProductSpeed = "";
		this.xaReturnedModemSerial = "";
		this.xaRoutingFlag = "";
		this.xaRoutingFlagTime = "";
		this.xaSecOpticalCable = "";
		this.xaSecondaryNetworkBox = "";
		this.xaSecondaryNetworkBoxAddress = "";
		this.xaSecondaryNetworkBoxPort = "";
		this.xaSecondaryNetworkBoxPowerLevel = "";
		this.xaSecondaryNetworkBoxTrf = "";
		this.xaSecondaryNetworkBoxType = "";
		this.xaSecondaryNetworkCabinet = "";
		this.xaSecondaryNetworkCabinetAdd = "";
		this.xaSecondaryNetworkCabinetTrf = "";
		this.xaSecondaryNetworkCabinetTyp = "";
		this.xaSecondaryNetworkCable = "";
		this.xaSecondaryNetworkInternalBox = "";
		this.xaSecondaryNetworkInternalBoxPlace = "";
		this.xaSecondaryNetworkInternalBoxPort = "";
		this.xaSecondaryNetworkInternalBoxPwLev = "";
		this.xaSecondaryNetworkOntPowerLevel = "";
		this.xaSecondaryNetworkPort = "";
		this.xaSerialExtWifi1 = "";
		this.xaSerialExtWifi2 = "";
		this.xaSerialExtWifi3 = "";
		this.xaServiceId = "";
		this.xaSignalService = "";
		this.xaSuspendComment = "";
		this.xaSuspendReason = "";
		this.xaSyndicateContact = "";
		this.xaSyndicateContactTwo = "";
		this.xaSyndicateName = "";
		this.xaTemperature = "";
		this.xaTtCauseCode = "";
		this.xaTtNotDoneReason = "";
		this.xaTtVoipNotDoneReason = "";
		this.xaTypeOrder = "";
		this.xaUploadDateLetter = "";
		this.xaVlan2Ip = "";
		this.xaVoipProductId = "";
		this.xaVoipValidation = "";
		this.rowId = "";
		this.loteid = "";
		this.arquivo = "";
		this.arquivots = "";
		this.currentdate = "";
	}
	
	@Override
	public void write(DataOutput out) throws IOException {
		out.writeUTF(this.acoordStatus);
		out.writeUTF(this.acoordX);
		out.writeUTF(this.acoordY);
		out.writeUTF(this.deliveryWindowStart);
		out.writeUTF(this.endTime);
		out.writeUTF(this.apptNumber);
		out.writeUTF(this.serviceWindowEnd);
		out.writeUTF(this.serviceWindowStart);
		out.writeUTF(this.slaWindowEnd);
		out.writeUTF(this.slaWindowStart);
		out.writeUTF(this.ctimeDeliveredEnd);
		out.writeUTF(this.ctimeDeliveredStart);
		out.writeUTF(this.etaEndTime);
		out.writeUTF(this.eta);
		out.writeUTF(this.astatus);
		out.writeUTF(this.atimeOfAssignment);
		out.writeUTF(this.atimeOfBooking);
		out.writeUTF(this.aTsid);
		out.writeUTF(this.atype);
		out.writeUTF(this.activityWorkskills);
		out.writeUTF(this.aworktype);
		out.writeUTF(this.aworkzone);
		out.writeUTF(this.queueDate);
		out.writeUTF(this.timeZoneName);
		out.writeUTF(this.timeZone);
		out.writeUTF(this.aid);
		out.writeUTF(this.caddress);
		out.writeUTF(this.xaCaddress);
		out.writeUTF(this.ccell);
		out.writeUTF(this.cphone);
		out.writeUTF(this.cname);
		out.writeUTF(this.cstate);
		out.writeUTF(this.customerNumber);
		out.writeUTF(this.czip);
		out.writeUTF(this.externalId);
		out.writeUTF(this.firstManualOperation);
		out.writeUTF(this.parent);
		out.writeUTF(this.pname);
		out.writeUTF(this.positionInRoute);
		out.writeUTF(this.aTimeOfBooking);
		out.writeUTF(this.xaAcAbrDownSt);
		out.writeUTF(this.xaAcAbrDownVal);
		out.writeUTF(this.xaAcAbrUpSt);
		out.writeUTF(this.xaAcAbrUpVal);
		out.writeUTF(this.xaAcBitrtSt);
		out.writeUTF(this.xaAcBitrtVal);
		out.writeUTF(this.xaAcCpeCard);
		out.writeUTF(this.xaAcFlP1Voip);
		out.writeUTF(this.xaAcFlP2Voip);
		out.writeUTF(this.xaAcKl0);
		out.writeUTF(this.xaAcMsg);
		out.writeUTF(this.xaAcType);
		out.writeUTF(this.xaAccServiceId);
		out.writeUTF(this.xaAccessTechnology);
		out.writeUTF(this.xaAcertAaaNrmSt);
		out.writeUTF(this.xaAcertAtnSt);
		out.writeUTF(this.xaAcertAtnVal);
		out.writeUTF(this.xaAcertBrasAuthSt);
		out.writeUTF(this.xaAcertDslParamsSt);
		out.writeUTF(this.xaAcertDslProfile);
		out.writeUTF(this.xaAcertemprIp);
		out.writeUTF(this.xaAcertFlag);
		out.writeUTF(this.xaAcertPortSyncSt);
		out.writeUTF(this.xaAcertSnrSt);
		out.writeUTF(this.xaAcertSnrVal);
		out.writeUTF(this.xaAcgGponParams);
		out.writeUTF(this.xaAcgOltRxst);
		out.writeUTF(this.xaAcgOltRxval);
		out.writeUTF(this.xaAcgOnt);
		out.writeUTF(this.xaAcgOntLinkst);
		out.writeUTF(this.xaAcgOntLinkval);
		out.writeUTF(this.xaAcgOntRxst);
		out.writeUTF(this.xaAcgOntRxval);
		out.writeUTF(this.xaAcgProfile);
		out.writeUTF(this.xaActivityComment);
		out.writeUTF(this.xaActivityOrigin);
		out.writeUTF(this.xaAcvP1InConf);
		out.writeUTF(this.xaAcvP1Msg);
		out.writeUTF(this.xaAcvP1SswConf);
		out.writeUTF(this.xaAcvP1SswReg);
		out.writeUTF(this.xaAcvP2InConf);
		out.writeUTF(this.xaAcvP2Msg);
		out.writeUTF(this.xaAcvP2SswConf);
		out.writeUTF(this.xaAcvP2SswReg);
		out.writeUTF(this.xaAddrRef);
		out.writeUTF(this.xaAddressChangeFlag);
		out.writeUTF(this.xaBaNotDoneReason);
		out.writeUTF(this.xaBaVoipBbNotDoneReason);
		out.writeUTF(this.xaBaVoipNotDoneReason);
		out.writeUTF(this.xaBoxSecDestination);
		out.writeUTF(this.xaCaddress2);
		out.writeUTF(this.xaCancelReason);
		out.writeUTF(this.xaCardType);
		out.writeUTF(this.xaCaseId);
		out.writeUTF(this.xaCaseReason1);
		out.writeUTF(this.xaCaseReason2);
		out.writeUTF(this.xaCaseReason3);
		out.writeUTF(this.xaCbaNotDoneReason);
		out.writeUTF(this.xaCdoe);
		out.writeUTF(this.xaCdoeAddress);
		out.writeUTF(this.xaCdoePowerRef);
		out.writeUTF(this.xaCdoiPowerRef);
		out.writeUTF(this.xaChangeTech);
		out.writeUTF(this.xaClassification);
		out.writeUTF(this.xaCompletionCode);
		out.writeUTF(this.xaCorpAcl);
		out.writeUTF(this.xaCorpAtivitDate);
		out.writeUTF(this.xaCorpBuildDate);
		out.writeUTF(this.xaCorpCancelReason);
		out.writeUTF(this.xaCorpChecklist);
		out.writeUTF(this.xaCorpCompletionCode);
		out.writeUTF(this.xaCorpCountry);
		out.writeUTF(this.xaCorpCustomerContactAttempts);
		out.writeUTF(this.xaCorpCustomerPort);
		out.writeUTF(this.xaCorpCvlan);
		out.writeUTF(this.xaCorpDeliveryDeadline);
		out.writeUTF(this.xaCorpDownUpInd);
		out.writeUTF(this.xaCorpEquipModel);
		out.writeUTF(this.xaCorpFiberActivationDate);
		out.writeUTF(this.xaCorpFiberApproachDate);
		out.writeUTF(this.xaCorpFiberFusionDate);
		out.writeUTF(this.xaCorpFiberInstallDate);
		out.writeUTF(this.xaCorpGl);
		out.writeUTF(this.xaCorpMaksen1);
		out.writeUTF(this.xaCorpMaksen2);
		out.writeUTF(this.xaCorpMsanBras);
		out.writeUTF(this.xaCorpMsanCircuit);
		out.writeUTF(this.xaCorpMsanModel);
		out.writeUTF(this.xaCorpMsanSpazio);
		out.writeUTF(this.xaCorpMsanSwitch);
		out.writeUTF(this.xaCorpNotDoneReason);
		out.writeUTF(this.xaCorpPopA);
		out.writeUTF(this.xaCorpProjId);
		out.writeUTF(this.xaCorpProjectManager);
		out.writeUTF(this.xaCorpProjectManagerEmail);
		out.writeUTF(this.xaCorpProjectManagerPhone);
		out.writeUTF(this.xaCorpProvider);
		out.writeUTF(this.xaCorpSalesContact);
		out.writeUTF(this.xaCorpSalesContactPhone);
		out.writeUTF(this.xaCorpScheduledDate);
		out.writeUTF(this.xaCorpSerialNr);
		out.writeUTF(this.xaCorpSvlan);
		out.writeUTF(this.xaCorpTechContact);
		out.writeUTF(this.xaCorpTechContactPhone);
		out.writeUTF(this.xaCorpWoPivNr);
		out.writeUTF(this.xaCpeModel);
		out.writeUTF(this.xaCpeVendor);
		out.writeUTF(this.xaCrcDescription);
		out.writeUTF(this.xaCustomerContact);
		out.writeUTF(this.xaCustomerContactTwo);
		out.writeUTF(this.xaCustomerType);
		out.writeUTF(this.xaDistanceTerminalToAddress);
		out.writeUTF(this.xaEquipIdentification);
		out.writeUTF(this.xaExtWifi1);
		out.writeUTF(this.xaExtWifi2);
		out.writeUTF(this.xaExtWifi3);
		out.writeUTF(this.xaExtenderSerialNumber);
		out.writeUTF(this.xaExtenderWifi);
		out.writeUTF(this.xaFirstRoutingTime);
		out.writeUTF(this.xaGponOltRx);
		out.writeUTF(this.xaGponOntRx);
		out.writeUTF(this.xaGpsValidation);
		out.writeUTF(this.xaIdLote);
		out.writeUTF(this.xaIpWan);
		out.writeUTF(this.xaKeepFacilities);
		out.writeUTF(this.xaKeepMsan);
		out.writeUTF(this.xaLetterResponsableId);
		out.writeUTF(this.xaMeasureKl0);
		out.writeUTF(this.xaMeasureTrainDb);
		out.writeUTF(this.xaMeasureTrainRate);
		out.writeUTF(this.xaModemReused);
		out.writeUTF(this.xaModemSerialNumber);
		out.writeUTF(this.xaModemSerieNumber);
		out.writeUTF(this.xaMsanDestination);
		out.writeUTF(this.xaMsanDistance);
		out.writeUTF(this.xaNotDoneReason);
		out.writeUTF(this.xaNotDoneReasonCus);
		out.writeUTF(this.xaNttCaixaEmenda1);
		out.writeUTF(this.xaNttCaixaEmenda2);
		out.writeUTF(this.xaNttCustomerAddress);
		out.writeUTF(this.xaNttCustomerAddress2);
		out.writeUTF(this.xaNttDateNocCommunication);
		out.writeUTF(this.xaNttEquipmentId);
		out.writeUTF(this.xaNttEquipmentIdB);
		out.writeUTF(this.xaNttEquipmentSite);
		out.writeUTF(this.xaNttEquipmentSiteB);
		out.writeUTF(this.xaNttEquipmentType);
		out.writeUTF(this.xaNttFocableProblemSource);
		out.writeUTF(this.xaNttInterventionType);
		out.writeUTF(this.xaNttJobType);
		out.writeUTF(this.xaNttNotDoneReason);
		out.writeUTF(this.xaNttNotDoneReasonEquip);
		out.writeUTF(this.xaNttNotDoneReasonFocable);
		out.writeUTF(this.xaNttOsOpenDate);
		out.writeUTF(this.xaNttRingCable);
		out.writeUTF(this.xaNttSubcontractor);
		out.writeUTF(this.xaNttSuspReasonEquip);
		out.writeUTF(this.xaNttSuspReasonFocable);
		out.writeUTF(this.xaOcComments);
		out.writeUTF(this.xaOldCpeModel);
		out.writeUTF(this.xaOltPort);
		out.writeUTF(this.xaOntId);
		out.writeUTF(this.xaOntModel);
		out.writeUTF(this.xaOntOltMessage);
		out.writeUTF(this.xaOntSerialNumber);
		out.writeUTF(this.xaPairManeuverDestination);
		out.writeUTF(this.xaParentFaultId);
		out.writeUTF(this.xaPhone3);
		out.writeUTF(this.xaPhoneNumberTwo);
		out.writeUTF(this.xaPiAccessRestritions);
		out.writeUTF(this.xaPiActivateGmg);
		out.writeUTF(this.xaPiAffectedTrail);
		out.writeUTF(this.xaPiAlarmEndDate);
		out.writeUTF(this.xaPiAlarmManualEnd);
		out.writeUTF(this.xaPiAlarmManualInit);
		out.writeUTF(this.xaPiAlarmSugestDate);
		out.writeUTF(this.xaPiAlarmType);
		out.writeUTF(this.xaPiAmfAccompName);
		out.writeUTF(this.xaPiAmfAddress);
		out.writeUTF(this.xaPiAmfAvailability);
		out.writeUTF(this.xaPiAmfCustomerInCall);
		out.writeUTF(this.xaPiAmfDatetime);
		out.writeUTF(this.xaPiAmfDesignation);
		out.writeUTF(this.xaPiAmfEmail);
		out.writeUTF(this.xaPiAmfFailLocation);
		out.writeUTF(this.xaPiAmfOperator);
		out.writeUTF(this.xaPiAmfScheduleDate);
		out.writeUTF(this.xaPiAmfSite);
		out.writeUTF(this.xaPiAmfTel);
		out.writeUTF(this.xaPiAmfTimInCall);
		out.writeUTF(this.xaPiAmfVisitReason);
		out.writeUTF(this.xaPiArea);
		out.writeUTF(this.xaPiAssociatedNtts);
		out.writeUTF(this.xaPiAttendanceSeg);
		out.writeUTF(this.xaPiBo);
		out.writeUTF(this.xaPiBoDate);
		out.writeUTF(this.xaPiBoNotInformedReason);
		out.writeUTF(this.xaPiBoNumber);
		out.writeUTF(this.xaPiBreaking);
		out.writeUTF(this.xaPiBscRnc);
		out.writeUTF(this.xaPiCfPositionFiber);
		out.writeUTF(this.xaPiCfReceptionLevel);
		out.writeUTF(this.xaPiCircuitInfo);
		out.writeUTF(this.xaPiClaimant);
		out.writeUTF(this.xaPiCloseNote);
		out.writeUTF(this.xaPiCm);
		out.writeUTF(this.xaPiColabName);
		out.writeUTF(this.xaPiCompany);
		out.writeUTF(this.xaPiCompanyCosite);
		out.writeUTF(this.xaPiContract);
		out.writeUTF(this.xaPiCreateDate);
		out.writeUTF(this.xaPiCriticalElement);
		out.writeUTF(this.xaPiCsfNameTelTechAutorization);
		out.writeUTF(this.xaPiCsfSolution);
		out.writeUTF(this.xaPiCustomerFinalName);
		out.writeUTF(this.xaPiCustomerName);
		out.writeUTF(this.xaPiDefectResponsible);
		out.writeUTF(this.xaPiDelayReason);
		out.writeUTF(this.xaPiDependentsPerTx);
		out.writeUTF(this.xaPiDistance);
		out.writeUTF(this.xaPiEndId);
		out.writeUTF(this.xaPiEnergyCode);
		out.writeUTF(this.xaPiEnergyProtocol);
		out.writeUTF(this.xaPiEquipAlarm);
		out.writeUTF(this.xaPiFailCause);
		out.writeUTF(this.xaPiFailDescription);
		out.writeUTF(this.xaPiFailSolution);
		out.writeUTF(this.xaPiFailType);
		out.writeUTF(this.xaPiFcfArea);
		out.writeUTF(this.xaPiFcfMaterial);
		out.writeUTF(this.xaPiFcfOpenStretch);
		out.writeUTF(this.xaPiFcfQttBox);
		out.writeUTF(this.xaPiFcfRing);
		out.writeUTF(this.xaPiGmgDesc);
		out.writeUTF(this.xaPiGmgDistance);
		out.writeUTF(this.xaPiGmgEnd);
		out.writeUTF(this.xaPiGmgOwner);
		out.writeUTF(this.xaPiGmgPower);
		out.writeUTF(this.xaPiGmgStart);
		out.writeUTF(this.xaPiGmgStatus);
		out.writeUTF(this.xaPiHoliday);
		out.writeUTF(this.xaPiIdTicketCa);
		out.writeUTF(this.xaPiImpact);
		out.writeUTF(this.xaPiIndustrialBuildings);
		out.writeUTF(this.xaPiInfraAlarm);
		out.writeUTF(this.xaPiInterruptionService);
		out.writeUTF(this.xaPiInvChanged);
		out.writeUTF(this.xaPiIsocColabName);
		out.writeUTF(this.xaPiLlCircuit);
		out.writeUTF(this.xaPiLlEndDate);
		out.writeUTF(this.xaPiLlFailCause);
		out.writeUTF(this.xaPiLlHasenergy);
		out.writeUTF(this.xaPiLlHastest);
		out.writeUTF(this.xaPiLlInitDate);
		out.writeUTF(this.xaPiLlProviderName);
		out.writeUTF(this.xaPiMsc);
		out.writeUTF(this.xaPiMscBsc);
		out.writeUTF(this.xaPiMsgTicketCa);
		out.writeUTF(this.xaPiNeImpact);
		out.writeUTF(this.xaPiNeInfo);
		out.writeUTF(this.xaPiNeName);
		out.writeUTF(this.xaPiNeObs);
		out.writeUTF(this.xaPiNeType);
		out.writeUTF(this.xaPiNeighborhood);
		out.writeUTF(this.xaPiNetwork);
		out.writeUTF(this.xaPiNetworkElement);
		out.writeUTF(this.xaPiNttStatus);
		out.writeUTF(this.xaPiNttUserRule);
		out.writeUTF(this.xaPiObs);
		out.writeUTF(this.xaPiOp);
		out.writeUTF(this.xaPiOpeningNote);
		out.writeUTF(this.xaPiOrigin);
		out.writeUTF(this.xaPiPartnerCompany);
		out.writeUTF(this.xaPiPortalSolution);
		out.writeUTF(this.xaPiPowerDistCompany);
		out.writeUTF(this.xaPiPqClassification);
		out.writeUTF(this.xaPiPriority);
		out.writeUTF(this.xaPiRejectionNote);
		out.writeUTF(this.xaPiRelatedTickets);
		out.writeUTF(this.xaPiRelatedTrail);
		out.writeUTF(this.xaPiResponsable);
		out.writeUTF(this.xaPiRestartDate);
		out.writeUTF(this.xaPiSecTicket);
		out.writeUTF(this.xaPiSecurityCompany);
		out.writeUTF(this.xaPiSendGmg);
		out.writeUTF(this.xaPiSiteAutonomy);
		out.writeUTF(this.xaPiSiteImpact);
		out.writeUTF(this.xaPiSiteOwner);
		out.writeUTF(this.xaPiSolutionDescription);
		out.writeUTF(this.xaPiSpare);
		out.writeUTF(this.xaPiStEndDate);
		out.writeUTF(this.xaPiStInitDate);
		out.writeUTF(this.xaPiStartAlarmDatetime);
		out.writeUTF(this.xaPiSubArea);
		out.writeUTF(this.xaPiSuspendNote);
		out.writeUTF(this.xaPiSuspendReason);
		out.writeUTF(this.xaPiTdmaCosite);
		out.writeUTF(this.xaPiTestsDone);
		out.writeUTF(this.xaPiTheft);
		out.writeUTF(this.xaPiTicketTitl);
		out.writeUTF(this.xaPiToBeExecuted);
		out.writeUTF(this.xaPiTotalDependents);
		out.writeUTF(this.xaPiTramReason);
		out.writeUTF(this.xaPiTravelType);
		out.writeUTF(this.xaPiUmtsCosite);
		out.writeUTF(this.xaPiUser);
		out.writeUTF(this.xaPiVandalism);
		out.writeUTF(this.xaPiWorkDiary);
		out.writeUTF(this.xaPortManeuverDestination);
		out.writeUTF(this.xaPort1TnTemporary);
		out.writeUTF(this.xaPort1VoipProductName);
		out.writeUTF(this.xaPort1VoipServiceId);
		out.writeUTF(this.xaPort1VoipTn);
		out.writeUTF(this.xaPort2TnTemporary);
		out.writeUTF(this.xaPort2VoipProductName);
		out.writeUTF(this.xaPort2VoipServiceId);
		out.writeUTF(this.xaPort2VoipTn);
		out.writeUTF(this.xaPowerMeasuredCdoe);
		out.writeUTF(this.xaPowerMeasuredCdoi);
		out.writeUTF(this.xaPowerMeasuredOnt);
		out.writeUTF(this.xaPrimOpticalCable);
		out.writeUTF(this.xaPrimaryNetworkCable);
		out.writeUTF(this.xaPrimaryNetworkMsan);
		out.writeUTF(this.xaPrimaryNetworkMsanAddress);
		out.writeUTF(this.xaPrimaryNetworkPort);
		out.writeUTF(this.xaProductId);
		out.writeUTF(this.xaProductName);
		out.writeUTF(this.xaProductSpeed);
		out.writeUTF(this.xaReturnedModemSerial);
		out.writeUTF(this.xaRoutingFlag);
		out.writeUTF(this.xaRoutingFlagTime);
		out.writeUTF(this.xaSecOpticalCable);
		out.writeUTF(this.xaSecondaryNetworkBox);
		out.writeUTF(this.xaSecondaryNetworkBoxAddress);
		out.writeUTF(this.xaSecondaryNetworkBoxPort);
		out.writeUTF(this.xaSecondaryNetworkBoxPowerLevel);
		out.writeUTF(this.xaSecondaryNetworkBoxTrf);
		out.writeUTF(this.xaSecondaryNetworkBoxType);
		out.writeUTF(this.xaSecondaryNetworkCabinet);
		out.writeUTF(this.xaSecondaryNetworkCabinetAdd);
		out.writeUTF(this.xaSecondaryNetworkCabinetTrf);
		out.writeUTF(this.xaSecondaryNetworkCabinetTyp);
		out.writeUTF(this.xaSecondaryNetworkCable);
		out.writeUTF(this.xaSecondaryNetworkInternalBox);
		out.writeUTF(this.xaSecondaryNetworkInternalBoxPlace);
		out.writeUTF(this.xaSecondaryNetworkInternalBoxPort);
		out.writeUTF(this.xaSecondaryNetworkInternalBoxPwLev);
		out.writeUTF(this.xaSecondaryNetworkOntPowerLevel);
		out.writeUTF(this.xaSecondaryNetworkPort);
		out.writeUTF(this.xaSerialExtWifi1);
		out.writeUTF(this.xaSerialExtWifi2);
		out.writeUTF(this.xaSerialExtWifi3);
		out.writeUTF(this.xaServiceId);
		out.writeUTF(this.xaSignalService);
		out.writeUTF(this.xaSuspendComment);
		out.writeUTF(this.xaSuspendReason);
		out.writeUTF(this.xaSyndicateContact);
		out.writeUTF(this.xaSyndicateContactTwo);
		out.writeUTF(this.xaSyndicateName);
		out.writeUTF(this.xaTemperature);
		out.writeUTF(this.xaTtCauseCode);
		out.writeUTF(this.xaTtNotDoneReason);
		out.writeUTF(this.xaTtVoipNotDoneReason);
		out.writeUTF(this.xaTypeOrder);
		out.writeUTF(this.xaUploadDateLetter);
		out.writeUTF(this.xaVlan2Ip);
		out.writeUTF(this.xaVoipProductId);
		out.writeUTF(this.xaVoipValidation);
		out.writeUTF(this.rowId);
		out.writeUTF(this.loteid);
		out.writeUTF(this.arquivo);
		out.writeUTF(this.arquivots);
		out.writeUTF(this.currentdate);
	}
	
	@Override
	public void readFields(DataInput in) throws IOException {
		this.acoordStatus = in.readUTF();
		this.acoordX = in.readUTF();
		this.acoordY = in.readUTF();
		this.deliveryWindowStart = in.readUTF();
		this.endTime = in.readUTF();
		this.apptNumber = in.readUTF();
		this.serviceWindowEnd = in.readUTF();
		this.serviceWindowStart = in.readUTF();
		this.slaWindowEnd = in.readUTF();
		this.slaWindowStart = in.readUTF();
		this.ctimeDeliveredEnd = in.readUTF();
		this.ctimeDeliveredStart = in.readUTF();
		this.etaEndTime = in.readUTF();
		this.eta = in.readUTF();
		this.astatus = in.readUTF();
		this.atimeOfAssignment = in.readUTF();
		this.atimeOfBooking = in.readUTF();
		this.aTsid = in.readUTF();
		this.atype = in.readUTF();
		this.activityWorkskills = in.readUTF();
		this.aworktype = in.readUTF();
		this.aworkzone = in.readUTF();
		this.queueDate = in.readUTF();
		this.timeZoneName = in.readUTF();
		this.timeZone = in.readUTF();
		this.aid = in.readUTF();
		this.caddress = in.readUTF();
		this.xaCaddress = in.readUTF();
		this.ccell = in.readUTF();
		this.cphone = in.readUTF();
		this.cname = in.readUTF();
		this.cstate = in.readUTF();
		this.customerNumber = in.readUTF();
		this.czip = in.readUTF();
		this.externalId = in.readUTF();
		this.firstManualOperation = in.readUTF();
		this.parent = in.readUTF();
		this.pname = in.readUTF();
		this.positionInRoute = in.readUTF();
		this.aTimeOfBooking = in.readUTF();
		this.xaAcAbrDownSt = in.readUTF();
		this.xaAcAbrDownVal = in.readUTF();
		this.xaAcAbrUpSt = in.readUTF();
		this.xaAcAbrUpVal = in.readUTF();
		this.xaAcBitrtSt = in.readUTF();
		this.xaAcBitrtVal = in.readUTF();
		this.xaAcCpeCard = in.readUTF();
		this.xaAcFlP1Voip = in.readUTF();
		this.xaAcFlP2Voip = in.readUTF();
		this.xaAcKl0 = in.readUTF();
		this.xaAcMsg = in.readUTF();
		this.xaAcType = in.readUTF();
		this.xaAccServiceId = in.readUTF();
		this.xaAccessTechnology = in.readUTF();
		this.xaAcertAaaNrmSt = in.readUTF();
		this.xaAcertAtnSt = in.readUTF();
		this.xaAcertAtnVal = in.readUTF();
		this.xaAcertBrasAuthSt = in.readUTF();
		this.xaAcertDslParamsSt = in.readUTF();
		this.xaAcertDslProfile = in.readUTF();
		this.xaAcertemprIp = in.readUTF();
		this.xaAcertFlag = in.readUTF();
		this.xaAcertPortSyncSt = in.readUTF();
		this.xaAcertSnrSt = in.readUTF();
		this.xaAcertSnrVal = in.readUTF();
		this.xaAcgGponParams = in.readUTF();
		this.xaAcgOltRxst = in.readUTF();
		this.xaAcgOltRxval = in.readUTF();
		this.xaAcgOnt = in.readUTF();
		this.xaAcgOntLinkst = in.readUTF();
		this.xaAcgOntLinkval = in.readUTF();
		this.xaAcgOntRxst = in.readUTF();
		this.xaAcgOntRxval = in.readUTF();
		this.xaAcgProfile = in.readUTF();
		this.xaActivityComment = in.readUTF();
		this.xaActivityOrigin = in.readUTF();
		this.xaAcvP1InConf = in.readUTF();
		this.xaAcvP1Msg = in.readUTF();
		this.xaAcvP1SswConf = in.readUTF();
		this.xaAcvP1SswReg = in.readUTF();
		this.xaAcvP2InConf = in.readUTF();
		this.xaAcvP2Msg = in.readUTF();
		this.xaAcvP2SswConf = in.readUTF();
		this.xaAcvP2SswReg = in.readUTF();
		this.xaAddrRef = in.readUTF();
		this.xaAddressChangeFlag = in.readUTF();
		this.xaBaNotDoneReason = in.readUTF();
		this.xaBaVoipBbNotDoneReason = in.readUTF();
		this.xaBaVoipNotDoneReason = in.readUTF();
		this.xaBoxSecDestination = in.readUTF();
		this.xaCaddress2 = in.readUTF();
		this.xaCancelReason = in.readUTF();
		this.xaCardType = in.readUTF();
		this.xaCaseId = in.readUTF();
		this.xaCaseReason1 = in.readUTF();
		this.xaCaseReason2 = in.readUTF();
		this.xaCaseReason3 = in.readUTF();
		this.xaCbaNotDoneReason = in.readUTF();
		this.xaCdoe = in.readUTF();
		this.xaCdoeAddress = in.readUTF();
		this.xaCdoePowerRef = in.readUTF();
		this.xaCdoiPowerRef = in.readUTF();
		this.xaChangeTech = in.readUTF();
		this.xaClassification = in.readUTF();
		this.xaCompletionCode = in.readUTF();
		this.xaCorpAcl = in.readUTF();
		this.xaCorpAtivitDate = in.readUTF();
		this.xaCorpBuildDate = in.readUTF();
		this.xaCorpCancelReason = in.readUTF();
		this.xaCorpChecklist = in.readUTF();
		this.xaCorpCompletionCode = in.readUTF();
		this.xaCorpCountry = in.readUTF();
		this.xaCorpCustomerContactAttempts = in.readUTF();
		this.xaCorpCustomerPort = in.readUTF();
		this.xaCorpCvlan = in.readUTF();
		this.xaCorpDeliveryDeadline = in.readUTF();
		this.xaCorpDownUpInd = in.readUTF();
		this.xaCorpEquipModel = in.readUTF();
		this.xaCorpFiberActivationDate = in.readUTF();
		this.xaCorpFiberApproachDate = in.readUTF();
		this.xaCorpFiberFusionDate = in.readUTF();
		this.xaCorpFiberInstallDate = in.readUTF();
		this.xaCorpGl = in.readUTF();
		this.xaCorpMaksen1 = in.readUTF();
		this.xaCorpMaksen2 = in.readUTF();
		this.xaCorpMsanBras = in.readUTF();
		this.xaCorpMsanCircuit = in.readUTF();
		this.xaCorpMsanModel = in.readUTF();
		this.xaCorpMsanSpazio = in.readUTF();
		this.xaCorpMsanSwitch = in.readUTF();
		this.xaCorpNotDoneReason = in.readUTF();
		this.xaCorpPopA = in.readUTF();
		this.xaCorpProjId = in.readUTF();
		this.xaCorpProjectManager = in.readUTF();
		this.xaCorpProjectManagerEmail = in.readUTF();
		this.xaCorpProjectManagerPhone = in.readUTF();
		this.xaCorpProvider = in.readUTF();
		this.xaCorpSalesContact = in.readUTF();
		this.xaCorpSalesContactPhone = in.readUTF();
		this.xaCorpScheduledDate = in.readUTF();
		this.xaCorpSerialNr = in.readUTF();
		this.xaCorpSvlan = in.readUTF();
		this.xaCorpTechContact = in.readUTF();
		this.xaCorpTechContactPhone = in.readUTF();
		this.xaCorpWoPivNr = in.readUTF();
		this.xaCpeModel = in.readUTF();
		this.xaCpeVendor = in.readUTF();
		this.xaCrcDescription = in.readUTF();
		this.xaCustomerContact = in.readUTF();
		this.xaCustomerContactTwo = in.readUTF();
		this.xaCustomerType = in.readUTF();
		this.xaDistanceTerminalToAddress = in.readUTF();
		this.xaEquipIdentification = in.readUTF();
		this.xaExtWifi1 = in.readUTF();
		this.xaExtWifi2 = in.readUTF();
		this.xaExtWifi3 = in.readUTF();
		this.xaExtenderSerialNumber = in.readUTF();
		this.xaExtenderWifi = in.readUTF();
		this.xaFirstRoutingTime = in.readUTF();
		this.xaGponOltRx = in.readUTF();
		this.xaGponOntRx = in.readUTF();
		this.xaGpsValidation = in.readUTF();
		this.xaIdLote = in.readUTF();
		this.xaIpWan = in.readUTF();
		this.xaKeepFacilities = in.readUTF();
		this.xaKeepMsan = in.readUTF();
		this.xaLetterResponsableId = in.readUTF();
		this.xaMeasureKl0 = in.readUTF();
		this.xaMeasureTrainDb = in.readUTF();
		this.xaMeasureTrainRate = in.readUTF();
		this.xaModemReused = in.readUTF();
		this.xaModemSerialNumber = in.readUTF();
		this.xaModemSerieNumber = in.readUTF();
		this.xaMsanDestination = in.readUTF();
		this.xaMsanDistance = in.readUTF();
		this.xaNotDoneReason = in.readUTF();
		this.xaNotDoneReasonCus = in.readUTF();
		this.xaNttCaixaEmenda1 = in.readUTF();
		this.xaNttCaixaEmenda2 = in.readUTF();
		this.xaNttCustomerAddress = in.readUTF();
		this.xaNttCustomerAddress2 = in.readUTF();
		this.xaNttDateNocCommunication = in.readUTF();
		this.xaNttEquipmentId = in.readUTF();
		this.xaNttEquipmentIdB = in.readUTF();
		this.xaNttEquipmentSite = in.readUTF();
		this.xaNttEquipmentSiteB = in.readUTF();
		this.xaNttEquipmentType = in.readUTF();
		this.xaNttFocableProblemSource = in.readUTF();
		this.xaNttInterventionType = in.readUTF();
		this.xaNttJobType = in.readUTF();
		this.xaNttNotDoneReason = in.readUTF();
		this.xaNttNotDoneReasonEquip = in.readUTF();
		this.xaNttNotDoneReasonFocable = in.readUTF();
		this.xaNttOsOpenDate = in.readUTF();
		this.xaNttRingCable = in.readUTF();
		this.xaNttSubcontractor = in.readUTF();
		this.xaNttSuspReasonEquip = in.readUTF();
		this.xaNttSuspReasonFocable = in.readUTF();
		this.xaOcComments = in.readUTF();
		this.xaOldCpeModel = in.readUTF();
		this.xaOltPort = in.readUTF();
		this.xaOntId = in.readUTF();
		this.xaOntModel = in.readUTF();
		this.xaOntOltMessage = in.readUTF();
		this.xaOntSerialNumber = in.readUTF();
		this.xaPairManeuverDestination = in.readUTF();
		this.xaParentFaultId = in.readUTF();
		this.xaPhone3 = in.readUTF();
		this.xaPhoneNumberTwo = in.readUTF();
		this.xaPiAccessRestritions = in.readUTF();
		this.xaPiActivateGmg = in.readUTF();
		this.xaPiAffectedTrail = in.readUTF();
		this.xaPiAlarmEndDate = in.readUTF();
		this.xaPiAlarmManualEnd = in.readUTF();
		this.xaPiAlarmManualInit = in.readUTF();
		this.xaPiAlarmSugestDate = in.readUTF();
		this.xaPiAlarmType = in.readUTF();
		this.xaPiAmfAccompName = in.readUTF();
		this.xaPiAmfAddress = in.readUTF();
		this.xaPiAmfAvailability = in.readUTF();
		this.xaPiAmfCustomerInCall = in.readUTF();
		this.xaPiAmfDatetime = in.readUTF();
		this.xaPiAmfDesignation = in.readUTF();
		this.xaPiAmfEmail = in.readUTF();
		this.xaPiAmfFailLocation = in.readUTF();
		this.xaPiAmfOperator = in.readUTF();
		this.xaPiAmfScheduleDate = in.readUTF();
		this.xaPiAmfSite = in.readUTF();
		this.xaPiAmfTel = in.readUTF();
		this.xaPiAmfTimInCall = in.readUTF();
		this.xaPiAmfVisitReason = in.readUTF();
		this.xaPiArea = in.readUTF();
		this.xaPiAssociatedNtts = in.readUTF();
		this.xaPiAttendanceSeg = in.readUTF();
		this.xaPiBo = in.readUTF();
		this.xaPiBoDate = in.readUTF();
		this.xaPiBoNotInformedReason = in.readUTF();
		this.xaPiBoNumber = in.readUTF();
		this.xaPiBreaking = in.readUTF();
		this.xaPiBscRnc = in.readUTF();
		this.xaPiCfPositionFiber = in.readUTF();
		this.xaPiCfReceptionLevel = in.readUTF();
		this.xaPiCircuitInfo = in.readUTF();
		this.xaPiClaimant = in.readUTF();
		this.xaPiCloseNote = in.readUTF();
		this.xaPiCm = in.readUTF();
		this.xaPiColabName = in.readUTF();
		this.xaPiCompany = in.readUTF();
		this.xaPiCompanyCosite = in.readUTF();
		this.xaPiContract = in.readUTF();
		this.xaPiCreateDate = in.readUTF();
		this.xaPiCriticalElement = in.readUTF();
		this.xaPiCsfNameTelTechAutorization = in.readUTF();
		this.xaPiCsfSolution = in.readUTF();
		this.xaPiCustomerFinalName = in.readUTF();
		this.xaPiCustomerName = in.readUTF();
		this.xaPiDefectResponsible = in.readUTF();
		this.xaPiDelayReason = in.readUTF();
		this.xaPiDependentsPerTx = in.readUTF();
		this.xaPiDistance = in.readUTF();
		this.xaPiEndId = in.readUTF();
		this.xaPiEnergyCode = in.readUTF();
		this.xaPiEnergyProtocol = in.readUTF();
		this.xaPiEquipAlarm = in.readUTF();
		this.xaPiFailCause = in.readUTF();
		this.xaPiFailDescription = in.readUTF();
		this.xaPiFailSolution = in.readUTF();
		this.xaPiFailType = in.readUTF();
		this.xaPiFcfArea = in.readUTF();
		this.xaPiFcfMaterial = in.readUTF();
		this.xaPiFcfOpenStretch = in.readUTF();
		this.xaPiFcfQttBox = in.readUTF();
		this.xaPiFcfRing = in.readUTF();
		this.xaPiGmgDesc = in.readUTF();
		this.xaPiGmgDistance = in.readUTF();
		this.xaPiGmgEnd = in.readUTF();
		this.xaPiGmgOwner = in.readUTF();
		this.xaPiGmgPower = in.readUTF();
		this.xaPiGmgStart = in.readUTF();
		this.xaPiGmgStatus = in.readUTF();
		this.xaPiHoliday = in.readUTF();
		this.xaPiIdTicketCa = in.readUTF();
		this.xaPiImpact = in.readUTF();
		this.xaPiIndustrialBuildings = in.readUTF();
		this.xaPiInfraAlarm = in.readUTF();
		this.xaPiInterruptionService = in.readUTF();
		this.xaPiInvChanged = in.readUTF();
		this.xaPiIsocColabName = in.readUTF();
		this.xaPiLlCircuit = in.readUTF();
		this.xaPiLlEndDate = in.readUTF();
		this.xaPiLlFailCause = in.readUTF();
		this.xaPiLlHasenergy = in.readUTF();
		this.xaPiLlHastest = in.readUTF();
		this.xaPiLlInitDate = in.readUTF();
		this.xaPiLlProviderName = in.readUTF();
		this.xaPiMsc = in.readUTF();
		this.xaPiMscBsc = in.readUTF();
		this.xaPiMsgTicketCa = in.readUTF();
		this.xaPiNeImpact = in.readUTF();
		this.xaPiNeInfo = in.readUTF();
		this.xaPiNeName = in.readUTF();
		this.xaPiNeObs = in.readUTF();
		this.xaPiNeType = in.readUTF();
		this.xaPiNeighborhood = in.readUTF();
		this.xaPiNetwork = in.readUTF();
		this.xaPiNetworkElement = in.readUTF();
		this.xaPiNttStatus = in.readUTF();
		this.xaPiNttUserRule = in.readUTF();
		this.xaPiObs = in.readUTF();
		this.xaPiOp = in.readUTF();
		this.xaPiOpeningNote = in.readUTF();
		this.xaPiOrigin = in.readUTF();
		this.xaPiPartnerCompany = in.readUTF();
		this.xaPiPortalSolution = in.readUTF();
		this.xaPiPowerDistCompany = in.readUTF();
		this.xaPiPqClassification = in.readUTF();
		this.xaPiPriority = in.readUTF();
		this.xaPiRejectionNote = in.readUTF();
		this.xaPiRelatedTickets = in.readUTF();
		this.xaPiRelatedTrail = in.readUTF();
		this.xaPiResponsable = in.readUTF();
		this.xaPiRestartDate = in.readUTF();
		this.xaPiSecTicket = in.readUTF();
		this.xaPiSecurityCompany = in.readUTF();
		this.xaPiSendGmg = in.readUTF();
		this.xaPiSiteAutonomy = in.readUTF();
		this.xaPiSiteImpact = in.readUTF();
		this.xaPiSiteOwner = in.readUTF();
		this.xaPiSolutionDescription = in.readUTF();
		this.xaPiSpare = in.readUTF();
		this.xaPiStEndDate = in.readUTF();
		this.xaPiStInitDate = in.readUTF();
		this.xaPiStartAlarmDatetime = in.readUTF();
		this.xaPiSubArea = in.readUTF();
		this.xaPiSuspendNote = in.readUTF();
		this.xaPiSuspendReason = in.readUTF();
		this.xaPiTdmaCosite = in.readUTF();
		this.xaPiTestsDone = in.readUTF();
		this.xaPiTheft = in.readUTF();
		this.xaPiTicketTitl = in.readUTF();
		this.xaPiToBeExecuted = in.readUTF();
		this.xaPiTotalDependents = in.readUTF();
		this.xaPiTramReason = in.readUTF();
		this.xaPiTravelType = in.readUTF();
		this.xaPiUmtsCosite = in.readUTF();
		this.xaPiUser = in.readUTF();
		this.xaPiVandalism = in.readUTF();
		this.xaPiWorkDiary = in.readUTF();
		this.xaPortManeuverDestination = in.readUTF();
		this.xaPort1TnTemporary = in.readUTF();
		this.xaPort1VoipProductName = in.readUTF();
		this.xaPort1VoipServiceId = in.readUTF();
		this.xaPort1VoipTn = in.readUTF();
		this.xaPort2TnTemporary = in.readUTF();
		this.xaPort2VoipProductName = in.readUTF();
		this.xaPort2VoipServiceId = in.readUTF();
		this.xaPort2VoipTn = in.readUTF();
		this.xaPowerMeasuredCdoe = in.readUTF();
		this.xaPowerMeasuredCdoi = in.readUTF();
		this.xaPowerMeasuredOnt = in.readUTF();
		this.xaPrimOpticalCable = in.readUTF();
		this.xaPrimaryNetworkCable = in.readUTF();
		this.xaPrimaryNetworkMsan = in.readUTF();
		this.xaPrimaryNetworkMsanAddress = in.readUTF();
		this.xaPrimaryNetworkPort = in.readUTF();
		this.xaProductId = in.readUTF();
		this.xaProductName = in.readUTF();
		this.xaProductSpeed = in.readUTF();
		this.xaReturnedModemSerial = in.readUTF();
		this.xaRoutingFlag = in.readUTF();
		this.xaRoutingFlagTime = in.readUTF();
		this.xaSecOpticalCable = in.readUTF();
		this.xaSecondaryNetworkBox = in.readUTF();
		this.xaSecondaryNetworkBoxAddress = in.readUTF();
		this.xaSecondaryNetworkBoxPort = in.readUTF();
		this.xaSecondaryNetworkBoxPowerLevel = in.readUTF();
		this.xaSecondaryNetworkBoxTrf = in.readUTF();
		this.xaSecondaryNetworkBoxType = in.readUTF();
		this.xaSecondaryNetworkCabinet = in.readUTF();
		this.xaSecondaryNetworkCabinetAdd = in.readUTF();
		this.xaSecondaryNetworkCabinetTrf = in.readUTF();
		this.xaSecondaryNetworkCabinetTyp = in.readUTF();
		this.xaSecondaryNetworkCable = in.readUTF();
		this.xaSecondaryNetworkInternalBox = in.readUTF();
		this.xaSecondaryNetworkInternalBoxPlace = in.readUTF();
		this.xaSecondaryNetworkInternalBoxPort = in.readUTF();
		this.xaSecondaryNetworkInternalBoxPwLev = in.readUTF();
		this.xaSecondaryNetworkOntPowerLevel = in.readUTF();
		this.xaSecondaryNetworkPort = in.readUTF();
		this.xaSerialExtWifi1 = in.readUTF();
		this.xaSerialExtWifi2 = in.readUTF();
		this.xaSerialExtWifi3 = in.readUTF();
		this.xaServiceId = in.readUTF();
		this.xaSignalService = in.readUTF();
		this.xaSuspendComment = in.readUTF();
		this.xaSuspendReason = in.readUTF();
		this.xaSyndicateContact = in.readUTF();
		this.xaSyndicateContactTwo = in.readUTF();
		this.xaSyndicateName = in.readUTF();
		this.xaTemperature = in.readUTF();
		this.xaTtCauseCode = in.readUTF();
		this.xaTtNotDoneReason = in.readUTF();
		this.xaTtVoipNotDoneReason = in.readUTF();
		this.xaTypeOrder = in.readUTF();
		this.xaUploadDateLetter = in.readUTF();
		this.xaVlan2Ip = in.readUTF();
		this.xaVoipProductId = in.readUTF();
		this.xaVoipValidation = in.readUTF();
		this.rowId = in.readUTF();
		this.loteid = in.readUTF();
		this.arquivo = in.readUTF();
		this.arquivots = in.readUTF();
		this.currentdate = in.readUTF();
	}

	public String getAcoordStatus() {
		return acoordStatus;
	}

	public void setAcoordStatus(String acoordStatus) {
		this.acoordStatus = acoordStatus;
	}

	public String getAcoordX() {
		return acoordX;
	}

	public void setAcoordX(String acoordX) {
		this.acoordX = acoordX;
	}

	public String getAcoordY() {
		return acoordY;
	}

	public void setAcoordY(String acoordY) {
		this.acoordY = acoordY;
	}

	public String getDeliveryWindowStart() {
		return deliveryWindowStart;
	}

	public void setDeliveryWindowStart(String deliveryWindowStart) {
		this.deliveryWindowStart = deliveryWindowStart;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getApptNumber() {
		return apptNumber;
	}

	public void setApptNumber(String apptNumber) {
		this.apptNumber = apptNumber;
	}

	public String getServiceWindowEnd() {
		return serviceWindowEnd;
	}

	public void setServiceWindowEnd(String serviceWindowEnd) {
		this.serviceWindowEnd = serviceWindowEnd;
	}

	public String getServiceWindowStart() {
		return serviceWindowStart;
	}

	public void setServiceWindowStart(String serviceWindowStart) {
		this.serviceWindowStart = serviceWindowStart;
	}

	public String getSlaWindowEnd() {
		return slaWindowEnd;
	}

	public void setSlaWindowEnd(String slaWindowEnd) {
		this.slaWindowEnd = slaWindowEnd;
	}

	public String getSlaWindowStart() {
		return slaWindowStart;
	}

	public void setSlaWindowStart(String slaWindowStart) {
		this.slaWindowStart = slaWindowStart;
	}

	public String getCtimeDeliveredEnd() {
		return ctimeDeliveredEnd;
	}

	public void setCtimeDeliveredEnd(String ctimeDeliveredEnd) {
		this.ctimeDeliveredEnd = ctimeDeliveredEnd;
	}

	public String getCtimeDeliveredStart() {
		return ctimeDeliveredStart;
	}

	public void setCtimeDeliveredStart(String ctimeDeliveredStart) {
		this.ctimeDeliveredStart = ctimeDeliveredStart;
	}

	public String getEtaEndTime() {
		return etaEndTime;
	}

	public void setEtaEndTime(String etaEndTime) {
		this.etaEndTime = etaEndTime;
	}

	public String getEta() {
		return eta;
	}

	public void setEta(String eta) {
		this.eta = eta;
	}

	public String getAstatus() {
		return astatus;
	}

	public void setAstatus(String astatus) {
		this.astatus = astatus;
	}

	public String getAtimeOfAssignment() {
		return atimeOfAssignment;
	}

	public void setAtimeOfAssignment(String atimeOfAssignment) {
		this.atimeOfAssignment = atimeOfAssignment;
	}

	public String getAtimeOfBooking() {
		return atimeOfBooking;
	}

	public void setAtimeOfBooking(String atimeOfBooking) {
		this.atimeOfBooking = atimeOfBooking;
	}

	public String getaTsid() {
		return aTsid;
	}

	public void setaTsid(String aTsid) {
		this.aTsid = aTsid;
	}

	public String getAtype() {
		return atype;
	}

	public void setAtype(String atype) {
		this.atype = atype;
	}

	public String getActivityWorkskills() {
		return activityWorkskills;
	}

	public void setActivityWorkskills(String activityWorkskills) {
		this.activityWorkskills = activityWorkskills;
	}

	public String getAworktype() {
		return aworktype;
	}

	public void setAworktype(String aworktype) {
		this.aworktype = aworktype;
	}

	public String getAworkzone() {
		return aworkzone;
	}

	public void setAworkzone(String aworkzone) {
		this.aworkzone = aworkzone;
	}

	public String getQueueDate() {
		return queueDate;
	}

	public void setQueueDate(String queueDate) {
		this.queueDate = queueDate;
	}

	public String getTimeZoneName() {
		return timeZoneName;
	}

	public void setTimeZoneName(String timeZoneName) {
		this.timeZoneName = timeZoneName;
	}

	public String getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	public String getAid() {
		return aid;
	}

	public void setAid(String aid) {
		this.aid = aid;
	}

	public String getCaddress() {
		return caddress;
	}

	public void setCaddress(String caddress) {
		this.caddress = caddress;
	}

	public String getXaCaddress() {
		return xaCaddress;
	}

	public void setXaCaddress(String xaCaddress) {
		this.xaCaddress = xaCaddress;
	}

	public String getCcell() {
		return ccell;
	}

	public void setCcell(String ccell) {
		this.ccell = ccell;
	}

	public String getCphone() {
		return cphone;
	}

	public void setCphone(String cphone) {
		this.cphone = cphone;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getCstate() {
		return cstate;
	}

	public void setCstate(String cstate) {
		this.cstate = cstate;
	}

	public String getCustomerNumber() {
		return customerNumber;
	}

	public void setCustomerNumber(String customerNumber) {
		this.customerNumber = customerNumber;
	}

	public String getCzip() {
		return czip;
	}

	public void setCzip(String czip) {
		this.czip = czip;
	}

	public String getExternalId() {
		return externalId;
	}

	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}

	public String getFirstManualOperation() {
		return firstManualOperation;
	}

	public void setFirstManualOperation(String firstManualOperation) {
		this.firstManualOperation = firstManualOperation;
	}

	public String getParent() {
		return parent;
	}

	public void setParent(String parent) {
		this.parent = parent;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public String getPositionInRoute() {
		return positionInRoute;
	}

	public void setPositionInRoute(String positionInRoute) {
		this.positionInRoute = positionInRoute;
	}

	public String getaTimeOfBooking() {
		return aTimeOfBooking;
	}

	public void setaTimeOfBooking(String aTimeOfBooking) {
		this.aTimeOfBooking = aTimeOfBooking;
	}

	public String getXaAcAbrDownSt() {
		return xaAcAbrDownSt;
	}

	public void setXaAcAbrDownSt(String xaAcAbrDownSt) {
		this.xaAcAbrDownSt = xaAcAbrDownSt;
	}

	public String getXaAcAbrDownVal() {
		return xaAcAbrDownVal;
	}

	public void setXaAcAbrDownVal(String xaAcAbrDownVal) {
		this.xaAcAbrDownVal = xaAcAbrDownVal;
	}

	public String getXaAcAbrUpSt() {
		return xaAcAbrUpSt;
	}

	public void setXaAcAbrUpSt(String xaAcAbrUpSt) {
		this.xaAcAbrUpSt = xaAcAbrUpSt;
	}

	public String getXaAcAbrUpVal() {
		return xaAcAbrUpVal;
	}

	public void setXaAcAbrUpVal(String xaAcAbrUpVal) {
		this.xaAcAbrUpVal = xaAcAbrUpVal;
	}

	public String getXaAcBitrtSt() {
		return xaAcBitrtSt;
	}

	public void setXaAcBitrtSt(String xaAcBitrtSt) {
		this.xaAcBitrtSt = xaAcBitrtSt;
	}

	public String getXaAcBitrtVal() {
		return xaAcBitrtVal;
	}

	public void setXaAcBitrtVal(String xaAcBitrtVal) {
		this.xaAcBitrtVal = xaAcBitrtVal;
	}

	public String getXaAcCpeCard() {
		return xaAcCpeCard;
	}

	public void setXaAcCpeCard(String xaAcCpeCard) {
		this.xaAcCpeCard = xaAcCpeCard;
	}

	public String getXaAcFlP1Voip() {
		return xaAcFlP1Voip;
	}

	public void setXaAcFlP1Voip(String xaAcFlP1Voip) {
		this.xaAcFlP1Voip = xaAcFlP1Voip;
	}

	public String getXaAcFlP2Voip() {
		return xaAcFlP2Voip;
	}

	public void setXaAcFlP2Voip(String xaAcFlP2Voip) {
		this.xaAcFlP2Voip = xaAcFlP2Voip;
	}

	public String getXaAcKl0() {
		return xaAcKl0;
	}

	public void setXaAcKl0(String xaAcKl0) {
		this.xaAcKl0 = xaAcKl0;
	}

	public String getXaAcMsg() {
		return xaAcMsg;
	}

	public void setXaAcMsg(String xaAcMsg) {
		this.xaAcMsg = xaAcMsg;
	}

	public String getXaAcType() {
		return xaAcType;
	}

	public void setXaAcType(String xaAcType) {
		this.xaAcType = xaAcType;
	}

	public String getXaAccServiceId() {
		return xaAccServiceId;
	}

	public void setXaAccServiceId(String xaAccServiceId) {
		this.xaAccServiceId = xaAccServiceId;
	}

	public String getXaAccessTechnology() {
		return xaAccessTechnology;
	}

	public void setXaAccessTechnology(String xaAccessTechnology) {
		this.xaAccessTechnology = xaAccessTechnology;
	}

	public String getXaAcertAaaNrmSt() {
		return xaAcertAaaNrmSt;
	}

	public void setXaAcertAaaNrmSt(String xaAcertAaaNrmSt) {
		this.xaAcertAaaNrmSt = xaAcertAaaNrmSt;
	}

	public String getXaAcertAtnSt() {
		return xaAcertAtnSt;
	}

	public void setXaAcertAtnSt(String xaAcertAtnSt) {
		this.xaAcertAtnSt = xaAcertAtnSt;
	}

	public String getXaAcertAtnVal() {
		return xaAcertAtnVal;
	}

	public void setXaAcertAtnVal(String xaAcertAtnVal) {
		this.xaAcertAtnVal = xaAcertAtnVal;
	}

	public String getXaAcertBrasAuthSt() {
		return xaAcertBrasAuthSt;
	}

	public void setXaAcertBrasAuthSt(String xaAcertBrasAuthSt) {
		this.xaAcertBrasAuthSt = xaAcertBrasAuthSt;
	}

	public String getXaAcertDslParamsSt() {
		return xaAcertDslParamsSt;
	}

	public void setXaAcertDslParamsSt(String xaAcertDslParamsSt) {
		this.xaAcertDslParamsSt = xaAcertDslParamsSt;
	}

	public String getXaAcertDslProfile() {
		return xaAcertDslProfile;
	}

	public void setXaAcertDslProfile(String xaAcertDslProfile) {
		this.xaAcertDslProfile = xaAcertDslProfile;
	}

	public String getXaAcertemprIp() {
		return xaAcertemprIp;
	}

	public void setXaAcertemprIp(String xaAcertemprIp) {
		this.xaAcertemprIp = xaAcertemprIp;
	}

	public String getXaAcertFlag() {
		return xaAcertFlag;
	}

	public void setXaAcertFlag(String xaAcertFlag) {
		this.xaAcertFlag = xaAcertFlag;
	}

	public String getXaAcertPortSyncSt() {
		return xaAcertPortSyncSt;
	}

	public void setXaAcertPortSyncSt(String xaAcertPortSyncSt) {
		this.xaAcertPortSyncSt = xaAcertPortSyncSt;
	}

	public String getXaAcertSnrSt() {
		return xaAcertSnrSt;
	}

	public void setXaAcertSnrSt(String xaAcertSnrSt) {
		this.xaAcertSnrSt = xaAcertSnrSt;
	}

	public String getXaAcertSnrVal() {
		return xaAcertSnrVal;
	}

	public void setXaAcertSnrVal(String xaAcertSnrVal) {
		this.xaAcertSnrVal = xaAcertSnrVal;
	}

	public String getXaAcgGponParams() {
		return xaAcgGponParams;
	}

	public void setXaAcgGponParams(String xaAcgGponParams) {
		this.xaAcgGponParams = xaAcgGponParams;
	}

	public String getXaAcgOltRxst() {
		return xaAcgOltRxst;
	}

	public void setXaAcgOltRxst(String xaAcgOltRxst) {
		this.xaAcgOltRxst = xaAcgOltRxst;
	}

	public String getXaAcgOltRxval() {
		return xaAcgOltRxval;
	}

	public void setXaAcgOltRxval(String xaAcgOltRxval) {
		this.xaAcgOltRxval = xaAcgOltRxval;
	}

	public String getXaAcgOnt() {
		return xaAcgOnt;
	}

	public void setXaAcgOnt(String xaAcgOnt) {
		this.xaAcgOnt = xaAcgOnt;
	}

	public String getXaAcgOntLinkst() {
		return xaAcgOntLinkst;
	}

	public void setXaAcgOntLinkst(String xaAcgOntLinkst) {
		this.xaAcgOntLinkst = xaAcgOntLinkst;
	}

	public String getXaAcgOntLinkval() {
		return xaAcgOntLinkval;
	}

	public void setXaAcgOntLinkval(String xaAcgOntLinkval) {
		this.xaAcgOntLinkval = xaAcgOntLinkval;
	}

	public String getXaAcgOntRxst() {
		return xaAcgOntRxst;
	}

	public void setXaAcgOntRxst(String xaAcgOntRxst) {
		this.xaAcgOntRxst = xaAcgOntRxst;
	}

	public String getXaAcgOntRxval() {
		return xaAcgOntRxval;
	}

	public void setXaAcgOntRxval(String xaAcgOntRxval) {
		this.xaAcgOntRxval = xaAcgOntRxval;
	}

	public String getXaAcgProfile() {
		return xaAcgProfile;
	}

	public void setXaAcgProfile(String xaAcgProfile) {
		this.xaAcgProfile = xaAcgProfile;
	}

	public String getXaActivityComment() {
		return xaActivityComment;
	}

	public void setXaActivityComment(String xaActivityComment) {
		this.xaActivityComment = xaActivityComment;
	}

	public String getXaActivityOrigin() {
		return xaActivityOrigin;
	}

	public void setXaActivityOrigin(String xaActivityOrigin) {
		this.xaActivityOrigin = xaActivityOrigin;
	}

	public String getXaAcvP1InConf() {
		return xaAcvP1InConf;
	}

	public void setXaAcvP1InConf(String xaAcvP1InConf) {
		this.xaAcvP1InConf = xaAcvP1InConf;
	}

	public String getXaAcvP1Msg() {
		return xaAcvP1Msg;
	}

	public void setXaAcvP1Msg(String xaAcvP1Msg) {
		this.xaAcvP1Msg = xaAcvP1Msg;
	}

	public String getXaAcvP1SswConf() {
		return xaAcvP1SswConf;
	}

	public void setXaAcvP1SswConf(String xaAcvP1SswConf) {
		this.xaAcvP1SswConf = xaAcvP1SswConf;
	}

	public String getXaAcvP1SswReg() {
		return xaAcvP1SswReg;
	}

	public void setXaAcvP1SswReg(String xaAcvP1SswReg) {
		this.xaAcvP1SswReg = xaAcvP1SswReg;
	}

	public String getXaAcvP2InConf() {
		return xaAcvP2InConf;
	}

	public void setXaAcvP2InConf(String xaAcvP2InConf) {
		this.xaAcvP2InConf = xaAcvP2InConf;
	}

	public String getXaAcvP2Msg() {
		return xaAcvP2Msg;
	}

	public void setXaAcvP2Msg(String xaAcvP2Msg) {
		this.xaAcvP2Msg = xaAcvP2Msg;
	}

	public String getXaAcvP2SswConf() {
		return xaAcvP2SswConf;
	}

	public void setXaAcvP2SswConf(String xaAcvP2SswConf) {
		this.xaAcvP2SswConf = xaAcvP2SswConf;
	}

	public String getXaAcvP2SswReg() {
		return xaAcvP2SswReg;
	}

	public void setXaAcvP2SswReg(String xaAcvP2SswReg) {
		this.xaAcvP2SswReg = xaAcvP2SswReg;
	}

	public String getXaAddrRef() {
		return xaAddrRef;
	}

	public void setXaAddrRef(String xaAddrRef) {
		this.xaAddrRef = xaAddrRef;
	}

	public String getXaAddressChangeFlag() {
		return xaAddressChangeFlag;
	}

	public void setXaAddressChangeFlag(String xaAddressChangeFlag) {
		this.xaAddressChangeFlag = xaAddressChangeFlag;
	}

	public String getXaBaNotDoneReason() {
		return xaBaNotDoneReason;
	}

	public void setXaBaNotDoneReason(String xaBaNotDoneReason) {
		this.xaBaNotDoneReason = xaBaNotDoneReason;
	}

	public String getXaBaVoipBbNotDoneReason() {
		return xaBaVoipBbNotDoneReason;
	}

	public void setXaBaVoipBbNotDoneReason(String xaBaVoipBbNotDoneReason) {
		this.xaBaVoipBbNotDoneReason = xaBaVoipBbNotDoneReason;
	}

	public String getXaBaVoipNotDoneReason() {
		return xaBaVoipNotDoneReason;
	}

	public void setXaBaVoipNotDoneReason(String xaBaVoipNotDoneReason) {
		this.xaBaVoipNotDoneReason = xaBaVoipNotDoneReason;
	}

	public String getXaBoxSecDestination() {
		return xaBoxSecDestination;
	}

	public void setXaBoxSecDestination(String xaBoxSecDestination) {
		this.xaBoxSecDestination = xaBoxSecDestination;
	}

	public String getXaCaddress2() {
		return xaCaddress2;
	}

	public void setXaCaddress2(String xaCaddress2) {
		this.xaCaddress2 = xaCaddress2;
	}

	public String getXaCancelReason() {
		return xaCancelReason;
	}

	public void setXaCancelReason(String xaCancelReason) {
		this.xaCancelReason = xaCancelReason;
	}

	public String getXaCardType() {
		return xaCardType;
	}

	public void setXaCardType(String xaCardType) {
		this.xaCardType = xaCardType;
	}

	public String getXaCaseId() {
		return xaCaseId;
	}

	public void setXaCaseId(String xaCaseId) {
		this.xaCaseId = xaCaseId;
	}

	public String getXaCaseReason1() {
		return xaCaseReason1;
	}

	public void setXaCaseReason1(String xaCaseReason1) {
		this.xaCaseReason1 = xaCaseReason1;
	}

	public String getXaCaseReason2() {
		return xaCaseReason2;
	}

	public void setXaCaseReason2(String xaCaseReason2) {
		this.xaCaseReason2 = xaCaseReason2;
	}

	public String getXaCaseReason3() {
		return xaCaseReason3;
	}

	public void setXaCaseReason3(String xaCaseReason3) {
		this.xaCaseReason3 = xaCaseReason3;
	}

	public String getXaCbaNotDoneReason() {
		return xaCbaNotDoneReason;
	}

	public void setXaCbaNotDoneReason(String xaCbaNotDoneReason) {
		this.xaCbaNotDoneReason = xaCbaNotDoneReason;
	}

	public String getXaCdoe() {
		return xaCdoe;
	}

	public void setXaCdoe(String xaCdoe) {
		this.xaCdoe = xaCdoe;
	}

	public String getXaCdoeAddress() {
		return xaCdoeAddress;
	}

	public void setXaCdoeAddress(String xaCdoeAddress) {
		this.xaCdoeAddress = xaCdoeAddress;
	}

	public String getXaCdoePowerRef() {
		return xaCdoePowerRef;
	}

	public void setXaCdoePowerRef(String xaCdoePowerRef) {
		this.xaCdoePowerRef = xaCdoePowerRef;
	}

	public String getXaCdoiPowerRef() {
		return xaCdoiPowerRef;
	}

	public void setXaCdoiPowerRef(String xaCdoiPowerRef) {
		this.xaCdoiPowerRef = xaCdoiPowerRef;
	}

	public String getXaChangeTech() {
		return xaChangeTech;
	}

	public void setXaChangeTech(String xaChangeTech) {
		this.xaChangeTech = xaChangeTech;
	}

	public String getXaClassification() {
		return xaClassification;
	}

	public void setXaClassification(String xaClassification) {
		this.xaClassification = xaClassification;
	}

	public String getXaCompletionCode() {
		return xaCompletionCode;
	}

	public void setXaCompletionCode(String xaCompletionCode) {
		this.xaCompletionCode = xaCompletionCode;
	}

	public String getXaCorpAcl() {
		return xaCorpAcl;
	}

	public void setXaCorpAcl(String xaCorpAcl) {
		this.xaCorpAcl = xaCorpAcl;
	}

	public String getXaCorpAtivitDate() {
		return xaCorpAtivitDate;
	}

	public void setXaCorpAtivitDate(String xaCorpAtivitDate) {
		this.xaCorpAtivitDate = xaCorpAtivitDate;
	}

	public String getXaCorpBuildDate() {
		return xaCorpBuildDate;
	}

	public void setXaCorpBuildDate(String xaCorpBuildDate) {
		this.xaCorpBuildDate = xaCorpBuildDate;
	}

	public String getXaCorpCancelReason() {
		return xaCorpCancelReason;
	}

	public void setXaCorpCancelReason(String xaCorpCancelReason) {
		this.xaCorpCancelReason = xaCorpCancelReason;
	}

	public String getXaCorpChecklist() {
		return xaCorpChecklist;
	}

	public void setXaCorpChecklist(String xaCorpChecklist) {
		this.xaCorpChecklist = xaCorpChecklist;
	}

	public String getXaCorpCompletionCode() {
		return xaCorpCompletionCode;
	}

	public void setXaCorpCompletionCode(String xaCorpCompletionCode) {
		this.xaCorpCompletionCode = xaCorpCompletionCode;
	}

	public String getXaCorpCountry() {
		return xaCorpCountry;
	}

	public void setXaCorpCountry(String xaCorpCountry) {
		this.xaCorpCountry = xaCorpCountry;
	}

	public String getXaCorpCustomerContactAttempts() {
		return xaCorpCustomerContactAttempts;
	}

	public void setXaCorpCustomerContactAttempts(String xaCorpCustomerContactAttempts) {
		this.xaCorpCustomerContactAttempts = xaCorpCustomerContactAttempts;
	}

	public String getXaCorpCustomerPort() {
		return xaCorpCustomerPort;
	}

	public void setXaCorpCustomerPort(String xaCorpCustomerPort) {
		this.xaCorpCustomerPort = xaCorpCustomerPort;
	}

	public String getXaCorpCvlan() {
		return xaCorpCvlan;
	}

	public void setXaCorpCvlan(String xaCorpCvlan) {
		this.xaCorpCvlan = xaCorpCvlan;
	}

	public String getXaCorpDeliveryDeadline() {
		return xaCorpDeliveryDeadline;
	}

	public void setXaCorpDeliveryDeadline(String xaCorpDeliveryDeadline) {
		this.xaCorpDeliveryDeadline = xaCorpDeliveryDeadline;
	}

	public String getXaCorpDownUpInd() {
		return xaCorpDownUpInd;
	}

	public void setXaCorpDownUpInd(String xaCorpDownUpInd) {
		this.xaCorpDownUpInd = xaCorpDownUpInd;
	}

	public String getXaCorpEquipModel() {
		return xaCorpEquipModel;
	}

	public void setXaCorpEquipModel(String xaCorpEquipModel) {
		this.xaCorpEquipModel = xaCorpEquipModel;
	}

	public String getXaCorpFiberActivationDate() {
		return xaCorpFiberActivationDate;
	}

	public void setXaCorpFiberActivationDate(String xaCorpFiberActivationDate) {
		this.xaCorpFiberActivationDate = xaCorpFiberActivationDate;
	}

	public String getXaCorpFiberApproachDate() {
		return xaCorpFiberApproachDate;
	}

	public void setXaCorpFiberApproachDate(String xaCorpFiberApproachDate) {
		this.xaCorpFiberApproachDate = xaCorpFiberApproachDate;
	}

	public String getXaCorpFiberFusionDate() {
		return xaCorpFiberFusionDate;
	}

	public void setXaCorpFiberFusionDate(String xaCorpFiberFusionDate) {
		this.xaCorpFiberFusionDate = xaCorpFiberFusionDate;
	}

	public String getXaCorpFiberInstallDate() {
		return xaCorpFiberInstallDate;
	}

	public void setXaCorpFiberInstallDate(String xaCorpFiberInstallDate) {
		this.xaCorpFiberInstallDate = xaCorpFiberInstallDate;
	}

	public String getXaCorpGl() {
		return xaCorpGl;
	}

	public void setXaCorpGl(String xaCorpGl) {
		this.xaCorpGl = xaCorpGl;
	}

	public String getXaCorpMaksen1() {
		return xaCorpMaksen1;
	}

	public void setXaCorpMaksen1(String xaCorpMaksen1) {
		this.xaCorpMaksen1 = xaCorpMaksen1;
	}

	public String getXaCorpMaksen2() {
		return xaCorpMaksen2;
	}

	public void setXaCorpMaksen2(String xaCorpMaksen2) {
		this.xaCorpMaksen2 = xaCorpMaksen2;
	}

	public String getXaCorpMsanBras() {
		return xaCorpMsanBras;
	}

	public void setXaCorpMsanBras(String xaCorpMsanBras) {
		this.xaCorpMsanBras = xaCorpMsanBras;
	}

	public String getXaCorpMsanCircuit() {
		return xaCorpMsanCircuit;
	}

	public void setXaCorpMsanCircuit(String xaCorpMsanCircuit) {
		this.xaCorpMsanCircuit = xaCorpMsanCircuit;
	}

	public String getXaCorpMsanModel() {
		return xaCorpMsanModel;
	}

	public void setXaCorpMsanModel(String xaCorpMsanModel) {
		this.xaCorpMsanModel = xaCorpMsanModel;
	}

	public String getXaCorpMsanSpazio() {
		return xaCorpMsanSpazio;
	}

	public void setXaCorpMsanSpazio(String xaCorpMsanSpazio) {
		this.xaCorpMsanSpazio = xaCorpMsanSpazio;
	}

	public String getXaCorpMsanSwitch() {
		return xaCorpMsanSwitch;
	}

	public void setXaCorpMsanSwitch(String xaCorpMsanSwitch) {
		this.xaCorpMsanSwitch = xaCorpMsanSwitch;
	}

	public String getXaCorpNotDoneReason() {
		return xaCorpNotDoneReason;
	}

	public void setXaCorpNotDoneReason(String xaCorpNotDoneReason) {
		this.xaCorpNotDoneReason = xaCorpNotDoneReason;
	}

	public String getXaCorpPopA() {
		return xaCorpPopA;
	}

	public void setXaCorpPopA(String xaCorpPopA) {
		this.xaCorpPopA = xaCorpPopA;
	}

	public String getXaCorpProjId() {
		return xaCorpProjId;
	}

	public void setXaCorpProjId(String xaCorpProjId) {
		this.xaCorpProjId = xaCorpProjId;
	}

	public String getXaCorpProjectManager() {
		return xaCorpProjectManager;
	}

	public void setXaCorpProjectManager(String xaCorpProjectManager) {
		this.xaCorpProjectManager = xaCorpProjectManager;
	}

	public String getXaCorpProjectManagerEmail() {
		return xaCorpProjectManagerEmail;
	}

	public void setXaCorpProjectManagerEmail(String xaCorpProjectManagerEmail) {
		this.xaCorpProjectManagerEmail = xaCorpProjectManagerEmail;
	}

	public String getXaCorpProjectManagerPhone() {
		return xaCorpProjectManagerPhone;
	}

	public void setXaCorpProjectManagerPhone(String xaCorpProjectManagerPhone) {
		this.xaCorpProjectManagerPhone = xaCorpProjectManagerPhone;
	}

	public String getXaCorpProvider() {
		return xaCorpProvider;
	}

	public void setXaCorpProvider(String xaCorpProvider) {
		this.xaCorpProvider = xaCorpProvider;
	}

	public String getXaCorpSalesContact() {
		return xaCorpSalesContact;
	}

	public void setXaCorpSalesContact(String xaCorpSalesContact) {
		this.xaCorpSalesContact = xaCorpSalesContact;
	}

	public String getXaCorpSalesContactPhone() {
		return xaCorpSalesContactPhone;
	}

	public void setXaCorpSalesContactPhone(String xaCorpSalesContactPhone) {
		this.xaCorpSalesContactPhone = xaCorpSalesContactPhone;
	}

	public String getXaCorpScheduledDate() {
		return xaCorpScheduledDate;
	}

	public void setXaCorpScheduledDate(String xaCorpScheduledDate) {
		this.xaCorpScheduledDate = xaCorpScheduledDate;
	}

	public String getXaCorpSerialNr() {
		return xaCorpSerialNr;
	}

	public void setXaCorpSerialNr(String xaCorpSerialNr) {
		this.xaCorpSerialNr = xaCorpSerialNr;
	}

	public String getXaCorpSvlan() {
		return xaCorpSvlan;
	}

	public void setXaCorpSvlan(String xaCorpSvlan) {
		this.xaCorpSvlan = xaCorpSvlan;
	}

	public String getXaCorpTechContact() {
		return xaCorpTechContact;
	}

	public void setXaCorpTechContact(String xaCorpTechContact) {
		this.xaCorpTechContact = xaCorpTechContact;
	}

	public String getXaCorpTechContactPhone() {
		return xaCorpTechContactPhone;
	}

	public void setXaCorpTechContactPhone(String xaCorpTechContactPhone) {
		this.xaCorpTechContactPhone = xaCorpTechContactPhone;
	}

	public String getXaCorpWoPivNr() {
		return xaCorpWoPivNr;
	}

	public void setXaCorpWoPivNr(String xaCorpWoPivNr) {
		this.xaCorpWoPivNr = xaCorpWoPivNr;
	}

	public String getXaCpeModel() {
		return xaCpeModel;
	}

	public void setXaCpeModel(String xaCpeModel) {
		this.xaCpeModel = xaCpeModel;
	}

	public String getXaCpeVendor() {
		return xaCpeVendor;
	}

	public void setXaCpeVendor(String xaCpeVendor) {
		this.xaCpeVendor = xaCpeVendor;
	}

	public String getXaCrcDescription() {
		return xaCrcDescription;
	}

	public void setXaCrcDescription(String xaCrcDescription) {
		this.xaCrcDescription = xaCrcDescription;
	}

	public String getXaCustomerContact() {
		return xaCustomerContact;
	}

	public void setXaCustomerContact(String xaCustomerContact) {
		this.xaCustomerContact = xaCustomerContact;
	}

	public String getXaCustomerContactTwo() {
		return xaCustomerContactTwo;
	}

	public void setXaCustomerContactTwo(String xaCustomerContactTwo) {
		this.xaCustomerContactTwo = xaCustomerContactTwo;
	}

	public String getXaCustomerType() {
		return xaCustomerType;
	}

	public void setXaCustomerType(String xaCustomerType) {
		this.xaCustomerType = xaCustomerType;
	}

	public String getXaDistanceTerminalToAddress() {
		return xaDistanceTerminalToAddress;
	}

	public void setXaDistanceTerminalToAddress(String xaDistanceTerminalToAddress) {
		this.xaDistanceTerminalToAddress = xaDistanceTerminalToAddress;
	}

	public String getXaEquipIdentification() {
		return xaEquipIdentification;
	}

	public void setXaEquipIdentification(String xaEquipIdentification) {
		this.xaEquipIdentification = xaEquipIdentification;
	}

	public String getXaExtWifi1() {
		return xaExtWifi1;
	}

	public void setXaExtWifi1(String xaExtWifi1) {
		this.xaExtWifi1 = xaExtWifi1;
	}

	public String getXaExtWifi2() {
		return xaExtWifi2;
	}

	public void setXaExtWifi2(String xaExtWifi2) {
		this.xaExtWifi2 = xaExtWifi2;
	}

	public String getXaExtWifi3() {
		return xaExtWifi3;
	}

	public void setXaExtWifi3(String xaExtWifi3) {
		this.xaExtWifi3 = xaExtWifi3;
	}

	public String getXaExtenderSerialNumber() {
		return xaExtenderSerialNumber;
	}

	public void setXaExtenderSerialNumber(String xaExtenderSerialNumber) {
		this.xaExtenderSerialNumber = xaExtenderSerialNumber;
	}

	public String getXaExtenderWifi() {
		return xaExtenderWifi;
	}

	public void setXaExtenderWifi(String xaExtenderWifi) {
		this.xaExtenderWifi = xaExtenderWifi;
	}

	public String getXaFirstRoutingTime() {
		return xaFirstRoutingTime;
	}

	public void setXaFirstRoutingTime(String xaFirstRoutingTime) {
		this.xaFirstRoutingTime = xaFirstRoutingTime;
	}

	public String getXaGponOltRx() {
		return xaGponOltRx;
	}

	public void setXaGponOltRx(String xaGponOltRx) {
		this.xaGponOltRx = xaGponOltRx;
	}

	public String getXaGponOntRx() {
		return xaGponOntRx;
	}

	public void setXaGponOntRx(String xaGponOntRx) {
		this.xaGponOntRx = xaGponOntRx;
	}

	public String getXaGpsValidation() {
		return xaGpsValidation;
	}

	public void setXaGpsValidation(String xaGpsValidation) {
		this.xaGpsValidation = xaGpsValidation;
	}

	public String getXaIdLote() {
		return xaIdLote;
	}

	public void setXaIdLote(String xaIdLote) {
		this.xaIdLote = xaIdLote;
	}

	public String getXaIpWan() {
		return xaIpWan;
	}

	public void setXaIpWan(String xaIpWan) {
		this.xaIpWan = xaIpWan;
	}

	public String getXaKeepFacilities() {
		return xaKeepFacilities;
	}

	public void setXaKeepFacilities(String xaKeepFacilities) {
		this.xaKeepFacilities = xaKeepFacilities;
	}

	public String getXaKeepMsan() {
		return xaKeepMsan;
	}

	public void setXaKeepMsan(String xaKeepMsan) {
		this.xaKeepMsan = xaKeepMsan;
	}

	public String getXaLetterResponsableId() {
		return xaLetterResponsableId;
	}

	public void setXaLetterResponsableId(String xaLetterResponsableId) {
		this.xaLetterResponsableId = xaLetterResponsableId;
	}

	public String getXaMeasureKl0() {
		return xaMeasureKl0;
	}

	public void setXaMeasureKl0(String xaMeasureKl0) {
		this.xaMeasureKl0 = xaMeasureKl0;
	}

	public String getXaMeasureTrainDb() {
		return xaMeasureTrainDb;
	}

	public void setXaMeasureTrainDb(String xaMeasureTrainDb) {
		this.xaMeasureTrainDb = xaMeasureTrainDb;
	}

	public String getXaMeasureTrainRate() {
		return xaMeasureTrainRate;
	}

	public void setXaMeasureTrainRate(String xaMeasureTrainRate) {
		this.xaMeasureTrainRate = xaMeasureTrainRate;
	}

	public String getXaModemReused() {
		return xaModemReused;
	}

	public void setXaModemReused(String xaModemReused) {
		this.xaModemReused = xaModemReused;
	}

	public String getXaModemSerialNumber() {
		return xaModemSerialNumber;
	}

	public void setXaModemSerialNumber(String xaModemSerialNumber) {
		this.xaModemSerialNumber = xaModemSerialNumber;
	}

	public String getXaModemSerieNumber() {
		return xaModemSerieNumber;
	}

	public void setXaModemSerieNumber(String xaModemSerieNumber) {
		this.xaModemSerieNumber = xaModemSerieNumber;
	}

	public String getXaMsanDestination() {
		return xaMsanDestination;
	}

	public void setXaMsanDestination(String xaMsanDestination) {
		this.xaMsanDestination = xaMsanDestination;
	}

	public String getXaMsanDistance() {
		return xaMsanDistance;
	}

	public void setXaMsanDistance(String xaMsanDistance) {
		this.xaMsanDistance = xaMsanDistance;
	}

	public String getXaNotDoneReason() {
		return xaNotDoneReason;
	}

	public void setXaNotDoneReason(String xaNotDoneReason) {
		this.xaNotDoneReason = xaNotDoneReason;
	}

	public String getXaNotDoneReasonCus() {
		return xaNotDoneReasonCus;
	}

	public void setXaNotDoneReasonCus(String xaNotDoneReasonCus) {
		this.xaNotDoneReasonCus = xaNotDoneReasonCus;
	}

	public String getXaNttCaixaEmenda1() {
		return xaNttCaixaEmenda1;
	}

	public void setXaNttCaixaEmenda1(String xaNttCaixaEmenda1) {
		this.xaNttCaixaEmenda1 = xaNttCaixaEmenda1;
	}

	public String getXaNttCaixaEmenda2() {
		return xaNttCaixaEmenda2;
	}

	public void setXaNttCaixaEmenda2(String xaNttCaixaEmenda2) {
		this.xaNttCaixaEmenda2 = xaNttCaixaEmenda2;
	}

	public String getXaNttCustomerAddress() {
		return xaNttCustomerAddress;
	}

	public void setXaNttCustomerAddress(String xaNttCustomerAddress) {
		this.xaNttCustomerAddress = xaNttCustomerAddress;
	}

	public String getXaNttCustomerAddress2() {
		return xaNttCustomerAddress2;
	}

	public void setXaNttCustomerAddress2(String xaNttCustomerAddress2) {
		this.xaNttCustomerAddress2 = xaNttCustomerAddress2;
	}

	public String getXaNttDateNocCommunication() {
		return xaNttDateNocCommunication;
	}

	public void setXaNttDateNocCommunication(String xaNttDateNocCommunication) {
		this.xaNttDateNocCommunication = xaNttDateNocCommunication;
	}

	public String getXaNttEquipmentId() {
		return xaNttEquipmentId;
	}

	public void setXaNttEquipmentId(String xaNttEquipmentId) {
		this.xaNttEquipmentId = xaNttEquipmentId;
	}

	public String getXaNttEquipmentIdB() {
		return xaNttEquipmentIdB;
	}

	public void setXaNttEquipmentIdB(String xaNttEquipmentIdB) {
		this.xaNttEquipmentIdB = xaNttEquipmentIdB;
	}

	public String getXaNttEquipmentSite() {
		return xaNttEquipmentSite;
	}

	public void setXaNttEquipmentSite(String xaNttEquipmentSite) {
		this.xaNttEquipmentSite = xaNttEquipmentSite;
	}

	public String getXaNttEquipmentSiteB() {
		return xaNttEquipmentSiteB;
	}

	public void setXaNttEquipmentSiteB(String xaNttEquipmentSiteB) {
		this.xaNttEquipmentSiteB = xaNttEquipmentSiteB;
	}

	public String getXaNttEquipmentType() {
		return xaNttEquipmentType;
	}

	public void setXaNttEquipmentType(String xaNttEquipmentType) {
		this.xaNttEquipmentType = xaNttEquipmentType;
	}

	public String getXaNttFocableProblemSource() {
		return xaNttFocableProblemSource;
	}

	public void setXaNttFocableProblemSource(String xaNttFocableProblemSource) {
		this.xaNttFocableProblemSource = xaNttFocableProblemSource;
	}

	public String getXaNttInterventionType() {
		return xaNttInterventionType;
	}

	public void setXaNttInterventionType(String xaNttInterventionType) {
		this.xaNttInterventionType = xaNttInterventionType;
	}

	public String getXaNttJobType() {
		return xaNttJobType;
	}

	public void setXaNttJobType(String xaNttJobType) {
		this.xaNttJobType = xaNttJobType;
	}

	public String getXaNttNotDoneReason() {
		return xaNttNotDoneReason;
	}

	public void setXaNttNotDoneReason(String xaNttNotDoneReason) {
		this.xaNttNotDoneReason = xaNttNotDoneReason;
	}

	public String getXaNttNotDoneReasonEquip() {
		return xaNttNotDoneReasonEquip;
	}

	public void setXaNttNotDoneReasonEquip(String xaNttNotDoneReasonEquip) {
		this.xaNttNotDoneReasonEquip = xaNttNotDoneReasonEquip;
	}

	public String getXaNttNotDoneReasonFocable() {
		return xaNttNotDoneReasonFocable;
	}

	public void setXaNttNotDoneReasonFocable(String xaNttNotDoneReasonFocable) {
		this.xaNttNotDoneReasonFocable = xaNttNotDoneReasonFocable;
	}

	public String getXaNttOsOpenDate() {
		return xaNttOsOpenDate;
	}

	public void setXaNttOsOpenDate(String xaNttOsOpenDate) {
		this.xaNttOsOpenDate = xaNttOsOpenDate;
	}

	public String getXaNttRingCable() {
		return xaNttRingCable;
	}

	public void setXaNttRingCable(String xaNttRingCable) {
		this.xaNttRingCable = xaNttRingCable;
	}

	public String getXaNttSubcontractor() {
		return xaNttSubcontractor;
	}

	public void setXaNttSubcontractor(String xaNttSubcontractor) {
		this.xaNttSubcontractor = xaNttSubcontractor;
	}

	public String getXaNttSuspReasonEquip() {
		return xaNttSuspReasonEquip;
	}

	public void setXaNttSuspReasonEquip(String xaNttSuspReasonEquip) {
		this.xaNttSuspReasonEquip = xaNttSuspReasonEquip;
	}

	public String getXaNttSuspReasonFocable() {
		return xaNttSuspReasonFocable;
	}

	public void setXaNttSuspReasonFocable(String xaNttSuspReasonFocable) {
		this.xaNttSuspReasonFocable = xaNttSuspReasonFocable;
	}

	public String getXaOcComments() {
		return xaOcComments;
	}

	public void setXaOcComments(String xaOcComments) {
		this.xaOcComments = xaOcComments;
	}

	public String getXaOldCpeModel() {
		return xaOldCpeModel;
	}

	public void setXaOldCpeModel(String xaOldCpeModel) {
		this.xaOldCpeModel = xaOldCpeModel;
	}

	public String getXaOltPort() {
		return xaOltPort;
	}

	public void setXaOltPort(String xaOltPort) {
		this.xaOltPort = xaOltPort;
	}

	public String getXaOntId() {
		return xaOntId;
	}

	public void setXaOntId(String xaOntId) {
		this.xaOntId = xaOntId;
	}

	public String getXaOntModel() {
		return xaOntModel;
	}

	public void setXaOntModel(String xaOntModel) {
		this.xaOntModel = xaOntModel;
	}

	public String getXaOntOltMessage() {
		return xaOntOltMessage;
	}

	public void setXaOntOltMessage(String xaOntOltMessage) {
		this.xaOntOltMessage = xaOntOltMessage;
	}

	public String getXaOntSerialNumber() {
		return xaOntSerialNumber;
	}

	public void setXaOntSerialNumber(String xaOntSerialNumber) {
		this.xaOntSerialNumber = xaOntSerialNumber;
	}

	public String getXaPairManeuverDestination() {
		return xaPairManeuverDestination;
	}

	public void setXaPairManeuverDestination(String xaPairManeuverDestination) {
		this.xaPairManeuverDestination = xaPairManeuverDestination;
	}

	public String getXaParentFaultId() {
		return xaParentFaultId;
	}

	public void setXaParentFaultId(String xaParentFaultId) {
		this.xaParentFaultId = xaParentFaultId;
	}

	public String getXaPhone3() {
		return xaPhone3;
	}

	public void setXaPhone3(String xaPhone3) {
		this.xaPhone3 = xaPhone3;
	}

	public String getXaPhoneNumberTwo() {
		return xaPhoneNumberTwo;
	}

	public void setXaPhoneNumberTwo(String xaPhoneNumberTwo) {
		this.xaPhoneNumberTwo = xaPhoneNumberTwo;
	}

	public String getXaPiAccessRestritions() {
		return xaPiAccessRestritions;
	}

	public void setXaPiAccessRestritions(String xaPiAccessRestritions) {
		this.xaPiAccessRestritions = xaPiAccessRestritions;
	}

	public String getXaPiActivateGmg() {
		return xaPiActivateGmg;
	}

	public void setXaPiActivateGmg(String xaPiActivateGmg) {
		this.xaPiActivateGmg = xaPiActivateGmg;
	}

	public String getXaPiAffectedTrail() {
		return xaPiAffectedTrail;
	}

	public void setXaPiAffectedTrail(String xaPiAffectedTrail) {
		this.xaPiAffectedTrail = xaPiAffectedTrail;
	}

	public String getXaPiAlarmEndDate() {
		return xaPiAlarmEndDate;
	}

	public void setXaPiAlarmEndDate(String xaPiAlarmEndDate) {
		this.xaPiAlarmEndDate = xaPiAlarmEndDate;
	}

	public String getXaPiAlarmManualEnd() {
		return xaPiAlarmManualEnd;
	}

	public void setXaPiAlarmManualEnd(String xaPiAlarmManualEnd) {
		this.xaPiAlarmManualEnd = xaPiAlarmManualEnd;
	}

	public String getXaPiAlarmManualInit() {
		return xaPiAlarmManualInit;
	}

	public void setXaPiAlarmManualInit(String xaPiAlarmManualInit) {
		this.xaPiAlarmManualInit = xaPiAlarmManualInit;
	}

	public String getXaPiAlarmSugestDate() {
		return xaPiAlarmSugestDate;
	}

	public void setXaPiAlarmSugestDate(String xaPiAlarmSugestDate) {
		this.xaPiAlarmSugestDate = xaPiAlarmSugestDate;
	}

	public String getXaPiAlarmType() {
		return xaPiAlarmType;
	}

	public void setXaPiAlarmType(String xaPiAlarmType) {
		this.xaPiAlarmType = xaPiAlarmType;
	}

	public String getXaPiAmfAccompName() {
		return xaPiAmfAccompName;
	}

	public void setXaPiAmfAccompName(String xaPiAmfAccompName) {
		this.xaPiAmfAccompName = xaPiAmfAccompName;
	}

	public String getXaPiAmfAddress() {
		return xaPiAmfAddress;
	}

	public void setXaPiAmfAddress(String xaPiAmfAddress) {
		this.xaPiAmfAddress = xaPiAmfAddress;
	}

	public String getXaPiAmfAvailability() {
		return xaPiAmfAvailability;
	}

	public void setXaPiAmfAvailability(String xaPiAmfAvailability) {
		this.xaPiAmfAvailability = xaPiAmfAvailability;
	}

	public String getXaPiAmfCustomerInCall() {
		return xaPiAmfCustomerInCall;
	}

	public void setXaPiAmfCustomerInCall(String xaPiAmfCustomerInCall) {
		this.xaPiAmfCustomerInCall = xaPiAmfCustomerInCall;
	}

	public String getXaPiAmfDatetime() {
		return xaPiAmfDatetime;
	}

	public void setXaPiAmfDatetime(String xaPiAmfDatetime) {
		this.xaPiAmfDatetime = xaPiAmfDatetime;
	}

	public String getXaPiAmfDesignation() {
		return xaPiAmfDesignation;
	}

	public void setXaPiAmfDesignation(String xaPiAmfDesignation) {
		this.xaPiAmfDesignation = xaPiAmfDesignation;
	}

	public String getXaPiAmfEmail() {
		return xaPiAmfEmail;
	}

	public void setXaPiAmfEmail(String xaPiAmfEmail) {
		this.xaPiAmfEmail = xaPiAmfEmail;
	}

	public String getXaPiAmfFailLocation() {
		return xaPiAmfFailLocation;
	}

	public void setXaPiAmfFailLocation(String xaPiAmfFailLocation) {
		this.xaPiAmfFailLocation = xaPiAmfFailLocation;
	}

	public String getXaPiAmfOperator() {
		return xaPiAmfOperator;
	}

	public void setXaPiAmfOperator(String xaPiAmfOperator) {
		this.xaPiAmfOperator = xaPiAmfOperator;
	}

	public String getXaPiAmfScheduleDate() {
		return xaPiAmfScheduleDate;
	}

	public void setXaPiAmfScheduleDate(String xaPiAmfScheduleDate) {
		this.xaPiAmfScheduleDate = xaPiAmfScheduleDate;
	}

	public String getXaPiAmfSite() {
		return xaPiAmfSite;
	}

	public void setXaPiAmfSite(String xaPiAmfSite) {
		this.xaPiAmfSite = xaPiAmfSite;
	}

	public String getXaPiAmfTel() {
		return xaPiAmfTel;
	}

	public void setXaPiAmfTel(String xaPiAmfTel) {
		this.xaPiAmfTel = xaPiAmfTel;
	}

	public String getXaPiAmfTimInCall() {
		return xaPiAmfTimInCall;
	}

	public void setXaPiAmfTimInCall(String xaPiAmfTimInCall) {
		this.xaPiAmfTimInCall = xaPiAmfTimInCall;
	}

	public String getXaPiAmfVisitReason() {
		return xaPiAmfVisitReason;
	}

	public void setXaPiAmfVisitReason(String xaPiAmfVisitReason) {
		this.xaPiAmfVisitReason = xaPiAmfVisitReason;
	}

	public String getXaPiArea() {
		return xaPiArea;
	}

	public void setXaPiArea(String xaPiArea) {
		this.xaPiArea = xaPiArea;
	}

	public String getXaPiAssociatedNtts() {
		return xaPiAssociatedNtts;
	}

	public void setXaPiAssociatedNtts(String xaPiAssociatedNtts) {
		this.xaPiAssociatedNtts = xaPiAssociatedNtts;
	}

	public String getXaPiAttendanceSeg() {
		return xaPiAttendanceSeg;
	}

	public void setXaPiAttendanceSeg(String xaPiAttendanceSeg) {
		this.xaPiAttendanceSeg = xaPiAttendanceSeg;
	}

	public String getXaPiBo() {
		return xaPiBo;
	}

	public void setXaPiBo(String xaPiBo) {
		this.xaPiBo = xaPiBo;
	}

	public String getXaPiBoDate() {
		return xaPiBoDate;
	}

	public void setXaPiBoDate(String xaPiBoDate) {
		this.xaPiBoDate = xaPiBoDate;
	}

	public String getXaPiBoNotInformedReason() {
		return xaPiBoNotInformedReason;
	}

	public void setXaPiBoNotInformedReason(String xaPiBoNotInformedReason) {
		this.xaPiBoNotInformedReason = xaPiBoNotInformedReason;
	}

	public String getXaPiBoNumber() {
		return xaPiBoNumber;
	}

	public void setXaPiBoNumber(String xaPiBoNumber) {
		this.xaPiBoNumber = xaPiBoNumber;
	}

	public String getXaPiBreaking() {
		return xaPiBreaking;
	}

	public void setXaPiBreaking(String xaPiBreaking) {
		this.xaPiBreaking = xaPiBreaking;
	}

	public String getXaPiBscRnc() {
		return xaPiBscRnc;
	}

	public void setXaPiBscRnc(String xaPiBscRnc) {
		this.xaPiBscRnc = xaPiBscRnc;
	}

	public String getXaPiCfPositionFiber() {
		return xaPiCfPositionFiber;
	}

	public void setXaPiCfPositionFiber(String xaPiCfPositionFiber) {
		this.xaPiCfPositionFiber = xaPiCfPositionFiber;
	}

	public String getXaPiCfReceptionLevel() {
		return xaPiCfReceptionLevel;
	}

	public void setXaPiCfReceptionLevel(String xaPiCfReceptionLevel) {
		this.xaPiCfReceptionLevel = xaPiCfReceptionLevel;
	}

	public String getXaPiCircuitInfo() {
		return xaPiCircuitInfo;
	}

	public void setXaPiCircuitInfo(String xaPiCircuitInfo) {
		this.xaPiCircuitInfo = xaPiCircuitInfo;
	}

	public String getXaPiClaimant() {
		return xaPiClaimant;
	}

	public void setXaPiClaimant(String xaPiClaimant) {
		this.xaPiClaimant = xaPiClaimant;
	}

	public String getXaPiCloseNote() {
		return xaPiCloseNote;
	}

	public void setXaPiCloseNote(String xaPiCloseNote) {
		this.xaPiCloseNote = xaPiCloseNote;
	}

	public String getXaPiCm() {
		return xaPiCm;
	}

	public void setXaPiCm(String xaPiCm) {
		this.xaPiCm = xaPiCm;
	}

	public String getXaPiColabName() {
		return xaPiColabName;
	}

	public void setXaPiColabName(String xaPiColabName) {
		this.xaPiColabName = xaPiColabName;
	}

	public String getXaPiCompany() {
		return xaPiCompany;
	}

	public void setXaPiCompany(String xaPiCompany) {
		this.xaPiCompany = xaPiCompany;
	}

	public String getXaPiCompanyCosite() {
		return xaPiCompanyCosite;
	}

	public void setXaPiCompanyCosite(String xaPiCompanyCosite) {
		this.xaPiCompanyCosite = xaPiCompanyCosite;
	}

	public String getXaPiContract() {
		return xaPiContract;
	}

	public void setXaPiContract(String xaPiContract) {
		this.xaPiContract = xaPiContract;
	}

	public String getXaPiCreateDate() {
		return xaPiCreateDate;
	}

	public void setXaPiCreateDate(String xaPiCreateDate) {
		this.xaPiCreateDate = xaPiCreateDate;
	}

	public String getXaPiCriticalElement() {
		return xaPiCriticalElement;
	}

	public void setXaPiCriticalElement(String xaPiCriticalElement) {
		this.xaPiCriticalElement = xaPiCriticalElement;
	}

	public String getXaPiCsfNameTelTechAutorization() {
		return xaPiCsfNameTelTechAutorization;
	}

	public void setXaPiCsfNameTelTechAutorization(String xaPiCsfNameTelTechAutorization) {
		this.xaPiCsfNameTelTechAutorization = xaPiCsfNameTelTechAutorization;
	}

	public String getXaPiCsfSolution() {
		return xaPiCsfSolution;
	}

	public void setXaPiCsfSolution(String xaPiCsfSolution) {
		this.xaPiCsfSolution = xaPiCsfSolution;
	}

	public String getXaPiCustomerFinalName() {
		return xaPiCustomerFinalName;
	}

	public void setXaPiCustomerFinalName(String xaPiCustomerFinalName) {
		this.xaPiCustomerFinalName = xaPiCustomerFinalName;
	}

	public String getXaPiCustomerName() {
		return xaPiCustomerName;
	}

	public void setXaPiCustomerName(String xaPiCustomerName) {
		this.xaPiCustomerName = xaPiCustomerName;
	}

	public String getXaPiDefectResponsible() {
		return xaPiDefectResponsible;
	}

	public void setXaPiDefectResponsible(String xaPiDefectResponsible) {
		this.xaPiDefectResponsible = xaPiDefectResponsible;
	}

	public String getXaPiDelayReason() {
		return xaPiDelayReason;
	}

	public void setXaPiDelayReason(String xaPiDelayReason) {
		this.xaPiDelayReason = xaPiDelayReason;
	}

	public String getXaPiDependentsPerTx() {
		return xaPiDependentsPerTx;
	}

	public void setXaPiDependentsPerTx(String xaPiDependentsPerTx) {
		this.xaPiDependentsPerTx = xaPiDependentsPerTx;
	}

	public String getXaPiDistance() {
		return xaPiDistance;
	}

	public void setXaPiDistance(String xaPiDistance) {
		this.xaPiDistance = xaPiDistance;
	}

	public String getXaPiEndId() {
		return xaPiEndId;
	}

	public void setXaPiEndId(String xaPiEndId) {
		this.xaPiEndId = xaPiEndId;
	}

	public String getXaPiEnergyCode() {
		return xaPiEnergyCode;
	}

	public void setXaPiEnergyCode(String xaPiEnergyCode) {
		this.xaPiEnergyCode = xaPiEnergyCode;
	}

	public String getXaPiEnergyProtocol() {
		return xaPiEnergyProtocol;
	}

	public void setXaPiEnergyProtocol(String xaPiEnergyProtocol) {
		this.xaPiEnergyProtocol = xaPiEnergyProtocol;
	}

	public String getXaPiEquipAlarm() {
		return xaPiEquipAlarm;
	}

	public void setXaPiEquipAlarm(String xaPiEquipAlarm) {
		this.xaPiEquipAlarm = xaPiEquipAlarm;
	}

	public String getXaPiFailCause() {
		return xaPiFailCause;
	}

	public void setXaPiFailCause(String xaPiFailCause) {
		this.xaPiFailCause = xaPiFailCause;
	}

	public String getXaPiFailDescription() {
		return xaPiFailDescription;
	}

	public void setXaPiFailDescription(String xaPiFailDescription) {
		this.xaPiFailDescription = xaPiFailDescription;
	}

	public String getXaPiFailSolution() {
		return xaPiFailSolution;
	}

	public void setXaPiFailSolution(String xaPiFailSolution) {
		this.xaPiFailSolution = xaPiFailSolution;
	}

	public String getXaPiFailType() {
		return xaPiFailType;
	}

	public void setXaPiFailType(String xaPiFailType) {
		this.xaPiFailType = xaPiFailType;
	}

	public String getXaPiFcfArea() {
		return xaPiFcfArea;
	}

	public void setXaPiFcfArea(String xaPiFcfArea) {
		this.xaPiFcfArea = xaPiFcfArea;
	}

	public String getXaPiFcfMaterial() {
		return xaPiFcfMaterial;
	}

	public void setXaPiFcfMaterial(String xaPiFcfMaterial) {
		this.xaPiFcfMaterial = xaPiFcfMaterial;
	}

	public String getXaPiFcfOpenStretch() {
		return xaPiFcfOpenStretch;
	}

	public void setXaPiFcfOpenStretch(String xaPiFcfOpenStretch) {
		this.xaPiFcfOpenStretch = xaPiFcfOpenStretch;
	}

	public String getXaPiFcfQttBox() {
		return xaPiFcfQttBox;
	}

	public void setXaPiFcfQttBox(String xaPiFcfQttBox) {
		this.xaPiFcfQttBox = xaPiFcfQttBox;
	}

	public String getXaPiFcfRing() {
		return xaPiFcfRing;
	}

	public void setXaPiFcfRing(String xaPiFcfRing) {
		this.xaPiFcfRing = xaPiFcfRing;
	}

	public String getXaPiGmgDesc() {
		return xaPiGmgDesc;
	}

	public void setXaPiGmgDesc(String xaPiGmgDesc) {
		this.xaPiGmgDesc = xaPiGmgDesc;
	}

	public String getXaPiGmgDistance() {
		return xaPiGmgDistance;
	}

	public void setXaPiGmgDistance(String xaPiGmgDistance) {
		this.xaPiGmgDistance = xaPiGmgDistance;
	}

	public String getXaPiGmgEnd() {
		return xaPiGmgEnd;
	}

	public void setXaPiGmgEnd(String xaPiGmgEnd) {
		this.xaPiGmgEnd = xaPiGmgEnd;
	}

	public String getXaPiGmgOwner() {
		return xaPiGmgOwner;
	}

	public void setXaPiGmgOwner(String xaPiGmgOwner) {
		this.xaPiGmgOwner = xaPiGmgOwner;
	}

	public String getXaPiGmgPower() {
		return xaPiGmgPower;
	}

	public void setXaPiGmgPower(String xaPiGmgPower) {
		this.xaPiGmgPower = xaPiGmgPower;
	}

	public String getXaPiGmgStart() {
		return xaPiGmgStart;
	}

	public void setXaPiGmgStart(String xaPiGmgStart) {
		this.xaPiGmgStart = xaPiGmgStart;
	}

	public String getXaPiGmgStatus() {
		return xaPiGmgStatus;
	}

	public void setXaPiGmgStatus(String xaPiGmgStatus) {
		this.xaPiGmgStatus = xaPiGmgStatus;
	}

	public String getXaPiHoliday() {
		return xaPiHoliday;
	}

	public void setXaPiHoliday(String xaPiHoliday) {
		this.xaPiHoliday = xaPiHoliday;
	}

	public String getXaPiIdTicketCa() {
		return xaPiIdTicketCa;
	}

	public void setXaPiIdTicketCa(String xaPiIdTicketCa) {
		this.xaPiIdTicketCa = xaPiIdTicketCa;
	}

	public String getXaPiImpact() {
		return xaPiImpact;
	}

	public void setXaPiImpact(String xaPiImpact) {
		this.xaPiImpact = xaPiImpact;
	}

	public String getXaPiIndustrialBuildings() {
		return xaPiIndustrialBuildings;
	}

	public void setXaPiIndustrialBuildings(String xaPiIndustrialBuildings) {
		this.xaPiIndustrialBuildings = xaPiIndustrialBuildings;
	}

	public String getXaPiInfraAlarm() {
		return xaPiInfraAlarm;
	}

	public void setXaPiInfraAlarm(String xaPiInfraAlarm) {
		this.xaPiInfraAlarm = xaPiInfraAlarm;
	}

	public String getXaPiInterruptionService() {
		return xaPiInterruptionService;
	}

	public void setXaPiInterruptionService(String xaPiInterruptionService) {
		this.xaPiInterruptionService = xaPiInterruptionService;
	}

	public String getXaPiInvChanged() {
		return xaPiInvChanged;
	}

	public void setXaPiInvChanged(String xaPiInvChanged) {
		this.xaPiInvChanged = xaPiInvChanged;
	}

	public String getXaPiIsocColabName() {
		return xaPiIsocColabName;
	}

	public void setXaPiIsocColabName(String xaPiIsocColabName) {
		this.xaPiIsocColabName = xaPiIsocColabName;
	}

	public String getXaPiLlCircuit() {
		return xaPiLlCircuit;
	}

	public void setXaPiLlCircuit(String xaPiLlCircuit) {
		this.xaPiLlCircuit = xaPiLlCircuit;
	}

	public String getXaPiLlEndDate() {
		return xaPiLlEndDate;
	}

	public void setXaPiLlEndDate(String xaPiLlEndDate) {
		this.xaPiLlEndDate = xaPiLlEndDate;
	}

	public String getXaPiLlFailCause() {
		return xaPiLlFailCause;
	}

	public void setXaPiLlFailCause(String xaPiLlFailCause) {
		this.xaPiLlFailCause = xaPiLlFailCause;
	}

	public String getXaPiLlHasenergy() {
		return xaPiLlHasenergy;
	}

	public void setXaPiLlHasenergy(String xaPiLlHasenergy) {
		this.xaPiLlHasenergy = xaPiLlHasenergy;
	}

	public String getXaPiLlHastest() {
		return xaPiLlHastest;
	}

	public void setXaPiLlHastest(String xaPiLlHastest) {
		this.xaPiLlHastest = xaPiLlHastest;
	}

	public String getXaPiLlInitDate() {
		return xaPiLlInitDate;
	}

	public void setXaPiLlInitDate(String xaPiLlInitDate) {
		this.xaPiLlInitDate = xaPiLlInitDate;
	}

	public String getXaPiLlProviderName() {
		return xaPiLlProviderName;
	}

	public void setXaPiLlProviderName(String xaPiLlProviderName) {
		this.xaPiLlProviderName = xaPiLlProviderName;
	}

	public String getXaPiMsc() {
		return xaPiMsc;
	}

	public void setXaPiMsc(String xaPiMsc) {
		this.xaPiMsc = xaPiMsc;
	}

	public String getXaPiMscBsc() {
		return xaPiMscBsc;
	}

	public void setXaPiMscBsc(String xaPiMscBsc) {
		this.xaPiMscBsc = xaPiMscBsc;
	}

	public String getXaPiMsgTicketCa() {
		return xaPiMsgTicketCa;
	}

	public void setXaPiMsgTicketCa(String xaPiMsgTicketCa) {
		this.xaPiMsgTicketCa = xaPiMsgTicketCa;
	}

	public String getXaPiNeImpact() {
		return xaPiNeImpact;
	}

	public void setXaPiNeImpact(String xaPiNeImpact) {
		this.xaPiNeImpact = xaPiNeImpact;
	}

	public String getXaPiNeInfo() {
		return xaPiNeInfo;
	}

	public void setXaPiNeInfo(String xaPiNeInfo) {
		this.xaPiNeInfo = xaPiNeInfo;
	}

	public String getXaPiNeName() {
		return xaPiNeName;
	}

	public void setXaPiNeName(String xaPiNeName) {
		this.xaPiNeName = xaPiNeName;
	}

	public String getXaPiNeObs() {
		return xaPiNeObs;
	}

	public void setXaPiNeObs(String xaPiNeObs) {
		this.xaPiNeObs = xaPiNeObs;
	}

	public String getXaPiNeType() {
		return xaPiNeType;
	}

	public void setXaPiNeType(String xaPiNeType) {
		this.xaPiNeType = xaPiNeType;
	}

	public String getXaPiNeighborhood() {
		return xaPiNeighborhood;
	}

	public void setXaPiNeighborhood(String xaPiNeighborhood) {
		this.xaPiNeighborhood = xaPiNeighborhood;
	}

	public String getXaPiNetwork() {
		return xaPiNetwork;
	}

	public void setXaPiNetwork(String xaPiNetwork) {
		this.xaPiNetwork = xaPiNetwork;
	}

	public String getXaPiNetworkElement() {
		return xaPiNetworkElement;
	}

	public void setXaPiNetworkElement(String xaPiNetworkElement) {
		this.xaPiNetworkElement = xaPiNetworkElement;
	}

	public String getXaPiNttStatus() {
		return xaPiNttStatus;
	}

	public void setXaPiNttStatus(String xaPiNttStatus) {
		this.xaPiNttStatus = xaPiNttStatus;
	}

	public String getXaPiNttUserRule() {
		return xaPiNttUserRule;
	}

	public void setXaPiNttUserRule(String xaPiNttUserRule) {
		this.xaPiNttUserRule = xaPiNttUserRule;
	}

	public String getXaPiObs() {
		return xaPiObs;
	}

	public void setXaPiObs(String xaPiObs) {
		this.xaPiObs = xaPiObs;
	}

	public String getXaPiOp() {
		return xaPiOp;
	}

	public void setXaPiOp(String xaPiOp) {
		this.xaPiOp = xaPiOp;
	}

	public String getXaPiOpeningNote() {
		return xaPiOpeningNote;
	}

	public void setXaPiOpeningNote(String xaPiOpeningNote) {
		this.xaPiOpeningNote = xaPiOpeningNote;
	}

	public String getXaPiOrigin() {
		return xaPiOrigin;
	}

	public void setXaPiOrigin(String xaPiOrigin) {
		this.xaPiOrigin = xaPiOrigin;
	}

	public String getXaPiPartnerCompany() {
		return xaPiPartnerCompany;
	}

	public void setXaPiPartnerCompany(String xaPiPartnerCompany) {
		this.xaPiPartnerCompany = xaPiPartnerCompany;
	}

	public String getXaPiPortalSolution() {
		return xaPiPortalSolution;
	}

	public void setXaPiPortalSolution(String xaPiPortalSolution) {
		this.xaPiPortalSolution = xaPiPortalSolution;
	}

	public String getXaPiPowerDistCompany() {
		return xaPiPowerDistCompany;
	}

	public void setXaPiPowerDistCompany(String xaPiPowerDistCompany) {
		this.xaPiPowerDistCompany = xaPiPowerDistCompany;
	}

	public String getXaPiPqClassification() {
		return xaPiPqClassification;
	}

	public void setXaPiPqClassification(String xaPiPqClassification) {
		this.xaPiPqClassification = xaPiPqClassification;
	}

	public String getXaPiPriority() {
		return xaPiPriority;
	}

	public void setXaPiPriority(String xaPiPriority) {
		this.xaPiPriority = xaPiPriority;
	}

	public String getXaPiRejectionNote() {
		return xaPiRejectionNote;
	}

	public void setXaPiRejectionNote(String xaPiRejectionNote) {
		this.xaPiRejectionNote = xaPiRejectionNote;
	}

	public String getXaPiRelatedTickets() {
		return xaPiRelatedTickets;
	}

	public void setXaPiRelatedTickets(String xaPiRelatedTickets) {
		this.xaPiRelatedTickets = xaPiRelatedTickets;
	}

	public String getXaPiRelatedTrail() {
		return xaPiRelatedTrail;
	}

	public void setXaPiRelatedTrail(String xaPiRelatedTrail) {
		this.xaPiRelatedTrail = xaPiRelatedTrail;
	}

	public String getXaPiResponsable() {
		return xaPiResponsable;
	}

	public void setXaPiResponsable(String xaPiResponsable) {
		this.xaPiResponsable = xaPiResponsable;
	}

	public String getXaPiRestartDate() {
		return xaPiRestartDate;
	}

	public void setXaPiRestartDate(String xaPiRestartDate) {
		this.xaPiRestartDate = xaPiRestartDate;
	}

	public String getXaPiSecTicket() {
		return xaPiSecTicket;
	}

	public void setXaPiSecTicket(String xaPiSecTicket) {
		this.xaPiSecTicket = xaPiSecTicket;
	}

	public String getXaPiSecurityCompany() {
		return xaPiSecurityCompany;
	}

	public void setXaPiSecurityCompany(String xaPiSecurityCompany) {
		this.xaPiSecurityCompany = xaPiSecurityCompany;
	}

	public String getXaPiSendGmg() {
		return xaPiSendGmg;
	}

	public void setXaPiSendGmg(String xaPiSendGmg) {
		this.xaPiSendGmg = xaPiSendGmg;
	}

	public String getXaPiSiteAutonomy() {
		return xaPiSiteAutonomy;
	}

	public void setXaPiSiteAutonomy(String xaPiSiteAutonomy) {
		this.xaPiSiteAutonomy = xaPiSiteAutonomy;
	}

	public String getXaPiSiteImpact() {
		return xaPiSiteImpact;
	}

	public void setXaPiSiteImpact(String xaPiSiteImpact) {
		this.xaPiSiteImpact = xaPiSiteImpact;
	}

	public String getXaPiSiteOwner() {
		return xaPiSiteOwner;
	}

	public void setXaPiSiteOwner(String xaPiSiteOwner) {
		this.xaPiSiteOwner = xaPiSiteOwner;
	}

	public String getXaPiSolutionDescription() {
		return xaPiSolutionDescription;
	}

	public void setXaPiSolutionDescription(String xaPiSolutionDescription) {
		this.xaPiSolutionDescription = xaPiSolutionDescription;
	}

	public String getXaPiSpare() {
		return xaPiSpare;
	}

	public void setXaPiSpare(String xaPiSpare) {
		this.xaPiSpare = xaPiSpare;
	}

	public String getXaPiStEndDate() {
		return xaPiStEndDate;
	}

	public void setXaPiStEndDate(String xaPiStEndDate) {
		this.xaPiStEndDate = xaPiStEndDate;
	}

	public String getXaPiStInitDate() {
		return xaPiStInitDate;
	}

	public void setXaPiStInitDate(String xaPiStInitDate) {
		this.xaPiStInitDate = xaPiStInitDate;
	}

	public String getXaPiStartAlarmDatetime() {
		return xaPiStartAlarmDatetime;
	}

	public void setXaPiStartAlarmDatetime(String xaPiStartAlarmDatetime) {
		this.xaPiStartAlarmDatetime = xaPiStartAlarmDatetime;
	}

	public String getXaPiSubArea() {
		return xaPiSubArea;
	}

	public void setXaPiSubArea(String xaPiSubArea) {
		this.xaPiSubArea = xaPiSubArea;
	}

	public String getXaPiSuspendNote() {
		return xaPiSuspendNote;
	}

	public void setXaPiSuspendNote(String xaPiSuspendNote) {
		this.xaPiSuspendNote = xaPiSuspendNote;
	}

	public String getXaPiSuspendReason() {
		return xaPiSuspendReason;
	}

	public void setXaPiSuspendReason(String xaPiSuspendReason) {
		this.xaPiSuspendReason = xaPiSuspendReason;
	}

	public String getXaPiTdmaCosite() {
		return xaPiTdmaCosite;
	}

	public void setXaPiTdmaCosite(String xaPiTdmaCosite) {
		this.xaPiTdmaCosite = xaPiTdmaCosite;
	}

	public String getXaPiTestsDone() {
		return xaPiTestsDone;
	}

	public void setXaPiTestsDone(String xaPiTestsDone) {
		this.xaPiTestsDone = xaPiTestsDone;
	}

	public String getXaPiTheft() {
		return xaPiTheft;
	}

	public void setXaPiTheft(String xaPiTheft) {
		this.xaPiTheft = xaPiTheft;
	}

	public String getXaPiTicketTitl() {
		return xaPiTicketTitl;
	}

	public void setXaPiTicketTitl(String xaPiTicketTitl) {
		this.xaPiTicketTitl = xaPiTicketTitl;
	}

	public String getXaPiToBeExecuted() {
		return xaPiToBeExecuted;
	}

	public void setXaPiToBeExecuted(String xaPiToBeExecuted) {
		this.xaPiToBeExecuted = xaPiToBeExecuted;
	}

	public String getXaPiTotalDependents() {
		return xaPiTotalDependents;
	}

	public void setXaPiTotalDependents(String xaPiTotalDependents) {
		this.xaPiTotalDependents = xaPiTotalDependents;
	}

	public String getXaPiTramReason() {
		return xaPiTramReason;
	}

	public void setXaPiTramReason(String xaPiTramReason) {
		this.xaPiTramReason = xaPiTramReason;
	}

	public String getXaPiTravelType() {
		return xaPiTravelType;
	}

	public void setXaPiTravelType(String xaPiTravelType) {
		this.xaPiTravelType = xaPiTravelType;
	}

	public String getXaPiUmtsCosite() {
		return xaPiUmtsCosite;
	}

	public void setXaPiUmtsCosite(String xaPiUmtsCosite) {
		this.xaPiUmtsCosite = xaPiUmtsCosite;
	}

	public String getXaPiUser() {
		return xaPiUser;
	}

	public void setXaPiUser(String xaPiUser) {
		this.xaPiUser = xaPiUser;
	}

	public String getXaPiVandalism() {
		return xaPiVandalism;
	}

	public void setXaPiVandalism(String xaPiVandalism) {
		this.xaPiVandalism = xaPiVandalism;
	}

	public String getXaPiWorkDiary() {
		return xaPiWorkDiary;
	}

	public void setXaPiWorkDiary(String xaPiWorkDiary) {
		this.xaPiWorkDiary = xaPiWorkDiary;
	}

	public String getXaPortManeuverDestination() {
		return xaPortManeuverDestination;
	}

	public void setXaPortManeuverDestination(String xaPortManeuverDestination) {
		this.xaPortManeuverDestination = xaPortManeuverDestination;
	}

	public String getXaPort1TnTemporary() {
		return xaPort1TnTemporary;
	}

	public void setXaPort1TnTemporary(String xaPort1TnTemporary) {
		this.xaPort1TnTemporary = xaPort1TnTemporary;
	}

	public String getXaPort1VoipProductName() {
		return xaPort1VoipProductName;
	}

	public void setXaPort1VoipProductName(String xaPort1VoipProductName) {
		this.xaPort1VoipProductName = xaPort1VoipProductName;
	}

	public String getXaPort1VoipServiceId() {
		return xaPort1VoipServiceId;
	}

	public void setXaPort1VoipServiceId(String xaPort1VoipServiceId) {
		this.xaPort1VoipServiceId = xaPort1VoipServiceId;
	}

	public String getXaPort1VoipTn() {
		return xaPort1VoipTn;
	}

	public void setXaPort1VoipTn(String xaPort1VoipTn) {
		this.xaPort1VoipTn = xaPort1VoipTn;
	}

	public String getXaPort2TnTemporary() {
		return xaPort2TnTemporary;
	}

	public void setXaPort2TnTemporary(String xaPort2TnTemporary) {
		this.xaPort2TnTemporary = xaPort2TnTemporary;
	}

	public String getXaPort2VoipProductName() {
		return xaPort2VoipProductName;
	}

	public void setXaPort2VoipProductName(String xaPort2VoipProductName) {
		this.xaPort2VoipProductName = xaPort2VoipProductName;
	}

	public String getXaPort2VoipServiceId() {
		return xaPort2VoipServiceId;
	}

	public void setXaPort2VoipServiceId(String xaPort2VoipServiceId) {
		this.xaPort2VoipServiceId = xaPort2VoipServiceId;
	}

	public String getXaPort2VoipTn() {
		return xaPort2VoipTn;
	}

	public void setXaPort2VoipTn(String xaPort2VoipTn) {
		this.xaPort2VoipTn = xaPort2VoipTn;
	}

	public String getXaPowerMeasuredCdoe() {
		return xaPowerMeasuredCdoe;
	}

	public void setXaPowerMeasuredCdoe(String xaPowerMeasuredCdoe) {
		this.xaPowerMeasuredCdoe = xaPowerMeasuredCdoe;
	}

	public String getXaPowerMeasuredCdoi() {
		return xaPowerMeasuredCdoi;
	}

	public void setXaPowerMeasuredCdoi(String xaPowerMeasuredCdoi) {
		this.xaPowerMeasuredCdoi = xaPowerMeasuredCdoi;
	}

	public String getXaPowerMeasuredOnt() {
		return xaPowerMeasuredOnt;
	}

	public void setXaPowerMeasuredOnt(String xaPowerMeasuredOnt) {
		this.xaPowerMeasuredOnt = xaPowerMeasuredOnt;
	}

	public String getXaPrimOpticalCable() {
		return xaPrimOpticalCable;
	}

	public void setXaPrimOpticalCable(String xaPrimOpticalCable) {
		this.xaPrimOpticalCable = xaPrimOpticalCable;
	}

	public String getXaPrimaryNetworkCable() {
		return xaPrimaryNetworkCable;
	}

	public void setXaPrimaryNetworkCable(String xaPrimaryNetworkCable) {
		this.xaPrimaryNetworkCable = xaPrimaryNetworkCable;
	}

	public String getXaPrimaryNetworkMsan() {
		return xaPrimaryNetworkMsan;
	}

	public void setXaPrimaryNetworkMsan(String xaPrimaryNetworkMsan) {
		this.xaPrimaryNetworkMsan = xaPrimaryNetworkMsan;
	}

	public String getXaPrimaryNetworkMsanAddress() {
		return xaPrimaryNetworkMsanAddress;
	}

	public void setXaPrimaryNetworkMsanAddress(String xaPrimaryNetworkMsanAddress) {
		this.xaPrimaryNetworkMsanAddress = xaPrimaryNetworkMsanAddress;
	}

	public String getXaPrimaryNetworkPort() {
		return xaPrimaryNetworkPort;
	}

	public void setXaPrimaryNetworkPort(String xaPrimaryNetworkPort) {
		this.xaPrimaryNetworkPort = xaPrimaryNetworkPort;
	}

	public String getXaProductId() {
		return xaProductId;
	}

	public void setXaProductId(String xaProductId) {
		this.xaProductId = xaProductId;
	}

	public String getXaProductName() {
		return xaProductName;
	}

	public void setXaProductName(String xaProductName) {
		this.xaProductName = xaProductName;
	}

	public String getXaProductSpeed() {
		return xaProductSpeed;
	}

	public void setXaProductSpeed(String xaProductSpeed) {
		this.xaProductSpeed = xaProductSpeed;
	}

	public String getXaReturnedModemSerial() {
		return xaReturnedModemSerial;
	}

	public void setXaReturnedModemSerial(String xaReturnedModemSerial) {
		this.xaReturnedModemSerial = xaReturnedModemSerial;
	}

	public String getXaRoutingFlag() {
		return xaRoutingFlag;
	}

	public void setXaRoutingFlag(String xaRoutingFlag) {
		this.xaRoutingFlag = xaRoutingFlag;
	}

	public String getXaRoutingFlagTime() {
		return xaRoutingFlagTime;
	}

	public void setXaRoutingFlagTime(String xaRoutingFlagTime) {
		this.xaRoutingFlagTime = xaRoutingFlagTime;
	}

	public String getXaSecOpticalCable() {
		return xaSecOpticalCable;
	}

	public void setXaSecOpticalCable(String xaSecOpticalCable) {
		this.xaSecOpticalCable = xaSecOpticalCable;
	}

	public String getXaSecondaryNetworkBox() {
		return xaSecondaryNetworkBox;
	}

	public void setXaSecondaryNetworkBox(String xaSecondaryNetworkBox) {
		this.xaSecondaryNetworkBox = xaSecondaryNetworkBox;
	}

	public String getXaSecondaryNetworkBoxAddress() {
		return xaSecondaryNetworkBoxAddress;
	}

	public void setXaSecondaryNetworkBoxAddress(String xaSecondaryNetworkBoxAddress) {
		this.xaSecondaryNetworkBoxAddress = xaSecondaryNetworkBoxAddress;
	}

	public String getXaSecondaryNetworkBoxPort() {
		return xaSecondaryNetworkBoxPort;
	}

	public void setXaSecondaryNetworkBoxPort(String xaSecondaryNetworkBoxPort) {
		this.xaSecondaryNetworkBoxPort = xaSecondaryNetworkBoxPort;
	}

	public String getXaSecondaryNetworkBoxPowerLevel() {
		return xaSecondaryNetworkBoxPowerLevel;
	}

	public void setXaSecondaryNetworkBoxPowerLevel(String xaSecondaryNetworkBoxPowerLevel) {
		this.xaSecondaryNetworkBoxPowerLevel = xaSecondaryNetworkBoxPowerLevel;
	}

	public String getXaSecondaryNetworkBoxTrf() {
		return xaSecondaryNetworkBoxTrf;
	}

	public void setXaSecondaryNetworkBoxTrf(String xaSecondaryNetworkBoxTrf) {
		this.xaSecondaryNetworkBoxTrf = xaSecondaryNetworkBoxTrf;
	}

	public String getXaSecondaryNetworkBoxType() {
		return xaSecondaryNetworkBoxType;
	}

	public void setXaSecondaryNetworkBoxType(String xaSecondaryNetworkBoxType) {
		this.xaSecondaryNetworkBoxType = xaSecondaryNetworkBoxType;
	}

	public String getXaSecondaryNetworkCabinet() {
		return xaSecondaryNetworkCabinet;
	}

	public void setXaSecondaryNetworkCabinet(String xaSecondaryNetworkCabinet) {
		this.xaSecondaryNetworkCabinet = xaSecondaryNetworkCabinet;
	}

	public String getXaSecondaryNetworkCabinetAdd() {
		return xaSecondaryNetworkCabinetAdd;
	}

	public void setXaSecondaryNetworkCabinetAdd(String xaSecondaryNetworkCabinetAdd) {
		this.xaSecondaryNetworkCabinetAdd = xaSecondaryNetworkCabinetAdd;
	}

	public String getXaSecondaryNetworkCabinetTrf() {
		return xaSecondaryNetworkCabinetTrf;
	}

	public void setXaSecondaryNetworkCabinetTrf(String xaSecondaryNetworkCabinetTrf) {
		this.xaSecondaryNetworkCabinetTrf = xaSecondaryNetworkCabinetTrf;
	}

	public String getXaSecondaryNetworkCabinetTyp() {
		return xaSecondaryNetworkCabinetTyp;
	}

	public void setXaSecondaryNetworkCabinetTyp(String xaSecondaryNetworkCabinetTyp) {
		this.xaSecondaryNetworkCabinetTyp = xaSecondaryNetworkCabinetTyp;
	}

	public String getXaSecondaryNetworkCable() {
		return xaSecondaryNetworkCable;
	}

	public void setXaSecondaryNetworkCable(String xaSecondaryNetworkCable) {
		this.xaSecondaryNetworkCable = xaSecondaryNetworkCable;
	}

	public String getXaSecondaryNetworkInternalBox() {
		return xaSecondaryNetworkInternalBox;
	}

	public void setXaSecondaryNetworkInternalBox(String xaSecondaryNetworkInternalBox) {
		this.xaSecondaryNetworkInternalBox = xaSecondaryNetworkInternalBox;
	}

	public String getXaSecondaryNetworkInternalBoxPlace() {
		return xaSecondaryNetworkInternalBoxPlace;
	}

	public void setXaSecondaryNetworkInternalBoxPlace(String xaSecondaryNetworkInternalBoxPlace) {
		this.xaSecondaryNetworkInternalBoxPlace = xaSecondaryNetworkInternalBoxPlace;
	}

	public String getXaSecondaryNetworkInternalBoxPort() {
		return xaSecondaryNetworkInternalBoxPort;
	}

	public void setXaSecondaryNetworkInternalBoxPort(String xaSecondaryNetworkInternalBoxPort) {
		this.xaSecondaryNetworkInternalBoxPort = xaSecondaryNetworkInternalBoxPort;
	}

	public String getXaSecondaryNetworkInternalBoxPwLev() {
		return xaSecondaryNetworkInternalBoxPwLev;
	}

	public void setXaSecondaryNetworkInternalBoxPwLev(String xaSecondaryNetworkInternalBoxPwLev) {
		this.xaSecondaryNetworkInternalBoxPwLev = xaSecondaryNetworkInternalBoxPwLev;
	}

	public String getXaSecondaryNetworkOntPowerLevel() {
		return xaSecondaryNetworkOntPowerLevel;
	}

	public void setXaSecondaryNetworkOntPowerLevel(String xaSecondaryNetworkOntPowerLevel) {
		this.xaSecondaryNetworkOntPowerLevel = xaSecondaryNetworkOntPowerLevel;
	}

	public String getXaSecondaryNetworkPort() {
		return xaSecondaryNetworkPort;
	}

	public void setXaSecondaryNetworkPort(String xaSecondaryNetworkPort) {
		this.xaSecondaryNetworkPort = xaSecondaryNetworkPort;
	}

	public String getXaSerialExtWifi1() {
		return xaSerialExtWifi1;
	}

	public void setXaSerialExtWifi1(String xaSerialExtWifi1) {
		this.xaSerialExtWifi1 = xaSerialExtWifi1;
	}

	public String getXaSerialExtWifi2() {
		return xaSerialExtWifi2;
	}

	public void setXaSerialExtWifi2(String xaSerialExtWifi2) {
		this.xaSerialExtWifi2 = xaSerialExtWifi2;
	}

	public String getXaSerialExtWifi3() {
		return xaSerialExtWifi3;
	}

	public void setXaSerialExtWifi3(String xaSerialExtWifi3) {
		this.xaSerialExtWifi3 = xaSerialExtWifi3;
	}

	public String getXaServiceId() {
		return xaServiceId;
	}

	public void setXaServiceId(String xaServiceId) {
		this.xaServiceId = xaServiceId;
	}

	public String getXaSignalService() {
		return xaSignalService;
	}

	public void setXaSignalService(String xaSignalService) {
		this.xaSignalService = xaSignalService;
	}

	public String getXaSuspendComment() {
		return xaSuspendComment;
	}

	public void setXaSuspendComment(String xaSuspendComment) {
		this.xaSuspendComment = xaSuspendComment;
	}

	public String getXaSuspendReason() {
		return xaSuspendReason;
	}

	public void setXaSuspendReason(String xaSuspendReason) {
		this.xaSuspendReason = xaSuspendReason;
	}

	public String getXaSyndicateContact() {
		return xaSyndicateContact;
	}

	public void setXaSyndicateContact(String xaSyndicateContact) {
		this.xaSyndicateContact = xaSyndicateContact;
	}

	public String getXaSyndicateContactTwo() {
		return xaSyndicateContactTwo;
	}

	public void setXaSyndicateContactTwo(String xaSyndicateContactTwo) {
		this.xaSyndicateContactTwo = xaSyndicateContactTwo;
	}

	public String getXaSyndicateName() {
		return xaSyndicateName;
	}

	public void setXaSyndicateName(String xaSyndicateName) {
		this.xaSyndicateName = xaSyndicateName;
	}

	public String getXaTemperature() {
		return xaTemperature;
	}

	public void setXaTemperature(String xaTemperature) {
		this.xaTemperature = xaTemperature;
	}

	public String getXaTtCauseCode() {
		return xaTtCauseCode;
	}

	public void setXaTtCauseCode(String xaTtCauseCode) {
		this.xaTtCauseCode = xaTtCauseCode;
	}

	public String getXaTtNotDoneReason() {
		return xaTtNotDoneReason;
	}

	public void setXaTtNotDoneReason(String xaTtNotDoneReason) {
		this.xaTtNotDoneReason = xaTtNotDoneReason;
	}

	public String getXaTtVoipNotDoneReason() {
		return xaTtVoipNotDoneReason;
	}

	public void setXaTtVoipNotDoneReason(String xaTtVoipNotDoneReason) {
		this.xaTtVoipNotDoneReason = xaTtVoipNotDoneReason;
	}

	public String getXaTypeOrder() {
		return xaTypeOrder;
	}

	public void setXaTypeOrder(String xaTypeOrder) {
		this.xaTypeOrder = xaTypeOrder;
	}

	public String getXaUploadDateLetter() {
		return xaUploadDateLetter;
	}

	public void setXaUploadDateLetter(String xaUploadDateLetter) {
		this.xaUploadDateLetter = xaUploadDateLetter;
	}

	public String getXaVlan2Ip() {
		return xaVlan2Ip;
	}

	public void setXaVlan2Ip(String xaVlan2Ip) {
		this.xaVlan2Ip = xaVlan2Ip;
	}

	public String getXaVoipProductId() {
		return xaVoipProductId;
	}

	public void setXaVoipProductId(String xaVoipProductId) {
		this.xaVoipProductId = xaVoipProductId;
	}

	public String getXaVoipValidation() {
		return xaVoipValidation;
	}

	public void setXaVoipValidation(String xaVoipValidation) {
		this.xaVoipValidation = xaVoipValidation;
	}

	public String getRowId() {
		return rowId;
	}

	public void setRowId(String rowId) {
		this.rowId = rowId;
	}

	public String getLoteid() {
		return loteid;
	}

	public void setLoteid(String loteid) {
		this.loteid = loteid;
	}

	public String getArquivo() {
		return arquivo;
	}

	public void setArquivo(String arquivo) {
		this.arquivo = arquivo;
	}

	public String getArquivots() {
		return arquivots;
	}

	public void setArquivots(String arquivots) {
		this.arquivots = arquivots;
	}

	public String getCurrentdate() {
		return currentdate;
	}

	public void setCurrentdate(String currentdate) {
		this.currentdate = currentdate;
	}
	
}
