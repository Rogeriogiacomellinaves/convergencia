package br.com.tim.mapreduce.e2e.step3;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

public class GroupingComparator extends WritableComparator {

    public GroupingComparator() {
        super(E2EStep3Key.class, true);
    }

    @SuppressWarnings({"rawtypes"})
    @Override
    public int compare(WritableComparable a, WritableComparable b) {
        E2EStep3Key keyA = (E2EStep3Key) a;
        E2EStep3Key keyB = (E2EStep3Key) b;

        return keyA.compareToGrouping(keyB);
    }

}
