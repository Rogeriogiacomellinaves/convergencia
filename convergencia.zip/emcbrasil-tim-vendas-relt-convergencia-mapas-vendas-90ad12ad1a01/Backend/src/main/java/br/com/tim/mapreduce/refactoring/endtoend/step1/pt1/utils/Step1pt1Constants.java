package br.com.tim.mapreduce.refactoring.endtoend.step1.pt1.utils;

public class Step1pt1Constants {
	
	public static final String STEP1PT1_NAME = "process-id-pt1";
	
	public static final String STEP1PT1_LOOK_BACK_DAYS = "lookback-days-item";
	
	public static final String STEP1PT1_ITEM_FACT_INPUT= "input-path-item";
	public static final String STEP1PT1_ITEM = "ITEM";
	public static final String STEP1PT1_OUTPUT = "output-path-step1";


}
