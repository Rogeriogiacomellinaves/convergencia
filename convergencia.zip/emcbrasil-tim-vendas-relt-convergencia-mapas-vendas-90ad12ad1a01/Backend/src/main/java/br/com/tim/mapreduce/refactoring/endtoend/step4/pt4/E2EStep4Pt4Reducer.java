package br.com.tim.mapreduce.refactoring.endtoend.step4.pt4;

import java.io.IOException;

import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.log4j.Logger;

import br.com.tim.mapreduce.refactoring.endtoend.step4.utils.Step4PT4Counters;


public class E2EStep4Pt4Reducer extends org.apache.hadoop.mapreduce.Reducer<E2EStep4Pt4Key,E2EStep4Pt4Value,NullWritable,Text> {

    protected static final Logger LOG = Logger.getLogger(E2EStep4Pt4Reducer.class);
    private E2EStep4Pt4OutValue outValue;


    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        super.setup(context);
        outValue = new E2EStep4Pt4OutValue();
    }

    @Override
    protected void reduce(E2EStep4Pt4Key key, Iterable<E2EStep4Pt4Value> values, Context context) throws InterruptedException {

        outValue.clear();

        try {
            for (E2EStep4Pt4Value value : values) {
                if (value.getTipo().equals(TypeStep4Pt4.RELT)){
                    outValue.clearRelt();
                    outValue.setRelt(value);
                    if (StringUtils.isEmpty(value.getNumeroAcesso()) || StringUtils.isEmpty(value.getCodContratoAtivacao())) {
                    	outValue.setFiberEmpty();
                    }
                    context.write(NullWritable.get(), new Text(outValue.toString()));
                    context.getCounter(Step4PT4Counters.STEP1PT4_REDUCER_WRITE).increment(1l);
                }else if (value.getTipo().equals(TypeStep4Pt4.Fiber)){
                    outValue.setFiber(value);
                }
            }

        } catch (Exception e) {
            LOG.error(" ############ ERROR EXECUTION REDUCER ############ ");
            LOG.error(e.getMessage());
            throw new InterruptedException(e.getMessage());
        }
    }



    @Override
    protected void cleanup(Context context) throws IOException, InterruptedException {
        super.cleanup(context);

    }
}


