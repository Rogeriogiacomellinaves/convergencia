
package br.com.tim.mapreduce.refactoring.endtoend.step1.pt3;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Writable;

import br.com.tim.mapreduce.refactoring.endtoend.step1.pt3.model.Step1pt2Result;
import br.com.tim.mapreduce.refactoring.model.Wfmtoa;
import br.com.tim.utils.CommonsConstants;

public class E2EStep1pt3Value implements Writable {
	
	protected TypeStep1pt3 tipo;
	protected String datRef;
	protected String datCriacaoOrdem;
	protected String horCriacaoOrdem;
	protected String datVenda;
	protected String horaVenda;
	protected String datStatusOrdem;
	protected String horStatusOrdem;
	protected String numOrdemSiebel;
	protected String codContratoOltp;
	protected String codContratoAtivacao;
	protected String numeroAcesso;
	protected String customerId;
	protected String tipoDocumento;
	protected String documento;
	protected String tipoVenda;
	protected String tipoProduto;
	protected String planoAtivacaoOferta;
	protected String loginVendedor;
	protected String canal;
	protected String cnpjParceiro;
	protected String custCode;
	protected String position;
	protected String flgCancAntesVenda;
	protected String flgCancPosVenda;
	protected String datCancVenda;
	protected String motivoCancelamento;
	protected String nomeCliente;
	protected String telefone;
	protected String email;
	protected String uf;
	protected String tipoLogradouro;
	protected String logradouro;
	protected String numero;
	protected String complemento;
	protected String bairro;
	protected String cep;
	protected String cidade;
	protected String statusOrdem;
	protected String tecnologia;
	protected String formaPagamento;
	protected String tipoConta;
	protected String codBanco;
	protected String codAgenciaBanco;
	protected String codContaCorrente;
	protected String codDebitoAutomatico;
	protected String diaVencimento;
	protected String semanaVenda;
	protected String score;
	protected String scoreConsumido;
	protected String datFinalizacaoOrdem;
	protected String qtdContratos;
	protected String numProtocolo;
	protected String flgOrdemAutomatica;
	protected String dscTxRecorrente;
	protected String dscTxNaoRecorrente;
	protected String dscStatusItem;
	protected String nomLoginResponsavel;
	protected String flgPortabilidade;
	protected String dscOperadoraDoadora;
	protected String codDdd;
	protected String numTelefonePortado;
	protected String datJanelaPortabilidade;
	protected String horJanela;
	protected String dscEnderecoFatura;
	protected String dscAreaVoip;
	protected String cpe;
	protected String ont;
	protected String detalheRecusaCrivo;
	protected String itemRoot;
	protected String loginCancelamentoOrdem;
	protected String dominioRoot;
	protected String codContaFinanceira;
	protected String nomPlanoAtual;
	protected String valPlanoAtualItem;
	protected String nomDescontoAtualItem;
	protected String valDescontoAtualItem;
	protected String nroOrdem;
	protected String acessoRowId;
	protected String acessoRowIdRoot;
	protected String codigoProduto;
	protected String datVendaOrig;
	protected String horVendaOrig;
	protected String numOrdemSiebelOrig;
	protected String loginVendedorOrig;
	protected String canalOrig;
	protected String cnpjParceiroOrig;
	protected String custCodeOrig;
	protected String positionOrig;
	protected String flgVendaSubmetida;
	protected String flgVendaDuplicada;
	protected String flgVendaBruta;
	protected String flgVendaLiquida;
	protected String flgCancDupl;
	protected String flgCancLiquido;
	protected String semanaVendaOrig;
	protected String nomeParceiroVenda;
	protected String nomeParceiroVendaOrig;
	protected String rowIdDoItemDaOrdem;
	protected String rowIdDoItemDaOrdemPai;
	protected String categoriaItemOrdem;
	protected String msan_olt_venda;
	protected String dt_conclusao_wfm;
	protected String dscStatusOrdemWfm;
	protected String datStatusWfm;
	protected String horaStatusWfm;
	protected String idRecursoWfm;
	protected String nomRecursoWfm;
	protected String idRecursoPaiWfm;
	protected String datPrimeiroAgend;
	protected String horaPrimeiroAgendamento;
	protected String datAgendAtual;
	protected String horaAgendamentoAtual;
	protected String dscStatusAtivacao;
	
	

	@Override
	public void readFields(DataInput dataInput) throws IOException {
		this.tipo = TypeStep1pt3.values()[dataInput.readInt()];
		this.datRef = dataInput.readUTF();
		this.datCriacaoOrdem = dataInput.readUTF();
		this.horCriacaoOrdem = dataInput.readUTF();
		this.datVenda = dataInput.readUTF();
		this.horaVenda = dataInput.readUTF();
		this.datStatusOrdem = dataInput.readUTF();
		this.horStatusOrdem = dataInput.readUTF();
		this.numOrdemSiebel = dataInput.readUTF();
		this.codContratoOltp = dataInput.readUTF();
		this.codContratoAtivacao = dataInput.readUTF();
		this.numeroAcesso = dataInput.readUTF();
		this.customerId = dataInput.readUTF();
		this.tipoDocumento = dataInput.readUTF();
		this.documento = dataInput.readUTF();
		this.tipoVenda = dataInput.readUTF();
		this.tipoProduto = dataInput.readUTF();
		this.planoAtivacaoOferta = dataInput.readUTF();
		this.loginVendedor = dataInput.readUTF();
		this.canal = dataInput.readUTF();
		this.cnpjParceiro = dataInput.readUTF();
		this.custCode = dataInput.readUTF();
		this.position = dataInput.readUTF();
		this.flgCancAntesVenda = dataInput.readUTF();
		this.flgCancPosVenda = dataInput.readUTF();
		this.datCancVenda = dataInput.readUTF();
		this.motivoCancelamento = dataInput.readUTF();
		this.nomeCliente = dataInput.readUTF();
		this.telefone = dataInput.readUTF();
		this.email = dataInput.readUTF();
		this.uf = dataInput.readUTF();
		this.tipoLogradouro = dataInput.readUTF();
		this.logradouro = dataInput.readUTF();
		this.numero = dataInput.readUTF();
		this.complemento = dataInput.readUTF();
		this.bairro = dataInput.readUTF();
		this.cep = dataInput.readUTF();
		this.cidade = dataInput.readUTF();
		this.statusOrdem = dataInput.readUTF();
		this.tecnologia = dataInput.readUTF();
		this.formaPagamento = dataInput.readUTF();
		this.tipoConta = dataInput.readUTF();
		this.codBanco = dataInput.readUTF();
		this.codAgenciaBanco = dataInput.readUTF();
		this.codContaCorrente = dataInput.readUTF();
		this.codDebitoAutomatico = dataInput.readUTF();
		this.diaVencimento = dataInput.readUTF();
		this.semanaVenda = dataInput.readUTF();
		this.score = dataInput.readUTF();
		this.scoreConsumido = dataInput.readUTF();
		this.datFinalizacaoOrdem = dataInput.readUTF();
		this.qtdContratos = dataInput.readUTF();
		this.numProtocolo = dataInput.readUTF();
		this.flgOrdemAutomatica = dataInput.readUTF();
		this.dscTxRecorrente = dataInput.readUTF();
		this.dscTxNaoRecorrente = dataInput.readUTF();
		this.dscStatusItem = dataInput.readUTF();
		this.nomLoginResponsavel = dataInput.readUTF();
		this.flgPortabilidade = dataInput.readUTF();
		this.dscOperadoraDoadora = dataInput.readUTF();
		this.codDdd = dataInput.readUTF();
		this.numTelefonePortado = dataInput.readUTF();
		this.datJanelaPortabilidade = dataInput.readUTF();
		this.horJanela = dataInput.readUTF();
		this.dscEnderecoFatura = dataInput.readUTF();
		this.dscAreaVoip = dataInput.readUTF();
		this.cpe = dataInput.readUTF();
		this.ont = dataInput.readUTF();
		this.detalheRecusaCrivo = dataInput.readUTF();
		this.itemRoot = dataInput.readUTF();
		this.loginCancelamentoOrdem = dataInput.readUTF();
		this.dominioRoot = dataInput.readUTF();
		this.codContaFinanceira = dataInput.readUTF();
		this.nomPlanoAtual = dataInput.readUTF();
		this.valPlanoAtualItem = dataInput.readUTF();
		this.nomDescontoAtualItem = dataInput.readUTF();
		this.valDescontoAtualItem = dataInput.readUTF();
		this.nroOrdem = dataInput.readUTF();
		this.acessoRowId = dataInput.readUTF();
		this.acessoRowIdRoot = dataInput.readUTF();
		this.codigoProduto = dataInput.readUTF();
		this.datVendaOrig = dataInput.readUTF();
		this.horVendaOrig = dataInput.readUTF();
		this.numOrdemSiebelOrig = dataInput.readUTF();
		this.loginVendedorOrig = dataInput.readUTF();
		this.canalOrig = dataInput.readUTF();
		this.cnpjParceiroOrig = dataInput.readUTF();
		this.custCodeOrig = dataInput.readUTF();
		this.positionOrig = dataInput.readUTF();
		this.flgVendaSubmetida = dataInput.readUTF();
		this.flgVendaDuplicada = dataInput.readUTF();
		this.flgVendaBruta = dataInput.readUTF();
		this.flgVendaLiquida = dataInput.readUTF();
		this.flgCancDupl = dataInput.readUTF();
		this.flgCancLiquido = dataInput.readUTF();
		this.semanaVendaOrig = dataInput.readUTF();
		this.nomeParceiroVenda = dataInput.readUTF();
		this.nomeParceiroVendaOrig = dataInput.readUTF();
		this.rowIdDoItemDaOrdem = dataInput.readUTF();
		this.rowIdDoItemDaOrdemPai = dataInput.readUTF();
		this.categoriaItemOrdem = dataInput.readUTF();
		this.msan_olt_venda = dataInput.readUTF();
		this.dt_conclusao_wfm = dataInput.readUTF();
		this.dscStatusOrdemWfm = dataInput.readUTF();
		this.datStatusWfm = dataInput.readUTF();
		this.horaStatusWfm = dataInput.readUTF();
		this.idRecursoWfm = dataInput.readUTF();
		this.nomRecursoWfm = dataInput.readUTF();
		this.idRecursoPaiWfm = dataInput.readUTF();
		this.datPrimeiroAgend = dataInput.readUTF();
		this.horaPrimeiroAgendamento = dataInput.readUTF();
		this.datAgendAtual = dataInput.readUTF();
		this.horaAgendamentoAtual = dataInput.readUTF();
		this.dscStatusAtivacao = dataInput.readUTF();
		
	}

	@Override
	public void write(DataOutput dataOutput) throws IOException {
		dataOutput.writeInt(tipo.ordinal());
		dataOutput.writeUTF(datRef);
		dataOutput.writeUTF(datCriacaoOrdem);
		dataOutput.writeUTF(horCriacaoOrdem);
		dataOutput.writeUTF(datVenda);
		dataOutput.writeUTF(horaVenda);
		dataOutput.writeUTF(datStatusOrdem);
		dataOutput.writeUTF(horStatusOrdem);
		dataOutput.writeUTF(numOrdemSiebel);
		dataOutput.writeUTF(codContratoOltp);
		dataOutput.writeUTF(codContratoAtivacao);
		dataOutput.writeUTF(numeroAcesso);
		dataOutput.writeUTF(customerId);
		dataOutput.writeUTF(tipoDocumento);
		dataOutput.writeUTF(documento);
		dataOutput.writeUTF(tipoVenda);
		dataOutput.writeUTF(tipoProduto);
		dataOutput.writeUTF(planoAtivacaoOferta);
		dataOutput.writeUTF(loginVendedor);
		dataOutput.writeUTF(canal);
		dataOutput.writeUTF(cnpjParceiro);
		dataOutput.writeUTF(custCode);
		dataOutput.writeUTF(position);
		dataOutput.writeUTF(flgCancAntesVenda);
		dataOutput.writeUTF(flgCancPosVenda);
		dataOutput.writeUTF(datCancVenda);
		dataOutput.writeUTF(motivoCancelamento);
		dataOutput.writeUTF(nomeCliente);
		dataOutput.writeUTF(telefone);
		dataOutput.writeUTF(email);
		dataOutput.writeUTF(uf);
		dataOutput.writeUTF(tipoLogradouro);
		dataOutput.writeUTF(logradouro);
		dataOutput.writeUTF(numero);
		dataOutput.writeUTF(complemento);
		dataOutput.writeUTF(bairro);
		dataOutput.writeUTF(cep);
		dataOutput.writeUTF(cidade);
		dataOutput.writeUTF(statusOrdem);
		dataOutput.writeUTF(tecnologia);
		dataOutput.writeUTF(formaPagamento);
		dataOutput.writeUTF(tipoConta);
		dataOutput.writeUTF(codBanco);
		dataOutput.writeUTF(codAgenciaBanco);
		dataOutput.writeUTF(codContaCorrente);
		dataOutput.writeUTF(codDebitoAutomatico);
		dataOutput.writeUTF(diaVencimento);
		dataOutput.writeUTF(semanaVenda);
		dataOutput.writeUTF(score);
		dataOutput.writeUTF(scoreConsumido);
		dataOutput.writeUTF(datFinalizacaoOrdem);
		dataOutput.writeUTF(qtdContratos);
		dataOutput.writeUTF(numProtocolo);
		dataOutput.writeUTF(flgOrdemAutomatica);
		dataOutput.writeUTF(dscTxRecorrente);
		dataOutput.writeUTF(dscTxNaoRecorrente);
		dataOutput.writeUTF(dscStatusItem);
		dataOutput.writeUTF(nomLoginResponsavel);
		dataOutput.writeUTF(flgPortabilidade);
		dataOutput.writeUTF(dscOperadoraDoadora);
		dataOutput.writeUTF(codDdd);
		dataOutput.writeUTF(numTelefonePortado);
		dataOutput.writeUTF(datJanelaPortabilidade);
		dataOutput.writeUTF(horJanela);
		dataOutput.writeUTF(dscEnderecoFatura);
		dataOutput.writeUTF(dscAreaVoip);
		dataOutput.writeUTF(cpe);
		dataOutput.writeUTF(ont);
		dataOutput.writeUTF(detalheRecusaCrivo);
		dataOutput.writeUTF(itemRoot);
		dataOutput.writeUTF(loginCancelamentoOrdem);
		dataOutput.writeUTF(dominioRoot);
		dataOutput.writeUTF(codContaFinanceira);
		dataOutput.writeUTF(nomPlanoAtual);
		dataOutput.writeUTF(valPlanoAtualItem);
		dataOutput.writeUTF(nomDescontoAtualItem);
		dataOutput.writeUTF(valDescontoAtualItem);
		dataOutput.writeUTF(nroOrdem);
		dataOutput.writeUTF(acessoRowId);
		dataOutput.writeUTF(acessoRowIdRoot);
		dataOutput.writeUTF(codigoProduto);
		dataOutput.writeUTF(datVendaOrig);
		dataOutput.writeUTF(horVendaOrig);
		dataOutput.writeUTF(numOrdemSiebelOrig);
		dataOutput.writeUTF(loginVendedorOrig);
		dataOutput.writeUTF(canalOrig);
		dataOutput.writeUTF(cnpjParceiroOrig);
		dataOutput.writeUTF(custCodeOrig);
		dataOutput.writeUTF(positionOrig);
		dataOutput.writeUTF(flgVendaSubmetida);
		dataOutput.writeUTF(flgVendaDuplicada);
		dataOutput.writeUTF(flgVendaBruta);
		dataOutput.writeUTF(flgVendaLiquida);
		dataOutput.writeUTF(flgCancDupl);
		dataOutput.writeUTF(flgCancLiquido);
		dataOutput.writeUTF(semanaVendaOrig);
		dataOutput.writeUTF(nomeParceiroVenda);
		dataOutput.writeUTF(nomeParceiroVendaOrig);
		dataOutput.writeUTF(rowIdDoItemDaOrdem);
		dataOutput.writeUTF(rowIdDoItemDaOrdemPai);
		dataOutput.writeUTF(categoriaItemOrdem);
		dataOutput.writeUTF(msan_olt_venda);
		dataOutput.writeUTF(dt_conclusao_wfm);
		dataOutput.writeUTF(dscStatusOrdemWfm);
		dataOutput.writeUTF(datStatusWfm);
		dataOutput.writeUTF(horaStatusWfm);
		dataOutput.writeUTF(idRecursoWfm);
		dataOutput.writeUTF(nomRecursoWfm);
		dataOutput.writeUTF(idRecursoPaiWfm);
		dataOutput.writeUTF(datPrimeiroAgend);
		dataOutput.writeUTF(horaPrimeiroAgendamento);
		dataOutput.writeUTF(datAgendAtual);
		dataOutput.writeUTF(horaAgendamentoAtual);
		dataOutput.writeUTF(dscStatusAtivacao);
		
	}
	
	public void setStep9PT2Result(Step1pt2Result result) {
		this.clear();
		this.tipo = TypeStep1pt3.RELT;
		
		this.datRef = result.getDatRef();
		this.datCriacaoOrdem = result.getDatCriacaoOrdem();
		this.horCriacaoOrdem = result.getHorCriacaoOrdem();
		this.datVenda = result.getDatVenda();
		this.horaVenda = result.getHoraVenda();
		this.datStatusOrdem = result.getDatStatusOrdem();
		this.horStatusOrdem = result.getHorStatusOrdem();
		this.numOrdemSiebel = result.getNumOrdemSiebel();
		this.codContratoOltp = result.getCodContratoOltp();
		this.codContratoAtivacao = result.getCodContratoAtivacao();
		this.numeroAcesso = result.getNumeroAcesso();
		this.customerId = result.getCustomerId();
		this.tipoDocumento = result.getTipoDocumento();
		this.documento = result.getDocumento();
		this.tipoVenda = result.getTipoVenda();
		this.tipoProduto = result.getTipoProduto();
		this.planoAtivacaoOferta = result.getPlanoAtivacaoOferta();
		this.loginVendedor = result.getLoginVendedor();
		this.canal = result.getCanal();
		this.cnpjParceiro = result.getCnpjParceiro();
		this.custCode = result.getCustCode();
		this.position = result.getPosition();
		this.flgCancAntesVenda = result.getFlgCancAntesVenda();
		this.flgCancPosVenda = result.getFlgCancPosVenda();
		this.datCancVenda = result.getDatCancVenda();
		this.motivoCancelamento = result.getMotivoCancelamento();
		this.nomeCliente = result.getNomeCliente();
		this.telefone = result.getTelefone();
		this.email = result.getEmail();
		this.uf = result.getUf();
		this.tipoLogradouro = result.getTipoLogradouro();
		this.logradouro = result.getLogradouro();
		this.numero = result.getNumero();
		this.complemento = result.getComplemento();
		this.bairro = result.getBairro();
		this.cep = result.getCep();
		this.cidade = result.getCidade();
		this.statusOrdem = result.getStatusOrdem();
		this.tecnologia = result.getTecnologia();
		this.formaPagamento = result.getFormaPagamento();
		this.tipoConta = result.getTipoConta();
		this.codBanco = result.getCodBanco();
		this.codAgenciaBanco = result.getCodAgenciaBanco();
		this.codContaCorrente = result.getCodContaCorrente();
		this.codDebitoAutomatico = result.getCodDebitoAutomatico();
		this.diaVencimento = result.getDiaVencimento();
		this.semanaVenda = result.getSemanaVenda();
		this.score = result.getScore();
		this.scoreConsumido = result.getScoreConsumido();
		this.datFinalizacaoOrdem = result.getDatFinalizacaoOrdem();
		this.qtdContratos = result.getQtdContratos();
		this.numProtocolo = result.getNumProtocolo();
		this.flgOrdemAutomatica = result.getFlgOrdemAutomatica();
		this.dscTxRecorrente = result.getDscTxRecorrente();
		this.dscTxNaoRecorrente = result.getDscTxNaoRecorrente();
		this.dscStatusItem = result.getDscStatusItem();
		this.nomLoginResponsavel = result.getNomLoginResponsavel();
		this.flgPortabilidade = result.getFlgPortabilidade();
		this.dscOperadoraDoadora = result.getDscOperadoraDoadora();
		this.codDdd = result.getCodDdd();
		this.numTelefonePortado = result.getNumTelefonePortado();
		this.datJanelaPortabilidade = result.getDatJanelaPortabilidade();
		this.horJanela = result.getHorJanela();
		this.dscEnderecoFatura = result.getDscEnderecoFatura();
		this.dscAreaVoip = result.getDscAreaVoip();
		this.cpe = result.getCpe();
		this.ont = result.getOnt();
		this.detalheRecusaCrivo = result.getDetalheRecusaCrivo();
		this.itemRoot = result.getItemRoot();
		this.loginCancelamentoOrdem = result.getLoginCancelamentoOrdem();
		this.dominioRoot = result.getDominioRoot();
		this.codContaFinanceira = result.getCodContaFinanceira();
		this.nomPlanoAtual = result.getNomPlanoAtual();
		this.valPlanoAtualItem = result.getValPlanoAtualItem();
		this.nomDescontoAtualItem = result.getNomDescontoAtualItem();
		this.valDescontoAtualItem = result.getValDescontoAtualItem();
		this.nroOrdem = result.getNroOrdem();
		this.acessoRowId = result.getAcessoRowId();
		this.acessoRowIdRoot = result.getAcessoRowIdRoot();
		this.codigoProduto = result.getCodigoProduto();
		this.datVendaOrig = result.getDatVendaOrig();
		this.horVendaOrig = result.getHorVendaOrig();
		this.numOrdemSiebelOrig = result.getNumOrdemSiebelOrig();
		this.loginVendedorOrig = result.getLoginVendedorOrig();
		this.canalOrig = result.getCanalOrig();
		this.cnpjParceiroOrig = result.getCnpjParceiroOrig();
		this.custCodeOrig = result.getCustCodeOrig();
		this.positionOrig = result.getPositionOrig();
		this.flgVendaSubmetida = result.getFlgVendaSubmetida();
		this.flgVendaDuplicada = result.getFlgVendaDuplicada();
		this.flgVendaBruta = result.getFlgVendaBruta();
		this.flgVendaLiquida = result.getFlgVendaLiquida();
		this.flgCancDupl = result.getFlgCancDupl();
		this.flgCancLiquido = result.getFlgCancLiquido();
		this.semanaVendaOrig = result.getSemanaVendaOrig();
		this.nomeParceiroVenda = result.getNomeParceiroVenda();
		this.nomeParceiroVendaOrig = result.getNomeParceiroVendaOrig();
		this.rowIdDoItemDaOrdem = result.getRowIdDoItemDaOrdem();
		this.rowIdDoItemDaOrdemPai = result.getRowIdDoItemDaOrdemPai();
		this.categoriaItemOrdem = result.getCategoriaItemOrdem();
		
	}
	
	
	
	public void setWfmtoa(Wfmtoa wfm) {
		this.clear();
		this.tipo = TypeStep1pt3.WFMTOA;
		this.msan_olt_venda = wfm.getXaPrimaryNetworkMsan();
		this.dt_conclusao_wfm = wfm.getQueueDate().trim() +" " + wfm.getEndTime().trim();
		this.dscStatusOrdemWfm = wfm.getAstatus();
	
		if(wfm.getAstatus().trim().equals("pending")) {
			this.datStatusWfm = wfm.getAtimeOfBooking().trim().substring(0, 10);
			this.horaStatusWfm = wfm.getAtimeOfBooking().trim().substring(11, 19); 
		}else if(wfm.getAstatus().trim().equals("suspended") ||
				wfm.getAstatus().trim().equals("notdone") ||
				wfm.getAstatus().trim().equals("completed")) {
			this.datStatusWfm = wfm.getQueueDate().trim() + " " + wfm.getEndTime().trim();
			this.horaStatusWfm = wfm.getEndTime();
		}else if(wfm.getAstatus().trim().equals("cancelled")) {
			this.datStatusWfm = "";
			this.horaStatusWfm = "";
		}
		
		this.idRecursoWfm = wfm.getExternalId();
		this.nomRecursoWfm = wfm.getPname();
		this.idRecursoPaiWfm = wfm.getParent();

		if (wfm.getaTimeOfBooking().trim().length() >=9) {
			this.datPrimeiroAgend = wfm.getaTimeOfBooking().trim().substring(0, 10);
		}
		
		if (wfm.getaTimeOfBooking().trim().length() >=20) {
			this.horaPrimeiroAgendamento = wfm.getaTimeOfBooking().trim().substring(11, 19);
		}
		
		if(wfm.getQueueDate().trim().length() >= 9) {
			this.datAgendAtual = wfm.getQueueDate().trim().substring(0, 10);
		}
		
		if(wfm.getEta().trim().length() >= 19) {
			this.horaAgendamentoAtual = wfm.getEta().trim().substring(11, 19); 
		}
		
		if(wfm.getaTimeOfBooking().trim().length() >= 9) {
			this.datPrimeiroAgend = wfm.getaTimeOfBooking().trim().substring(0, 10);
		}
				
		if (wfm.getaTimeOfBooking().trim().length() >=20) {
			this.horaPrimeiroAgendamento = wfm.getaTimeOfBooking().trim().substring(11, 19);
		}
		
		this.dscStatusAtivacao = wfm.getXaCompletionCode();
		
	}
	
	
	public void clear(){
        this.tipo = null;
        this.datRef = CommonsConstants.EMPTY;
        this.datCriacaoOrdem = CommonsConstants.EMPTY;
        this.horCriacaoOrdem = CommonsConstants.EMPTY;
        this.datVenda = CommonsConstants.EMPTY;
        this.horaVenda = CommonsConstants.EMPTY;
        this.datStatusOrdem = CommonsConstants.EMPTY;
        this.horStatusOrdem = CommonsConstants.EMPTY;
        this.numOrdemSiebel = CommonsConstants.EMPTY;
        this.codContratoOltp = CommonsConstants.EMPTY;
        this.codContratoAtivacao = CommonsConstants.EMPTY;
        this.numeroAcesso = CommonsConstants.EMPTY;
        this.customerId = CommonsConstants.EMPTY;
        this.tipoDocumento = CommonsConstants.EMPTY;
        this.documento = CommonsConstants.EMPTY;
        this.tipoVenda = CommonsConstants.EMPTY;
        this.tipoProduto = CommonsConstants.EMPTY;
        this.planoAtivacaoOferta = CommonsConstants.EMPTY;
        this.loginVendedor = CommonsConstants.EMPTY;
        this.canal = CommonsConstants.EMPTY;
        this.cnpjParceiro = CommonsConstants.EMPTY;
        this.custCode = CommonsConstants.EMPTY;
        this.position = CommonsConstants.EMPTY;
        this.flgCancAntesVenda = CommonsConstants.EMPTY;
        this.flgCancPosVenda = CommonsConstants.EMPTY;
        this.datCancVenda = CommonsConstants.EMPTY;
        this.motivoCancelamento = CommonsConstants.EMPTY;
        this.nomeCliente = CommonsConstants.EMPTY;
        this.telefone = CommonsConstants.EMPTY;
        this.email = CommonsConstants.EMPTY;
        this.uf = CommonsConstants.EMPTY;
        this.tipoLogradouro = CommonsConstants.EMPTY;
        this.logradouro = CommonsConstants.EMPTY;
        this.numero = CommonsConstants.EMPTY;
        this.complemento = CommonsConstants.EMPTY;
        this.bairro = CommonsConstants.EMPTY;
        this.cep = CommonsConstants.EMPTY;
        this.cidade = CommonsConstants.EMPTY;
        this.statusOrdem = CommonsConstants.EMPTY;
        this.tecnologia = CommonsConstants.EMPTY;
        this.formaPagamento = CommonsConstants.EMPTY;
        this.tipoConta = CommonsConstants.EMPTY;
        this.codBanco = CommonsConstants.EMPTY;
        this.codAgenciaBanco = CommonsConstants.EMPTY;
        this.codContaCorrente = CommonsConstants.EMPTY;
        this.codDebitoAutomatico = CommonsConstants.EMPTY;
        this.diaVencimento = CommonsConstants.EMPTY;
        this.semanaVenda = CommonsConstants.EMPTY;
        this.score = CommonsConstants.EMPTY;
        this.scoreConsumido = CommonsConstants.EMPTY;
        this.datFinalizacaoOrdem = CommonsConstants.EMPTY;
        this.qtdContratos = CommonsConstants.EMPTY;
        this.numProtocolo = CommonsConstants.EMPTY;
        this.flgOrdemAutomatica = CommonsConstants.EMPTY;
        this.dscTxRecorrente = CommonsConstants.EMPTY;
        this.dscTxNaoRecorrente = CommonsConstants.EMPTY;
        this.dscStatusItem = CommonsConstants.EMPTY;
        this.nomLoginResponsavel = CommonsConstants.EMPTY;
        this.flgPortabilidade = CommonsConstants.EMPTY;
        this.dscOperadoraDoadora = CommonsConstants.EMPTY;
        this.codDdd = CommonsConstants.EMPTY;
        this.numTelefonePortado = CommonsConstants.EMPTY;
        this.datJanelaPortabilidade = CommonsConstants.EMPTY;
        this.horJanela = CommonsConstants.EMPTY;
        this.dscEnderecoFatura = CommonsConstants.EMPTY;
        this.dscAreaVoip = CommonsConstants.EMPTY;
        this.cpe = CommonsConstants.EMPTY;
        this.ont = CommonsConstants.EMPTY;
        this.detalheRecusaCrivo = CommonsConstants.EMPTY;
        this.itemRoot = CommonsConstants.EMPTY;
        this.loginCancelamentoOrdem = CommonsConstants.EMPTY;
        this.dominioRoot = CommonsConstants.EMPTY;
        this.codContaFinanceira = CommonsConstants.EMPTY;
        this.nomPlanoAtual = CommonsConstants.EMPTY;
        this.valPlanoAtualItem = CommonsConstants.EMPTY;
        this.nomDescontoAtualItem = CommonsConstants.EMPTY;
        this.valDescontoAtualItem = CommonsConstants.EMPTY;
        this.nroOrdem = CommonsConstants.EMPTY;
        this.acessoRowId = CommonsConstants.EMPTY;
        this.acessoRowIdRoot = CommonsConstants.EMPTY;
        this.codigoProduto = CommonsConstants.EMPTY;
        this.datVendaOrig = CommonsConstants.EMPTY;
        this.horVendaOrig = CommonsConstants.EMPTY;
        this.numOrdemSiebelOrig = CommonsConstants.EMPTY;
        this.loginVendedorOrig = CommonsConstants.EMPTY;
        this.canalOrig = CommonsConstants.EMPTY;
        this.cnpjParceiroOrig = CommonsConstants.EMPTY;
        this.custCodeOrig = CommonsConstants.EMPTY;
        this.positionOrig = CommonsConstants.EMPTY;
        this.flgVendaSubmetida = CommonsConstants.EMPTY;
        this.flgVendaDuplicada = CommonsConstants.EMPTY;
        this.flgVendaBruta = CommonsConstants.EMPTY;
        this.flgVendaLiquida = CommonsConstants.EMPTY;
        this.flgCancDupl = CommonsConstants.EMPTY;
        this.flgCancLiquido = CommonsConstants.EMPTY;
        this.semanaVendaOrig = CommonsConstants.EMPTY;
        this.nomeParceiroVenda = CommonsConstants.EMPTY;
        this.nomeParceiroVendaOrig = CommonsConstants.EMPTY;
        this.rowIdDoItemDaOrdem = CommonsConstants.EMPTY;
        this.rowIdDoItemDaOrdemPai = CommonsConstants.EMPTY;
        this.categoriaItemOrdem = CommonsConstants.EMPTY;
        this.msan_olt_venda = CommonsConstants.EMPTY;
        this.dt_conclusao_wfm = CommonsConstants.EMPTY;
        this.dscStatusOrdemWfm = CommonsConstants.EMPTY;
        this.datStatusWfm = CommonsConstants.EMPTY;
        this.horaStatusWfm = CommonsConstants.EMPTY;
        this.idRecursoWfm = CommonsConstants.EMPTY;
        this.nomRecursoWfm = CommonsConstants.EMPTY;
        this.idRecursoPaiWfm = CommonsConstants.EMPTY;
        this.datPrimeiroAgend = CommonsConstants.EMPTY;
        this.horaPrimeiroAgendamento = CommonsConstants.EMPTY;
        this.datAgendAtual = CommonsConstants.EMPTY;
        this.horaAgendamentoAtual = CommonsConstants.EMPTY;
        this.dscStatusAtivacao = CommonsConstants.EMPTY;
	}

	public TypeStep1pt3 getTipo() {
		return tipo;
	}

	public void setTipo(TypeStep1pt3 tipo) {
		this.tipo = tipo;
	}

	public String getDatRef() {
		return datRef;
	}

	public void setDatRef(String datRef) {
		this.datRef = datRef;
	}

	public String getDatCriacaoOrdem() {
		return datCriacaoOrdem;
	}

	public void setDatCriacaoOrdem(String datCriacaoOrdem) {
		this.datCriacaoOrdem = datCriacaoOrdem;
	}

	public String getHorCriacaoOrdem() {
		return horCriacaoOrdem;
	}

	public void setHorCriacaoOrdem(String horCriacaoOrdem) {
		this.horCriacaoOrdem = horCriacaoOrdem;
	}

	public String getDatVenda() {
		return datVenda;
	}

	public void setDatVenda(String datVenda) {
		this.datVenda = datVenda;
	}

	public String getHoraVenda() {
		return horaVenda;
	}

	public void setHoraVenda(String horaVenda) {
		this.horaVenda = horaVenda;
	}

	public String getDatStatusOrdem() {
		return datStatusOrdem;
	}

	public void setDatStatusOrdem(String datStatusOrdem) {
		this.datStatusOrdem = datStatusOrdem;
	}

	public String getHorStatusOrdem() {
		return horStatusOrdem;
	}

	public void setHorStatusOrdem(String horStatusOrdem) {
		this.horStatusOrdem = horStatusOrdem;
	}

	public String getNumOrdemSiebel() {
		return numOrdemSiebel;
	}

	public void setNumOrdemSiebel(String numOrdemSiebel) {
		this.numOrdemSiebel = numOrdemSiebel;
	}

	public String getCodContratoOltp() {
		return codContratoOltp;
	}

	public void setCodContratoOltp(String codContratoOltp) {
		this.codContratoOltp = codContratoOltp;
	}

	public String getCodContratoAtivacao() {
		return codContratoAtivacao;
	}

	public void setCodContratoAtivacao(String codContratoAtivacao) {
		this.codContratoAtivacao = codContratoAtivacao;
	}

	public String getNumeroAcesso() {
		return numeroAcesso;
	}

	public void setNumeroAcesso(String numeroAcesso) {
		this.numeroAcesso = numeroAcesso;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public String getDocumento() {
		return documento;
	}

	public void setDocumento(String documento) {
		this.documento = documento;
	}

	public String getTipoVenda() {
		return tipoVenda;
	}

	public void setTipoVenda(String tipoVenda) {
		this.tipoVenda = tipoVenda;
	}

	public String getTipoProduto() {
		return tipoProduto;
	}

	public void setTipoProduto(String tipoProduto) {
		this.tipoProduto = tipoProduto;
	}

	public String getPlanoAtivacaoOferta() {
		return planoAtivacaoOferta;
	}

	public void setPlanoAtivacaoOferta(String planoAtivacaoOferta) {
		this.planoAtivacaoOferta = planoAtivacaoOferta;
	}

	public String getLoginVendedor() {
		return loginVendedor;
	}

	public void setLoginVendedor(String loginVendedor) {
		this.loginVendedor = loginVendedor;
	}

	public String getCanal() {
		return canal;
	}

	public void setCanal(String canal) {
		this.canal = canal;
	}

	public String getCnpjParceiro() {
		return cnpjParceiro;
	}

	public void setCnpjParceiro(String cnpjParceiro) {
		this.cnpjParceiro = cnpjParceiro;
	}

	public String getCustCode() {
		return custCode;
	}

	public void setCustCode(String custCode) {
		this.custCode = custCode;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getFlgCancAntesVenda() {
		return flgCancAntesVenda;
	}

	public void setFlgCancAntesVenda(String flgCancAntesVenda) {
		this.flgCancAntesVenda = flgCancAntesVenda;
	}

	public String getFlgCancPosVenda() {
		return flgCancPosVenda;
	}

	public void setFlgCancPosVenda(String flgCancPosVenda) {
		this.flgCancPosVenda = flgCancPosVenda;
	}

	public String getDatCancVenda() {
		return datCancVenda;
	}

	public void setDatCancVenda(String datCancVenda) {
		this.datCancVenda = datCancVenda;
	}

	public String getMotivoCancelamento() {
		return motivoCancelamento;
	}

	public void setMotivoCancelamento(String motivoCancelamento) {
		this.motivoCancelamento = motivoCancelamento;
	}

	public String getNomeCliente() {
		return nomeCliente;
	}

	public void setNomeCliente(String nomeCliente) {
		this.nomeCliente = nomeCliente;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	public String getTipoLogradouro() {
		return tipoLogradouro;
	}

	public void setTipoLogradouro(String tipoLogradouro) {
		this.tipoLogradouro = tipoLogradouro;
	}

	public String getLogradouro() {
		return logradouro;
	}

	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getComplemento() {
		return complemento;
	}

	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getStatusOrdem() {
		return statusOrdem;
	}

	public void setStatusOrdem(String statusOrdem) {
		this.statusOrdem = statusOrdem;
	}

	public String getTecnologia() {
		return tecnologia;
	}

	public void setTecnologia(String tecnologia) {
		this.tecnologia = tecnologia;
	}

	public String getFormaPagamento() {
		return formaPagamento;
	}

	public void setFormaPagamento(String formaPagamento) {
		this.formaPagamento = formaPagamento;
	}

	public String getTipoConta() {
		return tipoConta;
	}

	public void setTipoConta(String tipoConta) {
		this.tipoConta = tipoConta;
	}

	public String getCodBanco() {
		return codBanco;
	}

	public void setCodBanco(String codBanco) {
		this.codBanco = codBanco;
	}

	public String getCodAgenciaBanco() {
		return codAgenciaBanco;
	}

	public void setCodAgenciaBanco(String codAgenciaBanco) {
		this.codAgenciaBanco = codAgenciaBanco;
	}

	public String getCodContaCorrente() {
		return codContaCorrente;
	}

	public void setCodContaCorrente(String codContaCorrente) {
		this.codContaCorrente = codContaCorrente;
	}

	public String getCodDebitoAutomatico() {
		return codDebitoAutomatico;
	}

	public void setCodDebitoAutomatico(String codDebitoAutomatico) {
		this.codDebitoAutomatico = codDebitoAutomatico;
	}

	public String getDiaVencimento() {
		return diaVencimento;
	}

	public void setDiaVencimento(String diaVencimento) {
		this.diaVencimento = diaVencimento;
	}

	public String getSemanaVenda() {
		return semanaVenda;
	}

	public void setSemanaVenda(String semanaVenda) {
		this.semanaVenda = semanaVenda;
	}

	public String getScore() {
		return score;
	}

	public void setScore(String score) {
		this.score = score;
	}

	public String getScoreConsumido() {
		return scoreConsumido;
	}

	public void setScoreConsumido(String scoreConsumido) {
		this.scoreConsumido = scoreConsumido;
	}

	public String getDatFinalizacaoOrdem() {
		return datFinalizacaoOrdem;
	}

	public void setDatFinalizacaoOrdem(String datFinalizacaoOrdem) {
		this.datFinalizacaoOrdem = datFinalizacaoOrdem;
	}

	public String getQtdContratos() {
		return qtdContratos;
	}

	public void setQtdContratos(String qtdContratos) {
		this.qtdContratos = qtdContratos;
	}

	public String getNumProtocolo() {
		return numProtocolo;
	}

	public void setNumProtocolo(String numProtocolo) {
		this.numProtocolo = numProtocolo;
	}

	public String getFlgOrdemAutomatica() {
		return flgOrdemAutomatica;
	}

	public void setFlgOrdemAutomatica(String flgOrdemAutomatica) {
		this.flgOrdemAutomatica = flgOrdemAutomatica;
	}

	public String getDscTxRecorrente() {
		return dscTxRecorrente;
	}

	public void setDscTxRecorrente(String dscTxRecorrente) {
		this.dscTxRecorrente = dscTxRecorrente;
	}

	public String getDscTxNaoRecorrente() {
		return dscTxNaoRecorrente;
	}

	public void setDscTxNaoRecorrente(String dscTxNaoRecorrente) {
		this.dscTxNaoRecorrente = dscTxNaoRecorrente;
	}

	public String getDscStatusItem() {
		return dscStatusItem;
	}

	public void setDscStatusItem(String dscStatusItem) {
		this.dscStatusItem = dscStatusItem;
	}

	public String getNomLoginResponsavel() {
		return nomLoginResponsavel;
	}

	public void setNomLoginResponsavel(String nomLoginResponsavel) {
		this.nomLoginResponsavel = nomLoginResponsavel;
	}

	public String getFlgPortabilidade() {
		return flgPortabilidade;
	}

	public void setFlgPortabilidade(String flgPortabilidade) {
		this.flgPortabilidade = flgPortabilidade;
	}

	public String getDscOperadoraDoadora() {
		return dscOperadoraDoadora;
	}

	public void setDscOperadoraDoadora(String dscOperadoraDoadora) {
		this.dscOperadoraDoadora = dscOperadoraDoadora;
	}

	public String getCodDdd() {
		return codDdd;
	}

	public void setCodDdd(String codDdd) {
		this.codDdd = codDdd;
	}

	public String getNumTelefonePortado() {
		return numTelefonePortado;
	}

	public void setNumTelefonePortado(String numTelefonePortado) {
		this.numTelefonePortado = numTelefonePortado;
	}

	public String getDatJanelaPortabilidade() {
		return datJanelaPortabilidade;
	}

	public void setDatJanelaPortabilidade(String datJanelaPortabilidade) {
		this.datJanelaPortabilidade = datJanelaPortabilidade;
	}

	public String getHorJanela() {
		return horJanela;
	}

	public void setHorJanela(String horJanela) {
		this.horJanela = horJanela;
	}

	public String getDscEnderecoFatura() {
		return dscEnderecoFatura;
	}

	public void setDscEnderecoFatura(String dscEnderecoFatura) {
		this.dscEnderecoFatura = dscEnderecoFatura;
	}

	public String getDscAreaVoip() {
		return dscAreaVoip;
	}

	public void setDscAreaVoip(String dscAreaVoip) {
		this.dscAreaVoip = dscAreaVoip;
	}

	public String getCpe() {
		return cpe;
	}

	public void setCpe(String cpe) {
		this.cpe = cpe;
	}

	public String getOnt() {
		return ont;
	}

	public void setOnt(String ont) {
		this.ont = ont;
	}

	public String getDetalheRecusaCrivo() {
		return detalheRecusaCrivo;
	}

	public void setDetalheRecusaCrivo(String detalheRecusaCrivo) {
		this.detalheRecusaCrivo = detalheRecusaCrivo;
	}

	public String getItemRoot() {
		return itemRoot;
	}

	public void setItemRoot(String itemRoot) {
		this.itemRoot = itemRoot;
	}

	public String getLoginCancelamentoOrdem() {
		return loginCancelamentoOrdem;
	}

	public void setLoginCancelamentoOrdem(String loginCancelamentoOrdem) {
		this.loginCancelamentoOrdem = loginCancelamentoOrdem;
	}

	public String getDominioRoot() {
		return dominioRoot;
	}

	public void setDominioRoot(String dominioRoot) {
		this.dominioRoot = dominioRoot;
	}

	public String getCodContaFinanceira() {
		return codContaFinanceira;
	}

	public void setCodContaFinanceira(String codContaFinanceira) {
		this.codContaFinanceira = codContaFinanceira;
	}

	public String getNomPlanoAtual() {
		return nomPlanoAtual;
	}

	public void setNomPlanoAtual(String nomPlanoAtual) {
		this.nomPlanoAtual = nomPlanoAtual;
	}

	public String getValPlanoAtualItem() {
		return valPlanoAtualItem;
	}

	public void setValPlanoAtualItem(String valPlanoAtualItem) {
		this.valPlanoAtualItem = valPlanoAtualItem;
	}

	public String getNomDescontoAtualItem() {
		return nomDescontoAtualItem;
	}

	public void setNomDescontoAtualItem(String nomDescontoAtualItem) {
		this.nomDescontoAtualItem = nomDescontoAtualItem;
	}

	public String getValDescontoAtualItem() {
		return valDescontoAtualItem;
	}

	public void setValDescontoAtualItem(String valDescontoAtualItem) {
		this.valDescontoAtualItem = valDescontoAtualItem;
	}

	public String getNroOrdem() {
		return nroOrdem;
	}

	public void setNroOrdem(String nroOrdem) {
		this.nroOrdem = nroOrdem;
	}

	public String getAcessoRowId() {
		return acessoRowId;
	}

	public void setAcessoRowId(String acessoRowId) {
		this.acessoRowId = acessoRowId;
	}

	public String getAcessoRowIdRoot() {
		return acessoRowIdRoot;
	}

	public void setAcessoRowIdRoot(String acessoRowIdRoot) {
		this.acessoRowIdRoot = acessoRowIdRoot;
	}

	public String getCodigoProduto() {
		return codigoProduto;
	}

	public void setCodigoProduto(String codigoProduto) {
		this.codigoProduto = codigoProduto;
	}

	public String getDatVendaOrig() {
		return datVendaOrig;
	}

	public void setDatVendaOrig(String datVendaOrig) {
		this.datVendaOrig = datVendaOrig;
	}

	public String getHorVendaOrig() {
		return horVendaOrig;
	}

	public void setHorVendaOrig(String horVendaOrig) {
		this.horVendaOrig = horVendaOrig;
	}

	public String getNumOrdemSiebelOrig() {
		return numOrdemSiebelOrig;
	}

	public void setNumOrdemSiebelOrig(String numOrdemSiebelOrig) {
		this.numOrdemSiebelOrig = numOrdemSiebelOrig;
	}

	public String getLoginVendedorOrig() {
		return loginVendedorOrig;
	}

	public void setLoginVendedorOrig(String loginVendedorOrig) {
		this.loginVendedorOrig = loginVendedorOrig;
	}

	public String getCanalOrig() {
		return canalOrig;
	}

	public void setCanalOrig(String canalOrig) {
		this.canalOrig = canalOrig;
	}

	public String getCnpjParceiroOrig() {
		return cnpjParceiroOrig;
	}

	public void setCnpjParceiroOrig(String cnpjParceiroOrig) {
		this.cnpjParceiroOrig = cnpjParceiroOrig;
	}

	public String getCustCodeOrig() {
		return custCodeOrig;
	}

	public void setCustCodeOrig(String custCodeOrig) {
		this.custCodeOrig = custCodeOrig;
	}

	public String getPositionOrig() {
		return positionOrig;
	}

	public void setPositionOrig(String positionOrig) {
		this.positionOrig = positionOrig;
	}

	public String getFlgVendaSubmetida() {
		return flgVendaSubmetida;
	}

	public void setFlgVendaSubmetida(String flgVendaSubmetida) {
		this.flgVendaSubmetida = flgVendaSubmetida;
	}

	public String getFlgVendaDuplicada() {
		return flgVendaDuplicada;
	}

	public void setFlgVendaDuplicada(String flgVendaDuplicada) {
		this.flgVendaDuplicada = flgVendaDuplicada;
	}

	public String getFlgVendaBruta() {
		return flgVendaBruta;
	}

	public void setFlgVendaBruta(String flgVendaBruta) {
		this.flgVendaBruta = flgVendaBruta;
	}

	public String getFlgVendaLiquida() {
		return flgVendaLiquida;
	}

	public void setFlgVendaLiquida(String flgVendaLiquida) {
		this.flgVendaLiquida = flgVendaLiquida;
	}

	public String getFlgCancDupl() {
		return flgCancDupl;
	}

	public void setFlgCancDupl(String flgCancDupl) {
		this.flgCancDupl = flgCancDupl;
	}

	public String getFlgCancLiquido() {
		return flgCancLiquido;
	}

	public void setFlgCancLiquido(String flgCancLiquido) {
		this.flgCancLiquido = flgCancLiquido;
	}

	public String getSemanaVendaOrig() {
		return semanaVendaOrig;
	}

	public void setSemanaVendaOrig(String semanaVendaOrig) {
		this.semanaVendaOrig = semanaVendaOrig;
	}

	public String getNomeParceiroVenda() {
		return nomeParceiroVenda;
	}

	public void setNomeParceiroVenda(String nomeParceiroVenda) {
		this.nomeParceiroVenda = nomeParceiroVenda;
	}

	public String getNomeParceiroVendaOrig() {
		return nomeParceiroVendaOrig;
	}

	public void setNomeParceiroVendaOrig(String nomeParceiroVendaOrig) {
		this.nomeParceiroVendaOrig = nomeParceiroVendaOrig;
	}

	public String getRowIdDoItemDaOrdem() {
		return rowIdDoItemDaOrdem;
	}

	public void setRowIdDoItemDaOrdem(String rowIdDoItemDaOrdem) {
		this.rowIdDoItemDaOrdem = rowIdDoItemDaOrdem;
	}

	public String getRowIdDoItemDaOrdemPai() {
		return rowIdDoItemDaOrdemPai;
	}

	public void setRowIdDoItemDaOrdemPai(String rowIdDoItemDaOrdemPai) {
		this.rowIdDoItemDaOrdemPai = rowIdDoItemDaOrdemPai;
	}

	public String getCategoriaItemOrdem() {
		return categoriaItemOrdem;
	}

	public void setCategoriaItemOrdem(String categoriaItemOrdem) {
		this.categoriaItemOrdem = categoriaItemOrdem;
	}

	public String getMsan_olt_venda() {
		return msan_olt_venda;
	}

	public void setMsan_olt_venda(String msan_olt_venda) {
		this.msan_olt_venda = msan_olt_venda;
	}

	public String getDt_conclusao_wfm() {
		return dt_conclusao_wfm;
	}

	public void setDt_conclusao_wfm(String dt_conclusao_wfm) {
		this.dt_conclusao_wfm = dt_conclusao_wfm;
	}

	public String getDscStatusOrdemWfm() {
		return dscStatusOrdemWfm;
	}

	public void setDscStatusOrdemWfm(String dscStatusOrdemWfm) {
		this.dscStatusOrdemWfm = dscStatusOrdemWfm;
	}

	public String getDatStatusWfm() {
		return datStatusWfm;
	}

	public void setDatStatusWfm(String datStatusWfm) {
		this.datStatusWfm = datStatusWfm;
	}

	public String getHoraStatusWfm() {
		return horaStatusWfm;
	}

	public void setHoraStatusWfm(String horaStatusWfm) {
		this.horaStatusWfm = horaStatusWfm;
	}

	public String getIdRecursoWfm() {
		return idRecursoWfm;
	}

	public void setIdRecursoWfm(String idRecursoWfm) {
		this.idRecursoWfm = idRecursoWfm;
	}

	public String getNomRecursoWfm() {
		return nomRecursoWfm;
	}

	public void setNomRecursoWfm(String nomRecursoWfm) {
		this.nomRecursoWfm = nomRecursoWfm;
	}

	public String getIdRecursoPaiWfm() {
		return idRecursoPaiWfm;
	}

	public void setIdRecursoPaiWfm(String idRecursoPaiWfm) {
		this.idRecursoPaiWfm = idRecursoPaiWfm;
	}

	public String getDatPrimeiroAgend() {
		return datPrimeiroAgend;
	}

	public void setDatPrimeiroAgend(String datPrimeiroAgend) {
		this.datPrimeiroAgend = datPrimeiroAgend;
	}

	public String getHoraPrimeiroAgendamento() {
		return horaPrimeiroAgendamento;
	}

	public void setHoraPrimeiroAgendamento(String horaPrimeiroAgendamento) {
		this.horaPrimeiroAgendamento = horaPrimeiroAgendamento;
	}

	public String getDatAgendAtual() {
		return datAgendAtual;
	}

	public void setDatAgendAtual(String datAgendAtual) {
		this.datAgendAtual = datAgendAtual;
	}

	public String getHoraAgendamentoAtual() {
		return horaAgendamentoAtual;
	}

	public void setHoraAgendamentoAtual(String horaAgendamentoAtual) {
		this.horaAgendamentoAtual = horaAgendamentoAtual;
	}

	public String getDscStatusAtivacao() {
		return dscStatusAtivacao;
	}

	public void setDscStatusAtivacao(String dscStatusAtivacao) {
		this.dscStatusAtivacao = dscStatusAtivacao;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((acessoRowId == null) ? 0 : acessoRowId.hashCode());
		result = prime * result + ((acessoRowIdRoot == null) ? 0 : acessoRowIdRoot.hashCode());
		result = prime * result + ((bairro == null) ? 0 : bairro.hashCode());
		result = prime * result + ((canal == null) ? 0 : canal.hashCode());
		result = prime * result + ((canalOrig == null) ? 0 : canalOrig.hashCode());
		result = prime * result + ((categoriaItemOrdem == null) ? 0 : categoriaItemOrdem.hashCode());
		result = prime * result + ((cep == null) ? 0 : cep.hashCode());
		result = prime * result + ((cidade == null) ? 0 : cidade.hashCode());
		result = prime * result + ((cnpjParceiro == null) ? 0 : cnpjParceiro.hashCode());
		result = prime * result + ((cnpjParceiroOrig == null) ? 0 : cnpjParceiroOrig.hashCode());
		result = prime * result + ((codAgenciaBanco == null) ? 0 : codAgenciaBanco.hashCode());
		result = prime * result + ((codBanco == null) ? 0 : codBanco.hashCode());
		result = prime * result + ((codContaCorrente == null) ? 0 : codContaCorrente.hashCode());
		result = prime * result + ((codContaFinanceira == null) ? 0 : codContaFinanceira.hashCode());
		result = prime * result + ((codContratoAtivacao == null) ? 0 : codContratoAtivacao.hashCode());
		result = prime * result + ((codContratoOltp == null) ? 0 : codContratoOltp.hashCode());
		result = prime * result + ((codDdd == null) ? 0 : codDdd.hashCode());
		result = prime * result + ((codDebitoAutomatico == null) ? 0 : codDebitoAutomatico.hashCode());
		result = prime * result + ((codigoProduto == null) ? 0 : codigoProduto.hashCode());
		result = prime * result + ((complemento == null) ? 0 : complemento.hashCode());
		result = prime * result + ((cpe == null) ? 0 : cpe.hashCode());
		result = prime * result + ((custCode == null) ? 0 : custCode.hashCode());
		result = prime * result + ((custCodeOrig == null) ? 0 : custCodeOrig.hashCode());
		result = prime * result + ((customerId == null) ? 0 : customerId.hashCode());
		result = prime * result + ((datAgendAtual == null) ? 0 : datAgendAtual.hashCode());
		result = prime * result + ((datCancVenda == null) ? 0 : datCancVenda.hashCode());
		result = prime * result + ((datCriacaoOrdem == null) ? 0 : datCriacaoOrdem.hashCode());
		result = prime * result + ((datFinalizacaoOrdem == null) ? 0 : datFinalizacaoOrdem.hashCode());
		result = prime * result + ((datJanelaPortabilidade == null) ? 0 : datJanelaPortabilidade.hashCode());
		result = prime * result + ((datPrimeiroAgend == null) ? 0 : datPrimeiroAgend.hashCode());
		result = prime * result + ((datRef == null) ? 0 : datRef.hashCode());
		result = prime * result + ((datStatusOrdem == null) ? 0 : datStatusOrdem.hashCode());
		result = prime * result + ((datStatusWfm == null) ? 0 : datStatusWfm.hashCode());
		result = prime * result + ((datVenda == null) ? 0 : datVenda.hashCode());
		result = prime * result + ((datVendaOrig == null) ? 0 : datVendaOrig.hashCode());
		result = prime * result + ((detalheRecusaCrivo == null) ? 0 : detalheRecusaCrivo.hashCode());
		result = prime * result + ((diaVencimento == null) ? 0 : diaVencimento.hashCode());
		result = prime * result + ((documento == null) ? 0 : documento.hashCode());
		result = prime * result + ((dominioRoot == null) ? 0 : dominioRoot.hashCode());
		result = prime * result + ((dscAreaVoip == null) ? 0 : dscAreaVoip.hashCode());
		result = prime * result + ((dscEnderecoFatura == null) ? 0 : dscEnderecoFatura.hashCode());
		result = prime * result + ((dscOperadoraDoadora == null) ? 0 : dscOperadoraDoadora.hashCode());
		result = prime * result + ((dscStatusAtivacao == null) ? 0 : dscStatusAtivacao.hashCode());
		result = prime * result + ((dscStatusItem == null) ? 0 : dscStatusItem.hashCode());
		result = prime * result + ((dscStatusOrdemWfm == null) ? 0 : dscStatusOrdemWfm.hashCode());
		result = prime * result + ((dscTxNaoRecorrente == null) ? 0 : dscTxNaoRecorrente.hashCode());
		result = prime * result + ((dscTxRecorrente == null) ? 0 : dscTxRecorrente.hashCode());
		result = prime * result + ((dt_conclusao_wfm == null) ? 0 : dt_conclusao_wfm.hashCode());
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((flgCancAntesVenda == null) ? 0 : flgCancAntesVenda.hashCode());
		result = prime * result + ((flgCancDupl == null) ? 0 : flgCancDupl.hashCode());
		result = prime * result + ((flgCancLiquido == null) ? 0 : flgCancLiquido.hashCode());
		result = prime * result + ((flgCancPosVenda == null) ? 0 : flgCancPosVenda.hashCode());
		result = prime * result + ((flgOrdemAutomatica == null) ? 0 : flgOrdemAutomatica.hashCode());
		result = prime * result + ((flgPortabilidade == null) ? 0 : flgPortabilidade.hashCode());
		result = prime * result + ((flgVendaBruta == null) ? 0 : flgVendaBruta.hashCode());
		result = prime * result + ((flgVendaDuplicada == null) ? 0 : flgVendaDuplicada.hashCode());
		result = prime * result + ((flgVendaLiquida == null) ? 0 : flgVendaLiquida.hashCode());
		result = prime * result + ((flgVendaSubmetida == null) ? 0 : flgVendaSubmetida.hashCode());
		result = prime * result + ((formaPagamento == null) ? 0 : formaPagamento.hashCode());
		result = prime * result + ((horCriacaoOrdem == null) ? 0 : horCriacaoOrdem.hashCode());
		result = prime * result + ((horJanela == null) ? 0 : horJanela.hashCode());
		result = prime * result + ((horStatusOrdem == null) ? 0 : horStatusOrdem.hashCode());
		result = prime * result + ((horVendaOrig == null) ? 0 : horVendaOrig.hashCode());
		result = prime * result + ((horaAgendamentoAtual == null) ? 0 : horaAgendamentoAtual.hashCode());
		result = prime * result + ((horaPrimeiroAgendamento == null) ? 0 : horaPrimeiroAgendamento.hashCode());
		result = prime * result + ((horaStatusWfm == null) ? 0 : horaStatusWfm.hashCode());
		result = prime * result + ((horaVenda == null) ? 0 : horaVenda.hashCode());
		result = prime * result + ((idRecursoPaiWfm == null) ? 0 : idRecursoPaiWfm.hashCode());
		result = prime * result + ((idRecursoWfm == null) ? 0 : idRecursoWfm.hashCode());
		result = prime * result + ((itemRoot == null) ? 0 : itemRoot.hashCode());
		result = prime * result + ((loginCancelamentoOrdem == null) ? 0 : loginCancelamentoOrdem.hashCode());
		result = prime * result + ((loginVendedor == null) ? 0 : loginVendedor.hashCode());
		result = prime * result + ((loginVendedorOrig == null) ? 0 : loginVendedorOrig.hashCode());
		result = prime * result + ((logradouro == null) ? 0 : logradouro.hashCode());
		result = prime * result + ((motivoCancelamento == null) ? 0 : motivoCancelamento.hashCode());
		result = prime * result + ((msan_olt_venda == null) ? 0 : msan_olt_venda.hashCode());
		result = prime * result + ((nomDescontoAtualItem == null) ? 0 : nomDescontoAtualItem.hashCode());
		result = prime * result + ((nomLoginResponsavel == null) ? 0 : nomLoginResponsavel.hashCode());
		result = prime * result + ((nomPlanoAtual == null) ? 0 : nomPlanoAtual.hashCode());
		result = prime * result + ((nomRecursoWfm == null) ? 0 : nomRecursoWfm.hashCode());
		result = prime * result + ((nomeCliente == null) ? 0 : nomeCliente.hashCode());
		result = prime * result + ((nomeParceiroVenda == null) ? 0 : nomeParceiroVenda.hashCode());
		result = prime * result + ((nomeParceiroVendaOrig == null) ? 0 : nomeParceiroVendaOrig.hashCode());
		result = prime * result + ((nroOrdem == null) ? 0 : nroOrdem.hashCode());
		result = prime * result + ((numOrdemSiebel == null) ? 0 : numOrdemSiebel.hashCode());
		result = prime * result + ((numOrdemSiebelOrig == null) ? 0 : numOrdemSiebelOrig.hashCode());
		result = prime * result + ((numProtocolo == null) ? 0 : numProtocolo.hashCode());
		result = prime * result + ((numTelefonePortado == null) ? 0 : numTelefonePortado.hashCode());
		result = prime * result + ((numero == null) ? 0 : numero.hashCode());
		result = prime * result + ((numeroAcesso == null) ? 0 : numeroAcesso.hashCode());
		result = prime * result + ((ont == null) ? 0 : ont.hashCode());
		result = prime * result + ((planoAtivacaoOferta == null) ? 0 : planoAtivacaoOferta.hashCode());
		result = prime * result + ((position == null) ? 0 : position.hashCode());
		result = prime * result + ((positionOrig == null) ? 0 : positionOrig.hashCode());
		result = prime * result + ((qtdContratos == null) ? 0 : qtdContratos.hashCode());
		result = prime * result + ((rowIdDoItemDaOrdem == null) ? 0 : rowIdDoItemDaOrdem.hashCode());
		result = prime * result + ((rowIdDoItemDaOrdemPai == null) ? 0 : rowIdDoItemDaOrdemPai.hashCode());
		result = prime * result + ((score == null) ? 0 : score.hashCode());
		result = prime * result + ((scoreConsumido == null) ? 0 : scoreConsumido.hashCode());
		result = prime * result + ((semanaVenda == null) ? 0 : semanaVenda.hashCode());
		result = prime * result + ((semanaVendaOrig == null) ? 0 : semanaVendaOrig.hashCode());
		result = prime * result + ((statusOrdem == null) ? 0 : statusOrdem.hashCode());
		result = prime * result + ((tecnologia == null) ? 0 : tecnologia.hashCode());
		result = prime * result + ((telefone == null) ? 0 : telefone.hashCode());
		result = prime * result + ((tipo == null) ? 0 : tipo.hashCode());
		result = prime * result + ((tipoConta == null) ? 0 : tipoConta.hashCode());
		result = prime * result + ((tipoDocumento == null) ? 0 : tipoDocumento.hashCode());
		result = prime * result + ((tipoLogradouro == null) ? 0 : tipoLogradouro.hashCode());
		result = prime * result + ((tipoProduto == null) ? 0 : tipoProduto.hashCode());
		result = prime * result + ((tipoVenda == null) ? 0 : tipoVenda.hashCode());
		result = prime * result + ((uf == null) ? 0 : uf.hashCode());
		result = prime * result + ((valDescontoAtualItem == null) ? 0 : valDescontoAtualItem.hashCode());
		result = prime * result + ((valPlanoAtualItem == null) ? 0 : valPlanoAtualItem.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		E2EStep1pt3Value other = (E2EStep1pt3Value) obj;
		if (acessoRowId == null) {
			if (other.acessoRowId != null)
				return false;
		} else if (!acessoRowId.equals(other.acessoRowId))
			return false;
		if (acessoRowIdRoot == null) {
			if (other.acessoRowIdRoot != null)
				return false;
		} else if (!acessoRowIdRoot.equals(other.acessoRowIdRoot))
			return false;
		if (bairro == null) {
			if (other.bairro != null)
				return false;
		} else if (!bairro.equals(other.bairro))
			return false;
		if (canal == null) {
			if (other.canal != null)
				return false;
		} else if (!canal.equals(other.canal))
			return false;
		if (canalOrig == null) {
			if (other.canalOrig != null)
				return false;
		} else if (!canalOrig.equals(other.canalOrig))
			return false;
		if (categoriaItemOrdem == null) {
			if (other.categoriaItemOrdem != null)
				return false;
		} else if (!categoriaItemOrdem.equals(other.categoriaItemOrdem))
			return false;
		if (cep == null) {
			if (other.cep != null)
				return false;
		} else if (!cep.equals(other.cep))
			return false;
		if (cidade == null) {
			if (other.cidade != null)
				return false;
		} else if (!cidade.equals(other.cidade))
			return false;
		if (cnpjParceiro == null) {
			if (other.cnpjParceiro != null)
				return false;
		} else if (!cnpjParceiro.equals(other.cnpjParceiro))
			return false;
		if (cnpjParceiroOrig == null) {
			if (other.cnpjParceiroOrig != null)
				return false;
		} else if (!cnpjParceiroOrig.equals(other.cnpjParceiroOrig))
			return false;
		if (codAgenciaBanco == null) {
			if (other.codAgenciaBanco != null)
				return false;
		} else if (!codAgenciaBanco.equals(other.codAgenciaBanco))
			return false;
		if (codBanco == null) {
			if (other.codBanco != null)
				return false;
		} else if (!codBanco.equals(other.codBanco))
			return false;
		if (codContaCorrente == null) {
			if (other.codContaCorrente != null)
				return false;
		} else if (!codContaCorrente.equals(other.codContaCorrente))
			return false;
		if (codContaFinanceira == null) {
			if (other.codContaFinanceira != null)
				return false;
		} else if (!codContaFinanceira.equals(other.codContaFinanceira))
			return false;
		if (codContratoAtivacao == null) {
			if (other.codContratoAtivacao != null)
				return false;
		} else if (!codContratoAtivacao.equals(other.codContratoAtivacao))
			return false;
		if (codContratoOltp == null) {
			if (other.codContratoOltp != null)
				return false;
		} else if (!codContratoOltp.equals(other.codContratoOltp))
			return false;
		if (codDdd == null) {
			if (other.codDdd != null)
				return false;
		} else if (!codDdd.equals(other.codDdd))
			return false;
		if (codDebitoAutomatico == null) {
			if (other.codDebitoAutomatico != null)
				return false;
		} else if (!codDebitoAutomatico.equals(other.codDebitoAutomatico))
			return false;
		if (codigoProduto == null) {
			if (other.codigoProduto != null)
				return false;
		} else if (!codigoProduto.equals(other.codigoProduto))
			return false;
		if (complemento == null) {
			if (other.complemento != null)
				return false;
		} else if (!complemento.equals(other.complemento))
			return false;
		if (cpe == null) {
			if (other.cpe != null)
				return false;
		} else if (!cpe.equals(other.cpe))
			return false;
		if (custCode == null) {
			if (other.custCode != null)
				return false;
		} else if (!custCode.equals(other.custCode))
			return false;
		if (custCodeOrig == null) {
			if (other.custCodeOrig != null)
				return false;
		} else if (!custCodeOrig.equals(other.custCodeOrig))
			return false;
		if (customerId == null) {
			if (other.customerId != null)
				return false;
		} else if (!customerId.equals(other.customerId))
			return false;
		if (datAgendAtual == null) {
			if (other.datAgendAtual != null)
				return false;
		} else if (!datAgendAtual.equals(other.datAgendAtual))
			return false;
		if (datCancVenda == null) {
			if (other.datCancVenda != null)
				return false;
		} else if (!datCancVenda.equals(other.datCancVenda))
			return false;
		if (datCriacaoOrdem == null) {
			if (other.datCriacaoOrdem != null)
				return false;
		} else if (!datCriacaoOrdem.equals(other.datCriacaoOrdem))
			return false;
		if (datFinalizacaoOrdem == null) {
			if (other.datFinalizacaoOrdem != null)
				return false;
		} else if (!datFinalizacaoOrdem.equals(other.datFinalizacaoOrdem))
			return false;
		if (datJanelaPortabilidade == null) {
			if (other.datJanelaPortabilidade != null)
				return false;
		} else if (!datJanelaPortabilidade.equals(other.datJanelaPortabilidade))
			return false;
		if (datPrimeiroAgend == null) {
			if (other.datPrimeiroAgend != null)
				return false;
		} else if (!datPrimeiroAgend.equals(other.datPrimeiroAgend))
			return false;
		if (datRef == null) {
			if (other.datRef != null)
				return false;
		} else if (!datRef.equals(other.datRef))
			return false;
		if (datStatusOrdem == null) {
			if (other.datStatusOrdem != null)
				return false;
		} else if (!datStatusOrdem.equals(other.datStatusOrdem))
			return false;
		if (datStatusWfm == null) {
			if (other.datStatusWfm != null)
				return false;
		} else if (!datStatusWfm.equals(other.datStatusWfm))
			return false;
		if (datVenda == null) {
			if (other.datVenda != null)
				return false;
		} else if (!datVenda.equals(other.datVenda))
			return false;
		if (datVendaOrig == null) {
			if (other.datVendaOrig != null)
				return false;
		} else if (!datVendaOrig.equals(other.datVendaOrig))
			return false;
		if (detalheRecusaCrivo == null) {
			if (other.detalheRecusaCrivo != null)
				return false;
		} else if (!detalheRecusaCrivo.equals(other.detalheRecusaCrivo))
			return false;
		if (diaVencimento == null) {
			if (other.diaVencimento != null)
				return false;
		} else if (!diaVencimento.equals(other.diaVencimento))
			return false;
		if (documento == null) {
			if (other.documento != null)
				return false;
		} else if (!documento.equals(other.documento))
			return false;
		if (dominioRoot == null) {
			if (other.dominioRoot != null)
				return false;
		} else if (!dominioRoot.equals(other.dominioRoot))
			return false;
		if (dscAreaVoip == null) {
			if (other.dscAreaVoip != null)
				return false;
		} else if (!dscAreaVoip.equals(other.dscAreaVoip))
			return false;
		if (dscEnderecoFatura == null) {
			if (other.dscEnderecoFatura != null)
				return false;
		} else if (!dscEnderecoFatura.equals(other.dscEnderecoFatura))
			return false;
		if (dscOperadoraDoadora == null) {
			if (other.dscOperadoraDoadora != null)
				return false;
		} else if (!dscOperadoraDoadora.equals(other.dscOperadoraDoadora))
			return false;
		if (dscStatusAtivacao == null) {
			if (other.dscStatusAtivacao != null)
				return false;
		} else if (!dscStatusAtivacao.equals(other.dscStatusAtivacao))
			return false;
		if (dscStatusItem == null) {
			if (other.dscStatusItem != null)
				return false;
		} else if (!dscStatusItem.equals(other.dscStatusItem))
			return false;
		if (dscStatusOrdemWfm == null) {
			if (other.dscStatusOrdemWfm != null)
				return false;
		} else if (!dscStatusOrdemWfm.equals(other.dscStatusOrdemWfm))
			return false;
		if (dscTxNaoRecorrente == null) {
			if (other.dscTxNaoRecorrente != null)
				return false;
		} else if (!dscTxNaoRecorrente.equals(other.dscTxNaoRecorrente))
			return false;
		if (dscTxRecorrente == null) {
			if (other.dscTxRecorrente != null)
				return false;
		} else if (!dscTxRecorrente.equals(other.dscTxRecorrente))
			return false;
		if (dt_conclusao_wfm == null) {
			if (other.dt_conclusao_wfm != null)
				return false;
		} else if (!dt_conclusao_wfm.equals(other.dt_conclusao_wfm))
			return false;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (flgCancAntesVenda == null) {
			if (other.flgCancAntesVenda != null)
				return false;
		} else if (!flgCancAntesVenda.equals(other.flgCancAntesVenda))
			return false;
		if (flgCancDupl == null) {
			if (other.flgCancDupl != null)
				return false;
		} else if (!flgCancDupl.equals(other.flgCancDupl))
			return false;
		if (flgCancLiquido == null) {
			if (other.flgCancLiquido != null)
				return false;
		} else if (!flgCancLiquido.equals(other.flgCancLiquido))
			return false;
		if (flgCancPosVenda == null) {
			if (other.flgCancPosVenda != null)
				return false;
		} else if (!flgCancPosVenda.equals(other.flgCancPosVenda))
			return false;
		if (flgOrdemAutomatica == null) {
			if (other.flgOrdemAutomatica != null)
				return false;
		} else if (!flgOrdemAutomatica.equals(other.flgOrdemAutomatica))
			return false;
		if (flgPortabilidade == null) {
			if (other.flgPortabilidade != null)
				return false;
		} else if (!flgPortabilidade.equals(other.flgPortabilidade))
			return false;
		if (flgVendaBruta == null) {
			if (other.flgVendaBruta != null)
				return false;
		} else if (!flgVendaBruta.equals(other.flgVendaBruta))
			return false;
		if (flgVendaDuplicada == null) {
			if (other.flgVendaDuplicada != null)
				return false;
		} else if (!flgVendaDuplicada.equals(other.flgVendaDuplicada))
			return false;
		if (flgVendaLiquida == null) {
			if (other.flgVendaLiquida != null)
				return false;
		} else if (!flgVendaLiquida.equals(other.flgVendaLiquida))
			return false;
		if (flgVendaSubmetida == null) {
			if (other.flgVendaSubmetida != null)
				return false;
		} else if (!flgVendaSubmetida.equals(other.flgVendaSubmetida))
			return false;
		if (formaPagamento == null) {
			if (other.formaPagamento != null)
				return false;
		} else if (!formaPagamento.equals(other.formaPagamento))
			return false;
		if (horCriacaoOrdem == null) {
			if (other.horCriacaoOrdem != null)
				return false;
		} else if (!horCriacaoOrdem.equals(other.horCriacaoOrdem))
			return false;
		if (horJanela == null) {
			if (other.horJanela != null)
				return false;
		} else if (!horJanela.equals(other.horJanela))
			return false;
		if (horStatusOrdem == null) {
			if (other.horStatusOrdem != null)
				return false;
		} else if (!horStatusOrdem.equals(other.horStatusOrdem))
			return false;
		if (horVendaOrig == null) {
			if (other.horVendaOrig != null)
				return false;
		} else if (!horVendaOrig.equals(other.horVendaOrig))
			return false;
		if (horaAgendamentoAtual == null) {
			if (other.horaAgendamentoAtual != null)
				return false;
		} else if (!horaAgendamentoAtual.equals(other.horaAgendamentoAtual))
			return false;
		if (horaPrimeiroAgendamento == null) {
			if (other.horaPrimeiroAgendamento != null)
				return false;
		} else if (!horaPrimeiroAgendamento.equals(other.horaPrimeiroAgendamento))
			return false;
		if (horaStatusWfm == null) {
			if (other.horaStatusWfm != null)
				return false;
		} else if (!horaStatusWfm.equals(other.horaStatusWfm))
			return false;
		if (horaVenda == null) {
			if (other.horaVenda != null)
				return false;
		} else if (!horaVenda.equals(other.horaVenda))
			return false;
		if (idRecursoPaiWfm == null) {
			if (other.idRecursoPaiWfm != null)
				return false;
		} else if (!idRecursoPaiWfm.equals(other.idRecursoPaiWfm))
			return false;
		if (idRecursoWfm == null) {
			if (other.idRecursoWfm != null)
				return false;
		} else if (!idRecursoWfm.equals(other.idRecursoWfm))
			return false;
		if (itemRoot == null) {
			if (other.itemRoot != null)
				return false;
		} else if (!itemRoot.equals(other.itemRoot))
			return false;
		if (loginCancelamentoOrdem == null) {
			if (other.loginCancelamentoOrdem != null)
				return false;
		} else if (!loginCancelamentoOrdem.equals(other.loginCancelamentoOrdem))
			return false;
		if (loginVendedor == null) {
			if (other.loginVendedor != null)
				return false;
		} else if (!loginVendedor.equals(other.loginVendedor))
			return false;
		if (loginVendedorOrig == null) {
			if (other.loginVendedorOrig != null)
				return false;
		} else if (!loginVendedorOrig.equals(other.loginVendedorOrig))
			return false;
		if (logradouro == null) {
			if (other.logradouro != null)
				return false;
		} else if (!logradouro.equals(other.logradouro))
			return false;
		if (motivoCancelamento == null) {
			if (other.motivoCancelamento != null)
				return false;
		} else if (!motivoCancelamento.equals(other.motivoCancelamento))
			return false;
		if (msan_olt_venda == null) {
			if (other.msan_olt_venda != null)
				return false;
		} else if (!msan_olt_venda.equals(other.msan_olt_venda))
			return false;
		if (nomDescontoAtualItem == null) {
			if (other.nomDescontoAtualItem != null)
				return false;
		} else if (!nomDescontoAtualItem.equals(other.nomDescontoAtualItem))
			return false;
		if (nomLoginResponsavel == null) {
			if (other.nomLoginResponsavel != null)
				return false;
		} else if (!nomLoginResponsavel.equals(other.nomLoginResponsavel))
			return false;
		if (nomPlanoAtual == null) {
			if (other.nomPlanoAtual != null)
				return false;
		} else if (!nomPlanoAtual.equals(other.nomPlanoAtual))
			return false;
		if (nomRecursoWfm == null) {
			if (other.nomRecursoWfm != null)
				return false;
		} else if (!nomRecursoWfm.equals(other.nomRecursoWfm))
			return false;
		if (nomeCliente == null) {
			if (other.nomeCliente != null)
				return false;
		} else if (!nomeCliente.equals(other.nomeCliente))
			return false;
		if (nomeParceiroVenda == null) {
			if (other.nomeParceiroVenda != null)
				return false;
		} else if (!nomeParceiroVenda.equals(other.nomeParceiroVenda))
			return false;
		if (nomeParceiroVendaOrig == null) {
			if (other.nomeParceiroVendaOrig != null)
				return false;
		} else if (!nomeParceiroVendaOrig.equals(other.nomeParceiroVendaOrig))
			return false;
		if (nroOrdem == null) {
			if (other.nroOrdem != null)
				return false;
		} else if (!nroOrdem.equals(other.nroOrdem))
			return false;
		if (numOrdemSiebel == null) {
			if (other.numOrdemSiebel != null)
				return false;
		} else if (!numOrdemSiebel.equals(other.numOrdemSiebel))
			return false;
		if (numOrdemSiebelOrig == null) {
			if (other.numOrdemSiebelOrig != null)
				return false;
		} else if (!numOrdemSiebelOrig.equals(other.numOrdemSiebelOrig))
			return false;
		if (numProtocolo == null) {
			if (other.numProtocolo != null)
				return false;
		} else if (!numProtocolo.equals(other.numProtocolo))
			return false;
		if (numTelefonePortado == null) {
			if (other.numTelefonePortado != null)
				return false;
		} else if (!numTelefonePortado.equals(other.numTelefonePortado))
			return false;
		if (numero == null) {
			if (other.numero != null)
				return false;
		} else if (!numero.equals(other.numero))
			return false;
		if (numeroAcesso == null) {
			if (other.numeroAcesso != null)
				return false;
		} else if (!numeroAcesso.equals(other.numeroAcesso))
			return false;
		if (ont == null) {
			if (other.ont != null)
				return false;
		} else if (!ont.equals(other.ont))
			return false;
		if (planoAtivacaoOferta == null) {
			if (other.planoAtivacaoOferta != null)
				return false;
		} else if (!planoAtivacaoOferta.equals(other.planoAtivacaoOferta))
			return false;
		if (position == null) {
			if (other.position != null)
				return false;
		} else if (!position.equals(other.position))
			return false;
		if (positionOrig == null) {
			if (other.positionOrig != null)
				return false;
		} else if (!positionOrig.equals(other.positionOrig))
			return false;
		if (qtdContratos == null) {
			if (other.qtdContratos != null)
				return false;
		} else if (!qtdContratos.equals(other.qtdContratos))
			return false;
		if (rowIdDoItemDaOrdem == null) {
			if (other.rowIdDoItemDaOrdem != null)
				return false;
		} else if (!rowIdDoItemDaOrdem.equals(other.rowIdDoItemDaOrdem))
			return false;
		if (rowIdDoItemDaOrdemPai == null) {
			if (other.rowIdDoItemDaOrdemPai != null)
				return false;
		} else if (!rowIdDoItemDaOrdemPai.equals(other.rowIdDoItemDaOrdemPai))
			return false;
		if (score == null) {
			if (other.score != null)
				return false;
		} else if (!score.equals(other.score))
			return false;
		if (scoreConsumido == null) {
			if (other.scoreConsumido != null)
				return false;
		} else if (!scoreConsumido.equals(other.scoreConsumido))
			return false;
		if (semanaVenda == null) {
			if (other.semanaVenda != null)
				return false;
		} else if (!semanaVenda.equals(other.semanaVenda))
			return false;
		if (semanaVendaOrig == null) {
			if (other.semanaVendaOrig != null)
				return false;
		} else if (!semanaVendaOrig.equals(other.semanaVendaOrig))
			return false;
		if (statusOrdem == null) {
			if (other.statusOrdem != null)
				return false;
		} else if (!statusOrdem.equals(other.statusOrdem))
			return false;
		if (tecnologia == null) {
			if (other.tecnologia != null)
				return false;
		} else if (!tecnologia.equals(other.tecnologia))
			return false;
		if (telefone == null) {
			if (other.telefone != null)
				return false;
		} else if (!telefone.equals(other.telefone))
			return false;
		if (tipo != other.tipo)
			return false;
		if (tipoConta == null) {
			if (other.tipoConta != null)
				return false;
		} else if (!tipoConta.equals(other.tipoConta))
			return false;
		if (tipoDocumento == null) {
			if (other.tipoDocumento != null)
				return false;
		} else if (!tipoDocumento.equals(other.tipoDocumento))
			return false;
		if (tipoLogradouro == null) {
			if (other.tipoLogradouro != null)
				return false;
		} else if (!tipoLogradouro.equals(other.tipoLogradouro))
			return false;
		if (tipoProduto == null) {
			if (other.tipoProduto != null)
				return false;
		} else if (!tipoProduto.equals(other.tipoProduto))
			return false;
		if (tipoVenda == null) {
			if (other.tipoVenda != null)
				return false;
		} else if (!tipoVenda.equals(other.tipoVenda))
			return false;
		if (uf == null) {
			if (other.uf != null)
				return false;
		} else if (!uf.equals(other.uf))
			return false;
		if (valDescontoAtualItem == null) {
			if (other.valDescontoAtualItem != null)
				return false;
		} else if (!valDescontoAtualItem.equals(other.valDescontoAtualItem))
			return false;
		if (valPlanoAtualItem == null) {
			if (other.valPlanoAtualItem != null)
				return false;
		} else if (!valPlanoAtualItem.equals(other.valPlanoAtualItem))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "E2EStep2pt2Value [tipo=" + tipo + ", datRef=" + datRef + ", datCriacaoOrdem=" + datCriacaoOrdem
				+ ", horCriacaoOrdem=" + horCriacaoOrdem + ", datVenda=" + datVenda + ", horaVenda=" + horaVenda
				+ ", datStatusOrdem=" + datStatusOrdem + ", horStatusOrdem=" + horStatusOrdem + ", numOrdemSiebel="
				+ numOrdemSiebel + ", codContratoOltp=" + codContratoOltp + ", codContratoAtivacao="
				+ codContratoAtivacao + ", numeroAcesso=" + numeroAcesso + ", customerId=" + customerId
				+ ", tipoDocumento=" + tipoDocumento + ", documento=" + documento + ", tipoVenda=" + tipoVenda
				+ ", tipoProduto=" + tipoProduto + ", planoAtivacaoOferta=" + planoAtivacaoOferta + ", loginVendedor="
				+ loginVendedor + ", canal=" + canal + ", cnpjParceiro=" + cnpjParceiro + ", custCode=" + custCode
				+ ", position=" + position + ", flgCancAntesVenda=" + flgCancAntesVenda + ", flgCancPosVenda="
				+ flgCancPosVenda + ", datCancVenda=" + datCancVenda + ", motivoCancelamento=" + motivoCancelamento
				+ ", nomeCliente=" + nomeCliente + ", telefone=" + telefone + ", email=" + email + ", uf=" + uf
				+ ", tipoLogradouro=" + tipoLogradouro + ", logradouro=" + logradouro + ", numero=" + numero
				+ ", complemento=" + complemento + ", bairro=" + bairro + ", cep=" + cep + ", cidade=" + cidade
				+ ", statusOrdem=" + statusOrdem + ", tecnologia=" + tecnologia + ", formaPagamento=" + formaPagamento
				+ ", tipoConta=" + tipoConta + ", codBanco=" + codBanco + ", codAgenciaBanco=" + codAgenciaBanco
				+ ", codContaCorrente=" + codContaCorrente + ", codDebitoAutomatico=" + codDebitoAutomatico
				+ ", diaVencimento=" + diaVencimento + ", semanaVenda=" + semanaVenda + ", score=" + score
				+ ", scoreConsumido=" + scoreConsumido + ", datFinalizacaoOrdem=" + datFinalizacaoOrdem
				+ ", qtdContratos=" + qtdContratos + ", numProtocolo=" + numProtocolo + ", flgOrdemAutomatica="
				+ flgOrdemAutomatica + ", dscTxRecorrente=" + dscTxRecorrente + ", dscTxNaoRecorrente="
				+ dscTxNaoRecorrente + ", dscStatusItem=" + dscStatusItem + ", nomLoginResponsavel="
				+ nomLoginResponsavel + ", flgPortabilidade=" + flgPortabilidade + ", dscOperadoraDoadora="
				+ dscOperadoraDoadora + ", codDdd=" + codDdd + ", numTelefonePortado=" + numTelefonePortado
				+ ", datJanelaPortabilidade=" + datJanelaPortabilidade + ", horJanela=" + horJanela
				+ ", dscEnderecoFatura=" + dscEnderecoFatura + ", dscAreaVoip=" + dscAreaVoip + ", cpe=" + cpe
				+ ", ont=" + ont + ", detalheRecusaCrivo=" + detalheRecusaCrivo + ", itemRoot=" + itemRoot
				+ ", loginCancelamentoOrdem=" + loginCancelamentoOrdem + ", dominioRoot=" + dominioRoot
				+ ", codContaFinanceira=" + codContaFinanceira + ", nomPlanoAtual=" + nomPlanoAtual
				+ ", valPlanoAtualItem=" + valPlanoAtualItem + ", nomDescontoAtualItem=" + nomDescontoAtualItem
				+ ", valDescontoAtualItem=" + valDescontoAtualItem + ", nroOrdem=" + nroOrdem + ", acessoRowId="
				+ acessoRowId + ", acessoRowIdRoot=" + acessoRowIdRoot + ", codigoProduto=" + codigoProduto
				+ ", datVendaOrig=" + datVendaOrig + ", horVendaOrig=" + horVendaOrig + ", numOrdemSiebelOrig="
				+ numOrdemSiebelOrig + ", loginVendedorOrig=" + loginVendedorOrig + ", canalOrig=" + canalOrig
				+ ", cnpjParceiroOrig=" + cnpjParceiroOrig + ", custCodeOrig=" + custCodeOrig + ", positionOrig="
				+ positionOrig + ", flgVendaSubmetida=" + flgVendaSubmetida + ", flgVendaDuplicada=" + flgVendaDuplicada
				+ ", flgVendaBruta=" + flgVendaBruta + ", flgVendaLiquida=" + flgVendaLiquida + ", flgCancDupl="
				+ flgCancDupl + ", flgCancLiquido=" + flgCancLiquido + ", semanaVendaOrig=" + semanaVendaOrig
				+ ", nomeParceiroVenda=" + nomeParceiroVenda + ", nomeParceiroVendaOrig=" + nomeParceiroVendaOrig
				+ ", rowIdDoItemDaOrdem=" + rowIdDoItemDaOrdem + ", rowIdDoItemDaOrdemPai=" + rowIdDoItemDaOrdemPai
				+ ", categoriaItemOrdem=" + categoriaItemOrdem + ", msan_olt_venda=" + msan_olt_venda
				+ ", dt_conclusao_wfm=" + dt_conclusao_wfm + ", dscStatusOrdemWfm=" + dscStatusOrdemWfm
				+ ", datStatusWfm=" + datStatusWfm + ", horaStatusWfm=" + horaStatusWfm + ", idRecursoWfm="
				+ idRecursoWfm + ", nomRecursoWfm=" + nomRecursoWfm + ", idRecursoPaiWfm=" + idRecursoPaiWfm
				+ ", datPrimeiroAgend=" + datPrimeiroAgend + ", horaPrimeiroAgendamento=" + horaPrimeiroAgendamento
				+ ", datAgendAtual=" + datAgendAtual + ", horaAgendamentoAtual=" + horaAgendamentoAtual
				+ ", dscStatusAtivacao=" + dscStatusAtivacao + "]";
	}

	
	
	
}
