package br.com.tim.mapreduce.e2e.step10;

import org.apache.hadoop.mapreduce.Partitioner;

public class JoinPartitioner extends Partitioner<E2EStep10Key, E2EStep10Value> {

	@Override
	public int getPartition(E2EStep10Key taggedKey, E2EStep10Value value, int numPartitions) {
		return Math.abs(taggedKey.hashCodeJoin() % numPartitions);
	}

}
