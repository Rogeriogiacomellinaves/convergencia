package br.com.tim.mapreduce.e2e.step6;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

public class GroupingComparator extends WritableComparator {

    public GroupingComparator() {
        super(E2EStep6Key.class, true);
    }

    @SuppressWarnings({"rawtypes"})
    @Override
    public int compare(WritableComparable a, WritableComparable b) {
        E2EStep6Key keyA = (E2EStep6Key) a;
        E2EStep6Key keyB = (E2EStep6Key) b;

        return keyA.compareToGrouping(keyB);
    }

}
