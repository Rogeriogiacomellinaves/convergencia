package br.com.tim.mapreduce.itemordem.step1;

import java.io.IOException;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.log4j.Logger;

import br.com.tim.mr.utils.TaggedKey;

public class IOStep1Reducer extends org.apache.hadoop.mapreduce.Reducer<TaggedKey,IOStep1Value,NullWritable,Text> {

    protected static final Logger LOG = Logger.getLogger(IOStep1Reducer.class);
    private IOStep1OutValue outValue;

    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        super.setup(context);
        outValue = new IOStep1OutValue();
    }

    @Override
    protected void reduce(TaggedKey key, Iterable<IOStep1Value> values, Context context) throws InterruptedException {

        outValue.clear();
        outValue.setNroOrdem(key.getJoinKey().toString());

        try {
            for (IOStep1Value value : values) {
            	
            	 if (value.getTipo().equals(TypeStep1.ORDEM)){
                     outValue.setOrdem(value);
                     
                 } else if (value.getTipo().equals(TypeStep1.WFM_TOA)) {
                 	outValue.setWfm(value);
                 	
                 } else if (value.getTipo().equals(TypeStep1.ITEM)){
                    outValue.clearItem();
                    outValue.setItem(value);
                    
                    context.write(NullWritable.get(), new Text(outValue.toString()));
                }
            }

        } catch (Exception e) {
            LOG.error(" ############ ERROR EXECUTION REDUCER ############ ");
            LOG.error(e.getMessage());
            throw new InterruptedException(e.getMessage());
        }
    }

    @Override
    protected void cleanup(Context context) throws IOException, InterruptedException {
        super.cleanup(context);

    }
}
