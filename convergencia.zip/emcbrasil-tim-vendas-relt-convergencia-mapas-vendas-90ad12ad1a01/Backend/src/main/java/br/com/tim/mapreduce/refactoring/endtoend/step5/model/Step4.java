package br.com.tim.mapreduce.refactoring.endtoend.step5.model;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

import com.google.common.base.Strings;

import br.com.tim.mapreduce.refactoring.endtoend.step5.enums.Step4Enum;
import br.com.tim.utils.CommonsConstants;

public class Step4 implements Writable{
	
	private String datref;
	private String datCriacaoOrdem;
	private String horaCriacaoDaOrdem;
	private String datVenda;
	private String horaDaVenda;
	private String datStatusOrdem;
	private String hrStatusOrdem;
	private String numOrdemSiebel;
	private String numOrdemSiebelOrig;
	private String codContratoOltp;
	private String codContratoAtivacao;
	private String numeroAcesso;
	private String customerId;
	private String tipoDocumento;
	private String documento;
	private String tipoVenda;
	private String tipoProduto;
	private String velocidadeDownload;
	private String velocidadeUpload;
	private String planoAtivacaoOferta;
	private String loginVendedor;
	private String canal;
	private String cnpjParceiro;
	private String custcode;
	private String position;
	private String flgCancAntesVenda;
	private String flgCancPosVenda;
	private String dtCancVenda;
	private String motivoCancelamento;
	private String nomeCliente;
	private String telefone;
	private String emailFatura;
	private String uf;
	private String tipoLogradouro;
	private String logradouro;
	private String numero;
	private String complemento;
	private String bairro;
	private String cep;
	private String cidade;
	private String statusOrdem;
	private String tecnologia;
	private String formaPagamento;
	private String tipoConta;
	private String codBanco;
	private String codAgengiaBco;
	private String codContaCorrente;
	private String codDebitoAutomatico;
	private String diaVencimento;
	private String semanaVenda;
	private String score;
	private String scoreConsumido;
	private String dtFinalizacaoOrdem;
	private String qdeContratos;
	private String numProtocolo;
	private String flgOrdemAutomatica;
	private String dscTxRecorrente;
	private String dscTxNaoRecorrente;
	private String dscStatusItem;
	private String nomLoginResponsavel;
	private String flgPortabilidade;
	private String dscOperadoraDoadora;
	private String codDdd;
	private String numTelefonePortado;
	private String datJanelaPortabilidade;
	private String horaDaJanela;
	private String dscEnderecoFatura;
	private String dscAreaVoip;
	private String cpe;
	private String ont;
	private String codigoConvergente;
	private String detalheRecusaCrivo;
	private String itemRoot;
	private String loginCancelamentoOrdem;
	private String custcodeCliente;
	private String dominioRoot;
	private String codContFinanceira;
	private String valPlanoAtualItem;
	private String nomDescontoAtualItem;
	private String valDescontoAtualItem;
	private String nroOrdem;
	private String acessoRowId;
	private String acessoRowIdRoot;
	private String codigoProduto;
	private String flgVendaSubmetida;
	private String flgVendaDuplicada;
	private String flgVendaBruta;
	private String flgVendaLiquida;
	private String flgCancDupl;
	private String flgCancLiquido;
	private String nomeParceiroVenda;
	private String nomeParceiroVendaOrig;
	private String rowIdItemOrdem;
	private String rowIdItemOrdemPai;
	private String categoriaItemOrder;
	private String msanOltVenda;
	private String dtConclusaoWfm;
	private String dscStatusOrdemWfm;
	private String datStatusWfm;
	private String horaStatusWfm;
	private String idRecursoWfm;
	private String nomRecursoWfm;
	private String idRecursoPaiWfm;
	private String datPrimeiroAgend;
	private String horaPrimeiroAgendamento;
	private String datAgendAtual;
	private String horaAgendamentoAtual;
	private String dscStatusAtivacao;
	private String msanOltTrafego;
	private String datVendaOrig;
	private String horaVendaOrig;
	private String loginVendedorOrig;
	private String canalOrig;
	private String cnpjParceiroOrig;
	private String custcodeOrig;
	private String positionOrig;
	private String semanaVendaOrig;
	private String codContratoAtual;
	private String nomPlanoAtual;
	private String nomeVendedorOrig;
	private String flVendaDuplicada;
	private String flGross;
	private String dtGross;
	private String flChurn;
	private String dtChurn;
	private String motivoChurn;
	private String codOrdemChurn;
	private String tipoChurn;
	private String dtCriacaoOrdemChurn;
	private String dtConclusaoOrdemChurn;
	private String nomeVendedor;
	private String nomeUsuarioCancOrdem;
	private String emailCliente;
	
	
	
	
	public Step4() {
		this.clean();
	}
	
	
	
	
	public void update(Step4 v) {
		
		this.datref = v.getDatref();
		this.datCriacaoOrdem = v.getDatCriacaoOrdem();
		this.horaCriacaoDaOrdem = v.getHoraCriacaoDaOrdem();
		this.datVenda = v.getDatVenda();
		this.horaDaVenda = v.getHoraDaVenda();
		this.datStatusOrdem = v.getDatStatusOrdem();
		this.hrStatusOrdem = v.getHrStatusOrdem();
		this.numOrdemSiebel = v.getNumOrdemSiebel();
		this.numOrdemSiebelOrig = v.getNumOrdemSiebelOrig();
		this.codContratoOltp = v.getCodContratoOltp();
		this.codContratoAtivacao = v.getCodContratoAtivacao();
		this.numeroAcesso = v.getNumeroAcesso();
		this.customerId = v.getCustomerId();
		this.tipoDocumento = v.getTipoDocumento();
		this.documento = v.getDocumento();
		this.tipoVenda = v.getTipoVenda();
		this.tipoProduto = v.getTipoProduto();
		this.velocidadeDownload = v.getVelocidadeDownload();
		this.velocidadeUpload = v.getVelocidadeUpload();
		this.planoAtivacaoOferta = v.getPlanoAtivacaoOferta();
		this.loginVendedor = v.getLoginVendedor();
		this.canal = v.getCanal();
		this.cnpjParceiro = v.getCnpjParceiro();
		this.custcode = v.getCustcode();
		this.position = v.getPosition();
		this.flgCancAntesVenda = v.getFlgCancAntesVenda();
		this.flgCancPosVenda = v.getFlgCancPosVenda();
		this.dtCancVenda = v.getDtCancVenda();
		this.motivoCancelamento = v.getMotivoCancelamento();
		this.nomeCliente = v.getNomeCliente();
		this.telefone = v.getTelefone();
		this.emailFatura = v.getEmailFatura();
		this.uf = v.getUf();
		this.tipoLogradouro = v.getTipoLogradouro();
		this.logradouro = v.getLogradouro();
		this.numero = v.getNumero();
		this.complemento = v.getComplemento();
		this.bairro = v.getBairro();
		this.cep = v.getCep();
		this.cidade = v.getCidade();
		this.statusOrdem = v.getStatusOrdem();
		this.tecnologia = v.getTecnologia();
		this.formaPagamento = v.getFormaPagamento();
		this.tipoConta = v.getTipoConta();
		this.codBanco = v.getCodBanco();
		this.codAgengiaBco = v.getCodAgengiaBco();
		this.codContaCorrente = v.getCodContaCorrente();
		this.codDebitoAutomatico = v.getCodDebitoAutomatico();
		this.diaVencimento = v.getDiaVencimento();
		this.semanaVenda = v.getSemanaVenda();
		this.score = v.getScore();
		this.scoreConsumido = v.getScoreConsumido();
		this.dtFinalizacaoOrdem = v.getDtFinalizacaoOrdem();
		this.qdeContratos = v.getQdeContratos();
		this.numProtocolo = v.getNumProtocolo();
		this.flgOrdemAutomatica = v.getFlgOrdemAutomatica();
		this.dscTxRecorrente = v.getDscTxRecorrente();
		this.dscTxNaoRecorrente = v.getDscTxNaoRecorrente();
		this.dscStatusItem = v.getDscStatusItem();
		this.nomLoginResponsavel = v.getNomLoginResponsavel();
		this.flgPortabilidade = v.getFlgPortabilidade();
		this.dscOperadoraDoadora = v.getDscOperadoraDoadora();
		this.codDdd = v.getCodDdd();
		this.numTelefonePortado = v.getNumTelefonePortado();
		this.datJanelaPortabilidade = v.getDatJanelaPortabilidade();
		this.horaDaJanela = v.getHoraDaJanela();
		this.dscEnderecoFatura = v.getDscEnderecoFatura();
		this.dscAreaVoip = v.getDscAreaVoip();
		this.cpe = v.getCpe();
		this.ont = v.getOnt();
		this.codigoConvergente = v.getCodigoConvergente();
		this.detalheRecusaCrivo = v.getDetalheRecusaCrivo();
		this.itemRoot = v.getItemRoot();
		this.loginCancelamentoOrdem = v.getLoginCancelamentoOrdem();
		this.custcodeCliente = v.getCustcodeCliente();
		this.dominioRoot = v.getDominioRoot();
		this.codContFinanceira = v.getCodContFinanceira();
		this.valPlanoAtualItem = v.getValPlanoAtualItem();
		this.nomDescontoAtualItem = v.getNomDescontoAtualItem();
		this.valDescontoAtualItem = v.getValDescontoAtualItem();
		this.nroOrdem = v.getNroOrdem();
		this.acessoRowId = v.getAcessoRowId();
		this.acessoRowIdRoot = v.getAcessoRowIdRoot();
		this.codigoProduto = v.getCodigoProduto();
		this.flgVendaSubmetida = v.getFlgVendaSubmetida();
		this.flgVendaDuplicada = v.getFlgVendaDuplicada();
		this.flgVendaBruta = v.getFlgVendaBruta();
		this.flgVendaLiquida = v.getFlgVendaLiquida();
		this.flgCancDupl = v.getFlgCancDupl();
		this.flgCancLiquido = v.getFlgCancLiquido();
		this.nomeParceiroVenda = v.getNomeParceiroVenda();
		this.nomeParceiroVendaOrig = v.getNomeParceiroVendaOrig();
		this.rowIdItemOrdem = v.getRowIdItemOrdem();
		this.rowIdItemOrdemPai = v.getRowIdItemOrdemPai();
		this.categoriaItemOrder = v.getCategoriaItemOrder();
		this.msanOltVenda = v.getMsanOltVenda();
		this.dtConclusaoWfm = v.getDtConclusaoWfm();
		this.dscStatusOrdemWfm = v.getDscStatusOrdemWfm();
		this.datStatusWfm = v.getDatStatusWfm();
		this.horaStatusWfm = v.getHoraStatusWfm();
		this.idRecursoWfm = v.getIdRecursoWfm();
		this.nomRecursoWfm = v.getNomRecursoWfm();
		this.idRecursoPaiWfm = v.getIdRecursoPaiWfm();
		this.datPrimeiroAgend = v.getDatPrimeiroAgend();
		this.horaPrimeiroAgendamento = v.getHoraPrimeiroAgendamento();
		this.datAgendAtual = v.getDatAgendAtual();
		this.horaAgendamentoAtual = v.getHoraAgendamentoAtual();
		this.dscStatusAtivacao = v.getDscStatusAtivacao();
		this.msanOltTrafego = v.getMsanOltTrafego();
		this.datVendaOrig = v.getDatVendaOrig();
		this.horaVendaOrig = v.getHoraVendaOrig();
		this.loginVendedorOrig = v.getLoginVendedorOrig();
		this.canalOrig = v.getCanalOrig();
		this.cnpjParceiroOrig = v.getCnpjParceiroOrig();
		this.custcodeOrig = v.getCustcodeOrig();
		this.positionOrig = v.getPositionOrig();
		this.semanaVendaOrig = v.getSemanaVendaOrig();
		this.codContratoAtual = v.getCodContratoAtual();
		this.nomPlanoAtual = v.getNomPlanoAtual();
		this.nomeVendedorOrig = v.getNomeVendedorOrig();
		this.flVendaDuplicada = v.getFlVendaDuplicada();
		this.flGross = v.getFlGross();
		this.dtGross = v.getDtGross();
		this.flChurn = v.getFlChurn();
		this.dtChurn = v.getDtChurn();
		this.motivoChurn = v.getMotivoChurn();
		this.codOrdemChurn = v.getCodOrdemChurn();
		this.tipoChurn = v.getTipoChurn();
		this.dtCriacaoOrdemChurn = v.getDtCriacaoOrdemChurn();
		this.dtConclusaoOrdemChurn = v.getDtConclusaoOrdemChurn();
		this.nomeVendedor = v.getNomeVendedor();
		this.nomeUsuarioCancOrdem = v.getNomeUsuarioCancOrdem();
		this.emailCliente = v.getEmailCliente();
	}




	public void parseFromText(Text text) {
		
		this.clean();
		
        if(!Strings.isNullOrEmpty(text.toString())){

            String[] line = text.toString().split(CommonsConstants.FILE_SPLIT_REGEX, -1);

            if(line.length > 0){
            	
            	this.datref = line[Step4Enum.datref.ordinal()].trim();
            	this.datCriacaoOrdem = line[Step4Enum.datCriacaoOrdem.ordinal()].trim();
            	this.horaCriacaoDaOrdem = line[Step4Enum.horaCriacaoDaOrdem.ordinal()].trim();
            	this.datVenda = line[Step4Enum.datVenda.ordinal()].trim();
            	this.horaDaVenda = line[Step4Enum.horaDaVenda.ordinal()].trim();
            	this.datStatusOrdem = line[Step4Enum.datStatusOrdem.ordinal()].trim();
            	this.hrStatusOrdem = line[Step4Enum.hrStatusOrdem.ordinal()].trim();
            	this.numOrdemSiebel = line[Step4Enum.numOrdemSiebel.ordinal()].trim();
            	this.numOrdemSiebelOrig = line[Step4Enum.numOrdemSiebelOrig.ordinal()].trim();
            	this.codContratoOltp = line[Step4Enum.codContratoOltp.ordinal()].trim();
            	this.codContratoAtivacao = line[Step4Enum.codContratoAtivacao.ordinal()].trim();
            	this.numeroAcesso = line[Step4Enum.numeroAcesso.ordinal()].trim();
            	this.customerId = line[Step4Enum.customerId.ordinal()].trim();
            	this.tipoDocumento = line[Step4Enum.tipoDocumento.ordinal()].trim();
            	this.documento = line[Step4Enum.documento.ordinal()].trim();
            	this.tipoVenda = line[Step4Enum.tipoVenda.ordinal()].trim();
            	this.tipoProduto = line[Step4Enum.tipoProduto.ordinal()].trim();
            	this.velocidadeDownload = line[Step4Enum.velocidadeDownload.ordinal()].trim();
            	this.velocidadeUpload = line[Step4Enum.velocidadeUpload.ordinal()].trim();
            	this.planoAtivacaoOferta = line[Step4Enum.planoAtivacaoOferta.ordinal()].trim();
            	this.loginVendedor = line[Step4Enum.loginVendedor.ordinal()].trim();
            	this.canal = line[Step4Enum.canal.ordinal()].trim();
            	this.cnpjParceiro = line[Step4Enum.cnpjParceiro.ordinal()].trim();
            	this.custcode = line[Step4Enum.custcode.ordinal()].trim();
            	this.position = line[Step4Enum.position.ordinal()].trim();
            	this.flgCancAntesVenda = line[Step4Enum.flgCancAntesVenda.ordinal()].trim();
            	this.flgCancPosVenda = line[Step4Enum.flgCancPosVenda.ordinal()].trim();
            	this.dtCancVenda = line[Step4Enum.dtCancVenda.ordinal()].trim();
            	this.motivoCancelamento = line[Step4Enum.motivoCancelamento.ordinal()].trim();
            	this.nomeCliente = line[Step4Enum.nomeCliente.ordinal()].trim();
            	this.telefone = line[Step4Enum.telefone.ordinal()].trim();
            	this.emailFatura = line[Step4Enum.emailFatura.ordinal()].trim();
            	this.uf = line[Step4Enum.uf.ordinal()].trim();
            	this.tipoLogradouro = line[Step4Enum.tipoLogradouro.ordinal()].trim();
            	this.logradouro = line[Step4Enum.logradouro.ordinal()].trim();
            	this.numero = line[Step4Enum.numero.ordinal()].trim();
            	this.complemento = line[Step4Enum.complemento.ordinal()].trim();
            	this.bairro = line[Step4Enum.bairro.ordinal()].trim();
            	this.cep = line[Step4Enum.cep.ordinal()].trim();
            	this.cidade = line[Step4Enum.cidade.ordinal()].trim();
            	this.statusOrdem = line[Step4Enum.statusOrdem.ordinal()].trim();
            	this.tecnologia = line[Step4Enum.tecnologia.ordinal()].trim();
            	this.formaPagamento = line[Step4Enum.formaPagamento.ordinal()].trim();
            	this.tipoConta = line[Step4Enum.tipoConta.ordinal()].trim();
            	this.codBanco = line[Step4Enum.codBanco.ordinal()].trim();
            	this.codAgengiaBco = line[Step4Enum.codAgengiaBco.ordinal()].trim();
            	this.codContaCorrente = line[Step4Enum.codContaCorrente.ordinal()].trim();
            	this.codDebitoAutomatico = line[Step4Enum.codDebitoAutomatico.ordinal()].trim();
            	this.diaVencimento = line[Step4Enum.diaVencimento.ordinal()].trim();
            	this.semanaVenda = line[Step4Enum.semanaVenda.ordinal()].trim();
            	this.score = line[Step4Enum.score.ordinal()].trim();
            	this.scoreConsumido = line[Step4Enum.scoreConsumido.ordinal()].trim();
            	this.dtFinalizacaoOrdem = line[Step4Enum.dtFinalizacaoOrdem.ordinal()].trim();
            	this.qdeContratos = line[Step4Enum.qdeContratos.ordinal()].trim();
            	this.numProtocolo = line[Step4Enum.numProtocolo.ordinal()].trim();
            	this.flgOrdemAutomatica = line[Step4Enum.flgOrdemAutomatica.ordinal()].trim();
            	this.dscTxRecorrente = line[Step4Enum.dscTxRecorrente.ordinal()].trim();
            	this.dscTxNaoRecorrente = line[Step4Enum.dscTxNaoRecorrente.ordinal()].trim();
            	this.dscStatusItem = line[Step4Enum.dscStatusItem.ordinal()].trim();
            	this.nomLoginResponsavel = line[Step4Enum.nomLoginResponsavel.ordinal()].trim();
            	this.flgPortabilidade = line[Step4Enum.flgPortabilidade.ordinal()].trim();
            	this.dscOperadoraDoadora = line[Step4Enum.dscOperadoraDoadora.ordinal()].trim();
            	this.codDdd = line[Step4Enum.codDdd.ordinal()].trim();
            	this.numTelefonePortado = line[Step4Enum.numTelefonePortado.ordinal()].trim();
            	this.datJanelaPortabilidade = line[Step4Enum.datJanelaPortabilidade.ordinal()].trim();
            	this.horaDaJanela = line[Step4Enum.horaDaJanela.ordinal()].trim();
            	this.dscEnderecoFatura = line[Step4Enum.dscEnderecoFatura.ordinal()].trim();
            	this.dscAreaVoip = line[Step4Enum.dscAreaVoip.ordinal()].trim();
            	this.cpe = line[Step4Enum.cpe.ordinal()].trim();
            	this.ont = line[Step4Enum.ont.ordinal()].trim();
            	this.codigoConvergente = line[Step4Enum.codigoConvergente.ordinal()].trim();
            	this.detalheRecusaCrivo = line[Step4Enum.detalheRecusaCrivo.ordinal()].trim();
            	this.itemRoot = line[Step4Enum.itemRoot.ordinal()].trim();
            	this.loginCancelamentoOrdem = line[Step4Enum.loginCancelamentoOrdem.ordinal()].trim();
            	this.custcodeCliente = line[Step4Enum.custcodeCliente.ordinal()].trim();
            	this.dominioRoot = line[Step4Enum.dominioRoot.ordinal()].trim();
            	this.codContFinanceira = line[Step4Enum.codContFinanceira.ordinal()].trim();
            	this.valPlanoAtualItem = line[Step4Enum.valPlanoAtualItem.ordinal()].trim();
            	this.nomDescontoAtualItem = line[Step4Enum.nomDescontoAtualItem.ordinal()].trim();
            	this.valDescontoAtualItem = line[Step4Enum.valDescontoAtualItem.ordinal()].trim();
            	this.nroOrdem = line[Step4Enum.nroOrdem.ordinal()].trim();
            	this.acessoRowId = line[Step4Enum.acessoRowId.ordinal()].trim();
            	this.acessoRowIdRoot = line[Step4Enum.acessoRowIdRoot.ordinal()].trim();
            	this.codigoProduto = line[Step4Enum.codigoProduto.ordinal()].trim();
            	this.flgVendaSubmetida = line[Step4Enum.flgVendaSubmetida.ordinal()].trim();
            	this.flgVendaDuplicada = line[Step4Enum.flgVendaDuplicada.ordinal()].trim();
            	this.flgVendaBruta = line[Step4Enum.flgVendaBruta.ordinal()].trim();
            	this.flgVendaLiquida = line[Step4Enum.flgVendaLiquida.ordinal()].trim();
            	this.flgCancDupl = line[Step4Enum.flgCancDupl.ordinal()].trim();
            	this.flgCancLiquido = line[Step4Enum.flgCancLiquido.ordinal()].trim();
            	this.nomeParceiroVenda = line[Step4Enum.nomeParceiroVenda.ordinal()].trim();
            	this.nomeParceiroVendaOrig = line[Step4Enum.nomeParceiroVendaOrig.ordinal()].trim();
            	this.rowIdItemOrdem = line[Step4Enum.rowIdItemOrdem.ordinal()].trim();
            	this.rowIdItemOrdemPai = line[Step4Enum.rowIdItemOrdemPai.ordinal()].trim();
            	this.categoriaItemOrder = line[Step4Enum.categoriaItemOrder.ordinal()].trim();
            	this.msanOltVenda = line[Step4Enum.msan_olt_venda.ordinal()].trim();
            	this.dtConclusaoWfm = line[Step4Enum.dt_conclusao_wfm.ordinal()].trim();
            	this.dscStatusOrdemWfm = line[Step4Enum.dsc_status_ordem_wfm.ordinal()].trim();
            	this.datStatusWfm = line[Step4Enum.dat_status_wfm.ordinal()].trim();
            	this.horaStatusWfm = line[Step4Enum.hora_status_wfm.ordinal()].trim();
            	this.idRecursoWfm = line[Step4Enum.id_recurso_wfm.ordinal()].trim();
            	this.nomRecursoWfm = line[Step4Enum.nom_recurso_wfm.ordinal()].trim();
            	this.idRecursoPaiWfm = line[Step4Enum.id_recurso_pai_wfm.ordinal()].trim();
            	this.datPrimeiroAgend = line[Step4Enum.dat_primeiro_agend.ordinal()].trim();
            	this.horaPrimeiroAgendamento = line[Step4Enum.hora_primeiro_agendamento.ordinal()].trim();
            	this.datAgendAtual = line[Step4Enum.dat_agend_atual.ordinal()].trim();
            	this.horaAgendamentoAtual = line[Step4Enum.hora_agendamento_atual.ordinal()].trim();
            	this.dscStatusAtivacao = line[Step4Enum.dsc_status_ativacao.ordinal()].trim();
            	this.msanOltTrafego = line[Step4Enum.msan_olt_trafego.ordinal()].trim();
            	this.datVendaOrig = line[Step4Enum.datVendaOrig.ordinal()].trim();
            	this.horaVendaOrig = line[Step4Enum.horaVendaOrig.ordinal()].trim();
            	this.loginVendedorOrig = line[Step4Enum.loginVendedorOrig.ordinal()].trim();
            	this.canalOrig = line[Step4Enum.canalOrig.ordinal()].trim();
            	this.cnpjParceiroOrig = line[Step4Enum.cnpjParceiroOrig.ordinal()].trim();
            	this.custcodeOrig = line[Step4Enum.custcodeOrig.ordinal()].trim();
            	this.positionOrig = line[Step4Enum.positionOrig.ordinal()].trim();
            	this.semanaVendaOrig = line[Step4Enum.semanaVendaOrig.ordinal()].trim();
            	this.codContratoAtual = line[Step4Enum.codContratoAtual.ordinal()].trim();
            	this.nomPlanoAtual = line[Step4Enum.nomPlanoAtual.ordinal()].trim();
            	this.nomeVendedorOrig = line[Step4Enum.nomeVendedorOrig.ordinal()].trim();
            	this.flVendaDuplicada = line[Step4Enum.flVendaDuplicada.ordinal()].trim();
            	this.flGross = line[Step4Enum.flGross.ordinal()].trim();
            	this.dtGross = line[Step4Enum.dtGross.ordinal()].trim();
            	this.flChurn = line[Step4Enum.flChurn.ordinal()].trim();
            	this.dtChurn = line[Step4Enum.dtChurn.ordinal()].trim();
            	this.motivoChurn = line[Step4Enum.motivoChurn.ordinal()].trim();
            	this.codOrdemChurn = line[Step4Enum.codOrdemChurn.ordinal()].trim();
            	this.tipoChurn = line[Step4Enum.tipoChurn.ordinal()].trim();
            	this.dtCriacaoOrdemChurn = line[Step4Enum.dtCriacaoOrdemChurn.ordinal()].trim();
            	this.dtConclusaoOrdemChurn = line[Step4Enum.dtConclusaoOrdemChurn.ordinal()].trim();
            	this.nomeVendedor = line[Step4Enum.nome_vendedor.ordinal()].trim();
            	this.nomeUsuarioCancOrdem = line[Step4Enum.nome_usuario_canc_ordem.ordinal()].trim();
            	this.emailCliente = line[Step4Enum.email_cliente.ordinal()].trim();
            	
            	}
            }
            
		
	}
	
	@Override
	public void write(DataOutput out) throws IOException {
		
		out.writeUTF(this.datref);
		out.writeUTF(this.datCriacaoOrdem);
		out.writeUTF(this.horaCriacaoDaOrdem);
		out.writeUTF(this.datVenda);
		out.writeUTF(this.horaDaVenda);
		out.writeUTF(this.datStatusOrdem);
		out.writeUTF(this.hrStatusOrdem);
		out.writeUTF(this.numOrdemSiebel);
		out.writeUTF(this.numOrdemSiebelOrig);
		out.writeUTF(this.codContratoOltp);
		out.writeUTF(this.codContratoAtivacao);
		out.writeUTF(this.numeroAcesso);
		out.writeUTF(this.customerId);
		out.writeUTF(this.tipoDocumento);
		out.writeUTF(this.documento);
		out.writeUTF(this.tipoVenda);
		out.writeUTF(this.tipoProduto);
		out.writeUTF(this.velocidadeDownload);
		out.writeUTF(this.velocidadeUpload);
		out.writeUTF(this.planoAtivacaoOferta);
		out.writeUTF(this.loginVendedor);
		out.writeUTF(this.canal);
		out.writeUTF(this.cnpjParceiro);
		out.writeUTF(this.custcode);
		out.writeUTF(this.position);
		out.writeUTF(this.flgCancAntesVenda);
		out.writeUTF(this.flgCancPosVenda);
		out.writeUTF(this.dtCancVenda);
		out.writeUTF(this.motivoCancelamento);
		out.writeUTF(this.nomeCliente);
		out.writeUTF(this.telefone);
		out.writeUTF(this.emailFatura);
		out.writeUTF(this.uf);
		out.writeUTF(this.tipoLogradouro);
		out.writeUTF(this.logradouro);
		out.writeUTF(this.numero);
		out.writeUTF(this.complemento);
		out.writeUTF(this.bairro);
		out.writeUTF(this.cep);
		out.writeUTF(this.cidade);
		out.writeUTF(this.statusOrdem);
		out.writeUTF(this.tecnologia);
		out.writeUTF(this.formaPagamento);
		out.writeUTF(this.tipoConta);
		out.writeUTF(this.codBanco);
		out.writeUTF(this.codAgengiaBco);
		out.writeUTF(this.codContaCorrente);
		out.writeUTF(this.codDebitoAutomatico);
		out.writeUTF(this.diaVencimento);
		out.writeUTF(this.semanaVenda);
		out.writeUTF(this.score);
		out.writeUTF(this.scoreConsumido);
		out.writeUTF(this.dtFinalizacaoOrdem);
		out.writeUTF(this.qdeContratos);
		out.writeUTF(this.numProtocolo);
		out.writeUTF(this.flgOrdemAutomatica);
		out.writeUTF(this.dscTxRecorrente);
		out.writeUTF(this.dscTxNaoRecorrente);
		out.writeUTF(this.dscStatusItem);
		out.writeUTF(this.nomLoginResponsavel);
		out.writeUTF(this.flgPortabilidade);
		out.writeUTF(this.dscOperadoraDoadora);
		out.writeUTF(this.codDdd);
		out.writeUTF(this.numTelefonePortado);
		out.writeUTF(this.datJanelaPortabilidade);
		out.writeUTF(this.horaDaJanela);
		out.writeUTF(this.dscEnderecoFatura);
		out.writeUTF(this.dscAreaVoip);
		out.writeUTF(this.cpe);
		out.writeUTF(this.ont);
		out.writeUTF(this.codigoConvergente);
		out.writeUTF(this.detalheRecusaCrivo);
		out.writeUTF(this.itemRoot);
		out.writeUTF(this.loginCancelamentoOrdem);
		out.writeUTF(this.custcodeCliente);
		out.writeUTF(this.dominioRoot);
		out.writeUTF(this.codContFinanceira);
		out.writeUTF(this.valPlanoAtualItem);
		out.writeUTF(this.nomDescontoAtualItem);
		out.writeUTF(this.valDescontoAtualItem);
		out.writeUTF(this.nroOrdem);
		out.writeUTF(this.acessoRowId);
		out.writeUTF(this.acessoRowIdRoot);
		out.writeUTF(this.codigoProduto);
		out.writeUTF(this.flgVendaSubmetida);
		out.writeUTF(this.flgVendaDuplicada);
		out.writeUTF(this.flgVendaBruta);
		out.writeUTF(this.flgVendaLiquida);
		out.writeUTF(this.flgCancDupl);
		out.writeUTF(this.flgCancLiquido);
		out.writeUTF(this.nomeParceiroVenda);
		out.writeUTF(this.nomeParceiroVendaOrig);
		out.writeUTF(this.rowIdItemOrdem);
		out.writeUTF(this.rowIdItemOrdemPai);
		out.writeUTF(this.categoriaItemOrder);
		out.writeUTF(this.datVendaOrig);
		out.writeUTF(this.horaVendaOrig);
		out.writeUTF(this.loginVendedorOrig);
		out.writeUTF(this.canalOrig);
		out.writeUTF(this.cnpjParceiroOrig);
		out.writeUTF(this.custcodeOrig);
		out.writeUTF(this.positionOrig);
		out.writeUTF(this.semanaVendaOrig);
		out.writeUTF(this.codContratoAtual);
		out.writeUTF(this.nomPlanoAtual);
		out.writeUTF(this.nomeVendedorOrig);
		out.writeUTF(this.flVendaDuplicada);
		out.writeUTF(this.flGross);
		out.writeUTF(this.dtGross);
		out.writeUTF(this.flChurn);
		out.writeUTF(this.dtChurn);
		out.writeUTF(this.motivoChurn);
		out.writeUTF(this.codOrdemChurn);
		out.writeUTF(this.tipoChurn);
		out.writeUTF(this.dtCriacaoOrdemChurn);
		out.writeUTF(this.dtConclusaoOrdemChurn);
		out.writeUTF(this.msanOltVenda);
		out.writeUTF(this.dtConclusaoWfm);
		out.writeUTF(this.dscStatusOrdemWfm);
		out.writeUTF(this.datStatusWfm);
		out.writeUTF(this.horaStatusWfm);
		out.writeUTF(this.idRecursoWfm);
		out.writeUTF(this.nomRecursoWfm);
		out.writeUTF(this.idRecursoPaiWfm);
		out.writeUTF(this.datPrimeiroAgend);
		out.writeUTF(this.horaPrimeiroAgendamento);
		out.writeUTF(this.datAgendAtual);
		out.writeUTF(this.horaAgendamentoAtual);
		out.writeUTF(this.dscStatusAtivacao);
		out.writeUTF(this.msanOltTrafego);
		out.writeUTF(this.nomeVendedor);
		out.writeUTF(this.nomeUsuarioCancOrdem);
		out.writeUTF(this.emailCliente);


	}
	
	@Override
	public void readFields(DataInput in) throws IOException {

		this.datref = in.readUTF();
		this.datCriacaoOrdem = in.readUTF();
		this.horaCriacaoDaOrdem = in.readUTF();
		this.datVenda = in.readUTF();
		this.horaDaVenda = in.readUTF();
		this.datStatusOrdem = in.readUTF();
		this.hrStatusOrdem = in.readUTF();
		this.numOrdemSiebel = in.readUTF();
		this.numOrdemSiebelOrig = in.readUTF();
		this.codContratoOltp = in.readUTF();
		this.codContratoAtivacao = in.readUTF();
		this.numeroAcesso = in.readUTF();
		this.customerId = in.readUTF();
		this.tipoDocumento = in.readUTF();
		this.documento = in.readUTF();
		this.tipoVenda = in.readUTF();
		this.tipoProduto = in.readUTF();
		this.velocidadeDownload = in.readUTF();
		this.velocidadeUpload = in.readUTF();
		this.planoAtivacaoOferta = in.readUTF();
		this.loginVendedor = in.readUTF();
		this.canal = in.readUTF();
		this.cnpjParceiro = in.readUTF();
		this.custcode = in.readUTF();
		this.position = in.readUTF();
		this.flgCancAntesVenda = in.readUTF();
		this.flgCancPosVenda = in.readUTF();
		this.dtCancVenda = in.readUTF();
		this.motivoCancelamento = in.readUTF();
		this.nomeCliente = in.readUTF();
		this.telefone = in.readUTF();
		this.emailFatura = in.readUTF();
		this.uf = in.readUTF();
		this.tipoLogradouro = in.readUTF();
		this.logradouro = in.readUTF();
		this.numero = in.readUTF();
		this.complemento = in.readUTF();
		this.bairro = in.readUTF();
		this.cep = in.readUTF();
		this.cidade = in.readUTF();
		this.statusOrdem = in.readUTF();
		this.tecnologia = in.readUTF();
		this.formaPagamento = in.readUTF();
		this.tipoConta = in.readUTF();
		this.codBanco = in.readUTF();
		this.codAgengiaBco = in.readUTF();
		this.codContaCorrente = in.readUTF();
		this.codDebitoAutomatico = in.readUTF();
		this.diaVencimento = in.readUTF();
		this.semanaVenda = in.readUTF();
		this.score = in.readUTF();
		this.scoreConsumido = in.readUTF();
		this.dtFinalizacaoOrdem = in.readUTF();
		this.qdeContratos = in.readUTF();
		this.numProtocolo = in.readUTF();
		this.flgOrdemAutomatica = in.readUTF();
		this.dscTxRecorrente = in.readUTF();
		this.dscTxNaoRecorrente = in.readUTF();
		this.dscStatusItem = in.readUTF();
		this.nomLoginResponsavel = in.readUTF();
		this.flgPortabilidade = in.readUTF();
		this.dscOperadoraDoadora = in.readUTF();
		this.codDdd = in.readUTF();
		this.numTelefonePortado = in.readUTF();
		this.datJanelaPortabilidade = in.readUTF();
		this.horaDaJanela = in.readUTF();
		this.dscEnderecoFatura = in.readUTF();
		this.dscAreaVoip = in.readUTF();
		this.cpe = in.readUTF();
		this.ont = in.readUTF();
		this.codigoConvergente = in.readUTF();
		this.detalheRecusaCrivo = in.readUTF();
		this.itemRoot = in.readUTF();
		this.loginCancelamentoOrdem = in.readUTF();
		this.custcodeCliente = in.readUTF();
		this.dominioRoot = in.readUTF();
		this.codContFinanceira = in.readUTF();
		this.valPlanoAtualItem = in.readUTF();
		this.nomDescontoAtualItem = in.readUTF();
		this.valDescontoAtualItem = in.readUTF();
		this.nroOrdem = in.readUTF();
		this.acessoRowId = in.readUTF();
		this.acessoRowIdRoot = in.readUTF();
		this.codigoProduto = in.readUTF();
		this.flgVendaSubmetida = in.readUTF();
		this.flgVendaDuplicada = in.readUTF();
		this.flgVendaBruta = in.readUTF();
		this.flgVendaLiquida = in.readUTF();
		this.flgCancDupl = in.readUTF();
		this.flgCancLiquido = in.readUTF();
		this.nomeParceiroVenda = in.readUTF();
		this.nomeParceiroVendaOrig = in.readUTF();
		this.rowIdItemOrdem = in.readUTF();
		this.rowIdItemOrdemPai = in.readUTF();
		this.categoriaItemOrder = in.readUTF();
		this.datVendaOrig = in.readUTF();
		this.horaVendaOrig = in.readUTF();
		this.loginVendedorOrig = in.readUTF();
		this.canalOrig = in.readUTF();
		this.cnpjParceiroOrig = in.readUTF();
		this.custcodeOrig = in.readUTF();
		this.positionOrig = in.readUTF();
		this.semanaVendaOrig = in.readUTF();
		this.codContratoAtual = in.readUTF();
		this.nomPlanoAtual = in.readUTF();
		this.nomeVendedorOrig = in.readUTF();
		this.flVendaDuplicada = in.readUTF();
		this.flGross = in.readUTF();
		this.dtGross = in.readUTF();
		this.flChurn = in.readUTF();
		this.dtChurn = in.readUTF();
		this.motivoChurn = in.readUTF();
		this.codOrdemChurn = in.readUTF();
		this.tipoChurn = in.readUTF();
		this.dtCriacaoOrdemChurn = in.readUTF();
		this.dtConclusaoOrdemChurn = in.readUTF();
		this.msanOltVenda = in.readUTF();
		this.dtConclusaoWfm = in.readUTF();
		this.dscStatusOrdemWfm = in.readUTF();
		this.datStatusWfm = in.readUTF();
		this.horaStatusWfm = in.readUTF();
		this.idRecursoWfm = in.readUTF();
		this.nomRecursoWfm = in.readUTF();
		this.idRecursoPaiWfm = in.readUTF();
		this.datPrimeiroAgend = in.readUTF();
		this.horaPrimeiroAgendamento = in.readUTF();
		this.datAgendAtual = in.readUTF();
		this.horaAgendamentoAtual = in.readUTF();
		this.dscStatusAtivacao = in.readUTF();
		this.msanOltTrafego = in.readUTF();
		this.nomeVendedor = in.readUTF();
		this.nomeUsuarioCancOrdem = in.readUTF();
		this.emailCliente = in.readUTF();
		
	}
	
	
	
	public void clean() {
		
		this.datref = CommonsConstants.EMPTY;
		this.datCriacaoOrdem = CommonsConstants.EMPTY;
		this.horaCriacaoDaOrdem = CommonsConstants.EMPTY;
		this.datVenda = CommonsConstants.EMPTY;
		this.horaDaVenda = CommonsConstants.EMPTY;
		this.datStatusOrdem = CommonsConstants.EMPTY;
		this.hrStatusOrdem = CommonsConstants.EMPTY;
		this.numOrdemSiebel = CommonsConstants.EMPTY;
		this.numOrdemSiebelOrig = CommonsConstants.EMPTY;
		this.codContratoOltp = CommonsConstants.EMPTY;
		this.codContratoAtivacao = CommonsConstants.EMPTY;
		this.numeroAcesso = CommonsConstants.EMPTY;
		this.customerId = CommonsConstants.EMPTY;
		this.tipoDocumento = CommonsConstants.EMPTY;
		this.documento = CommonsConstants.EMPTY;
		this.tipoVenda = CommonsConstants.EMPTY;
		this.tipoProduto = CommonsConstants.EMPTY;
		this.velocidadeDownload = CommonsConstants.EMPTY;
		this.velocidadeUpload = CommonsConstants.EMPTY;
		this.planoAtivacaoOferta = CommonsConstants.EMPTY;
		this.loginVendedor = CommonsConstants.EMPTY;
		this.canal = CommonsConstants.EMPTY;
		this.cnpjParceiro = CommonsConstants.EMPTY;
		this.custcode = CommonsConstants.EMPTY;
		this.position = CommonsConstants.EMPTY;
		this.flgCancAntesVenda = CommonsConstants.EMPTY;
		this.flgCancPosVenda = CommonsConstants.EMPTY;
		this.dtCancVenda = CommonsConstants.EMPTY;
		this.motivoCancelamento = CommonsConstants.EMPTY;
		this.nomeCliente = CommonsConstants.EMPTY;
		this.telefone = CommonsConstants.EMPTY;
		this.emailFatura = CommonsConstants.EMPTY;
		this.uf = CommonsConstants.EMPTY;
		this.tipoLogradouro = CommonsConstants.EMPTY;
		this.logradouro = CommonsConstants.EMPTY;
		this.numero = CommonsConstants.EMPTY;
		this.complemento = CommonsConstants.EMPTY;
		this.bairro = CommonsConstants.EMPTY;
		this.cep = CommonsConstants.EMPTY;
		this.cidade = CommonsConstants.EMPTY;
		this.statusOrdem = CommonsConstants.EMPTY;
		this.tecnologia = CommonsConstants.EMPTY;
		this.formaPagamento = CommonsConstants.EMPTY;
		this.tipoConta = CommonsConstants.EMPTY;
		this.codBanco = CommonsConstants.EMPTY;
		this.codAgengiaBco = CommonsConstants.EMPTY;
		this.codContaCorrente = CommonsConstants.EMPTY;
		this.codDebitoAutomatico = CommonsConstants.EMPTY;
		this.diaVencimento = CommonsConstants.EMPTY;
		this.semanaVenda = CommonsConstants.EMPTY;
		this.score = CommonsConstants.EMPTY;
		this.scoreConsumido = CommonsConstants.EMPTY;
		this.dtFinalizacaoOrdem = CommonsConstants.EMPTY;
		this.qdeContratos = CommonsConstants.EMPTY;
		this.numProtocolo = CommonsConstants.EMPTY;
		this.flgOrdemAutomatica = CommonsConstants.EMPTY;
		this.dscTxRecorrente = CommonsConstants.EMPTY;
		this.dscTxNaoRecorrente = CommonsConstants.EMPTY;
		this.dscStatusItem = CommonsConstants.EMPTY;
		this.nomLoginResponsavel = CommonsConstants.EMPTY;
		this.flgPortabilidade = CommonsConstants.EMPTY;
		this.dscOperadoraDoadora = CommonsConstants.EMPTY;
		this.codDdd = CommonsConstants.EMPTY;
		this.numTelefonePortado = CommonsConstants.EMPTY;
		this.datJanelaPortabilidade = CommonsConstants.EMPTY;
		this.horaDaJanela = CommonsConstants.EMPTY;
		this.dscEnderecoFatura = CommonsConstants.EMPTY;
		this.dscAreaVoip = CommonsConstants.EMPTY;
		this.cpe = CommonsConstants.EMPTY;
		this.ont = CommonsConstants.EMPTY;
		this.codigoConvergente = CommonsConstants.EMPTY;
		this.detalheRecusaCrivo = CommonsConstants.EMPTY;
		this.itemRoot = CommonsConstants.EMPTY;
		this.loginCancelamentoOrdem = CommonsConstants.EMPTY;
		this.custcodeCliente = CommonsConstants.EMPTY;
		this.dominioRoot = CommonsConstants.EMPTY;
		this.codContFinanceira = CommonsConstants.EMPTY;
		this.valPlanoAtualItem = CommonsConstants.EMPTY;
		this.nomDescontoAtualItem = CommonsConstants.EMPTY;
		this.valDescontoAtualItem = CommonsConstants.EMPTY;
		this.nroOrdem = CommonsConstants.EMPTY;
		this.acessoRowId = CommonsConstants.EMPTY;
		this.acessoRowIdRoot = CommonsConstants.EMPTY;
		this.codigoProduto = CommonsConstants.EMPTY;
		this.flgVendaSubmetida = CommonsConstants.EMPTY;
		this.flgVendaDuplicada = CommonsConstants.EMPTY;
		this.flgVendaBruta = CommonsConstants.EMPTY;
		this.flgVendaLiquida = CommonsConstants.EMPTY;
		this.flgCancDupl = CommonsConstants.EMPTY;
		this.flgCancLiquido = CommonsConstants.EMPTY;
		this.nomeParceiroVenda = CommonsConstants.EMPTY;
		this.nomeParceiroVendaOrig = CommonsConstants.EMPTY;
		this.rowIdItemOrdem = CommonsConstants.EMPTY;
		this.rowIdItemOrdemPai = CommonsConstants.EMPTY;
		this.categoriaItemOrder = CommonsConstants.EMPTY;
		this.datVendaOrig = CommonsConstants.EMPTY;
		this.horaVendaOrig = CommonsConstants.EMPTY;
		this.loginVendedorOrig = CommonsConstants.EMPTY;
		this.canalOrig = CommonsConstants.EMPTY;
		this.cnpjParceiroOrig = CommonsConstants.EMPTY;
		this.custcodeOrig = CommonsConstants.EMPTY;
		this.positionOrig = CommonsConstants.EMPTY;
		this.semanaVendaOrig = CommonsConstants.EMPTY;
		this.codContratoAtual = CommonsConstants.EMPTY;
		this.nomPlanoAtual = CommonsConstants.EMPTY;
		this.nomeVendedorOrig = CommonsConstants.EMPTY;
		this.flVendaDuplicada = CommonsConstants.EMPTY;
		this.flGross = CommonsConstants.EMPTY;
		this.dtGross = CommonsConstants.EMPTY;
		this.flChurn = CommonsConstants.EMPTY;
		this.dtChurn = CommonsConstants.EMPTY;
		this.motivoChurn = CommonsConstants.EMPTY;
		this.codOrdemChurn = CommonsConstants.EMPTY;
		this.tipoChurn = CommonsConstants.EMPTY;
		this.dtCriacaoOrdemChurn = CommonsConstants.EMPTY;
		this.dtConclusaoOrdemChurn = CommonsConstants.EMPTY;
		this.msanOltVenda = CommonsConstants.EMPTY;
		this.dtConclusaoWfm = CommonsConstants.EMPTY;
		this.dscStatusOrdemWfm = CommonsConstants.EMPTY;
		this.datStatusWfm = CommonsConstants.EMPTY;
		this.horaStatusWfm = CommonsConstants.EMPTY;
		this.idRecursoWfm = CommonsConstants.EMPTY;
		this.nomRecursoWfm = CommonsConstants.EMPTY;
		this.idRecursoPaiWfm = CommonsConstants.EMPTY;
		this.datPrimeiroAgend = CommonsConstants.EMPTY;
		this.horaPrimeiroAgendamento = CommonsConstants.EMPTY;
		this.datAgendAtual = CommonsConstants.EMPTY;
		this.horaAgendamentoAtual = CommonsConstants.EMPTY;
		this.dscStatusAtivacao = CommonsConstants.EMPTY;
		this.msanOltTrafego = CommonsConstants.EMPTY;
		this.nomeVendedor = CommonsConstants.EMPTY;
		this.nomeUsuarioCancOrdem = CommonsConstants.EMPTY;
		this.emailCliente = CommonsConstants.EMPTY;
		
	}


	


	public String getDatref() {
		return datref;
	}


	public void setDatref(String datref) {
		this.datref = datref;
	}


	public String getDatCriacaoOrdem() {
		return datCriacaoOrdem;
	}


	public void setDatCriacaoOrdem(String datCriacaoOrdem) {
		this.datCriacaoOrdem = datCriacaoOrdem;
	}


	public String getHoraCriacaoDaOrdem() {
		return horaCriacaoDaOrdem;
	}


	public void setHoraCriacaoDaOrdem(String horaCriacaoDaOrdem) {
		this.horaCriacaoDaOrdem = horaCriacaoDaOrdem;
	}


	public String getDatVenda() {
		return datVenda;
	}


	public void setDatVenda(String datVenda) {
		this.datVenda = datVenda;
	}


	public String getHoraDaVenda() {
		return horaDaVenda;
	}


	public void setHoraDaVenda(String horaDaVenda) {
		this.horaDaVenda = horaDaVenda;
	}


	public String getDatStatusOrdem() {
		return datStatusOrdem;
	}


	public void setDatStatusOrdem(String datStatusOrdem) {
		this.datStatusOrdem = datStatusOrdem;
	}


	public String getHrStatusOrdem() {
		return hrStatusOrdem;
	}


	public void setHrStatusOrdem(String hrStatusOrdem) {
		this.hrStatusOrdem = hrStatusOrdem;
	}


	public String getNumOrdemSiebel() {
		return numOrdemSiebel;
	}


	public void setNumOrdemSiebel(String numOrdemSiebel) {
		this.numOrdemSiebel = numOrdemSiebel;
	}


	public String getNumOrdemSiebelOrig() {
		return numOrdemSiebelOrig;
	}


	public void setNumOrdemSiebelOrig(String numOrdemSiebelOrig) {
		this.numOrdemSiebelOrig = numOrdemSiebelOrig;
	}


	public String getCodContratoOltp() {
		return codContratoOltp;
	}


	public void setCodContratoOltp(String codContratoOltp) {
		this.codContratoOltp = codContratoOltp;
	}


	public String getCodContratoAtivacao() {
		return codContratoAtivacao;
	}


	public void setCodContratoAtivacao(String codContratoAtivacao) {
		this.codContratoAtivacao = codContratoAtivacao;
	}


	public String getNumeroAcesso() {
		return numeroAcesso;
	}


	public void setNumeroAcesso(String numeroAcesso) {
		this.numeroAcesso = numeroAcesso;
	}


	public String getCustomerId() {
		return customerId;
	}


	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}


	public String getTipoDocumento() {
		return tipoDocumento;
	}


	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}


	public String getDocumento() {
		return documento;
	}


	public void setDocumento(String documento) {
		this.documento = documento;
	}


	public String getTipoVenda() {
		return tipoVenda;
	}


	public void setTipoVenda(String tipoVenda) {
		this.tipoVenda = tipoVenda;
	}


	public String getTipoProduto() {
		return tipoProduto;
	}


	public void setTipoProduto(String tipoProduto) {
		this.tipoProduto = tipoProduto;
	}


	public String getVelocidadeDownload() {
		return velocidadeDownload;
	}


	public void setVelocidadeDownload(String velocidadeDownload) {
		this.velocidadeDownload = velocidadeDownload;
	}


	public String getVelocidadeUpload() {
		return velocidadeUpload;
	}


	public void setVelocidadeUpload(String velocidadeUpload) {
		this.velocidadeUpload = velocidadeUpload;
	}


	public String getPlanoAtivacaoOferta() {
		return planoAtivacaoOferta;
	}


	public void setPlanoAtivacaoOferta(String planoAtivacaoOferta) {
		this.planoAtivacaoOferta = planoAtivacaoOferta;
	}


	public String getLoginVendedor() {
		return loginVendedor;
	}


	public void setLoginVendedor(String loginVendedor) {
		this.loginVendedor = loginVendedor;
	}


	public String getCanal() {
		return canal;
	}


	public void setCanal(String canal) {
		this.canal = canal;
	}


	public String getCnpjParceiro() {
		return cnpjParceiro;
	}


	public void setCnpjParceiro(String cnpjParceiro) {
		this.cnpjParceiro = cnpjParceiro;
	}


	public String getCustcode() {
		return custcode;
	}


	public void setCustcode(String custcode) {
		this.custcode = custcode;
	}


	public String getPosition() {
		return position;
	}


	public void setPosition(String position) {
		this.position = position;
	}


	public String getFlgCancAntesVenda() {
		return flgCancAntesVenda;
	}


	public void setFlgCancAntesVenda(String flgCancAntesVenda) {
		this.flgCancAntesVenda = flgCancAntesVenda;
	}


	public String getFlgCancPosVenda() {
		return flgCancPosVenda;
	}


	public void setFlgCancPosVenda(String flgCancPosVenda) {
		this.flgCancPosVenda = flgCancPosVenda;
	}


	public String getDtCancVenda() {
		return dtCancVenda;
	}


	public void setDtCancVenda(String dtCancVenda) {
		this.dtCancVenda = dtCancVenda;
	}


	public String getMotivoCancelamento() {
		return motivoCancelamento;
	}


	public void setMotivoCancelamento(String motivoCancelamento) {
		this.motivoCancelamento = motivoCancelamento;
	}


	public String getNomeCliente() {
		return nomeCliente;
	}


	public void setNomeCliente(String nomeCliente) {
		this.nomeCliente = nomeCliente;
	}


	public String getTelefone() {
		return telefone;
	}


	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}


	public String getEmailFatura() {
		return emailFatura;
	}


	public void setEmailFatura(String emailFatura) {
		this.emailFatura = emailFatura;
	}


	public String getUf() {
		return uf;
	}


	public void setUf(String uf) {
		this.uf = uf;
	}


	public String getTipoLogradouro() {
		return tipoLogradouro;
	}


	public void setTipoLogradouro(String tipoLogradouro) {
		this.tipoLogradouro = tipoLogradouro;
	}


	public String getLogradouro() {
		return logradouro;
	}


	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}


	public String getNumero() {
		return numero;
	}


	public void setNumero(String numero) {
		this.numero = numero;
	}


	public String getComplemento() {
		return complemento;
	}


	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}


	public String getBairro() {
		return bairro;
	}


	public void setBairro(String bairro) {
		this.bairro = bairro;
	}


	public String getCep() {
		return cep;
	}


	public void setCep(String cep) {
		this.cep = cep;
	}


	public String getCidade() {
		return cidade;
	}


	public void setCidade(String cidade) {
		this.cidade = cidade;
	}


	public String getStatusOrdem() {
		return statusOrdem;
	}


	public void setStatusOrdem(String statusOrdem) {
		this.statusOrdem = statusOrdem;
	}


	public String getTecnologia() {
		return tecnologia;
	}


	public void setTecnologia(String tecnologia) {
		this.tecnologia = tecnologia;
	}


	public String getFormaPagamento() {
		return formaPagamento;
	}


	public void setFormaPagamento(String formaPagamento) {
		this.formaPagamento = formaPagamento;
	}


	public String getTipoConta() {
		return tipoConta;
	}


	public void setTipoConta(String tipoConta) {
		this.tipoConta = tipoConta;
	}


	public String getCodBanco() {
		return codBanco;
	}


	public void setCodBanco(String codBanco) {
		this.codBanco = codBanco;
	}


	public String getCodAgengiaBco() {
		return codAgengiaBco;
	}


	public void setCodAgengiaBco(String codAgengiaBco) {
		this.codAgengiaBco = codAgengiaBco;
	}


	public String getCodContaCorrente() {
		return codContaCorrente;
	}


	public void setCodContaCorrente(String codContaCorrente) {
		this.codContaCorrente = codContaCorrente;
	}


	public String getCodDebitoAutomatico() {
		return codDebitoAutomatico;
	}


	public void setCodDebitoAutomatico(String codDebitoAutomatico) {
		this.codDebitoAutomatico = codDebitoAutomatico;
	}


	public String getDiaVencimento() {
		return diaVencimento;
	}


	public void setDiaVencimento(String diaVencimento) {
		this.diaVencimento = diaVencimento;
	}


	public String getSemanaVenda() {
		return semanaVenda;
	}


	public void setSemanaVenda(String semanaVenda) {
		this.semanaVenda = semanaVenda;
	}


	public String getScore() {
		return score;
	}


	public void setScore(String score) {
		this.score = score;
	}


	public String getScoreConsumido() {
		return scoreConsumido;
	}


	public void setScoreConsumido(String scoreConsumido) {
		this.scoreConsumido = scoreConsumido;
	}


	public String getDtFinalizacaoOrdem() {
		return dtFinalizacaoOrdem;
	}


	public void setDtFinalizacaoOrdem(String dtFinalizacaoOrdem) {
		this.dtFinalizacaoOrdem = dtFinalizacaoOrdem;
	}


	public String getQdeContratos() {
		return qdeContratos;
	}


	public void setQdeContratos(String qdeContratos) {
		this.qdeContratos = qdeContratos;
	}


	public String getNumProtocolo() {
		return numProtocolo;
	}


	public void setNumProtocolo(String numProtocolo) {
		this.numProtocolo = numProtocolo;
	}


	public String getFlgOrdemAutomatica() {
		return flgOrdemAutomatica;
	}


	public void setFlgOrdemAutomatica(String flgOrdemAutomatica) {
		this.flgOrdemAutomatica = flgOrdemAutomatica;
	}


	public String getDscTxRecorrente() {
		return dscTxRecorrente;
	}


	public void setDscTxRecorrente(String dscTxRecorrente) {
		this.dscTxRecorrente = dscTxRecorrente;
	}


	public String getDscTxNaoRecorrente() {
		return dscTxNaoRecorrente;
	}


	public void setDscTxNaoRecorrente(String dscTxNaoRecorrente) {
		this.dscTxNaoRecorrente = dscTxNaoRecorrente;
	}


	public String getDscStatusItem() {
		return dscStatusItem;
	}


	public void setDscStatusItem(String dscStatusItem) {
		this.dscStatusItem = dscStatusItem;
	}


	public String getNomLoginResponsavel() {
		return nomLoginResponsavel;
	}


	public void setNomLoginResponsavel(String nomLoginResponsavel) {
		this.nomLoginResponsavel = nomLoginResponsavel;
	}


	public String getFlgPortabilidade() {
		return flgPortabilidade;
	}


	public void setFlgPortabilidade(String flgPortabilidade) {
		this.flgPortabilidade = flgPortabilidade;
	}


	public String getDscOperadoraDoadora() {
		return dscOperadoraDoadora;
	}


	public void setDscOperadoraDoadora(String dscOperadoraDoadora) {
		this.dscOperadoraDoadora = dscOperadoraDoadora;
	}


	public String getCodDdd() {
		return codDdd;
	}


	public void setCodDdd(String codDdd) {
		this.codDdd = codDdd;
	}


	public String getNumTelefonePortado() {
		return numTelefonePortado;
	}


	public void setNumTelefonePortado(String numTelefonePortado) {
		this.numTelefonePortado = numTelefonePortado;
	}


	public String getDatJanelaPortabilidade() {
		return datJanelaPortabilidade;
	}


	public void setDatJanelaPortabilidade(String datJanelaPortabilidade) {
		this.datJanelaPortabilidade = datJanelaPortabilidade;
	}


	public String getHoraDaJanela() {
		return horaDaJanela;
	}


	public void setHoraDaJanela(String horaDaJanela) {
		this.horaDaJanela = horaDaJanela;
	}


	public String getDscEnderecoFatura() {
		return dscEnderecoFatura;
	}


	public void setDscEnderecoFatura(String dscEnderecoFatura) {
		this.dscEnderecoFatura = dscEnderecoFatura;
	}


	public String getDscAreaVoip() {
		return dscAreaVoip;
	}


	public void setDscAreaVoip(String dscAreaVoip) {
		this.dscAreaVoip = dscAreaVoip;
	}


	public String getCpe() {
		return cpe;
	}


	public void setCpe(String cpe) {
		this.cpe = cpe;
	}


	public String getOnt() {
		return ont;
	}


	public void setOnt(String ont) {
		this.ont = ont;
	}


	public String getCodigoConvergente() {
		return codigoConvergente;
	}


	public void setCodigoConvergente(String codigoConvergente) {
		this.codigoConvergente = codigoConvergente;
	}


	public String getDetalheRecusaCrivo() {
		return detalheRecusaCrivo;
	}


	public void setDetalheRecusaCrivo(String detalheRecusaCrivo) {
		this.detalheRecusaCrivo = detalheRecusaCrivo;
	}


	public String getItemRoot() {
		return itemRoot;
	}


	public void setItemRoot(String itemRoot) {
		this.itemRoot = itemRoot;
	}


	public String getLoginCancelamentoOrdem() {
		return loginCancelamentoOrdem;
	}


	public void setLoginCancelamentoOrdem(String loginCancelamentoOrdem) {
		this.loginCancelamentoOrdem = loginCancelamentoOrdem;
	}


	public String getCustcodeCliente() {
		return custcodeCliente;
	}


	public void setCustcodeCliente(String custcodeCliente) {
		this.custcodeCliente = custcodeCliente;
	}


	public String getDominioRoot() {
		return dominioRoot;
	}


	public void setDominioRoot(String dominioRoot) {
		this.dominioRoot = dominioRoot;
	}


	public String getCodContFinanceira() {
		return codContFinanceira;
	}


	public void setCodContFinanceira(String codContFinanceira) {
		this.codContFinanceira = codContFinanceira;
	}


	public String getValPlanoAtualItem() {
		return valPlanoAtualItem;
	}


	public void setValPlanoAtualItem(String valPlanoAtualItem) {
		this.valPlanoAtualItem = valPlanoAtualItem;
	}


	public String getNomDescontoAtualItem() {
		return nomDescontoAtualItem;
	}


	public void setNomDescontoAtualItem(String nomDescontoAtualItem) {
		this.nomDescontoAtualItem = nomDescontoAtualItem;
	}


	public String getValDescontoAtualItem() {
		return valDescontoAtualItem;
	}


	public void setValDescontoAtualItem(String valDescontoAtualItem) {
		this.valDescontoAtualItem = valDescontoAtualItem;
	}


	public String getNroOrdem() {
		return nroOrdem;
	}


	public void setNroOrdem(String nroOrdem) {
		this.nroOrdem = nroOrdem;
	}


	public String getAcessoRowId() {
		return acessoRowId;
	}


	public void setAcessoRowId(String acessoRowId) {
		this.acessoRowId = acessoRowId;
	}


	public String getAcessoRowIdRoot() {
		return acessoRowIdRoot;
	}


	public void setAcessoRowIdRoot(String acessoRowIdRoot) {
		this.acessoRowIdRoot = acessoRowIdRoot;
	}


	public String getCodigoProduto() {
		return codigoProduto;
	}


	public void setCodigoProduto(String codigoProduto) {
		this.codigoProduto = codigoProduto;
	}


	public String getFlgVendaSubmetida() {
		return flgVendaSubmetida;
	}


	public void setFlgVendaSubmetida(String flgVendaSubmetida) {
		this.flgVendaSubmetida = flgVendaSubmetida;
	}


	public String getFlgVendaDuplicada() {
		return flgVendaDuplicada;
	}


	public void setFlgVendaDuplicada(String flgVendaDuplicada) {
		this.flgVendaDuplicada = flgVendaDuplicada;
	}


	public String getFlgVendaBruta() {
		return flgVendaBruta;
	}


	public void setFlgVendaBruta(String flgVendaBruta) {
		this.flgVendaBruta = flgVendaBruta;
	}


	public String getFlgVendaLiquida() {
		return flgVendaLiquida;
	}


	public void setFlgVendaLiquida(String flgVendaLiquida) {
		this.flgVendaLiquida = flgVendaLiquida;
	}


	public String getFlgCancDupl() {
		return flgCancDupl;
	}


	public void setFlgCancDupl(String flgCancDupl) {
		this.flgCancDupl = flgCancDupl;
	}


	public String getFlgCancLiquido() {
		return flgCancLiquido;
	}


	public void setFlgCancLiquido(String flgCancLiquido) {
		this.flgCancLiquido = flgCancLiquido;
	}


	public String getNomeParceiroVenda() {
		return nomeParceiroVenda;
	}


	public void setNomeParceiroVenda(String nomeParceiroVenda) {
		this.nomeParceiroVenda = nomeParceiroVenda;
	}


	public String getNomeParceiroVendaOrig() {
		return nomeParceiroVendaOrig;
	}


	public void setNomeParceiroVendaOrig(String nomeParceiroVendaOrig) {
		this.nomeParceiroVendaOrig = nomeParceiroVendaOrig;
	}


	public String getRowIdItemOrdem() {
		return rowIdItemOrdem;
	}


	public void setRowIdItemOrdem(String rowIdItemOrdem) {
		this.rowIdItemOrdem = rowIdItemOrdem;
	}


	public String getRowIdItemOrdemPai() {
		return rowIdItemOrdemPai;
	}


	public void setRowIdItemOrdemPai(String rowIdItemOrdemPai) {
		this.rowIdItemOrdemPai = rowIdItemOrdemPai;
	}


	public String getCategoriaItemOrder() {
		return categoriaItemOrder;
	}


	public void setCategoriaItemOrder(String categoriaItemOrder) {
		this.categoriaItemOrder = categoriaItemOrder;
	}


	public String getMsanOltVenda() {
		return msanOltVenda;
	}


	public void setMsanOltVenda(String msanOltVenda) {
		this.msanOltVenda = msanOltVenda;
	}


	public String getDtConclusaoWfm() {
		return dtConclusaoWfm;
	}


	public void setDtConclusaoWfm(String dtConclusaoWfm) {
		this.dtConclusaoWfm = dtConclusaoWfm;
	}


	public String getDscStatusOrdemWfm() {
		return dscStatusOrdemWfm;
	}


	public void setDscStatusOrdemWfm(String dscStatusOrdemWfm) {
		this.dscStatusOrdemWfm = dscStatusOrdemWfm;
	}


	public String getDatStatusWfm() {
		return datStatusWfm;
	}


	public void setDatStatusWfm(String datStatusWfm) {
		this.datStatusWfm = datStatusWfm;
	}


	public String getHoraStatusWfm() {
		return horaStatusWfm;
	}


	public void setHoraStatusWfm(String horaStatusWfm) {
		this.horaStatusWfm = horaStatusWfm;
	}


	public String getIdRecursoWfm() {
		return idRecursoWfm;
	}


	public void setIdRecursoWfm(String idRecursoWfm) {
		this.idRecursoWfm = idRecursoWfm;
	}


	public String getNomRecursoWfm() {
		return nomRecursoWfm;
	}


	public void setNomRecursoWfm(String nomRecursoWfm) {
		this.nomRecursoWfm = nomRecursoWfm;
	}


	public String getIdRecursoPaiWfm() {
		return idRecursoPaiWfm;
	}


	public void setIdRecursoPaiWfm(String idRecursoPaiWfm) {
		this.idRecursoPaiWfm = idRecursoPaiWfm;
	}


	public String getDatPrimeiroAgend() {
		return datPrimeiroAgend;
	}


	public void setDatPrimeiroAgend(String datPrimeiroAgend) {
		this.datPrimeiroAgend = datPrimeiroAgend;
	}


	public String getHoraPrimeiroAgendamento() {
		return horaPrimeiroAgendamento;
	}


	public void setHoraPrimeiroAgendamento(String horaPrimeiroAgendamento) {
		this.horaPrimeiroAgendamento = horaPrimeiroAgendamento;
	}


	public String getDatAgendAtual() {
		return datAgendAtual;
	}


	public void setDatAgendAtual(String datAgendAtual) {
		this.datAgendAtual = datAgendAtual;
	}


	public String getHoraAgendamentoAtual() {
		return horaAgendamentoAtual;
	}


	public void setHoraAgendamentoAtual(String horaAgendamentoAtual) {
		this.horaAgendamentoAtual = horaAgendamentoAtual;
	}


	public String getDscStatusAtivacao() {
		return dscStatusAtivacao;
	}


	public void setDscStatusAtivacao(String dscStatusAtivacao) {
		this.dscStatusAtivacao = dscStatusAtivacao;
	}


	public String getMsanOltTrafego() {
		return msanOltTrafego;
	}


	public void setMsanOltTrafego(String msanOltTrafego) {
		this.msanOltTrafego = msanOltTrafego;
	}


	public String getDatVendaOrig() {
		return datVendaOrig;
	}


	public void setDatVendaOrig(String datVendaOrig) {
		this.datVendaOrig = datVendaOrig;
	}


	public String getHoraVendaOrig() {
		return horaVendaOrig;
	}


	public void setHoraVendaOrig(String horaVendaOrig) {
		this.horaVendaOrig = horaVendaOrig;
	}


	public String getLoginVendedorOrig() {
		return loginVendedorOrig;
	}


	public void setLoginVendedorOrig(String loginVendedorOrig) {
		this.loginVendedorOrig = loginVendedorOrig;
	}


	public String getCanalOrig() {
		return canalOrig;
	}


	public void setCanalOrig(String canalOrig) {
		this.canalOrig = canalOrig;
	}


	public String getCnpjParceiroOrig() {
		return cnpjParceiroOrig;
	}


	public void setCnpjParceiroOrig(String cnpjParceiroOrig) {
		this.cnpjParceiroOrig = cnpjParceiroOrig;
	}


	public String getCustcodeOrig() {
		return custcodeOrig;
	}


	public void setCustcodeOrig(String custcodeOrig) {
		this.custcodeOrig = custcodeOrig;
	}


	public String getPositionOrig() {
		return positionOrig;
	}


	public void setPositionOrig(String positionOrig) {
		this.positionOrig = positionOrig;
	}


	public String getSemanaVendaOrig() {
		return semanaVendaOrig;
	}


	public void setSemanaVendaOrig(String semanaVendaOrig) {
		this.semanaVendaOrig = semanaVendaOrig;
	}


	public String getCodContratoAtual() {
		return codContratoAtual;
	}


	public void setCodContratoAtual(String codContratoAtual) {
		this.codContratoAtual = codContratoAtual;
	}


	public String getNomPlanoAtual() {
		return nomPlanoAtual;
	}


	public void setNomPlanoAtual(String nomPlanoAtual) {
		this.nomPlanoAtual = nomPlanoAtual;
	}


	public String getNomeVendedorOrig() {
		return nomeVendedorOrig;
	}


	public void setNomeVendedorOrig(String nomeVendedorOrig) {
		this.nomeVendedorOrig = nomeVendedorOrig;
	}


	public String getFlVendaDuplicada() {
		return flVendaDuplicada;
	}


	public void setFlVendaDuplicada(String flVendaDuplicada) {
		this.flVendaDuplicada = flVendaDuplicada;
	}


	public String getFlGross() {
		return flGross;
	}


	public void setFlGross(String flGross) {
		this.flGross = flGross;
	}


	public String getDtGross() {
		return dtGross;
	}


	public void setDtGross(String dtGross) {
		this.dtGross = dtGross;
	}


	public String getFlChurn() {
		return flChurn;
	}


	public void setFlChurn(String flChurn) {
		this.flChurn = flChurn;
	}


	public String getDtChurn() {
		return dtChurn;
	}


	public void setDtChurn(String dtChurn) {
		this.dtChurn = dtChurn;
	}


	public String getMotivoChurn() {
		return motivoChurn;
	}


	public void setMotivoChurn(String motivoChurn) {
		this.motivoChurn = motivoChurn;
	}


	public String getCodOrdemChurn() {
		return codOrdemChurn;
	}


	public void setCodOrdemChurn(String codOrdemChurn) {
		this.codOrdemChurn = codOrdemChurn;
	}


	public String getTipoChurn() {
		return tipoChurn;
	}


	public void setTipoChurn(String tipoChurn) {
		this.tipoChurn = tipoChurn;
	}


	public String getDtCriacaoOrdemChurn() {
		return dtCriacaoOrdemChurn;
	}


	public void setDtCriacaoOrdemChurn(String dtCriacaoOrdemChurn) {
		this.dtCriacaoOrdemChurn = dtCriacaoOrdemChurn;
	}


	public String getDtConclusaoOrdemChurn() {
		return dtConclusaoOrdemChurn;
	}


	public void setDtConclusaoOrdemChurn(String dtConclusaoOrdemChurn) {
		this.dtConclusaoOrdemChurn = dtConclusaoOrdemChurn;
	}


	public String getNomeVendedor() {
		return nomeVendedor;
	}


	public void setNomeVendedor(String nomeVendedor) {
		this.nomeVendedor = nomeVendedor;
	}


	public String getNomeUsuarioCancOrdem() {
		return nomeUsuarioCancOrdem;
	}


	public void setNomeUsuarioCancOrdem(String nomeUsuarioCancOrdem) {
		this.nomeUsuarioCancOrdem = nomeUsuarioCancOrdem;
	}


	public String getEmailCliente() {
		return emailCliente;
	}


	public void setEmailCliente(String emailCliente) {
		this.emailCliente = emailCliente;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((acessoRowId == null) ? 0 : acessoRowId.hashCode());
		result = prime * result + ((acessoRowIdRoot == null) ? 0 : acessoRowIdRoot.hashCode());
		result = prime * result + ((bairro == null) ? 0 : bairro.hashCode());
		result = prime * result + ((canal == null) ? 0 : canal.hashCode());
		result = prime * result + ((canalOrig == null) ? 0 : canalOrig.hashCode());
		result = prime * result + ((categoriaItemOrder == null) ? 0 : categoriaItemOrder.hashCode());
		result = prime * result + ((cep == null) ? 0 : cep.hashCode());
		result = prime * result + ((cidade == null) ? 0 : cidade.hashCode());
		result = prime * result + ((cnpjParceiro == null) ? 0 : cnpjParceiro.hashCode());
		result = prime * result + ((cnpjParceiroOrig == null) ? 0 : cnpjParceiroOrig.hashCode());
		result = prime * result + ((codAgengiaBco == null) ? 0 : codAgengiaBco.hashCode());
		result = prime * result + ((codBanco == null) ? 0 : codBanco.hashCode());
		result = prime * result + ((codContFinanceira == null) ? 0 : codContFinanceira.hashCode());
		result = prime * result + ((codContaCorrente == null) ? 0 : codContaCorrente.hashCode());
		result = prime * result + ((codContratoAtivacao == null) ? 0 : codContratoAtivacao.hashCode());
		result = prime * result + ((codContratoAtual == null) ? 0 : codContratoAtual.hashCode());
		result = prime * result + ((codContratoOltp == null) ? 0 : codContratoOltp.hashCode());
		result = prime * result + ((codDdd == null) ? 0 : codDdd.hashCode());
		result = prime * result + ((codDebitoAutomatico == null) ? 0 : codDebitoAutomatico.hashCode());
		result = prime * result + ((codOrdemChurn == null) ? 0 : codOrdemChurn.hashCode());
		result = prime * result + ((codigoConvergente == null) ? 0 : codigoConvergente.hashCode());
		result = prime * result + ((codigoProduto == null) ? 0 : codigoProduto.hashCode());
		result = prime * result + ((complemento == null) ? 0 : complemento.hashCode());
		result = prime * result + ((cpe == null) ? 0 : cpe.hashCode());
		result = prime * result + ((custcode == null) ? 0 : custcode.hashCode());
		result = prime * result + ((custcodeCliente == null) ? 0 : custcodeCliente.hashCode());
		result = prime * result + ((custcodeOrig == null) ? 0 : custcodeOrig.hashCode());
		result = prime * result + ((customerId == null) ? 0 : customerId.hashCode());
		result = prime * result + ((datAgendAtual == null) ? 0 : datAgendAtual.hashCode());
		result = prime * result + ((datCriacaoOrdem == null) ? 0 : datCriacaoOrdem.hashCode());
		result = prime * result + ((datJanelaPortabilidade == null) ? 0 : datJanelaPortabilidade.hashCode());
		result = prime * result + ((datPrimeiroAgend == null) ? 0 : datPrimeiroAgend.hashCode());
		result = prime * result + ((datStatusOrdem == null) ? 0 : datStatusOrdem.hashCode());
		result = prime * result + ((datStatusWfm == null) ? 0 : datStatusWfm.hashCode());
		result = prime * result + ((datVenda == null) ? 0 : datVenda.hashCode());
		result = prime * result + ((datVendaOrig == null) ? 0 : datVendaOrig.hashCode());
		result = prime * result + ((datref == null) ? 0 : datref.hashCode());
		result = prime * result + ((detalheRecusaCrivo == null) ? 0 : detalheRecusaCrivo.hashCode());
		result = prime * result + ((diaVencimento == null) ? 0 : diaVencimento.hashCode());
		result = prime * result + ((documento == null) ? 0 : documento.hashCode());
		result = prime * result + ((dominioRoot == null) ? 0 : dominioRoot.hashCode());
		result = prime * result + ((dscAreaVoip == null) ? 0 : dscAreaVoip.hashCode());
		result = prime * result + ((dscEnderecoFatura == null) ? 0 : dscEnderecoFatura.hashCode());
		result = prime * result + ((dscOperadoraDoadora == null) ? 0 : dscOperadoraDoadora.hashCode());
		result = prime * result + ((dscStatusAtivacao == null) ? 0 : dscStatusAtivacao.hashCode());
		result = prime * result + ((dscStatusItem == null) ? 0 : dscStatusItem.hashCode());
		result = prime * result + ((dscStatusOrdemWfm == null) ? 0 : dscStatusOrdemWfm.hashCode());
		result = prime * result + ((dscTxNaoRecorrente == null) ? 0 : dscTxNaoRecorrente.hashCode());
		result = prime * result + ((dscTxRecorrente == null) ? 0 : dscTxRecorrente.hashCode());
		result = prime * result + ((dtCancVenda == null) ? 0 : dtCancVenda.hashCode());
		result = prime * result + ((dtChurn == null) ? 0 : dtChurn.hashCode());
		result = prime * result + ((dtConclusaoOrdemChurn == null) ? 0 : dtConclusaoOrdemChurn.hashCode());
		result = prime * result + ((dtConclusaoWfm == null) ? 0 : dtConclusaoWfm.hashCode());
		result = prime * result + ((dtCriacaoOrdemChurn == null) ? 0 : dtCriacaoOrdemChurn.hashCode());
		result = prime * result + ((dtFinalizacaoOrdem == null) ? 0 : dtFinalizacaoOrdem.hashCode());
		result = prime * result + ((dtGross == null) ? 0 : dtGross.hashCode());
		result = prime * result + ((emailCliente == null) ? 0 : emailCliente.hashCode());
		result = prime * result + ((emailFatura == null) ? 0 : emailFatura.hashCode());
		result = prime * result + ((flChurn == null) ? 0 : flChurn.hashCode());
		result = prime * result + ((flGross == null) ? 0 : flGross.hashCode());
		result = prime * result + ((flVendaDuplicada == null) ? 0 : flVendaDuplicada.hashCode());
		result = prime * result + ((flgCancAntesVenda == null) ? 0 : flgCancAntesVenda.hashCode());
		result = prime * result + ((flgCancDupl == null) ? 0 : flgCancDupl.hashCode());
		result = prime * result + ((flgCancLiquido == null) ? 0 : flgCancLiquido.hashCode());
		result = prime * result + ((flgCancPosVenda == null) ? 0 : flgCancPosVenda.hashCode());
		result = prime * result + ((flgOrdemAutomatica == null) ? 0 : flgOrdemAutomatica.hashCode());
		result = prime * result + ((flgPortabilidade == null) ? 0 : flgPortabilidade.hashCode());
		result = prime * result + ((flgVendaBruta == null) ? 0 : flgVendaBruta.hashCode());
		result = prime * result + ((flgVendaDuplicada == null) ? 0 : flgVendaDuplicada.hashCode());
		result = prime * result + ((flgVendaLiquida == null) ? 0 : flgVendaLiquida.hashCode());
		result = prime * result + ((flgVendaSubmetida == null) ? 0 : flgVendaSubmetida.hashCode());
		result = prime * result + ((formaPagamento == null) ? 0 : formaPagamento.hashCode());
		result = prime * result + ((horaAgendamentoAtual == null) ? 0 : horaAgendamentoAtual.hashCode());
		result = prime * result + ((horaCriacaoDaOrdem == null) ? 0 : horaCriacaoDaOrdem.hashCode());
		result = prime * result + ((horaDaJanela == null) ? 0 : horaDaJanela.hashCode());
		result = prime * result + ((horaDaVenda == null) ? 0 : horaDaVenda.hashCode());
		result = prime * result + ((horaPrimeiroAgendamento == null) ? 0 : horaPrimeiroAgendamento.hashCode());
		result = prime * result + ((horaStatusWfm == null) ? 0 : horaStatusWfm.hashCode());
		result = prime * result + ((horaVendaOrig == null) ? 0 : horaVendaOrig.hashCode());
		result = prime * result + ((hrStatusOrdem == null) ? 0 : hrStatusOrdem.hashCode());
		result = prime * result + ((idRecursoPaiWfm == null) ? 0 : idRecursoPaiWfm.hashCode());
		result = prime * result + ((idRecursoWfm == null) ? 0 : idRecursoWfm.hashCode());
		result = prime * result + ((itemRoot == null) ? 0 : itemRoot.hashCode());
		result = prime * result + ((loginCancelamentoOrdem == null) ? 0 : loginCancelamentoOrdem.hashCode());
		result = prime * result + ((loginVendedor == null) ? 0 : loginVendedor.hashCode());
		result = prime * result + ((loginVendedorOrig == null) ? 0 : loginVendedorOrig.hashCode());
		result = prime * result + ((logradouro == null) ? 0 : logradouro.hashCode());
		result = prime * result + ((motivoCancelamento == null) ? 0 : motivoCancelamento.hashCode());
		result = prime * result + ((motivoChurn == null) ? 0 : motivoChurn.hashCode());
		result = prime * result + ((msanOltTrafego == null) ? 0 : msanOltTrafego.hashCode());
		result = prime * result + ((msanOltVenda == null) ? 0 : msanOltVenda.hashCode());
		result = prime * result + ((nomDescontoAtualItem == null) ? 0 : nomDescontoAtualItem.hashCode());
		result = prime * result + ((nomLoginResponsavel == null) ? 0 : nomLoginResponsavel.hashCode());
		result = prime * result + ((nomPlanoAtual == null) ? 0 : nomPlanoAtual.hashCode());
		result = prime * result + ((nomRecursoWfm == null) ? 0 : nomRecursoWfm.hashCode());
		result = prime * result + ((nomeCliente == null) ? 0 : nomeCliente.hashCode());
		result = prime * result + ((nomeParceiroVenda == null) ? 0 : nomeParceiroVenda.hashCode());
		result = prime * result + ((nomeParceiroVendaOrig == null) ? 0 : nomeParceiroVendaOrig.hashCode());
		result = prime * result + ((nomeUsuarioCancOrdem == null) ? 0 : nomeUsuarioCancOrdem.hashCode());
		result = prime * result + ((nomeVendedor == null) ? 0 : nomeVendedor.hashCode());
		result = prime * result + ((nomeVendedorOrig == null) ? 0 : nomeVendedorOrig.hashCode());
		result = prime * result + ((nroOrdem == null) ? 0 : nroOrdem.hashCode());
		result = prime * result + ((numOrdemSiebel == null) ? 0 : numOrdemSiebel.hashCode());
		result = prime * result + ((numOrdemSiebelOrig == null) ? 0 : numOrdemSiebelOrig.hashCode());
		result = prime * result + ((numProtocolo == null) ? 0 : numProtocolo.hashCode());
		result = prime * result + ((numTelefonePortado == null) ? 0 : numTelefonePortado.hashCode());
		result = prime * result + ((numero == null) ? 0 : numero.hashCode());
		result = prime * result + ((numeroAcesso == null) ? 0 : numeroAcesso.hashCode());
		result = prime * result + ((ont == null) ? 0 : ont.hashCode());
		result = prime * result + ((planoAtivacaoOferta == null) ? 0 : planoAtivacaoOferta.hashCode());
		result = prime * result + ((position == null) ? 0 : position.hashCode());
		result = prime * result + ((positionOrig == null) ? 0 : positionOrig.hashCode());
		result = prime * result + ((qdeContratos == null) ? 0 : qdeContratos.hashCode());
		result = prime * result + ((rowIdItemOrdem == null) ? 0 : rowIdItemOrdem.hashCode());
		result = prime * result + ((rowIdItemOrdemPai == null) ? 0 : rowIdItemOrdemPai.hashCode());
		result = prime * result + ((score == null) ? 0 : score.hashCode());
		result = prime * result + ((scoreConsumido == null) ? 0 : scoreConsumido.hashCode());
		result = prime * result + ((semanaVenda == null) ? 0 : semanaVenda.hashCode());
		result = prime * result + ((semanaVendaOrig == null) ? 0 : semanaVendaOrig.hashCode());
		result = prime * result + ((statusOrdem == null) ? 0 : statusOrdem.hashCode());
		result = prime * result + ((tecnologia == null) ? 0 : tecnologia.hashCode());
		result = prime * result + ((telefone == null) ? 0 : telefone.hashCode());
		result = prime * result + ((tipoChurn == null) ? 0 : tipoChurn.hashCode());
		result = prime * result + ((tipoConta == null) ? 0 : tipoConta.hashCode());
		result = prime * result + ((tipoDocumento == null) ? 0 : tipoDocumento.hashCode());
		result = prime * result + ((tipoLogradouro == null) ? 0 : tipoLogradouro.hashCode());
		result = prime * result + ((tipoProduto == null) ? 0 : tipoProduto.hashCode());
		result = prime * result + ((tipoVenda == null) ? 0 : tipoVenda.hashCode());
		result = prime * result + ((uf == null) ? 0 : uf.hashCode());
		result = prime * result + ((valDescontoAtualItem == null) ? 0 : valDescontoAtualItem.hashCode());
		result = prime * result + ((valPlanoAtualItem == null) ? 0 : valPlanoAtualItem.hashCode());
		result = prime * result + ((velocidadeDownload == null) ? 0 : velocidadeDownload.hashCode());
		result = prime * result + ((velocidadeUpload == null) ? 0 : velocidadeUpload.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Step4 other = (Step4) obj;
		if (acessoRowId == null) {
			if (other.acessoRowId != null)
				return false;
		} else if (!acessoRowId.equals(other.acessoRowId))
			return false;
		if (acessoRowIdRoot == null) {
			if (other.acessoRowIdRoot != null)
				return false;
		} else if (!acessoRowIdRoot.equals(other.acessoRowIdRoot))
			return false;
		if (bairro == null) {
			if (other.bairro != null)
				return false;
		} else if (!bairro.equals(other.bairro))
			return false;
		if (canal == null) {
			if (other.canal != null)
				return false;
		} else if (!canal.equals(other.canal))
			return false;
		if (canalOrig == null) {
			if (other.canalOrig != null)
				return false;
		} else if (!canalOrig.equals(other.canalOrig))
			return false;
		if (categoriaItemOrder == null) {
			if (other.categoriaItemOrder != null)
				return false;
		} else if (!categoriaItemOrder.equals(other.categoriaItemOrder))
			return false;
		if (cep == null) {
			if (other.cep != null)
				return false;
		} else if (!cep.equals(other.cep))
			return false;
		if (cidade == null) {
			if (other.cidade != null)
				return false;
		} else if (!cidade.equals(other.cidade))
			return false;
		if (cnpjParceiro == null) {
			if (other.cnpjParceiro != null)
				return false;
		} else if (!cnpjParceiro.equals(other.cnpjParceiro))
			return false;
		if (cnpjParceiroOrig == null) {
			if (other.cnpjParceiroOrig != null)
				return false;
		} else if (!cnpjParceiroOrig.equals(other.cnpjParceiroOrig))
			return false;
		if (codAgengiaBco == null) {
			if (other.codAgengiaBco != null)
				return false;
		} else if (!codAgengiaBco.equals(other.codAgengiaBco))
			return false;
		if (codBanco == null) {
			if (other.codBanco != null)
				return false;
		} else if (!codBanco.equals(other.codBanco))
			return false;
		if (codContFinanceira == null) {
			if (other.codContFinanceira != null)
				return false;
		} else if (!codContFinanceira.equals(other.codContFinanceira))
			return false;
		if (codContaCorrente == null) {
			if (other.codContaCorrente != null)
				return false;
		} else if (!codContaCorrente.equals(other.codContaCorrente))
			return false;
		if (codContratoAtivacao == null) {
			if (other.codContratoAtivacao != null)
				return false;
		} else if (!codContratoAtivacao.equals(other.codContratoAtivacao))
			return false;
		if (codContratoAtual == null) {
			if (other.codContratoAtual != null)
				return false;
		} else if (!codContratoAtual.equals(other.codContratoAtual))
			return false;
		if (codContratoOltp == null) {
			if (other.codContratoOltp != null)
				return false;
		} else if (!codContratoOltp.equals(other.codContratoOltp))
			return false;
		if (codDdd == null) {
			if (other.codDdd != null)
				return false;
		} else if (!codDdd.equals(other.codDdd))
			return false;
		if (codDebitoAutomatico == null) {
			if (other.codDebitoAutomatico != null)
				return false;
		} else if (!codDebitoAutomatico.equals(other.codDebitoAutomatico))
			return false;
		if (codOrdemChurn == null) {
			if (other.codOrdemChurn != null)
				return false;
		} else if (!codOrdemChurn.equals(other.codOrdemChurn))
			return false;
		if (codigoConvergente == null) {
			if (other.codigoConvergente != null)
				return false;
		} else if (!codigoConvergente.equals(other.codigoConvergente))
			return false;
		if (codigoProduto == null) {
			if (other.codigoProduto != null)
				return false;
		} else if (!codigoProduto.equals(other.codigoProduto))
			return false;
		if (complemento == null) {
			if (other.complemento != null)
				return false;
		} else if (!complemento.equals(other.complemento))
			return false;
		if (cpe == null) {
			if (other.cpe != null)
				return false;
		} else if (!cpe.equals(other.cpe))
			return false;
		if (custcode == null) {
			if (other.custcode != null)
				return false;
		} else if (!custcode.equals(other.custcode))
			return false;
		if (custcodeCliente == null) {
			if (other.custcodeCliente != null)
				return false;
		} else if (!custcodeCliente.equals(other.custcodeCliente))
			return false;
		if (custcodeOrig == null) {
			if (other.custcodeOrig != null)
				return false;
		} else if (!custcodeOrig.equals(other.custcodeOrig))
			return false;
		if (customerId == null) {
			if (other.customerId != null)
				return false;
		} else if (!customerId.equals(other.customerId))
			return false;
		if (datAgendAtual == null) {
			if (other.datAgendAtual != null)
				return false;
		} else if (!datAgendAtual.equals(other.datAgendAtual))
			return false;
		if (datCriacaoOrdem == null) {
			if (other.datCriacaoOrdem != null)
				return false;
		} else if (!datCriacaoOrdem.equals(other.datCriacaoOrdem))
			return false;
		if (datJanelaPortabilidade == null) {
			if (other.datJanelaPortabilidade != null)
				return false;
		} else if (!datJanelaPortabilidade.equals(other.datJanelaPortabilidade))
			return false;
		if (datPrimeiroAgend == null) {
			if (other.datPrimeiroAgend != null)
				return false;
		} else if (!datPrimeiroAgend.equals(other.datPrimeiroAgend))
			return false;
		if (datStatusOrdem == null) {
			if (other.datStatusOrdem != null)
				return false;
		} else if (!datStatusOrdem.equals(other.datStatusOrdem))
			return false;
		if (datStatusWfm == null) {
			if (other.datStatusWfm != null)
				return false;
		} else if (!datStatusWfm.equals(other.datStatusWfm))
			return false;
		if (datVenda == null) {
			if (other.datVenda != null)
				return false;
		} else if (!datVenda.equals(other.datVenda))
			return false;
		if (datVendaOrig == null) {
			if (other.datVendaOrig != null)
				return false;
		} else if (!datVendaOrig.equals(other.datVendaOrig))
			return false;
		if (datref == null) {
			if (other.datref != null)
				return false;
		} else if (!datref.equals(other.datref))
			return false;
		if (detalheRecusaCrivo == null) {
			if (other.detalheRecusaCrivo != null)
				return false;
		} else if (!detalheRecusaCrivo.equals(other.detalheRecusaCrivo))
			return false;
		if (diaVencimento == null) {
			if (other.diaVencimento != null)
				return false;
		} else if (!diaVencimento.equals(other.diaVencimento))
			return false;
		if (documento == null) {
			if (other.documento != null)
				return false;
		} else if (!documento.equals(other.documento))
			return false;
		if (dominioRoot == null) {
			if (other.dominioRoot != null)
				return false;
		} else if (!dominioRoot.equals(other.dominioRoot))
			return false;
		if (dscAreaVoip == null) {
			if (other.dscAreaVoip != null)
				return false;
		} else if (!dscAreaVoip.equals(other.dscAreaVoip))
			return false;
		if (dscEnderecoFatura == null) {
			if (other.dscEnderecoFatura != null)
				return false;
		} else if (!dscEnderecoFatura.equals(other.dscEnderecoFatura))
			return false;
		if (dscOperadoraDoadora == null) {
			if (other.dscOperadoraDoadora != null)
				return false;
		} else if (!dscOperadoraDoadora.equals(other.dscOperadoraDoadora))
			return false;
		if (dscStatusAtivacao == null) {
			if (other.dscStatusAtivacao != null)
				return false;
		} else if (!dscStatusAtivacao.equals(other.dscStatusAtivacao))
			return false;
		if (dscStatusItem == null) {
			if (other.dscStatusItem != null)
				return false;
		} else if (!dscStatusItem.equals(other.dscStatusItem))
			return false;
		if (dscStatusOrdemWfm == null) {
			if (other.dscStatusOrdemWfm != null)
				return false;
		} else if (!dscStatusOrdemWfm.equals(other.dscStatusOrdemWfm))
			return false;
		if (dscTxNaoRecorrente == null) {
			if (other.dscTxNaoRecorrente != null)
				return false;
		} else if (!dscTxNaoRecorrente.equals(other.dscTxNaoRecorrente))
			return false;
		if (dscTxRecorrente == null) {
			if (other.dscTxRecorrente != null)
				return false;
		} else if (!dscTxRecorrente.equals(other.dscTxRecorrente))
			return false;
		if (dtCancVenda == null) {
			if (other.dtCancVenda != null)
				return false;
		} else if (!dtCancVenda.equals(other.dtCancVenda))
			return false;
		if (dtChurn == null) {
			if (other.dtChurn != null)
				return false;
		} else if (!dtChurn.equals(other.dtChurn))
			return false;
		if (dtConclusaoOrdemChurn == null) {
			if (other.dtConclusaoOrdemChurn != null)
				return false;
		} else if (!dtConclusaoOrdemChurn.equals(other.dtConclusaoOrdemChurn))
			return false;
		if (dtConclusaoWfm == null) {
			if (other.dtConclusaoWfm != null)
				return false;
		} else if (!dtConclusaoWfm.equals(other.dtConclusaoWfm))
			return false;
		if (dtCriacaoOrdemChurn == null) {
			if (other.dtCriacaoOrdemChurn != null)
				return false;
		} else if (!dtCriacaoOrdemChurn.equals(other.dtCriacaoOrdemChurn))
			return false;
		if (dtFinalizacaoOrdem == null) {
			if (other.dtFinalizacaoOrdem != null)
				return false;
		} else if (!dtFinalizacaoOrdem.equals(other.dtFinalizacaoOrdem))
			return false;
		if (dtGross == null) {
			if (other.dtGross != null)
				return false;
		} else if (!dtGross.equals(other.dtGross))
			return false;
		if (emailCliente == null) {
			if (other.emailCliente != null)
				return false;
		} else if (!emailCliente.equals(other.emailCliente))
			return false;
		if (emailFatura == null) {
			if (other.emailFatura != null)
				return false;
		} else if (!emailFatura.equals(other.emailFatura))
			return false;
		if (flChurn == null) {
			if (other.flChurn != null)
				return false;
		} else if (!flChurn.equals(other.flChurn))
			return false;
		if (flGross == null) {
			if (other.flGross != null)
				return false;
		} else if (!flGross.equals(other.flGross))
			return false;
		if (flVendaDuplicada == null) {
			if (other.flVendaDuplicada != null)
				return false;
		} else if (!flVendaDuplicada.equals(other.flVendaDuplicada))
			return false;
		if (flgCancAntesVenda == null) {
			if (other.flgCancAntesVenda != null)
				return false;
		} else if (!flgCancAntesVenda.equals(other.flgCancAntesVenda))
			return false;
		if (flgCancDupl == null) {
			if (other.flgCancDupl != null)
				return false;
		} else if (!flgCancDupl.equals(other.flgCancDupl))
			return false;
		if (flgCancLiquido == null) {
			if (other.flgCancLiquido != null)
				return false;
		} else if (!flgCancLiquido.equals(other.flgCancLiquido))
			return false;
		if (flgCancPosVenda == null) {
			if (other.flgCancPosVenda != null)
				return false;
		} else if (!flgCancPosVenda.equals(other.flgCancPosVenda))
			return false;
		if (flgOrdemAutomatica == null) {
			if (other.flgOrdemAutomatica != null)
				return false;
		} else if (!flgOrdemAutomatica.equals(other.flgOrdemAutomatica))
			return false;
		if (flgPortabilidade == null) {
			if (other.flgPortabilidade != null)
				return false;
		} else if (!flgPortabilidade.equals(other.flgPortabilidade))
			return false;
		if (flgVendaBruta == null) {
			if (other.flgVendaBruta != null)
				return false;
		} else if (!flgVendaBruta.equals(other.flgVendaBruta))
			return false;
		if (flgVendaDuplicada == null) {
			if (other.flgVendaDuplicada != null)
				return false;
		} else if (!flgVendaDuplicada.equals(other.flgVendaDuplicada))
			return false;
		if (flgVendaLiquida == null) {
			if (other.flgVendaLiquida != null)
				return false;
		} else if (!flgVendaLiquida.equals(other.flgVendaLiquida))
			return false;
		if (flgVendaSubmetida == null) {
			if (other.flgVendaSubmetida != null)
				return false;
		} else if (!flgVendaSubmetida.equals(other.flgVendaSubmetida))
			return false;
		if (formaPagamento == null) {
			if (other.formaPagamento != null)
				return false;
		} else if (!formaPagamento.equals(other.formaPagamento))
			return false;
		if (horaAgendamentoAtual == null) {
			if (other.horaAgendamentoAtual != null)
				return false;
		} else if (!horaAgendamentoAtual.equals(other.horaAgendamentoAtual))
			return false;
		if (horaCriacaoDaOrdem == null) {
			if (other.horaCriacaoDaOrdem != null)
				return false;
		} else if (!horaCriacaoDaOrdem.equals(other.horaCriacaoDaOrdem))
			return false;
		if (horaDaJanela == null) {
			if (other.horaDaJanela != null)
				return false;
		} else if (!horaDaJanela.equals(other.horaDaJanela))
			return false;
		if (horaDaVenda == null) {
			if (other.horaDaVenda != null)
				return false;
		} else if (!horaDaVenda.equals(other.horaDaVenda))
			return false;
		if (horaPrimeiroAgendamento == null) {
			if (other.horaPrimeiroAgendamento != null)
				return false;
		} else if (!horaPrimeiroAgendamento.equals(other.horaPrimeiroAgendamento))
			return false;
		if (horaStatusWfm == null) {
			if (other.horaStatusWfm != null)
				return false;
		} else if (!horaStatusWfm.equals(other.horaStatusWfm))
			return false;
		if (horaVendaOrig == null) {
			if (other.horaVendaOrig != null)
				return false;
		} else if (!horaVendaOrig.equals(other.horaVendaOrig))
			return false;
		if (hrStatusOrdem == null) {
			if (other.hrStatusOrdem != null)
				return false;
		} else if (!hrStatusOrdem.equals(other.hrStatusOrdem))
			return false;
		if (idRecursoPaiWfm == null) {
			if (other.idRecursoPaiWfm != null)
				return false;
		} else if (!idRecursoPaiWfm.equals(other.idRecursoPaiWfm))
			return false;
		if (idRecursoWfm == null) {
			if (other.idRecursoWfm != null)
				return false;
		} else if (!idRecursoWfm.equals(other.idRecursoWfm))
			return false;
		if (itemRoot == null) {
			if (other.itemRoot != null)
				return false;
		} else if (!itemRoot.equals(other.itemRoot))
			return false;
		if (loginCancelamentoOrdem == null) {
			if (other.loginCancelamentoOrdem != null)
				return false;
		} else if (!loginCancelamentoOrdem.equals(other.loginCancelamentoOrdem))
			return false;
		if (loginVendedor == null) {
			if (other.loginVendedor != null)
				return false;
		} else if (!loginVendedor.equals(other.loginVendedor))
			return false;
		if (loginVendedorOrig == null) {
			if (other.loginVendedorOrig != null)
				return false;
		} else if (!loginVendedorOrig.equals(other.loginVendedorOrig))
			return false;
		if (logradouro == null) {
			if (other.logradouro != null)
				return false;
		} else if (!logradouro.equals(other.logradouro))
			return false;
		if (motivoCancelamento == null) {
			if (other.motivoCancelamento != null)
				return false;
		} else if (!motivoCancelamento.equals(other.motivoCancelamento))
			return false;
		if (motivoChurn == null) {
			if (other.motivoChurn != null)
				return false;
		} else if (!motivoChurn.equals(other.motivoChurn))
			return false;
		if (msanOltTrafego == null) {
			if (other.msanOltTrafego != null)
				return false;
		} else if (!msanOltTrafego.equals(other.msanOltTrafego))
			return false;
		if (msanOltVenda == null) {
			if (other.msanOltVenda != null)
				return false;
		} else if (!msanOltVenda.equals(other.msanOltVenda))
			return false;
		if (nomDescontoAtualItem == null) {
			if (other.nomDescontoAtualItem != null)
				return false;
		} else if (!nomDescontoAtualItem.equals(other.nomDescontoAtualItem))
			return false;
		if (nomLoginResponsavel == null) {
			if (other.nomLoginResponsavel != null)
				return false;
		} else if (!nomLoginResponsavel.equals(other.nomLoginResponsavel))
			return false;
		if (nomPlanoAtual == null) {
			if (other.nomPlanoAtual != null)
				return false;
		} else if (!nomPlanoAtual.equals(other.nomPlanoAtual))
			return false;
		if (nomRecursoWfm == null) {
			if (other.nomRecursoWfm != null)
				return false;
		} else if (!nomRecursoWfm.equals(other.nomRecursoWfm))
			return false;
		if (nomeCliente == null) {
			if (other.nomeCliente != null)
				return false;
		} else if (!nomeCliente.equals(other.nomeCliente))
			return false;
		if (nomeParceiroVenda == null) {
			if (other.nomeParceiroVenda != null)
				return false;
		} else if (!nomeParceiroVenda.equals(other.nomeParceiroVenda))
			return false;
		if (nomeParceiroVendaOrig == null) {
			if (other.nomeParceiroVendaOrig != null)
				return false;
		} else if (!nomeParceiroVendaOrig.equals(other.nomeParceiroVendaOrig))
			return false;
		if (nomeUsuarioCancOrdem == null) {
			if (other.nomeUsuarioCancOrdem != null)
				return false;
		} else if (!nomeUsuarioCancOrdem.equals(other.nomeUsuarioCancOrdem))
			return false;
		if (nomeVendedor == null) {
			if (other.nomeVendedor != null)
				return false;
		} else if (!nomeVendedor.equals(other.nomeVendedor))
			return false;
		if (nomeVendedorOrig == null) {
			if (other.nomeVendedorOrig != null)
				return false;
		} else if (!nomeVendedorOrig.equals(other.nomeVendedorOrig))
			return false;
		if (nroOrdem == null) {
			if (other.nroOrdem != null)
				return false;
		} else if (!nroOrdem.equals(other.nroOrdem))
			return false;
		if (numOrdemSiebel == null) {
			if (other.numOrdemSiebel != null)
				return false;
		} else if (!numOrdemSiebel.equals(other.numOrdemSiebel))
			return false;
		if (numOrdemSiebelOrig == null) {
			if (other.numOrdemSiebelOrig != null)
				return false;
		} else if (!numOrdemSiebelOrig.equals(other.numOrdemSiebelOrig))
			return false;
		if (numProtocolo == null) {
			if (other.numProtocolo != null)
				return false;
		} else if (!numProtocolo.equals(other.numProtocolo))
			return false;
		if (numTelefonePortado == null) {
			if (other.numTelefonePortado != null)
				return false;
		} else if (!numTelefonePortado.equals(other.numTelefonePortado))
			return false;
		if (numero == null) {
			if (other.numero != null)
				return false;
		} else if (!numero.equals(other.numero))
			return false;
		if (numeroAcesso == null) {
			if (other.numeroAcesso != null)
				return false;
		} else if (!numeroAcesso.equals(other.numeroAcesso))
			return false;
		if (ont == null) {
			if (other.ont != null)
				return false;
		} else if (!ont.equals(other.ont))
			return false;
		if (planoAtivacaoOferta == null) {
			if (other.planoAtivacaoOferta != null)
				return false;
		} else if (!planoAtivacaoOferta.equals(other.planoAtivacaoOferta))
			return false;
		if (position == null) {
			if (other.position != null)
				return false;
		} else if (!position.equals(other.position))
			return false;
		if (positionOrig == null) {
			if (other.positionOrig != null)
				return false;
		} else if (!positionOrig.equals(other.positionOrig))
			return false;
		if (qdeContratos == null) {
			if (other.qdeContratos != null)
				return false;
		} else if (!qdeContratos.equals(other.qdeContratos))
			return false;
		if (rowIdItemOrdem == null) {
			if (other.rowIdItemOrdem != null)
				return false;
		} else if (!rowIdItemOrdem.equals(other.rowIdItemOrdem))
			return false;
		if (rowIdItemOrdemPai == null) {
			if (other.rowIdItemOrdemPai != null)
				return false;
		} else if (!rowIdItemOrdemPai.equals(other.rowIdItemOrdemPai))
			return false;
		if (score == null) {
			if (other.score != null)
				return false;
		} else if (!score.equals(other.score))
			return false;
		if (scoreConsumido == null) {
			if (other.scoreConsumido != null)
				return false;
		} else if (!scoreConsumido.equals(other.scoreConsumido))
			return false;
		if (semanaVenda == null) {
			if (other.semanaVenda != null)
				return false;
		} else if (!semanaVenda.equals(other.semanaVenda))
			return false;
		if (semanaVendaOrig == null) {
			if (other.semanaVendaOrig != null)
				return false;
		} else if (!semanaVendaOrig.equals(other.semanaVendaOrig))
			return false;
		if (statusOrdem == null) {
			if (other.statusOrdem != null)
				return false;
		} else if (!statusOrdem.equals(other.statusOrdem))
			return false;
		if (tecnologia == null) {
			if (other.tecnologia != null)
				return false;
		} else if (!tecnologia.equals(other.tecnologia))
			return false;
		if (telefone == null) {
			if (other.telefone != null)
				return false;
		} else if (!telefone.equals(other.telefone))
			return false;
		if (tipoChurn == null) {
			if (other.tipoChurn != null)
				return false;
		} else if (!tipoChurn.equals(other.tipoChurn))
			return false;
		if (tipoConta == null) {
			if (other.tipoConta != null)
				return false;
		} else if (!tipoConta.equals(other.tipoConta))
			return false;
		if (tipoDocumento == null) {
			if (other.tipoDocumento != null)
				return false;
		} else if (!tipoDocumento.equals(other.tipoDocumento))
			return false;
		if (tipoLogradouro == null) {
			if (other.tipoLogradouro != null)
				return false;
		} else if (!tipoLogradouro.equals(other.tipoLogradouro))
			return false;
		if (tipoProduto == null) {
			if (other.tipoProduto != null)
				return false;
		} else if (!tipoProduto.equals(other.tipoProduto))
			return false;
		if (tipoVenda == null) {
			if (other.tipoVenda != null)
				return false;
		} else if (!tipoVenda.equals(other.tipoVenda))
			return false;
		if (uf == null) {
			if (other.uf != null)
				return false;
		} else if (!uf.equals(other.uf))
			return false;
		if (valDescontoAtualItem == null) {
			if (other.valDescontoAtualItem != null)
				return false;
		} else if (!valDescontoAtualItem.equals(other.valDescontoAtualItem))
			return false;
		if (valPlanoAtualItem == null) {
			if (other.valPlanoAtualItem != null)
				return false;
		} else if (!valPlanoAtualItem.equals(other.valPlanoAtualItem))
			return false;
		if (velocidadeDownload == null) {
			if (other.velocidadeDownload != null)
				return false;
		} else if (!velocidadeDownload.equals(other.velocidadeDownload))
			return false;
		if (velocidadeUpload == null) {
			if (other.velocidadeUpload != null)
				return false;
		} else if (!velocidadeUpload.equals(other.velocidadeUpload))
			return false;
		return true;
	}


	@Override
	public String toString() {
		return "Step2 [datref=" + datref + ", datCriacaoOrdem=" + datCriacaoOrdem + ", horaCriacaoDaOrdem="
				+ horaCriacaoDaOrdem + ", datVenda=" + datVenda + ", horaDaVenda=" + horaDaVenda + ", datStatusOrdem="
				+ datStatusOrdem + ", hrStatusOrdem=" + hrStatusOrdem + ", numOrdemSiebel=" + numOrdemSiebel
				+ ", numOrdemSiebelOrig=" + numOrdemSiebelOrig + ", codContratoOltp=" + codContratoOltp
				+ ", codContratoAtivacao=" + codContratoAtivacao + ", numeroAcesso=" + numeroAcesso + ", customerId="
				+ customerId + ", tipoDocumento=" + tipoDocumento + ", documento=" + documento + ", tipoVenda="
				+ tipoVenda + ", tipoProduto=" + tipoProduto + ", velocidadeDownload=" + velocidadeDownload
				+ ", velocidadeUpload=" + velocidadeUpload + ", planoAtivacaoOferta=" + planoAtivacaoOferta
				+ ", loginVendedor=" + loginVendedor + ", canal=" + canal + ", cnpjParceiro=" + cnpjParceiro
				+ ", custcode=" + custcode + ", position=" + position + ", flgCancAntesVenda=" + flgCancAntesVenda
				+ ", flgCancPosVenda=" + flgCancPosVenda + ", dtCancVenda=" + dtCancVenda + ", motivoCancelamento="
				+ motivoCancelamento + ", nomeCliente=" + nomeCliente + ", telefone=" + telefone + ", emailFatura="
				+ emailFatura + ", uf=" + uf + ", tipoLogradouro=" + tipoLogradouro + ", logradouro=" + logradouro
				+ ", numero=" + numero + ", complemento=" + complemento + ", bairro=" + bairro + ", cep=" + cep
				+ ", cidade=" + cidade + ", statusOrdem=" + statusOrdem + ", tecnologia=" + tecnologia
				+ ", formaPagamento=" + formaPagamento + ", tipoConta=" + tipoConta + ", codBanco=" + codBanco
				+ ", codAgengiaBco=" + codAgengiaBco + ", codContaCorrente=" + codContaCorrente
				+ ", codDebitoAutomatico=" + codDebitoAutomatico + ", diaVencimento=" + diaVencimento + ", semanaVenda="
				+ semanaVenda + ", score=" + score + ", scoreConsumido=" + scoreConsumido + ", dtFinalizacaoOrdem="
				+ dtFinalizacaoOrdem + ", qdeContratos=" + qdeContratos + ", numProtocolo=" + numProtocolo
				+ ", flgOrdemAutomatica=" + flgOrdemAutomatica + ", dscTxRecorrente=" + dscTxRecorrente
				+ ", dscTxNaoRecorrente=" + dscTxNaoRecorrente + ", dscStatusItem=" + dscStatusItem
				+ ", nomLoginResponsavel=" + nomLoginResponsavel + ", flgPortabilidade=" + flgPortabilidade
				+ ", dscOperadoraDoadora=" + dscOperadoraDoadora + ", codDdd=" + codDdd + ", numTelefonePortado="
				+ numTelefonePortado + ", datJanelaPortabilidade=" + datJanelaPortabilidade + ", horaDaJanela="
				+ horaDaJanela + ", dscEnderecoFatura=" + dscEnderecoFatura + ", dscAreaVoip=" + dscAreaVoip + ", cpe="
				+ cpe + ", ont=" + ont + ", codigoConvergente=" + codigoConvergente + ", detalheRecusaCrivo="
				+ detalheRecusaCrivo + ", itemRoot=" + itemRoot + ", loginCancelamentoOrdem=" + loginCancelamentoOrdem
				+ ", custcodeCliente=" + custcodeCliente + ", dominioRoot=" + dominioRoot + ", codContFinanceira="
				+ codContFinanceira + ", valPlanoAtualItem=" + valPlanoAtualItem + ", nomDescontoAtualItem="
				+ nomDescontoAtualItem + ", valDescontoAtualItem=" + valDescontoAtualItem + ", nroOrdem=" + nroOrdem
				+ ", acessoRowId=" + acessoRowId + ", acessoRowIdRoot=" + acessoRowIdRoot + ", codigoProduto="
				+ codigoProduto + ", flgVendaSubmetida=" + flgVendaSubmetida + ", flgVendaDuplicada="
				+ flgVendaDuplicada + ", flgVendaBruta=" + flgVendaBruta + ", flgVendaLiquida=" + flgVendaLiquida
				+ ", flgCancDupl=" + flgCancDupl + ", flgCancLiquido=" + flgCancLiquido + ", nomeParceiroVenda="
				+ nomeParceiroVenda + ", nomeParceiroVendaOrig=" + nomeParceiroVendaOrig + ", rowIdItemOrdem="
				+ rowIdItemOrdem + ", rowIdItemOrdemPai=" + rowIdItemOrdemPai + ", categoriaItemOrder="
				+ categoriaItemOrder + ", msanOltVenda=" + msanOltVenda + ", dtConclusaoWfm=" + dtConclusaoWfm
				+ ", dscStatusOrdemWfm=" + dscStatusOrdemWfm + ", datStatusWfm=" + datStatusWfm + ", horaStatusWfm="
				+ horaStatusWfm + ", idRecursoWfm=" + idRecursoWfm + ", nomRecursoWfm=" + nomRecursoWfm
				+ ", idRecursoPaiWfm=" + idRecursoPaiWfm + ", datPrimeiroAgend=" + datPrimeiroAgend
				+ ", horaPrimeiroAgendamento=" + horaPrimeiroAgendamento + ", datAgendAtual=" + datAgendAtual
				+ ", horaAgendamentoAtual=" + horaAgendamentoAtual + ", dscStatusAtivacao=" + dscStatusAtivacao
				+ ", msanOltTrafego=" + msanOltTrafego + ", datVendaOrig=" + datVendaOrig + ", horaVendaOrig="
				+ horaVendaOrig + ", loginVendedorOrig=" + loginVendedorOrig + ", canalOrig=" + canalOrig
				+ ", cnpjParceiroOrig=" + cnpjParceiroOrig + ", custcodeOrig=" + custcodeOrig + ", positionOrig="
				+ positionOrig + ", semanaVendaOrig=" + semanaVendaOrig + ", codContratoAtual=" + codContratoAtual
				+ ", nomPlanoAtual=" + nomPlanoAtual + ", nomeVendedorOrig=" + nomeVendedorOrig + ", flVendaDuplicada="
				+ flVendaDuplicada + ", flGross=" + flGross + ", dtGross=" + dtGross + ", flChurn=" + flChurn
				+ ", dtChurn=" + dtChurn + ", motivoChurn=" + motivoChurn + ", codOrdemChurn=" + codOrdemChurn
				+ ", tipoChurn=" + tipoChurn + ", dtCriacaoOrdemChurn=" + dtCriacaoOrdemChurn
				+ ", dtConclusaoOrdemChurn=" + dtConclusaoOrdemChurn + ", nomeVendedor=" + nomeVendedor
				+ ", nomeUsuarioCancOrdem=" + nomeUsuarioCancOrdem + ", emailCliente=" + emailCliente + "]";
	}
	

}
