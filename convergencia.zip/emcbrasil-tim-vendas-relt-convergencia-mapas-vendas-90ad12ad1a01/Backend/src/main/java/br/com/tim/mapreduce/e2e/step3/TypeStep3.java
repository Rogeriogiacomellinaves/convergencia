package br.com.tim.mapreduce.e2e.step3;

public enum TypeStep3 {

    BAT513, RELT
}
