package br.com.tim.mapreduce.refactoring.endtoend.step4.pt6;

import com.google.common.collect.ComparisonChain;
import br.com.tim.mapreduce.refactoring.endtoend.GroupComparable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Objects;


public class Step4Pt6Key implements GroupComparable<Step4Pt6Key>{
	
	private String codContrato;
	private TypeStep4Pt6 tipo;
	
	@Override
	public void write(DataOutput output) throws IOException {
		output.writeInt(tipo.ordinal());
		output.writeUTF(this.codContrato);
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		this.tipo = TypeStep4Pt6.values()[in.readInt()];
		this.codContrato = in.readUTF();
	}

	public String getCodContrato() {
		return codContrato;
	}

	public void setCodContrato(String nroOrdem) {
		this.codContrato = nroOrdem;
	}


	public void setTipo(TypeStep4Pt6 tipo) {
		this.tipo = tipo;
	}

	@Override
	public int compareTo(Step4Pt6Key o) {
		return ComparisonChain.start().compare(this.codContrato, o.codContrato).compare(this.tipo, o.tipo).result();
	}

	@Override
	public int compareToGrouping(Step4Pt6Key o) {
		return ComparisonChain.start().compare(this.codContrato, o.codContrato).result();
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		Step4Pt6Key key = (Step4Pt6Key) o;
		return Objects.equals(codContrato, key.codContrato);
	}

	public int hashCodeJoin() {

		return Objects.hash(codContrato);
	}

	@Override
	public int hashCode() {

		return Objects.hash(codContrato);
	}
}
