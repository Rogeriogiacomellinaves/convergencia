package br.com.tim.mapreduce.e2e.step9;

import br.com.tim.mapreduce.e2e.GroupComparable;
import com.google.common.collect.ComparisonChain;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Objects;

public class E2EStep9Key implements GroupComparable<E2EStep9Key> {

	private String nomParceiro;
	private TypeStep9 tipo;

	@Override
	public void write(DataOutput output) throws IOException {
		output.writeInt(tipo.ordinal());
		output.writeUTF(this.nomParceiro);
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		this.tipo = TypeStep9.values()[in.readInt()];
		this.nomParceiro = in.readUTF();
	}

	public void setTipo(TypeStep9 tipo) {
		this.tipo = tipo;
	}

	public void setNomParceiro(String nomParceiro) {
		this.nomParceiro = nomParceiro;
	}

	@Override
	public int compareTo(E2EStep9Key o) {
		return ComparisonChain.start().compare(this.nomParceiro, o.nomParceiro).compare(this.tipo, o.tipo)
				.result();
	}

	@Override
	public int compareToGrouping(E2EStep9Key o) {
		return ComparisonChain.start().compare(this.nomParceiro, o.nomParceiro).result();
	}


	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		E2EStep9Key key = (E2EStep9Key) o;
		return Objects.equals(nomParceiro, key.nomParceiro);
	}

	public int hashCodeJoin() {

		return Objects.hash(nomParceiro);
	}

	@Override
	public int hashCode() {

		return Objects.hash(nomParceiro);
	}
}