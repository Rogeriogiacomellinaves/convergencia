package br.com.tim.mapreduce.refactoring.model;

public class BAT511 {

}
