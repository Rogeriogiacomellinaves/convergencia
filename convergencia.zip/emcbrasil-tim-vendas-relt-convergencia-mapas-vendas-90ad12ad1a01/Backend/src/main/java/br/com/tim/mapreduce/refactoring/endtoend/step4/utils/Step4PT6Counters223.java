package br.com.tim.mapreduce.refactoring.endtoend.step4.utils;

public enum Step4PT6Counters223 {
	
	WRITE_RECORDS, BAT_223_MAPPER, SOCIALSECNO_IS_BLANCK, REDUCER_WRITE, BAT_223_REDUCER, STEP4PT5_MAPPER

}
