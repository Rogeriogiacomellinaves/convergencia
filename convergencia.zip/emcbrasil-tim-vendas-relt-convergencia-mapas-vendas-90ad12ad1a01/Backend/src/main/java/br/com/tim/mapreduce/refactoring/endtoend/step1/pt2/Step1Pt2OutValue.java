package br.com.tim.mapreduce.refactoring.endtoend.step1.pt2;


import java.util.TreeSet;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import br.com.tim.utils.CommonsConstants;

public class Step1Pt2OutValue {
	
	/**
	 * BAT509Order
	 * Step1Result
	 */

	public static final String DELIMITER = CommonsConstants.FILE_FIELD_SEPARATOR;
    private String datRef;
    private String codContratoOltp;
    private String codContratoAtivacao;
    private String numeroAcesso;
    private String customerId;
    private String tipoProduto;
    private String planoAtivacaoOferta;
    private String motivoChurn;
    public String getNumeroAcesso() {
		return numeroAcesso;
	}

	public void setNumeroAcesso(String numeroAcesso) {
		this.numeroAcesso = numeroAcesso;
	}

	public String getMotivoChurn() {
		return motivoChurn;
	}

	public void setMotivoChurn(String motivoChurn) {
		this.motivoChurn = motivoChurn;
	}

	public String getTipoChurn() {
		return tipoChurn;
	}

	public void setTipoChurn(String tipoChurn) {
		this.tipoChurn = tipoChurn;
	}

	private String tipoChurn;
    private String email;
    private String uf;
    private String tipoLogradouro;
    private String logradouro;
    private String numero;
    private String complemento;
    private String bairro;
    private String cep;
    private String cidade;
    private String tecnologia;
    private String formaPagamento;
    private String tipoConta;
    private String codBanco;
    private String codAgenciaBanco;
    private String codContaCorrente;
    private String codDebitoAutomatico;
    private String diaVencimento;
    private String codContaFinanceira;
    private String numProtocolo;
    private String flgOrdemAutomatica;
    private String dscTxRecorrente;
    private String dscTxNaoRecorrente;
    private String dscStatusItem;
    private String nomPlanoAtual;
    private String valPlanoAtualItem;
    private String nomDescontoAtualItem;
    private String valDescontoAtualItem;
    private String flgPortabilidade;
    private String dscOperadoraDoadora;
    private String codDdd;
    private String numTelefonePortado;
    private String datJanelaPortabilidade;
    private String horJanela;
    private String dscEnderecoFatura;
    private String dscAreaVoip;
    private String cpe;
    private String ont;
    private String itemRoot;
    private String dominioRoot;
    private String nroOrdem;
    private String acessoRowId;
    private String acessoRowIdRoot;
    private String codigoProduto;

    private String datCriacaoOrdem;
    private String horCriacaoOrdem;
    private String datVenda;
    private String horaVenda;
    private String datVendaOrig;
    private String horVendaOrig;
    private String datStatusOrdem;
    private String horStatusOrdem;
    private String numOrdemSiebel;
    private String numOrdemSiebelOrig;
    private String tipoDocumento;
    private String documento;
    private String tipoVenda;
    private String loginVendedor;
    private String loginVendedorOrig;
    private String canal;
    private String canalOrig;
    private String cnpjParceiro;
    private String cnpjParceiroOrig;
    private String custCode;
    private String custCodeOrig;
    private String position;
    private String positionOrig;
    private String flgCancAntesVenda;
    private String flgVendaSubmetida;
    private String flgVendaDuplicada;
    private String flgVendaBruta;
    private String flgVendaLiquida;
    private String flgCancPosVenda;
    private String flgCancDupl;
    private String flgCancLiquido;
    private String datCancVenda;
    private String motivoCancelamento;
    private String nomeCliente;
    private String telefone;
    private String statusOrdem;
    private String semanaVenda;
    private String semanaVendaOrig;
    private String score;
    private String scoreConsumido;
    private String datFinalizacaoOrdem;
    private String qtdContratos;
    private String nomLoginResponsavel;
    private String detalheRecusaCrivo;
    private String loginCancelamentoOrdem;
    private String nomeParceiroVenda;
    private String nomeParceiroVendaOrig;
    private String rowIdDoItemDaOrdem;
    private String rowIdDoItemDaOrdemPai;
    private String categoriaItemOrdem;


    private TreeSet<String> dupl = new TreeSet<String>();
    private TreeSet<String> brut = new TreeSet<String>();
    private boolean definido;
    private int contflg0;
    private int contflg1;

    DateTimeFormatter dtf = DateTimeFormat.forPattern("MM/dd/yyyy HH:mm:ss");

    public void clear(){
        this.datRef = "";
        this.codContratoOltp = "";
        this.codContratoAtivacao = "";
        this.numeroAcesso = "";
        this.customerId = "";
        this.tipoProduto = "";
        this.planoAtivacaoOferta = "";
        this.motivoChurn = "";
        this.tipoChurn = "";
        this.email = "";
        this.uf = "";
        this.tipoLogradouro = "";
        this.logradouro = "";
        this.numero = "";
        this.complemento = "";
        this.bairro = "";
        this.cep = "";
        this.cidade = "";
        this.tecnologia = "";
        this.formaPagamento = "";
        this.tipoConta = "";
        this.codBanco = "";
        this.codAgenciaBanco = "";
        this.codContaCorrente = "";
        this.codDebitoAutomatico = "";
        this.diaVencimento = "";
        this.codContaFinanceira = "";
        this.numProtocolo = "";
        this.flgOrdemAutomatica = "";
        this.dscTxRecorrente = "";
        this.dscTxNaoRecorrente = "";
        this.dscStatusItem = "";
        this.nomPlanoAtual = "";
        this.valPlanoAtualItem = "";
        this.nomDescontoAtualItem = "";
        this.valDescontoAtualItem = "";
        this.flgPortabilidade = "";
        this.dscOperadoraDoadora = "";
        this.codDdd = "";
        this.numTelefonePortado = "";
        this.datJanelaPortabilidade = "";
        this.horJanela = "";
        this.dscEnderecoFatura = "";
        this.dscAreaVoip = "";
        this.cpe = "";
        this.ont = "";
        this.itemRoot = "";
        this.dominioRoot = "";
        this.nroOrdem = "";
        this.acessoRowId = "";
        this.acessoRowIdRoot = "";
        this.codigoProduto = "";
        this.datCriacaoOrdem = "";
        this.horCriacaoOrdem = "";
        this.datVenda = "";
        this.horaVenda = "";
        this.datVendaOrig = "";
        this.horVendaOrig = "";
        this.datStatusOrdem = "";
        this.horStatusOrdem = "";
        this.numOrdemSiebel = "";
        this.numOrdemSiebelOrig = "";
        this.tipoDocumento = "";
        this.documento = "";
        this.tipoVenda = "";
        this.loginVendedor = "";
        this.loginVendedorOrig = "";
        this.canal = "";
        this.canalOrig = "";
        this.cnpjParceiro = "";
        this.cnpjParceiroOrig = "";
        this.custCode = "";
        this.custCodeOrig = "";
        this.position = "";
        this.positionOrig = "";
        this.flgCancAntesVenda = "";
        this.flgVendaSubmetida = "";
        this.flgVendaDuplicada = "";
        this.flgVendaBruta = "";
        this.flgVendaLiquida = "";
        this.flgCancPosVenda = "";
        this.flgCancDupl = "";
        this.flgCancLiquido = "";
        this.datCancVenda = "";
        this.motivoCancelamento = "";
        this.nomeCliente = "";
        this.telefone = "";
        this.statusOrdem = "";
        this.semanaVenda = "";
        this.semanaVendaOrig = "";
        this.score = "";
        this.scoreConsumido = "";
        this.datFinalizacaoOrdem = "";
        this.qtdContratos = "";
        this.nomLoginResponsavel = "";
        this.detalheRecusaCrivo = "";
        this.loginCancelamentoOrdem = "";
        this.nomeParceiroVenda = "";
        this.nomeParceiroVendaOrig = "";
        dupl.clear();
        brut.clear();
        definido = false;
        contflg0 = 0;
        contflg1 = 1;
        this.rowIdDoItemDaOrdem = "";
        this.rowIdDoItemDaOrdemPai = "";
        this.categoriaItemOrdem = "";

    }

    public void clearRelt(){
        this.datRef = "";
        this.codContratoOltp = "";
        this.codContratoAtivacao = "";
        this.numeroAcesso = "";
        this.customerId = "";
        this.tipoProduto = "";
        this.planoAtivacaoOferta = "";
        this.motivoChurn = "";
        this.tipoChurn = "";
        this.email = "";
        this.uf = "";
        this.tipoLogradouro = "";
        this.logradouro = "";
        this.numero = "";
        this.complemento = "";
        this.bairro = "";
        this.cep = "";
        this.cidade = "";
        this.tecnologia = "";
        this.formaPagamento = "";
        this.tipoConta = "";
        this.codBanco = "";
        this.codAgenciaBanco = "";
        this.codContaCorrente = "";
        this.codDebitoAutomatico = "";
        this.diaVencimento = "";
        this.codContaFinanceira = "";
        this.numProtocolo = "";
        this.flgOrdemAutomatica = "";
        this.dscTxRecorrente = "";
        this.dscTxNaoRecorrente = "";
        this.dscStatusItem = "";
        this.nomPlanoAtual = "";
        this.valPlanoAtualItem = "";
        this.nomDescontoAtualItem = "";
        this.valDescontoAtualItem = "";
        this.flgPortabilidade = "";
        this.dscOperadoraDoadora = "";
        this.codDdd = "";
        this.numTelefonePortado = "";
        this.datJanelaPortabilidade = "";
        this.horJanela = "";
        this.dscEnderecoFatura = "";
        this.dscAreaVoip = "";
        this.cpe = "";
        this.ont = "";
        this.itemRoot = "";
        this.dominioRoot = "";
        this.nroOrdem = "";
        this.acessoRowId = "";
        this.acessoRowIdRoot = "";
        this.codigoProduto = "";
        this.rowIdDoItemDaOrdem = "";
        this.rowIdDoItemDaOrdemPai = "";
        this.categoriaItemOrdem = "";
    }

    public void setRelt(Step1Pt2Value relt) {
        this.datRef = relt.getDatRef();
        this.codContratoOltp = relt.getCodContratoOltp();
        this.codContratoAtivacao = relt.getCodContratoAtivacao();
        this.numeroAcesso = relt.getNumeroAcesso();
        this.customerId = relt.getCustomerId();
        this.tipoProduto = relt.getTipoProduto();
        this.planoAtivacaoOferta = relt.getPlanoAtivacaoOferta();
        this.motivoChurn = relt.getMotivoChurn();
        this.tipoChurn = relt.getTipoChurn();
        this.email = relt.getEmail();
        this.uf = relt.getUf();
        this.tipoLogradouro = relt.getTipoLogradouro();
        this.logradouro = relt.getLogradouro();
        this.numero = relt.getNumero();
        this.complemento = relt.getComplemento();
        this.bairro = relt.getBairro();
        this.cep = relt.getCep();
        this.cidade = relt.getCidade();
        this.tecnologia = relt.getTecnologia();
        this.formaPagamento = relt.getFormaPagamento();
        this.tipoConta = relt.getTipoConta();
        this.codBanco = relt.getCodBanco();
        this.codAgenciaBanco = relt.getCodAgenciaBanco();
        this.codContaCorrente = relt.getCodContaCorrente();
        this.codDebitoAutomatico = relt.getCodDebitoAutomatico();
        this.diaVencimento = relt.getDiaVencimento();
        this.codContaFinanceira = relt.getCodContaFinanceira();
        this.numProtocolo = relt.getNumProtocolo();
        this.flgOrdemAutomatica = relt.getFlgOrdemAutomatica();
        this.dscTxRecorrente = relt.getDscTxRecorrente();
        this.dscTxNaoRecorrente = relt.getDscTxNaoRecorrente();
        this.dscStatusItem = relt.getDscStatusItem();
        this.nomPlanoAtual = relt.getNomPlanoAtual();
        this.valPlanoAtualItem = relt.getValPlanoAtualItem();
        this.nomDescontoAtualItem = relt.getNomDescontoAtualItem();
        this.valDescontoAtualItem = relt.getValDescontoAtualItem();
        this.flgPortabilidade = relt.getFlgPortabilidade();
        this.dscOperadoraDoadora = relt.getDscOperadoraDoadora();
        this.codDdd = relt.getCodDdd();
        this.numTelefonePortado = relt.getNumTelefonePortado();
        this.datJanelaPortabilidade = relt.getDatJanelaPortabilidade();
        this.horJanela = relt.getHorJanela();
        this.dscEnderecoFatura = relt.getDscEnderecoFatura();
        this.dscAreaVoip = relt.getDscAreaVoip();
        this.cpe = relt.getCpe();
        this.ont = relt.getOnt();
        this.itemRoot = relt.getItemRoot();
        this.dominioRoot = relt.getDominioRoot();
        this.nroOrdem = relt.getNroOrdem();
        this.acessoRowId = relt.getAcessoRowId();
        this.acessoRowIdRoot = relt.getAcessoRowIdRoot();
        this.codigoProduto = relt.getCodigoProduto();
        this.rowIdDoItemDaOrdem = relt.getRowIdDoItemDaOrdem();
        this.rowIdDoItemDaOrdemPai = relt.getRowIdDoItemDaOrdemPai();
        this.categoriaItemOrdem = relt.getCategoriaItemOrdem();
    }

    public void setOrdem(Step1Pt2Value ordem) {
        this.datCriacaoOrdem = ordem.getDatCriacaoOrdem();
        this.horCriacaoOrdem = ordem.getHorCriacaoOrdem();
        this.datVenda = ordem.getDatVenda();
        this.horaVenda = ordem.getHoraVenda();
        this.datStatusOrdem = ordem.getDatStatusOrdem();
        this.horStatusOrdem = ordem.getHorStatusOrdem();
        this.numOrdemSiebel = ordem.getNumOrdemSiebel();
        this.tipoDocumento = ordem.getTipoDocumento();
        this.documento = ordem.getDocumento();
        this.tipoVenda = ordem.getTipoVenda();
        this.loginVendedor = ordem.getLoginVendedor();
        this.canal = ordem.getCanal();
        this.cnpjParceiro = ordem.getCnpjParceiro();
        this.custCode = ordem.getCustCode();
        this.position = ordem.getPosition();
        this.flgCancAntesVenda = ordem.getFlgCancAntesVenda();
        this.flgVendaSubmetida = ordem.getFlgVendaSubmetida();
        this.flgCancPosVenda = ordem.getFlgCancPosVenda();

        this.flgVendaDuplicada = "0";
        if(StringUtils.isNotEmpty(ordem.getDatVenda())){
            if(!dupl.add(ordem.getTipoOrdem() + ordem.getNomeCliente()))
                this.flgVendaDuplicada = "1";
        }

        this.flgVendaBruta = "1";
        if(StringUtils.isNotEmpty(ordem.getDatVenda())){
            if(!brut.add(ordem.getTipoOrdem() + ordem.getNomeCliente()))
                this.flgVendaBruta = "0";
        }

        if(this.flgCancPosVenda.equals("0")) {
            this.flgCancDupl = "0";
            contflg0++;
        }
        else if(this.flgCancPosVenda.equals("1")) {
            contflg1++;
            if (this.flgCancPosVenda.equals("1") && contflg0 == 0)
                this.flgCancDupl = "0";
            else if(contflg1 == 1)
                this.flgCancDupl = "0";
            else if (ordem.getStatusOrdem().equals("Concluída"))
                this.flgCancDupl = "1";
            else if (ordem.getStatusOrdem().equals("Em Aprovisionamento"))
                this.flgCancDupl = "1";
        }


        if(this.flgCancPosVenda.equals("1") && this.flgCancDupl.equals("0"))
            this.flgCancLiquido = "1";
        else
            this.flgCancLiquido = "0";

        if(this.flgVendaBruta.equals("0"))
            this.flgVendaLiquida = "0";
        else if(this.flgVendaBruta.equals("1") && this.flgCancLiquido.equals("1")){
            this.flgVendaLiquida = "0";
            definido = true;
        }
        else if(this.flgVendaBruta.equals("1") && !definido)
            this.flgVendaLiquida = "1";
        this.datCancVenda = ordem.getDatCancVenda();
        this.motivoCancelamento = ordem.getMotivoCancelamento();
        this.nomeCliente = ordem.getNomeCliente();
        this.telefone = ordem.getTelefone();
        this.statusOrdem = ordem.getStatusOrdem();
        this.semanaVenda = ordem.getSemanaVenda();
        this.score = ordem.getScore();
        this.scoreConsumido = ordem.getScoreConsumido();
        this.datFinalizacaoOrdem = ordem.getDatFinalizacaoOrdem();
        this.qtdContratos = ordem.getQtdContratos();
        this.nomLoginResponsavel = ordem.getNomLoginResponsavel();
        this.detalheRecusaCrivo = ordem.getDetalheRecusaCrivo();
        this.loginCancelamentoOrdem = ordem.getLoginCancelamentoOrdem();
        this.nomeParceiroVenda = ordem.getNomeParceiroVenda();
    }

    public void setFirstOrdem(Step1Pt2Value ordem) {
        this.datCriacaoOrdem = ordem.getDatCriacaoOrdem();
        this.horCriacaoOrdem = ordem.getHorCriacaoOrdem();
        this.datVenda = ordem.getDatVenda();
        this.horaVenda = ordem.getHoraVenda();
        this.datVendaOrig = ordem.getDatVenda();
        this.horVendaOrig = ordem.getHoraVenda();
        this.datStatusOrdem = ordem.getDatStatusOrdem();
        this.horStatusOrdem = ordem.getHorStatusOrdem();
        this.numOrdemSiebel = ordem.getNumOrdemSiebel();
        this.numOrdemSiebelOrig = ordem.getNumOrdemSiebel();
        this.tipoDocumento = ordem.getTipoDocumento();
        this.documento = ordem.getDocumento();
        this.tipoVenda = ordem.getTipoVenda();
        this.loginVendedor = ordem.getLoginVendedor();
        this.loginVendedorOrig = ordem.getLoginVendedor();
        this.canal = ordem.getCanal();
        this.canalOrig = ordem.getCanal();
        this.cnpjParceiro = ordem.getCnpjParceiro();
        this.cnpjParceiroOrig = ordem.getCnpjParceiro();
        this.custCode = ordem.getCustCode();
        this.custCodeOrig = ordem.getCustCode();
        this.position = ordem.getPosition();
        this.positionOrig = ordem.getPosition();
        this.flgCancAntesVenda = ordem.getFlgCancAntesVenda();
        this.flgVendaSubmetida = ordem.getFlgVendaSubmetida();
        this.flgCancPosVenda = ordem.getFlgCancPosVenda();

        this.flgVendaDuplicada = "0";
        if(StringUtils.isNotEmpty(ordem.getDatVenda())){
            if(!dupl.add(ordem.getTipoOrdem() + ordem.getNomeCliente()))
                this.flgVendaDuplicada = "1";
        }

        this.flgVendaBruta = "1";
        if(StringUtils.isNotEmpty(ordem.getDatVenda())){
            if(!brut.add(ordem.getTipoOrdem() + ordem.getNomeCliente()))
                this.flgVendaBruta = "0";
        }

        if(this.flgCancPosVenda.equals("0")) {
            this.flgCancDupl = "0";
            contflg0++;
        }
        else if(this.flgCancPosVenda.equals("1")) {
            contflg1++;
            if (this.flgCancPosVenda.equals("1") && contflg0 == 0)
                this.flgCancDupl = "0";
            else if(contflg1 == 1)
                this.flgCancDupl = "0";
            else if (ordem.getStatusOrdem().equals("Concluída"))
                this.flgCancDupl = "1";
            else if (ordem.getStatusOrdem().equals("Em Aprovisionamento"))
                this.flgCancDupl = "1";
        }

        if(this.flgCancPosVenda.equals("1") && this.flgCancDupl.equals("0"))
            this.flgCancLiquido = "1";
        else
            this.flgCancLiquido = "0";

        if(this.flgVendaBruta.equals("0"))
            this.flgVendaLiquida = "0";
        else if(this.flgVendaBruta.equals("1") && this.flgCancLiquido.equals("1")){
            this.flgVendaLiquida = "0";
            definido = true;
        }
        else if(this.flgVendaBruta.equals("1") && !definido)
            flgVendaLiquida = "1";
        this.datCancVenda = ordem.getDatCancVenda();
        this.motivoCancelamento = ordem.getMotivoCancelamento();
        this.nomeCliente = ordem.getNomeCliente();
        this.telefone = ordem.getTelefone();
        this.statusOrdem = ordem.getStatusOrdem();
        this.semanaVenda = ordem.getSemanaVenda();

        if (StringUtils.isNotEmpty(ordem.getSemanaVenda())) {
            this.semanaVendaOrig = ordem.getSemanaVenda();
        } else
            this.semanaVendaOrig = StringUtils.EMPTY;

        this.score = ordem.getScore();
        this.scoreConsumido = ordem.getScoreConsumido();
        this.datFinalizacaoOrdem = ordem.getDatFinalizacaoOrdem();
        this.qtdContratos = ordem.getQtdContratos();
        this.nomLoginResponsavel = ordem.getNomLoginResponsavel();
        this.detalheRecusaCrivo = ordem.getDetalheRecusaCrivo();
        this.loginCancelamentoOrdem = ordem.getLoginCancelamentoOrdem();
        this.nomeParceiroVenda = ordem.getNomeParceiroVenda();
        this.nomeParceiroVendaOrig = ordem.getNomeParceiroVenda();
    }

    @Override
    public String toString() {
        return new StringBuilder()
                .append(datRef).append(DELIMITER)
                .append(datCriacaoOrdem).append(DELIMITER)
                .append(horCriacaoOrdem).append(DELIMITER)
                .append(datVenda).append(DELIMITER)
                .append(horaVenda).append(DELIMITER)
                .append(datStatusOrdem).append(DELIMITER)
                .append(horStatusOrdem).append(DELIMITER)
                .append(numOrdemSiebel).append(DELIMITER)
                .append(codContratoOltp).append(DELIMITER)
                .append(codContratoAtivacao).append(DELIMITER)
                .append(numeroAcesso).append(DELIMITER)
                .append(customerId).append(DELIMITER)
                .append(tipoDocumento).append(DELIMITER)
                .append(documento).append(DELIMITER)
                .append(tipoVenda).append(DELIMITER)
                .append(tipoProduto).append(DELIMITER)
                .append(planoAtivacaoOferta).append(DELIMITER)
                .append(loginVendedor).append(DELIMITER)
                .append(canal).append(DELIMITER)
                .append(cnpjParceiro).append(DELIMITER)
                .append(custCode).append(DELIMITER)
                .append(position).append(DELIMITER)
                .append(flgCancAntesVenda).append(DELIMITER)
                .append(flgCancPosVenda).append(DELIMITER)
                .append(datCancVenda).append(DELIMITER)
                .append(motivoCancelamento).append(DELIMITER)
                .append(nomeCliente).append(DELIMITER)
                .append(telefone).append(DELIMITER)
                .append(email).append(DELIMITER)
                .append(uf).append(DELIMITER)
                .append(tipoLogradouro).append(DELIMITER)
                .append(logradouro).append(DELIMITER)
                .append(numero).append(DELIMITER)
                .append(complemento).append(DELIMITER)
                .append(bairro).append(DELIMITER)
                .append(cep).append(DELIMITER)
                .append(cidade).append(DELIMITER)
                .append(statusOrdem).append(DELIMITER)
                .append(tecnologia).append(DELIMITER)
                .append(formaPagamento).append(DELIMITER)
                .append(tipoConta).append(DELIMITER)
                .append(codBanco).append(DELIMITER)
                .append(codAgenciaBanco).append(DELIMITER)
                .append(codContaCorrente).append(DELIMITER)
                .append(codDebitoAutomatico).append(DELIMITER)
                .append(diaVencimento).append(DELIMITER)
                .append(semanaVenda).append(DELIMITER)
                .append(score).append(DELIMITER)
                .append(scoreConsumido).append(DELIMITER)
                .append(datFinalizacaoOrdem).append(DELIMITER)
                .append(qtdContratos).append(DELIMITER)
                .append(numProtocolo).append(DELIMITER)
                .append(flgOrdemAutomatica).append(DELIMITER)
                .append(dscTxRecorrente).append(DELIMITER)
                .append(dscTxNaoRecorrente).append(DELIMITER)
                .append(dscStatusItem).append(DELIMITER)
                .append(nomLoginResponsavel).append(DELIMITER)
                .append(flgPortabilidade).append(DELIMITER)
                .append(dscOperadoraDoadora).append(DELIMITER)
                .append(codDdd).append(DELIMITER)
                .append(numTelefonePortado).append(DELIMITER)
                .append(datJanelaPortabilidade).append(DELIMITER)
                .append(horJanela).append(DELIMITER)
                .append(dscEnderecoFatura).append(DELIMITER)
                .append(dscAreaVoip).append(DELIMITER)
                .append(cpe).append(DELIMITER)
                .append(ont).append(DELIMITER)
                .append(detalheRecusaCrivo).append(DELIMITER)
                .append(itemRoot).append(DELIMITER)
                .append(loginCancelamentoOrdem).append(DELIMITER)
                .append(dominioRoot).append(DELIMITER)
                .append(codContaFinanceira).append(DELIMITER)
                .append(nomPlanoAtual).append(DELIMITER)
                .append(valPlanoAtualItem).append(DELIMITER)
                .append(nomDescontoAtualItem).append(DELIMITER)
                .append(valDescontoAtualItem).append(DELIMITER)
                .append(nroOrdem).append(DELIMITER)
                .append(acessoRowId).append(DELIMITER)
                .append(acessoRowIdRoot).append(DELIMITER)
                .append(codigoProduto).append(DELIMITER)
                .append(datVendaOrig).append(DELIMITER)
                .append(horVendaOrig).append(DELIMITER)
                .append(numOrdemSiebelOrig).append(DELIMITER)
                .append(loginVendedorOrig).append(DELIMITER)
                .append(canalOrig).append(DELIMITER)
                .append(cnpjParceiroOrig).append(DELIMITER)
                .append(custCodeOrig).append(DELIMITER)
                .append(positionOrig).append(DELIMITER)
                .append(flgVendaSubmetida).append(DELIMITER)
                .append(flgVendaDuplicada).append(DELIMITER)
                .append(flgVendaBruta).append(DELIMITER)
                .append(flgVendaLiquida).append(DELIMITER)
                .append(flgCancDupl).append(DELIMITER)
                .append(flgCancLiquido).append(DELIMITER)
                .append(semanaVendaOrig).append(DELIMITER)
                .append(nomeParceiroVenda).append(DELIMITER)
                .append(nomeParceiroVendaOrig).append(DELIMITER)
                .append(rowIdDoItemDaOrdem).append(DELIMITER)
                .append(rowIdDoItemDaOrdemPai).append(DELIMITER)
                .append(categoriaItemOrdem).toString();
    }

	public String getDatVenda() {
		return datVenda;
	}

	public void setDatVenda(String datVenda) {
		this.datVenda = datVenda;
	}

	public String getStatusOrdem() {
		return statusOrdem;
	}

	public void setStatusOrdem(String statusOrdem) {
		this.statusOrdem = statusOrdem;
	}
    
    
}
