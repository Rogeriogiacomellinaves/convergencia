package br.com.tim.mapreduce.refactoring.endtoend.step1.pt1;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

public class GroupingComparator extends WritableComparator {

    public GroupingComparator() {
        super(E2EStep1Pt1Key.class, true);
    }

    @SuppressWarnings({"rawtypes"})
    @Override
    public int compare(WritableComparable a, WritableComparable b) {
        E2EStep1Pt1Key keyA = (E2EStep1Pt1Key) a;
        E2EStep1Pt1Key keyB = (E2EStep1Pt1Key) b;

        return keyA.compareToGrouping(keyB);
    }

}
