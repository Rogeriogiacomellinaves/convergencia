package br.com.tim.mapreduce.e2e.step7;

public enum TypeStep7 {

    BAT510, RELT
}
