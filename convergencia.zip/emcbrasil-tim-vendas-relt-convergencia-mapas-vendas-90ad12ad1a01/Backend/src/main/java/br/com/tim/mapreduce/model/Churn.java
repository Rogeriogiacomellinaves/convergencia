package br.com.tim.mapreduce.model;

import org.apache.commons.lang3.StringUtils;

public class Churn {

    private String skyContrato;
    private String datReferencia;
    private String seqContrato;
    private String indTipoPrePos;
    private String numTelefone;
    private String codContratoOltp;
    private String skyPdv;
    private String seqPdv;
    private String skyMotivoStatus;
    private String seqMotivoStatus;
    private String skyMotivoChurnCmp;
    private String seqMotivoChurnCmp;
    private String skyTecnologia;
    private String seqTecnologia;
    private String skyClienteRaiz;
    private String seqClienteRaiz;
    private String nomCidade;
    private String skyDdd;
    private String seqDdd;
    private String skyPlanoTarifario;
    private String seqPlanoTarifario;
    private String seqTipoSegmentCliente;
    private String skyTipoSegmentCliente;
    private String skyPacote;
    private String seqPacote;
    private String datTempoBase;
    private String datInsDw;
    private String datAltDw;
    private String skyTipoCliente;
    private String nomLogin;
    private String seqTipoCliente;
    private String datEvento;
    private String numCpfCnpjCliente;
    private String codClienteOltp;
    private String skyGrupoOperadoraReceptora;
    private String seqGrupoOperadoraReceptora;
    private String codChip;
    private String mesReferencia;
    private String flgGrupoContrato;
    private String flgContratoPrincipal;
    private String skyContratoPrincipal;
    private String seqContratoPrincipal;
    private String skyCliente;
    private String seqCliente;
    private String skyPacoteDados;
    private String seqPacoteDados;
    private String codInfoCliente;
    private String indEis;
    private String codImei;
    private String skyTac;
    private String datAtivacaoPacoteDados;
    private String codInfoClientePrincipal;

    public Churn() {

        this.skyContrato = null;
        this.datReferencia = null;
        this.seqContrato = null;
        this.indTipoPrePos = null;
        this.numTelefone = null;
        this.codContratoOltp = null;
        this.skyPdv = null;
        this.seqPdv = null;
        this.skyMotivoStatus = null;
        this.seqMotivoStatus = null;
        this.skyMotivoChurnCmp = null;
        this.seqMotivoChurnCmp = null;
        this.skyTecnologia = null;
        this.seqTecnologia = null;
        this.skyClienteRaiz = null;
        this.seqClienteRaiz = null;
        this.nomCidade = null;
        this.skyDdd = null;
        this.seqDdd = null;
        this.skyPlanoTarifario = null;
        this.seqPlanoTarifario = null;
        this.seqTipoSegmentCliente = null;
        this.skyTipoSegmentCliente = null;
        this.skyPacote = null;
        this.seqPacote = null;
        this.datTempoBase = null;
        this.datInsDw = null;
        this.datAltDw = null;
        this.skyTipoCliente = null;
        this.nomLogin = null;
        this.seqTipoCliente = null;
        this.datEvento = null;
        this.numCpfCnpjCliente = null;
        this.codClienteOltp = null;
        this.skyGrupoOperadoraReceptora = null;
        this.seqGrupoOperadoraReceptora = null;
        this.codChip = null;
        this.mesReferencia = null;
        this.flgGrupoContrato = null;
        this.flgContratoPrincipal = null;
        this.skyContratoPrincipal = null;
        this.seqContratoPrincipal = null;
        this.skyCliente = null;
        this.seqCliente = null;
        this.skyPacoteDados = null;
        this.seqPacoteDados = null;
        this.codInfoCliente = null;
        this.indEis = null;
        this.codImei = null;
        this.skyTac = null;
        this.datAtivacaoPacoteDados = null;
        this.codInfoClientePrincipal = null;

    }

    public void setChurn(String skyContrato, String datReferencia, String seqContrato, String indTipoPrePos, String numTelefone, String codContratoOltp,
                         String skyPdv, String seqPdv, String skyMotivoStatus, String seqMotivoStatus, String skyMotivoChurnCmp, String seqMotivoChurnCmp,
                         String skyTecnologia, String seqTecnologia, String skyClienteRaiz, String seqClienteRaiz, String nomCidade, String skyDdd, String seqDdd,
                         String skyPlanoTarifario, String seqPlanoTarifario, String seqTipoSegmentCliente, String skyTipoSegmentCliente, String skyPacote,
                         String seqPacote, String datTempoBase, String datInsDw, String datAltDw, String skyTipoCliente, String nomLogin, String seqTipoCliente,
                         String datEvento, String numCpfCnpjCliente, String codClienteOltp, String skyGrupoOperadoraReceptora, String seqGrupoOperadoraReceptora,
                         String codChip, String mesReferencia, String flgGrupoContrato, String flgContratoPrincipal, String skyContratoPrincipal,
                         String seqContratoPrincipal, String skyCliente, String seqCliente, String skyPacoteDados, String seqPacoteDados, String codInfoCliente,
                         String indEis, String codImei, String skyTac, String datAtivacaoPacoteDados, String codInfoClientePrincipal) {
        this.skyContrato = skyContrato;
        this.datReferencia = datReferencia;
        this.seqContrato = seqContrato;
        this.indTipoPrePos = indTipoPrePos;
        this.numTelefone = numTelefone;
        this.codContratoOltp = codContratoOltp;
        this.skyPdv = skyPdv;
        this.seqPdv = seqPdv;
        this.skyMotivoStatus = skyMotivoStatus;
        this.seqMotivoStatus = seqMotivoStatus;
        this.skyMotivoChurnCmp = skyMotivoChurnCmp;
        this.seqMotivoChurnCmp = seqMotivoChurnCmp;
        this.skyTecnologia = skyTecnologia;
        this.seqTecnologia = seqTecnologia;
        this.skyClienteRaiz = skyClienteRaiz;
        this.seqClienteRaiz = seqClienteRaiz;
        this.nomCidade = nomCidade;
        this.skyDdd = skyDdd;
        this.seqDdd = seqDdd;
        this.skyPlanoTarifario = skyPlanoTarifario;
        this.seqPlanoTarifario = seqPlanoTarifario;
        this.seqTipoSegmentCliente = seqTipoSegmentCliente;
        this.skyTipoSegmentCliente = skyTipoSegmentCliente;
        this.skyPacote = skyPacote;
        this.seqPacote = seqPacote;
        this.datTempoBase = datTempoBase;
        this.datInsDw = datInsDw;
        this.datAltDw = datAltDw;
        this.skyTipoCliente = skyTipoCliente;
        this.nomLogin = nomLogin;
        this.seqTipoCliente = seqTipoCliente;
        this.datEvento = datEvento;
        this.numCpfCnpjCliente = numCpfCnpjCliente;
        this.codClienteOltp = codClienteOltp;
        this.skyGrupoOperadoraReceptora = skyGrupoOperadoraReceptora;
        this.seqGrupoOperadoraReceptora = seqGrupoOperadoraReceptora;
        this.codChip = codChip;
        this.mesReferencia = mesReferencia;
        this.flgGrupoContrato = flgGrupoContrato;
        this.flgContratoPrincipal = flgContratoPrincipal;
        this.skyContratoPrincipal = skyContratoPrincipal;
        this.seqContratoPrincipal = seqContratoPrincipal;
        this.skyCliente = skyCliente;
        this.seqCliente = seqCliente;
        this.skyPacoteDados = skyPacoteDados;
        this.seqPacoteDados = seqPacoteDados;
        this.codInfoCliente = codInfoCliente;
        this.indEis = indEis;
        this.codImei = codImei;
        this.skyTac = skyTac;
        this.datAtivacaoPacoteDados = datAtivacaoPacoteDados;
        this.codInfoClientePrincipal = codInfoClientePrincipal;
    }

    public boolean parse(String textString) {
        if (StringUtils.isNotBlank(textString)) {
            String[] cols = textString.split("\\|", -1);
            int i = 0;
            this.setChurn(cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                          cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                          cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                          cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                          cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                          cols[i++], cols[i++]);
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        String delimiter = "|";

        sb.append(skyContrato).append(delimiter)
          .append(datReferencia).append(delimiter)
          .append(seqContrato).append(delimiter)
          .append(indTipoPrePos).append(delimiter)
          .append(numTelefone).append(delimiter)
          .append(codContratoOltp).append(delimiter)
          .append(skyPdv).append(delimiter)
          .append(seqPdv).append(delimiter)
          .append(skyMotivoStatus).append(delimiter)
          .append(seqMotivoStatus).append(delimiter)
          .append(skyMotivoChurnCmp).append(delimiter)
          .append(seqMotivoChurnCmp).append(delimiter)
          .append(skyTecnologia).append(delimiter)
          .append(seqTecnologia).append(delimiter)
          .append(skyClienteRaiz).append(delimiter)
          .append(seqClienteRaiz).append(delimiter)
          .append(nomCidade).append(delimiter)
          .append(skyDdd).append(delimiter)
          .append(seqDdd).append(delimiter)
          .append(skyPlanoTarifario).append(delimiter)
          .append(seqPlanoTarifario).append(delimiter)
          .append(seqTipoSegmentCliente).append(delimiter)
          .append(skyTipoSegmentCliente).append(delimiter)
          .append(skyPacote).append(delimiter)
          .append(seqPacote).append(delimiter)
          .append(datTempoBase).append(delimiter)
          .append(datInsDw).append(delimiter)
          .append(datAltDw).append(delimiter)
          .append(skyTipoCliente).append(delimiter)
          .append(nomLogin).append(delimiter)
          .append(seqTipoCliente).append(delimiter)
          .append(datEvento).append(delimiter)
          .append(numCpfCnpjCliente).append(delimiter)
          .append(codClienteOltp).append(delimiter)
          .append(skyGrupoOperadoraReceptora).append(delimiter)
          .append(seqGrupoOperadoraReceptora).append(delimiter)
          .append(codChip).append(delimiter)
          .append(mesReferencia).append(delimiter)
          .append(flgGrupoContrato).append(delimiter)
          .append(flgContratoPrincipal).append(delimiter)
          .append(skyContratoPrincipal).append(delimiter)
          .append(seqContratoPrincipal).append(delimiter)
          .append(skyCliente).append(delimiter)
          .append(seqCliente).append(delimiter)
          .append(skyPacoteDados).append(delimiter)
          .append(seqPacoteDados).append(delimiter)
          .append(codInfoCliente).append(delimiter)
          .append(indEis).append(delimiter)
          .append(codImei).append(delimiter)
          .append(skyTac).append(delimiter)
          .append(datAtivacaoPacoteDados).append(delimiter)
          .append(codInfoClientePrincipal);

        return sb.toString();

    }

    public String getSkyContrato() {
        return skyContrato;
    }

    public void setSkyContrato(String skyContrato) {
        this.skyContrato = skyContrato;
    }

    public String getDatReferencia() {
        return datReferencia;
    }

    public void setDatReferencia(String datReferencia) {
        this.datReferencia = datReferencia;
    }

    public String getSeqContrato() {
        return seqContrato;
    }

    public void setSeqContrato(String seqContrato) {
        this.seqContrato = seqContrato;
    }

    public String getIndTipoPrePos() {
        return indTipoPrePos;
    }

    public void setIndTipoPrePos(String indTipoPrePos) {
        this.indTipoPrePos = indTipoPrePos;
    }

    public String getNumTelefone() {
        return numTelefone;
    }

    public void setNumTelefone(String numTelefone) {
        this.numTelefone = numTelefone;
    }

    public String getCodContratoOltp() {
        return codContratoOltp;
    }

    public void setCodContratoOltp(String codContratoOltp) {
        this.codContratoOltp = codContratoOltp;
    }

    public String getSkyPdv() {
        return skyPdv;
    }

    public void setSkyPdv(String skyPdv) {
        this.skyPdv = skyPdv;
    }

    public String getSeqPdv() {
        return seqPdv;
    }

    public void setSeqPdv(String seqPdv) {
        this.seqPdv = seqPdv;
    }

    public String getSkyMotivoStatus() {
        return skyMotivoStatus;
    }

    public void setSkyMotivoStatus(String skyMotivoStatus) {
        this.skyMotivoStatus = skyMotivoStatus;
    }

    public String getSeqMotivoStatus() {
        return seqMotivoStatus;
    }

    public void setSeqMotivoStatus(String seqMotivoStatus) {
        this.seqMotivoStatus = seqMotivoStatus;
    }

    public String getSkyMotivoChurnCmp() {
        return skyMotivoChurnCmp;
    }

    public void setSkyMotivoChurnCmp(String skyMotivoChurnCmp) {
        this.skyMotivoChurnCmp = skyMotivoChurnCmp;
    }

    public String getSeqMotivoChurnCmp() {
        return seqMotivoChurnCmp;
    }

    public void setSeqMotivoChurnCmp(String seqMotivoChurnCmp) {
        this.seqMotivoChurnCmp = seqMotivoChurnCmp;
    }

    public String getSkyTecnologia() {
        return skyTecnologia;
    }

    public void setSkyTecnologia(String skyTecnologia) {
        this.skyTecnologia = skyTecnologia;
    }

    public String getSeqTecnologia() {
        return seqTecnologia;
    }

    public void setSeqTecnologia(String seqTecnologia) {
        this.seqTecnologia = seqTecnologia;
    }

    public String getSkyClienteRaiz() {
        return skyClienteRaiz;
    }

    public void setSkyClienteRaiz(String skyClienteRaiz) {
        this.skyClienteRaiz = skyClienteRaiz;
    }

    public String getSeqClienteRaiz() {
        return seqClienteRaiz;
    }

    public void setSeqClienteRaiz(String seqClienteRaiz) {
        this.seqClienteRaiz = seqClienteRaiz;
    }

    public String getNomCidade() {
        return nomCidade;
    }

    public void setNomCidade(String nomCidade) {
        this.nomCidade = nomCidade;
    }

    public String getSkyDdd() {
        return skyDdd;
    }

    public void setSkyDdd(String skyDdd) {
        this.skyDdd = skyDdd;
    }

    public String getSeqDdd() {
        return seqDdd;
    }

    public void setSeqDdd(String seqDdd) {
        this.seqDdd = seqDdd;
    }

    public String getSkyPlanoTarifario() {
        return skyPlanoTarifario;
    }

    public void setSkyPlanoTarifario(String skyPlanoTarifario) {
        this.skyPlanoTarifario = skyPlanoTarifario;
    }

    public String getSeqPlanoTarifario() {
        return seqPlanoTarifario;
    }

    public void setSeqPlanoTarifario(String seqPlanoTarifario) {
        this.seqPlanoTarifario = seqPlanoTarifario;
    }

    public String getSeqTipoSegmentCliente() {
        return seqTipoSegmentCliente;
    }

    public void setSeqTipoSegmentCliente(String seqTipoSegmentCliente) {
        this.seqTipoSegmentCliente = seqTipoSegmentCliente;
    }

    public String getSkyTipoSegmentCliente() {
        return skyTipoSegmentCliente;
    }

    public void setSkyTipoSegmentCliente(String skyTipoSegmentCliente) {
        this.skyTipoSegmentCliente = skyTipoSegmentCliente;
    }

    public String getSkyPacote() {
        return skyPacote;
    }

    public void setSkyPacote(String skyPacote) {
        this.skyPacote = skyPacote;
    }

    public String getSeqPacote() {
        return seqPacote;
    }

    public void setSeqPacote(String seqPacote) {
        this.seqPacote = seqPacote;
    }

    public String getDatTempoBase() {
        return datTempoBase;
    }

    public void setDatTempoBase(String datTempoBase) {
        this.datTempoBase = datTempoBase;
    }

    public String getDatInsDw() {
        return datInsDw;
    }

    public void setDatInsDw(String datInsDw) {
        this.datInsDw = datInsDw;
    }

    public String getDatAltDw() {
        return datAltDw;
    }

    public void setDatAltDw(String datAltDw) {
        this.datAltDw = datAltDw;
    }

    public String getSkyTipoCliente() {
        return skyTipoCliente;
    }

    public void setSkyTipoCliente(String skyTipoCliente) {
        this.skyTipoCliente = skyTipoCliente;
    }

    public String getNomLogin() {
        return nomLogin;
    }

    public void setNomLogin(String nomLogin) {
        this.nomLogin = nomLogin;
    }

    public String getSeqTipoCliente() {
        return seqTipoCliente;
    }

    public void setSeqTipoCliente(String seqTipoCliente) {
        this.seqTipoCliente = seqTipoCliente;
    }

    public String getDatEvento() {
        return datEvento;
    }

    public void setDatEvento(String datEvento) {
        this.datEvento = datEvento;
    }

    public String getNumCpfCnpjCliente() {
        return numCpfCnpjCliente;
    }

    public void setNumCpfCnpjCliente(String numCpfCnpjCliente) {
        this.numCpfCnpjCliente = numCpfCnpjCliente;
    }

    public String getCodClienteOltp() {
        return codClienteOltp;
    }

    public void setCodClienteOltp(String codClienteOltp) {
        this.codClienteOltp = codClienteOltp;
    }

    public String getSkyGrupoOperadoraReceptora() {
        return skyGrupoOperadoraReceptora;
    }

    public void setSkyGrupoOperadoraReceptora(String skyGrupoOperadoraReceptora) {
        this.skyGrupoOperadoraReceptora = skyGrupoOperadoraReceptora;
    }

    public String getSeqGrupoOperadoraReceptora() {
        return seqGrupoOperadoraReceptora;
    }

    public void setSeqGrupoOperadoraReceptora(String seqGrupoOperadoraReceptora) {
        this.seqGrupoOperadoraReceptora = seqGrupoOperadoraReceptora;
    }

    public String getCodChip() {
        return codChip;
    }

    public void setCodChip(String codChip) {
        this.codChip = codChip;
    }

    public String getMesReferencia() {
        return mesReferencia;
    }

    public void setMesReferencia(String mesReferencia) {
        this.mesReferencia = mesReferencia;
    }

    public String getFlgGrupoContrato() {
        return flgGrupoContrato;
    }

    public void setFlgGrupoContrato(String flgGrupoContrato) {
        this.flgGrupoContrato = flgGrupoContrato;
    }

    public String getFlgContratoPrincipal() {
        return flgContratoPrincipal;
    }

    public void setFlgContratoPrincipal(String flgContratoPrincipal) {
        this.flgContratoPrincipal = flgContratoPrincipal;
    }

    public String getSkyContratoPrincipal() {
        return skyContratoPrincipal;
    }

    public void setSkyContratoPrincipal(String skyContratoPrincipal) {
        this.skyContratoPrincipal = skyContratoPrincipal;
    }

    public String getSeqContratoPrincipal() {
        return seqContratoPrincipal;
    }

    public void setSeqContratoPrincipal(String seqContratoPrincipal) {
        this.seqContratoPrincipal = seqContratoPrincipal;
    }

    public String getSkyCliente() {
        return skyCliente;
    }

    public void setSkyCliente(String skyCliente) {
        this.skyCliente = skyCliente;
    }

    public String getSeqCliente() {
        return seqCliente;
    }

    public void setSeqCliente(String seqCliente) {
        this.seqCliente = seqCliente;
    }

    public String getSkyPacoteDados() {
        return skyPacoteDados;
    }

    public void setSkyPacoteDados(String skyPacoteDados) {
        this.skyPacoteDados = skyPacoteDados;
    }

    public String getSeqPacoteDados() {
        return seqPacoteDados;
    }

    public void setSeqPacoteDados(String seqPacoteDados) {
        this.seqPacoteDados = seqPacoteDados;
    }

    public String getCodInfoCliente() {
        return codInfoCliente;
    }

    public void setCodInfoCliente(String codInfoCliente) {
        this.codInfoCliente = codInfoCliente;
    }

    public String getIndEis() {
        return indEis;
    }

    public void setIndEis(String indEis) {
        this.indEis = indEis;
    }

    public String getCodImei() {
        return codImei;
    }

    public void setCodImei(String codImei) {
        this.codImei = codImei;
    }

    public String getSkyTac() {
        return skyTac;
    }

    public void setSkyTac(String skyTac) {
        this.skyTac = skyTac;
    }

    public String getDatAtivacaoPacoteDados() {
        return datAtivacaoPacoteDados;
    }

    public void setDatAtivacaoPacoteDados(String datAtivacaoPacoteDados) {
        this.datAtivacaoPacoteDados = datAtivacaoPacoteDados;
    }

    public String getCodInfoClientePrincipal() {
        return codInfoClientePrincipal;
    }

    public void setCodInfoClientePrincipal(String codInfoClientePrincipal) {
        this.codInfoClientePrincipal = codInfoClientePrincipal;
    }
}
