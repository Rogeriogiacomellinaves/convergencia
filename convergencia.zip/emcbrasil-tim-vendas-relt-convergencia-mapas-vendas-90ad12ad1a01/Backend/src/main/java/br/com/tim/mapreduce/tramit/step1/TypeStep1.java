package br.com.tim.mapreduce.tramit.step1;

public enum TypeStep1 {

    ORDEM, WFMTOA, ITEM
}
