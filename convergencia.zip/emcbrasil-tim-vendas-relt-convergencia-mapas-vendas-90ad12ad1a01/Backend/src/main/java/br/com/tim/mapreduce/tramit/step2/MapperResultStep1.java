
package br.com.tim.mapreduce.tramit.step2;

import br.com.tim.mapreduce.tramit.step2.model.Step1Result;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

import java.io.IOException;

public class MapperResultStep1 extends org.apache.hadoop.mapreduce.Mapper<Writable,Text,TramitStep2Key,TramitStep2Value> {

	private TramitStep2Key outkey;
	private TramitStep2Value outValue;
	private Step1Result input;
	@Override
	protected void map(Writable key, Text value, Context context) throws IOException, InterruptedException {
		input.parse(value.toString());
		outkey.setOrdemSiebel(input.getOrdemSiebel());
		outkey.setTipo(TypeStep2.STEP1RESULT);
		outValue.setResultStep1(input);
		context.write(outkey,outValue);

	}

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		super.setup(context);
		this.outkey = new TramitStep2Key();
		this.outValue = new TramitStep2Value();
		this.input = new Step1Result();
	}

	@Override
	protected void cleanup(Context context) throws IOException, InterruptedException {
		super.cleanup(context);
		this.clear();
	}

	private void clear(){
	   this.outValue.clear();
	}

}