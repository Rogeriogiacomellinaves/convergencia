package br.com.tim.mapreduce.e2e.step6.pt1;

import br.com.tim.mapreduce.e2e.step6.E2EStep6Key;
import org.apache.hadoop.mapreduce.Partitioner;

public class JoinPartitioner extends Partitioner<E2EStep6Key, E2EStep6Value> {

    @Override
    public int getPartition(E2EStep6Key taggedKey, E2EStep6Value value, int numPartitions) {
        return Math.abs(taggedKey.hashCodeJoin() % numPartitions);
    }
}