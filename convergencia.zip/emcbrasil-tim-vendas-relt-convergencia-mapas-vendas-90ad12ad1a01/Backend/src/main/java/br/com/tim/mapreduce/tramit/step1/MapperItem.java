
package br.com.tim.mapreduce.tramit.step1;


import br.com.tim.mapreduce.model.BAT509Item;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

import java.io.IOException;

public class MapperItem extends org.apache.hadoop.mapreduce.Mapper<Writable,Text,TramitStep1Key,TramitStep1Value> {

	private TramitStep1Key outkey;
	private TramitStep1Value outValue;
	private BAT509Item input;

	@Override
	protected void map(Writable key, Text value, Context context) throws IOException, InterruptedException {
		input.parse(value.toString());
		outkey.setNroOrdem(input.getNumeroOrdem());
		outkey.setTipo(TypeStep1.ITEM);
		outValue.setItem(input);
		if(input.getTipoItemOrdem().toUpperCase().trim().equals("TIM_FIBER") ||
		   input.getTipoItemOrdem().toUpperCase().trim().equals("BANDA_LARGA") ||
		   input.getTipoItemOrdem().toUpperCase().trim().equals("TIM_FIXO_VOIP")) {
			context.write(outkey, outValue);
		}

	}

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		super.setup(context);
		this.outkey = new TramitStep1Key();
		this.outValue = new TramitStep1Value();
		this.input = new BAT509Item();
	}

	@Override
	protected void cleanup(Context context) throws IOException, InterruptedException {
		super.cleanup(context);
		this.clear();
	}

	private void clear(){
	   this.outValue.clear();
	}

}