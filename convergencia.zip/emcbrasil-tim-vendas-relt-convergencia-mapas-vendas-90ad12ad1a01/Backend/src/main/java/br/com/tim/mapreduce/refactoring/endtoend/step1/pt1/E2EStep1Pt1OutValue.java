package br.com.tim.mapreduce.refactoring.endtoend.step1.pt1;

public class E2EStep1Pt1OutValue {

    private String nroOrdem;
    private String acessoRowId;
    private String codigoProduto;
    private String datRef;
    private String codContratoOltp;
    private String codContratoAtivacao;
    private String numeroAcesso;
    private String customerId;
    private String tipoProduto;
    private String email;
    private String uf;
    private String tipoLogradouro;
	private String logradouro;
    private String numero;
    private String complemento;
    private String bairro;
    private String cep;
    private String cidade;
    private String tecnologia;
    private String formaPagamento;
    private String tipoConta;
    private String codBanco;
    private String codAgenciaBanco;
    private String codContaCorrente;
    private String codDebitoAutomatico;
    private String diaVencimento;
    private String codContaFinanceira;
    private String numProtocolo;
    private String flgOrdemAutomatica;
    private String dscTxRecorrente;
    private String dscTxNaoRecorrente;
    private String dscStatusItem;
    private String nomPlanoAtual;
    private String valPlanoAtualItem;

	private String nomDescontoAtualItem;
    private String valDescontoAtualItem;
    private String flgPortabilidade;
    private String dscOperadoraDoadora;
    private String codDdd;
    private String numTelefonePortado;
    private String datJanelaPortabilidade;
    private String horJanela;
    private String dscEnderecoFatura;
    private String dscAreaVoip;
    private String cpe;
    private String ont;
    private String itemRoot;
    private String dominioRoot;
    private String tipoItem;
    private String nomeProduto;
    private String motivoStatus;
    private String tipoMotivo;

    private String categoriaItemRoot;
    private String rowIdItemRootRoot;
    private String tipoItemRoot;
    private String acaoItemRoot;
    private String acessoRowIdRoot;
    private String statusItemRoot;

    private String categoriaItemPlano;
    private String tipoItemPlano;
    private String acaoItemPlano;
    private String numeroAcessoPlano;
    private String statusItemPlano;

    private String planoAtivacaoOferta;
    private String motivoChurn;
    private String tipoChurn;
    
    private String rowIdDoItemDaOrdem;
    private String rowIdDoItemDaOrdemPai;
    private String rowIdDoItemDaOrdemRoot;
    private String categoriaItemOrdem;

    
    public String getCategoriaItemOrdem() {
		return categoriaItemOrdem;
	}

	public void setCategoriaItemOrdem(String categoriaItemOrdem) {
		this.categoriaItemOrdem = categoriaItemOrdem;
	}    

    public String getRowIdDoItemDaOrdem() {
		return rowIdDoItemDaOrdem;
	}

	public void setRowIdDoItemDaOrdem(String rowIdDoItemDaOrdem) {
		this.rowIdDoItemDaOrdem = rowIdDoItemDaOrdem;
	}

	public String getRowIdDoItemDaOrdemPai() {
		return rowIdDoItemDaOrdemPai;
	}

	public void setRowIdDoItemDaOrdemPai(String rowIdDoItemDaOrdemPai) {
		this.rowIdDoItemDaOrdemPai = rowIdDoItemDaOrdemPai;
	}

	public String getRowIdDoItemDaOrdemRoot() {
		return rowIdDoItemDaOrdemRoot;
	}

	public void setRowIdDoItemDaOrdemRoot(String rowIdDoItemDaOrdemRoot) {
		this.rowIdDoItemDaOrdemRoot = rowIdDoItemDaOrdemRoot;
	}

	public void setPlanoAtivacaoOferta(E2EStep1Pt1PlanoValue value) {
        this.planoAtivacaoOferta = value.getPlanoAtivacaoOferta();
    	this.tecnologia = value.getTecnologia();
    	this.nomPlanoAtual = value.getNomPlanoAtual();
    	this.valPlanoAtualItem = value.getValPlanoAtualItem();
    	this.cpe = value.getCpe();
    	this.ont = value.getOnt();
    	this.codigoProduto = value.getCodigoProduto();
    }
	
	
	
	
	public void clearPlanoAtivacaoOferta() {
        this.planoAtivacaoOferta = "";
    	this.tecnologia = "";
    	this.nomPlanoAtual = "";
    	this.valPlanoAtualItem = "";
    	this.cpe = "";
    	this.ont = "";
    	this.codigoProduto = "";
    }

	public void clearItem(){
        this.nroOrdem = "";
        this.acessoRowId = "";
        this.datRef = "";
        this.codContratoOltp = "";
        this.codContratoAtivacao = "";
        this.numeroAcesso = "";
        this.customerId = "";
        this.tipoProduto = "";
        this.email = "";
        this.uf = "";
        this.tipoLogradouro = "";
        this.logradouro = "";
        this.numero = "";
        this.complemento = "";
        this.bairro = "";
        this.cep = "";
        this.cidade = "";
        this.tecnologia = "";
        this.formaPagamento = "";
        this.tipoConta = "";
        this.codBanco = "";
        this.codAgenciaBanco = "";
        this.codContaCorrente = "";
        this.codDebitoAutomatico = "";
        this.diaVencimento = "";
        this.codContaFinanceira = "";
        this.numProtocolo = "";
        this.flgOrdemAutomatica = "";
        this.dscTxRecorrente = "";
        this.dscTxNaoRecorrente = "";
        this.dscStatusItem = "";
        this.nomPlanoAtual = "";
        this.valPlanoAtualItem = "";
        this.nomDescontoAtualItem = "";
        this.valDescontoAtualItem = "";
        this.flgPortabilidade = "";
        this.dscOperadoraDoadora = "";
        this.codDdd = "";
        this.numTelefonePortado = "";
        this.datJanelaPortabilidade = "";
        this.horJanela = "";
        this.dscEnderecoFatura = "";
        this.dscAreaVoip = "";
        this.cpe = "";
        this.ont = "";
        this.itemRoot = "";
        this.dominioRoot = "";
        this.rowIdDoItemDaOrdem = "";
        this.rowIdDoItemDaOrdemPai = "";
        this.rowIdDoItemDaOrdemRoot = "";
        this.categoriaItemOrdem = "";

    }

    public void clear(){
        this.nroOrdem = "";
        this.acessoRowId = "";
        this.codigoProduto = "";
        this.datRef = "";
        this.codContratoOltp = "";
        this.codContratoAtivacao = "";
        this.numeroAcesso = "";
        this.customerId = "";
        this.tipoProduto = "";
        this.email = "";
        this.uf = "";
        this.tipoLogradouro = "";
        this.logradouro = "";
        this.numero = "";
        this.complemento = "";
        this.bairro = "";
        this.cep = "";
        this.cidade = "";
        this.tecnologia = "";
        this.formaPagamento = "";
        this.tipoConta = "";
        this.codBanco = "";
        this.codAgenciaBanco = "";
        this.codContaCorrente = "";
        this.codDebitoAutomatico = "";
        this.diaVencimento = "";
        this.codContaFinanceira = "";
        this.numProtocolo = "";
        this.flgOrdemAutomatica = "";
        this.dscTxRecorrente = "";
        this.dscTxNaoRecorrente = "";
        this.dscStatusItem = "";
        this.nomPlanoAtual = "";
        this.valPlanoAtualItem = "";
        this.nomDescontoAtualItem = "";
        this.valDescontoAtualItem = "";
        this.flgPortabilidade = "";
        this.dscOperadoraDoadora = "";
        this.codDdd = "";
        this.numTelefonePortado = "";
        this.datJanelaPortabilidade = "";
        this.horJanela = "";
        this.dscEnderecoFatura = "";
        this.dscAreaVoip = "";
        this.cpe = "";
        this.ont = "";
        this.itemRoot = "";
        this.dominioRoot = "";
        this.tipoItem = "";
        this.nomeProduto = "";
        this.motivoStatus = "";
        this.tipoMotivo = "";
        this.categoriaItemRoot = "";
        this.rowIdItemRootRoot = "";
        this.tipoItemRoot = "";
        this.acaoItemRoot = "";
        this.acessoRowIdRoot = "";
        this.statusItemRoot = "";
        this.categoriaItemPlano = "";
        this.tipoItemPlano = "";
        this.acaoItemPlano = "";
        this.numeroAcessoPlano = "";
        this.statusItemPlano = "";
        this.planoAtivacaoOferta = "";
        this.motivoChurn = "";
        this.tipoChurn = "";
        this.rowIdDoItemDaOrdem = "";
        this.rowIdDoItemDaOrdemPai = "";
        this.rowIdDoItemDaOrdemRoot = "";
        this.categoriaItemOrdem = "";

    }

    public void setItem(E2EStep1Pt1Value item) {
        this.nroOrdem = item.getNroOrdem();
        this.acessoRowId = item.getAcessoRowId();
        this.datRef = item.getDatRef();
        this.codContratoOltp = item.getCodContratoOltp();
        this.codContratoAtivacao = item.getCodContratoAtivacao();
        this.numeroAcesso = item.getNumeroAcesso();
        this.customerId = item.getCustomerId();
        this.tipoProduto = item.getTipoProduto();
        this.email = item.getEmail();
        this.uf = item.getUf();
        this.tipoLogradouro = item.getTipoLogradouro();
        this.logradouro = item.getLogradouro();
        this.numero = item.getNumero();
        this.complemento = item.getComplemento();
        this.bairro = item.getBairro();
        this.cep = item.getCep();
        this.cidade = item.getCidade();
        this.formaPagamento = item.getFormaPagamento();
        this.tipoConta = item.getTipoConta();
        this.codBanco = item.getCodBanco();
        this.codAgenciaBanco = item.getCodAgenciaBanco();
        this.codContaCorrente = item.getCodContaCorrente();
        this.codDebitoAutomatico = item.getCodDebitoAutomatico();
        this.diaVencimento = item.getDiaVencimento();
        this.codContaFinanceira = item.getCodContaFinanceira();
        this.numProtocolo = item.getNumProtocolo();
        this.flgOrdemAutomatica = item.getFlgOrdemAutomatica();
        this.dscTxRecorrente = item.getDscTxRecorrente();
        this.dscTxNaoRecorrente = item.getDscTxNaoRecorrente();
        this.dscStatusItem = item.getDscStatusItem();
        this.flgPortabilidade = item.getFlgPortabilidade();
        this.dscOperadoraDoadora = item.getDscOperadoraDoadora();
        this.codDdd = item.getCodDdd();
        this.numTelefonePortado = item.getNumTelefonePortado();
        this.datJanelaPortabilidade = item.getDatJanelaPortabilidade();
        this.horJanela = item.getHorJanela();
        this.dscEnderecoFatura = item.getDscEnderecoFatura();
        this.dscAreaVoip = item.getDscAreaVoip();
        this.itemRoot = item.getItemRoot();
        this.dominioRoot = item.getDominioRoot();
        this.rowIdDoItemDaOrdem = item.getRowIdDoItemDaOrdem();
        this.categoriaItemOrdem = item.getCategoriaItemOrdem();

    }

    public void setRoot(E2EStep1Pt1Value root) {
        this.rowIdItemRootRoot = root.getRowIdItemRootRoot();
        this.tipoItemRoot = root.getTipoItemRoot();
        this.acaoItemRoot = root.getAcaoItemRoot();
        this.acessoRowIdRoot = root.getAcessoRowIdRoot();
        this.statusItemRoot = root.getStatusItemRoot();
        this.rowIdDoItemDaOrdem = root.getRowIdDoItemDaOrdem();
    }

    @Override
    public String toString() {
        return new StringBuilder()
                .append(datRef).append("|")
                .append(codContratoOltp).append("|")
                .append(codContratoAtivacao).append("|")
                .append(numeroAcesso).append("|")
                .append(customerId).append("|")
                .append(tipoProduto).append("|")
                .append(planoAtivacaoOferta).append("|")
                .append(motivoChurn).append("|")
                .append(tipoChurn).append("|")
                .append(email).append("|")
                .append(uf).append("|")
                .append(tipoLogradouro).append("|")
                .append(logradouro).append("|")
                .append(numero).append("|")
                .append(complemento).append("|")
                .append(bairro).append("|")
                .append(cep).append("|")
                .append(cidade).append("|")
                .append(tecnologia).append("|")
                .append(formaPagamento).append("|")
                .append(tipoConta).append("|")
                .append(codBanco).append("|")
                .append(codAgenciaBanco).append("|")
                .append(codContaCorrente).append("|")
                .append(codDebitoAutomatico).append("|")
                .append(diaVencimento).append("|")
                .append(codContaFinanceira).append("|")
                .append(numProtocolo).append("|")
                .append(flgOrdemAutomatica).append("|")
                .append(dscTxRecorrente).append("|")
                .append(dscTxNaoRecorrente).append("|")
                .append(dscStatusItem).append("|")
                .append(nomPlanoAtual).append("|")
                .append(String.valueOf(valPlanoAtualItem).replace(",", ".")).append("|")
                .append(nomDescontoAtualItem).append("|")
                .append(valDescontoAtualItem).append("|")
                .append(flgPortabilidade).append("|")
                .append(dscOperadoraDoadora).append("|")
                .append(codDdd).append("|")
                .append(numTelefonePortado).append("|")
                .append(datJanelaPortabilidade).append("|")
                .append(horJanela).append("|")
                .append(dscEnderecoFatura).append("|")
                .append(dscAreaVoip).append("|")
                .append(cpe).append("|")
                .append(ont).append("|")
                .append(itemRoot).append("|")
                .append(dominioRoot).append("|")
                .append(nroOrdem).append("|")
                .append(acessoRowId).append("|")
                .append(rowIdDoItemDaOrdem).append("|")
                .append(codigoProduto).append("|")
                .append(rowIdDoItemDaOrdemPai).append("|")
                .append(categoriaItemOrdem).toString();    
        }
    
    public String getNumeroAcesso() {
		return numeroAcesso;
	}

	public void setNumeroAcesso(String numeroAcesso) {
		this.numeroAcesso = numeroAcesso;
	}

	public String getMotivoChurn() {
		return motivoChurn;
	}

	public void setMotivoChurn(String motivoChurn) {
		this.motivoChurn = motivoChurn;
	}

	public String getTipoChurn() {
		return tipoChurn;
	}

	public void setTipoChurn(String tipoChurn) {
		this.tipoChurn = tipoChurn;
	}
	
	public String getDscTxRecorrente() {
		return dscTxRecorrente;
	}

	public void setDscTxRecorrente(String dscTxRecorrente) {
		this.dscTxRecorrente = dscTxRecorrente;
	}

	public String getDscTxNaoRecorrente() {
		return dscTxNaoRecorrente;
	}

	public void setDscTxNaoRecorrente(String dscTxNaoRecorrente) {
		this.dscTxNaoRecorrente = dscTxNaoRecorrente;
	}
	
	public String getNomDescontoAtualItem() {
		return nomDescontoAtualItem;
	}

	public void setNomDescontoAtualItem(String nomDescontoAtualItem) {
		this.nomDescontoAtualItem = nomDescontoAtualItem;
	}

	public String getValDescontoAtualItem() {
		return valDescontoAtualItem;
	}

	public void setValDescontoAtualItem(String valDescontoAtualItem) {
		this.valDescontoAtualItem = valDescontoAtualItem;
	}
}
