package br.com.tim.mapreduce.refactoring.endtoend.step1.pt3;

import java.io.IOException;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.log4j.Logger;

import br.com.tim.mapreduce.refactoring.endtoend.step1.pt3.utils.Step1Pt3Counter;

public class E2EStep1pt3Reducer extends org.apache.hadoop.mapreduce.Reducer<E2EStep1pt3Key,E2EStep1pt3Value,NullWritable,Text>{
	protected static final Logger LOG = Logger.getLogger(E2EStep1pt3Reducer.class);
    private E2EStep1pt3OutValue outValue;
    
    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        super.setup(context);
        outValue = new E2EStep1pt3OutValue();
    }

    @Override
    protected void reduce(E2EStep1pt3Key key, Iterable<E2EStep1pt3Value> values, Context context) throws InterruptedException {
    	outValue.clear();
    	
    	try {
    		
    		for(E2EStep1pt3Value value : values) {
    			
    			if (value.getTipo().equals(TypeStep1pt3.RELT)) {
    				
    				outValue.clearRelt();
    				outValue.setRelt(value);
    				   				
    				context.write(NullWritable.get(), new Text(outValue.toString()));
    				context.getCounter(Step1Pt3Counter.STEP1PT3_REDUCER_WRITE).increment(1l);
    				
    			}else if(value.getTipo().equals(TypeStep1pt3.WFMTOA)) {
    				
    				outValue.clearWfmtoa();
    				outValue.setWfmtoa(value);
    				
    			}
    		}
    		
    	}catch (Exception e) {
            LOG.error(" ############ ERROR EXECUTION REDUCER ############ ");
            LOG.error(e.getMessage());
            throw new InterruptedException(e.getMessage());
        }
    }
    
    @Override
    protected void cleanup(Context context) throws IOException, InterruptedException {
        super.cleanup(context);

    }

}
