package br.com.tim.mapreduce.e2e.step4;

public enum TypeStep4 {

    BAT230, RELT
}
