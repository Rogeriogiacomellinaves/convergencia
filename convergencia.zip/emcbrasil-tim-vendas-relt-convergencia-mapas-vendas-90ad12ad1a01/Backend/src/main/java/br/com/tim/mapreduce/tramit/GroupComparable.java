package br.com.tim.mapreduce.tramit;

import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableComparable;

/**
 * @param <T>
 * @author Alexandro Feltrin
 */
public interface GroupComparable<T extends Writable> extends WritableComparable<T> {

    int compareToGrouping(T value);

}