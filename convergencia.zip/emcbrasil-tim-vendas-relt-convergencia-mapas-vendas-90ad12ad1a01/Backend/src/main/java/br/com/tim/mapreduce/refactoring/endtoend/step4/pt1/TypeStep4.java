package br.com.tim.mapreduce.refactoring.endtoend.step4.pt1;

public enum TypeStep4 {

	MAPA_HIST
	
}
