package br.com.tim.mapreduce.e2e.step9;

import br.com.tim.mapreduce.e2e.step6.E2EStep6Key;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

public class GroupingComparator extends WritableComparator {

    public GroupingComparator() {
        super(E2EStep9Key.class, true);
    }

    @SuppressWarnings({"rawtypes"})
    @Override
    public int compare(WritableComparable a, WritableComparable b) {
        E2EStep9Key keyA = (E2EStep9Key) a;
        E2EStep9Key keyB = (E2EStep9Key) b;

        return keyA.compareToGrouping(keyB);
    }

}
