package br.com.tim.mapreduce.refactoring.endtoend.step1.pt3.model;

import org.apache.commons.lang.StringUtils;

import br.com.tim.utils.CommonsConstants;

public class Step1pt2Result {
	
	
	protected String datRef;
	protected String datCriacaoOrdem;
	protected String horCriacaoOrdem;
	protected String datVenda;
	protected String horaVenda;
	protected String datStatusOrdem;
	protected String horStatusOrdem;
	protected String numOrdemSiebel;
	protected String codContratoOltp;
	protected String codContratoAtivacao;
	protected String numeroAcesso;
	protected String customerId;
	protected String tipoDocumento;
	protected String documento;
	protected String tipoVenda;
	protected String tipoProduto;
	protected String planoAtivacaoOferta;
	protected String loginVendedor;
	protected String canal;
	protected String cnpjParceiro;
	protected String custCode;
	protected String position;
	protected String flgCancAntesVenda;
	protected String flgCancPosVenda;
	protected String datCancVenda;
	protected String motivoCancelamento;
	protected String nomeCliente;
	protected String telefone;
	protected String email;
	protected String uf;
	protected String tipoLogradouro;
	protected String logradouro;
	protected String numero;
	protected String complemento;
	protected String bairro;
	protected String cep;
	protected String cidade;
	protected String statusOrdem;
	protected String tecnologia;
	protected String formaPagamento;
	protected String tipoConta;
	protected String codBanco;
	protected String codAgenciaBanco;
	protected String codContaCorrente;
	protected String codDebitoAutomatico;
	protected String diaVencimento;
	protected String semanaVenda;
	protected String score;
	protected String scoreConsumido;
	protected String datFinalizacaoOrdem;
	protected String qtdContratos;
	protected String numProtocolo;
	protected String flgOrdemAutomatica;
	protected String dscTxRecorrente;
	protected String dscTxNaoRecorrente;
	protected String dscStatusItem;
	protected String nomLoginResponsavel;
	protected String flgPortabilidade;
	protected String dscOperadoraDoadora;
	protected String codDdd;
	protected String numTelefonePortado;
	protected String datJanelaPortabilidade;
	protected String horJanela;
	protected String dscEnderecoFatura;
	protected String dscAreaVoip;
	protected String cpe;
	protected String ont;
	protected String detalheRecusaCrivo;
	protected String itemRoot;
	protected String loginCancelamentoOrdem;
	protected String dominioRoot;
	protected String codContaFinanceira;
	protected String nomPlanoAtual;
	protected String valPlanoAtualItem;
	protected String nomDescontoAtualItem;
	protected String valDescontoAtualItem;
	protected String nroOrdem;
	protected String acessoRowId;
	protected String acessoRowIdRoot;
	protected String codigoProduto;
	protected String datVendaOrig;
	protected String horVendaOrig;
	protected String numOrdemSiebelOrig;
	protected String loginVendedorOrig;
	protected String canalOrig;
	protected String cnpjParceiroOrig;
	protected String custCodeOrig;
	protected String positionOrig;
	protected String flgVendaSubmetida;
	protected String flgVendaDuplicada;
	protected String flgVendaBruta;
	protected String flgVendaLiquida;
	protected String flgCancDupl;
	protected String flgCancLiquido;
	protected String semanaVendaOrig;
	protected String nomeParceiroVenda;
	protected String nomeParceiroVendaOrig;
	protected String rowIdDoItemDaOrdem;
	protected String rowIdDoItemDaOrdemPai;
	protected String categoriaItemOrdem;
	
	
	public Step1pt2Result(String datRef, String datCriacaoOrdem, String horCriacaoOrdem, String datVenda,
			String horaVenda, String datStatusOrdem, String horStatusOrdem, String numOrdemSiebel,
			String codContratoOltp, String codContratoAtivacao, String numeroAcesso, String customerId,
			String tipoDocumento, String documento, String tipoVenda, String tipoProduto, String planoAtivacaoOferta,
			String loginVendedor, String canal, String cnpjParceiro, String custCode, String position,
			String flgCancAntesVenda, String flgCancPosVenda, String datCancVenda, String motivoCancelamento,
			String nomeCliente, String telefone, String email, String uf, String tipoLogradouro, String logradouro,
			String numero, String complemento, String bairro, String cep, String cidade, String statusOrdem,
			String tecnologia, String formaPagamento, String tipoConta, String codBanco, String codAgenciaBanco,
			String codContaCorrente, String codDebitoAutomatico, String diaVencimento, String semanaVenda, String score,
			String scoreConsumido, String datFinalizacaoOrdem, String qtdContratos, String numProtocolo,
			String flgOrdemAutomatica, String dscTxRecorrente, String dscTxNaoRecorrente, String dscStatusItem,
			String nomLoginResponsavel, String flgPortabilidade, String dscOperadoraDoadora, String codDdd,
			String numTelefonePortado, String datJanelaPortabilidade, String horJanela, String dscEnderecoFatura,
			String dscAreaVoip, String cpe, String ont, String detalheRecusaCrivo, String itemRoot,
			String loginCancelamentoOrdem, String dominioRoot, String codContaFinanceira, String nomPlanoAtual,
			String valPlanoAtualItem, String nomDescontoAtualItem, String valDescontoAtualItem, String nroOrdem,
			String acessoRowId, String acessoRowIdRoot, String codigoProduto, String datVendaOrig, String horVendaOrig,
			String numOrdemSiebelOrig, String loginVendedorOrig, String canalOrig, String cnpjParceiroOrig,
			String custCodeOrig, String positionOrig, String flgVendaSubmetida, String flgVendaDuplicada,
			String flgVendaBruta, String flgVendaLiquida, String flgCancDupl, String flgCancLiquido,
			String semanaVendaOrig, String nomeParceiroVenda, String nomeParceiroVendaOrig, String rowIdDoItemDaOrdem,
			String rowIdDoItemDaOrdemPai, String categoriaItemOrdem) {

		this.datRef = datRef;
		this.datCriacaoOrdem = datCriacaoOrdem;
		this.horCriacaoOrdem = horCriacaoOrdem;
		this.datVenda = datVenda;
		this.horaVenda = horaVenda;
		this.datStatusOrdem = datStatusOrdem;
		this.horStatusOrdem = horStatusOrdem;
		this.numOrdemSiebel = numOrdemSiebel;
		this.codContratoOltp = codContratoOltp;
		this.codContratoAtivacao = codContratoAtivacao;
		this.numeroAcesso = numeroAcesso;
		this.customerId = customerId;
		this.tipoDocumento = tipoDocumento;
		this.documento = documento;
		this.tipoVenda = tipoVenda;
		this.tipoProduto = tipoProduto;
		this.planoAtivacaoOferta = planoAtivacaoOferta;
		this.loginVendedor = loginVendedor;
		this.canal = canal;
		this.cnpjParceiro = cnpjParceiro;
		this.custCode = custCode;
		this.position = position;
		this.flgCancAntesVenda = flgCancAntesVenda;
		this.flgCancPosVenda = flgCancPosVenda;
		this.datCancVenda = datCancVenda;
		this.motivoCancelamento = motivoCancelamento;
		this.nomeCliente = nomeCliente;
		this.telefone = telefone;
		this.email = email;
		this.uf = uf;
		this.tipoLogradouro = tipoLogradouro;
		this.logradouro = logradouro;
		this.numero = numero;
		this.complemento = complemento;
		this.bairro = bairro;
		this.cep = cep;
		this.cidade = cidade;
		this.statusOrdem = statusOrdem;
		this.tecnologia = tecnologia;
		this.formaPagamento = formaPagamento;
		this.tipoConta = tipoConta;
		this.codBanco = codBanco;
		this.codAgenciaBanco = codAgenciaBanco;
		this.codContaCorrente = codContaCorrente;
		this.codDebitoAutomatico = codDebitoAutomatico;
		this.diaVencimento = diaVencimento;
		this.semanaVenda = semanaVenda;
		this.score = score;
		this.scoreConsumido = scoreConsumido;
		this.datFinalizacaoOrdem = datFinalizacaoOrdem;
		this.qtdContratos = qtdContratos;
		this.numProtocolo = numProtocolo;
		this.flgOrdemAutomatica = flgOrdemAutomatica;
		this.dscTxRecorrente = dscTxRecorrente;
		this.dscTxNaoRecorrente = dscTxNaoRecorrente;
		this.dscStatusItem = dscStatusItem;
		this.nomLoginResponsavel = nomLoginResponsavel;
		this.flgPortabilidade = flgPortabilidade;
		this.dscOperadoraDoadora = dscOperadoraDoadora;
		this.codDdd = codDdd;
		this.numTelefonePortado = numTelefonePortado;
		this.datJanelaPortabilidade = datJanelaPortabilidade;
		this.horJanela = horJanela;
		this.dscEnderecoFatura = dscEnderecoFatura;
		this.dscAreaVoip = dscAreaVoip;
		this.cpe = cpe;
		this.ont = ont;
		this.detalheRecusaCrivo = detalheRecusaCrivo;
		this.itemRoot = itemRoot;
		this.loginCancelamentoOrdem = loginCancelamentoOrdem;
		this.dominioRoot = dominioRoot;
		this.codContaFinanceira = codContaFinanceira;
		this.nomPlanoAtual = nomPlanoAtual;
		this.valPlanoAtualItem = valPlanoAtualItem;
		this.nomDescontoAtualItem = nomDescontoAtualItem;
		this.valDescontoAtualItem = valDescontoAtualItem;
		this.nroOrdem = nroOrdem;
		this.acessoRowId = acessoRowId;
		this.acessoRowIdRoot = acessoRowIdRoot;
		this.codigoProduto = codigoProduto;
		this.datVendaOrig = datVendaOrig;
		this.horVendaOrig = horVendaOrig;
		this.numOrdemSiebelOrig = numOrdemSiebelOrig;
		this.loginVendedorOrig = loginVendedorOrig;
		this.canalOrig = canalOrig;
		this.cnpjParceiroOrig = cnpjParceiroOrig;
		this.custCodeOrig = custCodeOrig;
		this.positionOrig = positionOrig;
		this.flgVendaSubmetida = flgVendaSubmetida;
		this.flgVendaDuplicada = flgVendaDuplicada;
		this.flgVendaBruta = flgVendaBruta;
		this.flgVendaLiquida = flgVendaLiquida;
		this.flgCancDupl = flgCancDupl;
		this.flgCancLiquido = flgCancLiquido;
		this.semanaVendaOrig = semanaVendaOrig;
		this.nomeParceiroVenda = nomeParceiroVenda;
		this.nomeParceiroVendaOrig = nomeParceiroVendaOrig;
		this.rowIdDoItemDaOrdem = rowIdDoItemDaOrdem;
		this.rowIdDoItemDaOrdemPai = rowIdDoItemDaOrdemPai;
		this.categoriaItemOrdem = categoriaItemOrdem;
	}
	
	
	public Step1pt2Result() {
		
		this.clean();

	}
	
	
	
	public static Step1pt2Result parseFromText(String text) {
		
		
		if(!StringUtils.isEmpty(text)) {
			
			String cols[] = text.split(CommonsConstants.FILE_SPLIT_REGEX, -1);
			int i = 0;
			
			return new Step1pt2Result(cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++]);
			
		}
		
		
		
		
		return new Step1pt2Result();
	}
	
	
	public void clean () {
		
		this.datRef = StringUtils.EMPTY;
		this.datCriacaoOrdem = StringUtils.EMPTY;
		this.horCriacaoOrdem = StringUtils.EMPTY;
		this.datVenda = StringUtils.EMPTY;
		this.horaVenda = StringUtils.EMPTY;
		this.datStatusOrdem = StringUtils.EMPTY;
		this.horStatusOrdem = StringUtils.EMPTY;
		this.numOrdemSiebel = StringUtils.EMPTY;
		this.codContratoOltp = StringUtils.EMPTY;
		this.codContratoAtivacao = StringUtils.EMPTY;
		this.numeroAcesso = StringUtils.EMPTY;
		this.customerId = StringUtils.EMPTY;
		this.tipoDocumento = StringUtils.EMPTY;
		this.documento = StringUtils.EMPTY;
		this.tipoVenda = StringUtils.EMPTY;
		this.tipoProduto = StringUtils.EMPTY;
		this.planoAtivacaoOferta = StringUtils.EMPTY;
		this.loginVendedor = StringUtils.EMPTY;
		this.canal = StringUtils.EMPTY;
		this.cnpjParceiro = StringUtils.EMPTY;
		this.custCode = StringUtils.EMPTY;
		this.position = StringUtils.EMPTY;
		this.flgCancAntesVenda = StringUtils.EMPTY;
		this.flgCancPosVenda = StringUtils.EMPTY;
		this.datCancVenda = StringUtils.EMPTY;
		this.motivoCancelamento = StringUtils.EMPTY;
		this.nomeCliente = StringUtils.EMPTY;
		this.telefone = StringUtils.EMPTY;
		this.email = StringUtils.EMPTY;
		this.uf = StringUtils.EMPTY;
		this.tipoLogradouro = StringUtils.EMPTY;
		this.logradouro = StringUtils.EMPTY;
		this.numero = StringUtils.EMPTY;
		this.complemento = StringUtils.EMPTY;
		this.bairro = StringUtils.EMPTY;
		this.cep = StringUtils.EMPTY;
		this.cidade = StringUtils.EMPTY;
		this.statusOrdem = StringUtils.EMPTY;
		this.tecnologia = StringUtils.EMPTY;
		this.formaPagamento = StringUtils.EMPTY;
		this.tipoConta = StringUtils.EMPTY;
		this.codBanco = StringUtils.EMPTY;
		this.codAgenciaBanco = StringUtils.EMPTY;
		this.codContaCorrente = StringUtils.EMPTY;
		this.codDebitoAutomatico = StringUtils.EMPTY;
		this.diaVencimento = StringUtils.EMPTY;
		this.semanaVenda = StringUtils.EMPTY;
		this.score = StringUtils.EMPTY;
		this.scoreConsumido = StringUtils.EMPTY;
		this.datFinalizacaoOrdem = StringUtils.EMPTY;
		this.qtdContratos = StringUtils.EMPTY;
		this.numProtocolo = StringUtils.EMPTY;
		this.flgOrdemAutomatica = StringUtils.EMPTY;
		this.dscTxRecorrente = StringUtils.EMPTY;
		this.dscTxNaoRecorrente = StringUtils.EMPTY;
		this.dscStatusItem = StringUtils.EMPTY;
		this.nomLoginResponsavel = StringUtils.EMPTY;
		this.flgPortabilidade = StringUtils.EMPTY;
		this.dscOperadoraDoadora = StringUtils.EMPTY;
		this.codDdd = StringUtils.EMPTY;
		this.numTelefonePortado = StringUtils.EMPTY;
		this.datJanelaPortabilidade = StringUtils.EMPTY;
		this.horJanela = StringUtils.EMPTY;
		this.dscEnderecoFatura = StringUtils.EMPTY;
		this.dscAreaVoip = StringUtils.EMPTY;
		this.cpe = StringUtils.EMPTY;
		this.ont = StringUtils.EMPTY;
		this.detalheRecusaCrivo = StringUtils.EMPTY;
		this.itemRoot = StringUtils.EMPTY;
		this.loginCancelamentoOrdem = StringUtils.EMPTY;
		this.dominioRoot = StringUtils.EMPTY;
		this.codContaFinanceira = StringUtils.EMPTY;
		this.nomPlanoAtual = StringUtils.EMPTY;
		this.valPlanoAtualItem = StringUtils.EMPTY;
		this.nomDescontoAtualItem = StringUtils.EMPTY;
		this.valDescontoAtualItem = StringUtils.EMPTY;
		this.nroOrdem = StringUtils.EMPTY;
		this.acessoRowId = StringUtils.EMPTY;
		this.acessoRowIdRoot = StringUtils.EMPTY;
		this.codigoProduto = StringUtils.EMPTY;
		this.datVendaOrig = StringUtils.EMPTY;
		this.horVendaOrig = StringUtils.EMPTY;
		this.numOrdemSiebelOrig = StringUtils.EMPTY;
		this.loginVendedorOrig = StringUtils.EMPTY;
		this.canalOrig = StringUtils.EMPTY;
		this.cnpjParceiroOrig = StringUtils.EMPTY;
		this.custCodeOrig = StringUtils.EMPTY;
		this.positionOrig = StringUtils.EMPTY;
		this.flgVendaSubmetida = StringUtils.EMPTY;
		this.flgVendaDuplicada = StringUtils.EMPTY;
		this.flgVendaBruta = StringUtils.EMPTY;
		this.flgVendaLiquida = StringUtils.EMPTY;
		this.flgCancDupl = StringUtils.EMPTY;
		this.flgCancLiquido = StringUtils.EMPTY;
		this.semanaVendaOrig = StringUtils.EMPTY;
		this.nomeParceiroVenda = StringUtils.EMPTY;
		this.nomeParceiroVendaOrig = StringUtils.EMPTY;
		this.rowIdDoItemDaOrdem = StringUtils.EMPTY;
		this.rowIdDoItemDaOrdemPai = StringUtils.EMPTY;
		this.categoriaItemOrdem = StringUtils.EMPTY;
		
	}


	public String getDatRef() {
		return datRef;
	}


	public void setDatRef(String datRef) {
		this.datRef = datRef;
	}


	public String getDatCriacaoOrdem() {
		return datCriacaoOrdem;
	}


	public void setDatCriacaoOrdem(String datCriacaoOrdem) {
		this.datCriacaoOrdem = datCriacaoOrdem;
	}


	public String getHorCriacaoOrdem() {
		return horCriacaoOrdem;
	}


	public void setHorCriacaoOrdem(String horCriacaoOrdem) {
		this.horCriacaoOrdem = horCriacaoOrdem;
	}


	public String getDatVenda() {
		return datVenda;
	}


	public void setDatVenda(String datVenda) {
		this.datVenda = datVenda;
	}


	public String getHoraVenda() {
		return horaVenda;
	}


	public void setHoraVenda(String horaVenda) {
		this.horaVenda = horaVenda;
	}


	public String getDatStatusOrdem() {
		return datStatusOrdem;
	}


	public void setDatStatusOrdem(String datStatusOrdem) {
		this.datStatusOrdem = datStatusOrdem;
	}


	public String getHorStatusOrdem() {
		return horStatusOrdem;
	}


	public void setHorStatusOrdem(String horStatusOrdem) {
		this.horStatusOrdem = horStatusOrdem;
	}


	public String getNumOrdemSiebel() {
		return numOrdemSiebel;
	}


	public void setNumOrdemSiebel(String numOrdemSiebel) {
		this.numOrdemSiebel = numOrdemSiebel;
	}


	public String getCodContratoOltp() {
		return codContratoOltp;
	}


	public void setCodContratoOltp(String codContratoOltp) {
		this.codContratoOltp = codContratoOltp;
	}


	public String getCodContratoAtivacao() {
		return codContratoAtivacao;
	}


	public void setCodContratoAtivacao(String codContratoAtivacao) {
		this.codContratoAtivacao = codContratoAtivacao;
	}


	public String getNumeroAcesso() {
		return numeroAcesso;
	}


	public void setNumeroAcesso(String numeroAcesso) {
		this.numeroAcesso = numeroAcesso;
	}


	public String getCustomerId() {
		return customerId;
	}


	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}


	public String getTipoDocumento() {
		return tipoDocumento;
	}


	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}


	public String getDocumento() {
		return documento;
	}


	public void setDocumento(String documento) {
		this.documento = documento;
	}


	public String getTipoVenda() {
		return tipoVenda;
	}


	public void setTipoVenda(String tipoVenda) {
		this.tipoVenda = tipoVenda;
	}


	public String getTipoProduto() {
		return tipoProduto;
	}


	public void setTipoProduto(String tipoProduto) {
		this.tipoProduto = tipoProduto;
	}


	public String getPlanoAtivacaoOferta() {
		return planoAtivacaoOferta;
	}


	public void setPlanoAtivacaoOferta(String planoAtivacaoOferta) {
		this.planoAtivacaoOferta = planoAtivacaoOferta;
	}


	public String getLoginVendedor() {
		return loginVendedor;
	}


	public void setLoginVendedor(String loginVendedor) {
		this.loginVendedor = loginVendedor;
	}


	public String getCanal() {
		return canal;
	}


	public void setCanal(String canal) {
		this.canal = canal;
	}


	public String getCnpjParceiro() {
		return cnpjParceiro;
	}


	public void setCnpjParceiro(String cnpjParceiro) {
		this.cnpjParceiro = cnpjParceiro;
	}


	public String getCustCode() {
		return custCode;
	}


	public void setCustCode(String custCode) {
		this.custCode = custCode;
	}


	public String getPosition() {
		return position;
	}


	public void setPosition(String position) {
		this.position = position;
	}


	public String getFlgCancAntesVenda() {
		return flgCancAntesVenda;
	}


	public void setFlgCancAntesVenda(String flgCancAntesVenda) {
		this.flgCancAntesVenda = flgCancAntesVenda;
	}


	public String getFlgCancPosVenda() {
		return flgCancPosVenda;
	}


	public void setFlgCancPosVenda(String flgCancPosVenda) {
		this.flgCancPosVenda = flgCancPosVenda;
	}


	public String getDatCancVenda() {
		return datCancVenda;
	}


	public void setDatCancVenda(String datCancVenda) {
		this.datCancVenda = datCancVenda;
	}


	public String getMotivoCancelamento() {
		return motivoCancelamento;
	}


	public void setMotivoCancelamento(String motivoCancelamento) {
		this.motivoCancelamento = motivoCancelamento;
	}


	public String getNomeCliente() {
		return nomeCliente;
	}


	public void setNomeCliente(String nomeCliente) {
		this.nomeCliente = nomeCliente;
	}


	public String getTelefone() {
		return telefone;
	}


	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getUf() {
		return uf;
	}


	public void setUf(String uf) {
		this.uf = uf;
	}


	public String getTipoLogradouro() {
		return tipoLogradouro;
	}


	public void setTipoLogradouro(String tipoLogradouro) {
		this.tipoLogradouro = tipoLogradouro;
	}


	public String getLogradouro() {
		return logradouro;
	}


	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}


	public String getNumero() {
		return numero;
	}


	public void setNumero(String numero) {
		this.numero = numero;
	}


	public String getComplemento() {
		return complemento;
	}


	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}


	public String getBairro() {
		return bairro;
	}


	public void setBairro(String bairro) {
		this.bairro = bairro;
	}


	public String getCep() {
		return cep;
	}


	public void setCep(String cep) {
		this.cep = cep;
	}


	public String getCidade() {
		return cidade;
	}


	public void setCidade(String cidade) {
		this.cidade = cidade;
	}


	public String getStatusOrdem() {
		return statusOrdem;
	}


	public void setStatusOrdem(String statusOrdem) {
		this.statusOrdem = statusOrdem;
	}


	public String getTecnologia() {
		return tecnologia;
	}


	public void setTecnologia(String tecnologia) {
		this.tecnologia = tecnologia;
	}


	public String getFormaPagamento() {
		return formaPagamento;
	}


	public void setFormaPagamento(String formaPagamento) {
		this.formaPagamento = formaPagamento;
	}


	public String getTipoConta() {
		return tipoConta;
	}


	public void setTipoConta(String tipoConta) {
		this.tipoConta = tipoConta;
	}


	public String getCodBanco() {
		return codBanco;
	}


	public void setCodBanco(String codBanco) {
		this.codBanco = codBanco;
	}


	public String getCodAgenciaBanco() {
		return codAgenciaBanco;
	}


	public void setCodAgenciaBanco(String codAgenciaBanco) {
		this.codAgenciaBanco = codAgenciaBanco;
	}


	public String getCodContaCorrente() {
		return codContaCorrente;
	}


	public void setCodContaCorrente(String codContaCorrente) {
		this.codContaCorrente = codContaCorrente;
	}


	public String getCodDebitoAutomatico() {
		return codDebitoAutomatico;
	}


	public void setCodDebitoAutomatico(String codDebitoAutomatico) {
		this.codDebitoAutomatico = codDebitoAutomatico;
	}


	public String getDiaVencimento() {
		return diaVencimento;
	}


	public void setDiaVencimento(String diaVencimento) {
		this.diaVencimento = diaVencimento;
	}


	public String getSemanaVenda() {
		return semanaVenda;
	}


	public void setSemanaVenda(String semanaVenda) {
		this.semanaVenda = semanaVenda;
	}


	public String getScore() {
		return score;
	}


	public void setScore(String score) {
		this.score = score;
	}


	public String getScoreConsumido() {
		return scoreConsumido;
	}


	public void setScoreConsumido(String scoreConsumido) {
		this.scoreConsumido = scoreConsumido;
	}


	public String getDatFinalizacaoOrdem() {
		return datFinalizacaoOrdem;
	}


	public void setDatFinalizacaoOrdem(String datFinalizacaoOrdem) {
		this.datFinalizacaoOrdem = datFinalizacaoOrdem;
	}


	public String getQtdContratos() {
		return qtdContratos;
	}


	public void setQtdContratos(String qtdContratos) {
		this.qtdContratos = qtdContratos;
	}


	public String getNumProtocolo() {
		return numProtocolo;
	}


	public void setNumProtocolo(String numProtocolo) {
		this.numProtocolo = numProtocolo;
	}


	public String getFlgOrdemAutomatica() {
		return flgOrdemAutomatica;
	}


	public void setFlgOrdemAutomatica(String flgOrdemAutomatica) {
		this.flgOrdemAutomatica = flgOrdemAutomatica;
	}


	public String getDscTxRecorrente() {
		return dscTxRecorrente;
	}


	public void setDscTxRecorrente(String dscTxRecorrente) {
		this.dscTxRecorrente = dscTxRecorrente;
	}


	public String getDscTxNaoRecorrente() {
		return dscTxNaoRecorrente;
	}


	public void setDscTxNaoRecorrente(String dscTxNaoRecorrente) {
		this.dscTxNaoRecorrente = dscTxNaoRecorrente;
	}


	public String getDscStatusItem() {
		return dscStatusItem;
	}


	public void setDscStatusItem(String dscStatusItem) {
		this.dscStatusItem = dscStatusItem;
	}


	public String getNomLoginResponsavel() {
		return nomLoginResponsavel;
	}


	public void setNomLoginResponsavel(String nomLoginResponsavel) {
		this.nomLoginResponsavel = nomLoginResponsavel;
	}


	public String getFlgPortabilidade() {
		return flgPortabilidade;
	}


	public void setFlgPortabilidade(String flgPortabilidade) {
		this.flgPortabilidade = flgPortabilidade;
	}


	public String getDscOperadoraDoadora() {
		return dscOperadoraDoadora;
	}


	public void setDscOperadoraDoadora(String dscOperadoraDoadora) {
		this.dscOperadoraDoadora = dscOperadoraDoadora;
	}


	public String getCodDdd() {
		return codDdd;
	}


	public void setCodDdd(String codDdd) {
		this.codDdd = codDdd;
	}


	public String getNumTelefonePortado() {
		return numTelefonePortado;
	}


	public void setNumTelefonePortado(String numTelefonePortado) {
		this.numTelefonePortado = numTelefonePortado;
	}


	public String getDatJanelaPortabilidade() {
		return datJanelaPortabilidade;
	}


	public void setDatJanelaPortabilidade(String datJanelaPortabilidade) {
		this.datJanelaPortabilidade = datJanelaPortabilidade;
	}


	public String getHorJanela() {
		return horJanela;
	}


	public void setHorJanela(String horJanela) {
		this.horJanela = horJanela;
	}


	public String getDscEnderecoFatura() {
		return dscEnderecoFatura;
	}


	public void setDscEnderecoFatura(String dscEnderecoFatura) {
		this.dscEnderecoFatura = dscEnderecoFatura;
	}


	public String getDscAreaVoip() {
		return dscAreaVoip;
	}


	public void setDscAreaVoip(String dscAreaVoip) {
		this.dscAreaVoip = dscAreaVoip;
	}


	public String getCpe() {
		return cpe;
	}


	public void setCpe(String cpe) {
		this.cpe = cpe;
	}


	public String getOnt() {
		return ont;
	}


	public void setOnt(String ont) {
		this.ont = ont;
	}


	public String getDetalheRecusaCrivo() {
		return detalheRecusaCrivo;
	}


	public void setDetalheRecusaCrivo(String detalheRecusaCrivo) {
		this.detalheRecusaCrivo = detalheRecusaCrivo;
	}


	public String getItemRoot() {
		return itemRoot;
	}


	public void setItemRoot(String itemRoot) {
		this.itemRoot = itemRoot;
	}


	public String getLoginCancelamentoOrdem() {
		return loginCancelamentoOrdem;
	}


	public void setLoginCancelamentoOrdem(String loginCancelamentoOrdem) {
		this.loginCancelamentoOrdem = loginCancelamentoOrdem;
	}


	public String getDominioRoot() {
		return dominioRoot;
	}


	public void setDominioRoot(String dominioRoot) {
		this.dominioRoot = dominioRoot;
	}


	public String getCodContaFinanceira() {
		return codContaFinanceira;
	}


	public void setCodContaFinanceira(String codContaFinanceira) {
		this.codContaFinanceira = codContaFinanceira;
	}


	public String getNomPlanoAtual() {
		return nomPlanoAtual;
	}


	public void setNomPlanoAtual(String nomPlanoAtual) {
		this.nomPlanoAtual = nomPlanoAtual;
	}


	public String getValPlanoAtualItem() {
		return valPlanoAtualItem;
	}


	public void setValPlanoAtualItem(String valPlanoAtualItem) {
		this.valPlanoAtualItem = valPlanoAtualItem;
	}


	public String getNomDescontoAtualItem() {
		return nomDescontoAtualItem;
	}


	public void setNomDescontoAtualItem(String nomDescontoAtualItem) {
		this.nomDescontoAtualItem = nomDescontoAtualItem;
	}


	public String getValDescontoAtualItem() {
		return valDescontoAtualItem;
	}


	public void setValDescontoAtualItem(String valDescontoAtualItem) {
		this.valDescontoAtualItem = valDescontoAtualItem;
	}


	public String getNroOrdem() {
		return nroOrdem;
	}


	public void setNroOrdem(String nroOrdem) {
		this.nroOrdem = nroOrdem;
	}


	public String getAcessoRowId() {
		return acessoRowId;
	}


	public void setAcessoRowId(String acessoRowId) {
		this.acessoRowId = acessoRowId;
	}


	public String getAcessoRowIdRoot() {
		return acessoRowIdRoot;
	}


	public void setAcessoRowIdRoot(String acessoRowIdRoot) {
		this.acessoRowIdRoot = acessoRowIdRoot;
	}


	public String getCodigoProduto() {
		return codigoProduto;
	}


	public void setCodigoProduto(String codigoProduto) {
		this.codigoProduto = codigoProduto;
	}


	public String getDatVendaOrig() {
		return datVendaOrig;
	}


	public void setDatVendaOrig(String datVendaOrig) {
		this.datVendaOrig = datVendaOrig;
	}


	public String getHorVendaOrig() {
		return horVendaOrig;
	}


	public void setHorVendaOrig(String horVendaOrig) {
		this.horVendaOrig = horVendaOrig;
	}


	public String getNumOrdemSiebelOrig() {
		return numOrdemSiebelOrig;
	}


	public void setNumOrdemSiebelOrig(String numOrdemSiebelOrig) {
		this.numOrdemSiebelOrig = numOrdemSiebelOrig;
	}


	public String getLoginVendedorOrig() {
		return loginVendedorOrig;
	}


	public void setLoginVendedorOrig(String loginVendedorOrig) {
		this.loginVendedorOrig = loginVendedorOrig;
	}


	public String getCanalOrig() {
		return canalOrig;
	}


	public void setCanalOrig(String canalOrig) {
		this.canalOrig = canalOrig;
	}


	public String getCnpjParceiroOrig() {
		return cnpjParceiroOrig;
	}


	public void setCnpjParceiroOrig(String cnpjParceiroOrig) {
		this.cnpjParceiroOrig = cnpjParceiroOrig;
	}


	public String getCustCodeOrig() {
		return custCodeOrig;
	}


	public void setCustCodeOrig(String custCodeOrig) {
		this.custCodeOrig = custCodeOrig;
	}


	public String getPositionOrig() {
		return positionOrig;
	}


	public void setPositionOrig(String positionOrig) {
		this.positionOrig = positionOrig;
	}


	public String getFlgVendaSubmetida() {
		return flgVendaSubmetida;
	}


	public void setFlgVendaSubmetida(String flgVendaSubmetida) {
		this.flgVendaSubmetida = flgVendaSubmetida;
	}


	public String getFlgVendaDuplicada() {
		return flgVendaDuplicada;
	}


	public void setFlgVendaDuplicada(String flgVendaDuplicada) {
		this.flgVendaDuplicada = flgVendaDuplicada;
	}


	public String getFlgVendaBruta() {
		return flgVendaBruta;
	}


	public void setFlgVendaBruta(String flgVendaBruta) {
		this.flgVendaBruta = flgVendaBruta;
	}


	public String getFlgVendaLiquida() {
		return flgVendaLiquida;
	}


	public void setFlgVendaLiquida(String flgVendaLiquida) {
		this.flgVendaLiquida = flgVendaLiquida;
	}


	public String getFlgCancDupl() {
		return flgCancDupl;
	}


	public void setFlgCancDupl(String flgCancDupl) {
		this.flgCancDupl = flgCancDupl;
	}


	public String getFlgCancLiquido() {
		return flgCancLiquido;
	}


	public void setFlgCancLiquido(String flgCancLiquido) {
		this.flgCancLiquido = flgCancLiquido;
	}


	public String getSemanaVendaOrig() {
		return semanaVendaOrig;
	}


	public void setSemanaVendaOrig(String semanaVendaOrig) {
		this.semanaVendaOrig = semanaVendaOrig;
	}


	public String getNomeParceiroVenda() {
		return nomeParceiroVenda;
	}


	public void setNomeParceiroVenda(String nomeParceiroVenda) {
		this.nomeParceiroVenda = nomeParceiroVenda;
	}


	public String getNomeParceiroVendaOrig() {
		return nomeParceiroVendaOrig;
	}


	public void setNomeParceiroVendaOrig(String nomeParceiroVendaOrig) {
		this.nomeParceiroVendaOrig = nomeParceiroVendaOrig;
	}


	public String getRowIdDoItemDaOrdem() {
		return rowIdDoItemDaOrdem;
	}


	public void setRowIdDoItemDaOrdem(String rowIdDoItemDaOrdem) {
		this.rowIdDoItemDaOrdem = rowIdDoItemDaOrdem;
	}


	public String getRowIdDoItemDaOrdemPai() {
		return rowIdDoItemDaOrdemPai;
	}


	public void setRowIdDoItemDaOrdemPai(String rowIdDoItemDaOrdemPai) {
		this.rowIdDoItemDaOrdemPai = rowIdDoItemDaOrdemPai;
	}


	public String getCategoriaItemOrdem() {
		return categoriaItemOrdem;
	}


	public void setCategoriaItemOrdem(String categoriaItemOrdem) {
		this.categoriaItemOrdem = categoriaItemOrdem;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((acessoRowId == null) ? 0 : acessoRowId.hashCode());
		result = prime * result + ((acessoRowIdRoot == null) ? 0 : acessoRowIdRoot.hashCode());
		result = prime * result + ((bairro == null) ? 0 : bairro.hashCode());
		result = prime * result + ((canal == null) ? 0 : canal.hashCode());
		result = prime * result + ((canalOrig == null) ? 0 : canalOrig.hashCode());
		result = prime * result + ((categoriaItemOrdem == null) ? 0 : categoriaItemOrdem.hashCode());
		result = prime * result + ((cep == null) ? 0 : cep.hashCode());
		result = prime * result + ((cidade == null) ? 0 : cidade.hashCode());
		result = prime * result + ((cnpjParceiro == null) ? 0 : cnpjParceiro.hashCode());
		result = prime * result + ((cnpjParceiroOrig == null) ? 0 : cnpjParceiroOrig.hashCode());
		result = prime * result + ((codAgenciaBanco == null) ? 0 : codAgenciaBanco.hashCode());
		result = prime * result + ((codBanco == null) ? 0 : codBanco.hashCode());
		result = prime * result + ((codContaCorrente == null) ? 0 : codContaCorrente.hashCode());
		result = prime * result + ((codContaFinanceira == null) ? 0 : codContaFinanceira.hashCode());
		result = prime * result + ((codContratoAtivacao == null) ? 0 : codContratoAtivacao.hashCode());
		result = prime * result + ((codContratoOltp == null) ? 0 : codContratoOltp.hashCode());
		result = prime * result + ((codDdd == null) ? 0 : codDdd.hashCode());
		result = prime * result + ((codDebitoAutomatico == null) ? 0 : codDebitoAutomatico.hashCode());
		result = prime * result + ((codigoProduto == null) ? 0 : codigoProduto.hashCode());
		result = prime * result + ((complemento == null) ? 0 : complemento.hashCode());
		result = prime * result + ((cpe == null) ? 0 : cpe.hashCode());
		result = prime * result + ((custCode == null) ? 0 : custCode.hashCode());
		result = prime * result + ((custCodeOrig == null) ? 0 : custCodeOrig.hashCode());
		result = prime * result + ((customerId == null) ? 0 : customerId.hashCode());
		result = prime * result + ((datCancVenda == null) ? 0 : datCancVenda.hashCode());
		result = prime * result + ((datCriacaoOrdem == null) ? 0 : datCriacaoOrdem.hashCode());
		result = prime * result + ((datFinalizacaoOrdem == null) ? 0 : datFinalizacaoOrdem.hashCode());
		result = prime * result + ((datJanelaPortabilidade == null) ? 0 : datJanelaPortabilidade.hashCode());
		result = prime * result + ((datRef == null) ? 0 : datRef.hashCode());
		result = prime * result + ((datStatusOrdem == null) ? 0 : datStatusOrdem.hashCode());
		result = prime * result + ((datVenda == null) ? 0 : datVenda.hashCode());
		result = prime * result + ((datVendaOrig == null) ? 0 : datVendaOrig.hashCode());
		result = prime * result + ((detalheRecusaCrivo == null) ? 0 : detalheRecusaCrivo.hashCode());
		result = prime * result + ((diaVencimento == null) ? 0 : diaVencimento.hashCode());
		result = prime * result + ((documento == null) ? 0 : documento.hashCode());
		result = prime * result + ((dominioRoot == null) ? 0 : dominioRoot.hashCode());
		result = prime * result + ((dscAreaVoip == null) ? 0 : dscAreaVoip.hashCode());
		result = prime * result + ((dscEnderecoFatura == null) ? 0 : dscEnderecoFatura.hashCode());
		result = prime * result + ((dscOperadoraDoadora == null) ? 0 : dscOperadoraDoadora.hashCode());
		result = prime * result + ((dscStatusItem == null) ? 0 : dscStatusItem.hashCode());
		result = prime * result + ((dscTxNaoRecorrente == null) ? 0 : dscTxNaoRecorrente.hashCode());
		result = prime * result + ((dscTxRecorrente == null) ? 0 : dscTxRecorrente.hashCode());
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((flgCancAntesVenda == null) ? 0 : flgCancAntesVenda.hashCode());
		result = prime * result + ((flgCancDupl == null) ? 0 : flgCancDupl.hashCode());
		result = prime * result + ((flgCancLiquido == null) ? 0 : flgCancLiquido.hashCode());
		result = prime * result + ((flgCancPosVenda == null) ? 0 : flgCancPosVenda.hashCode());
		result = prime * result + ((flgOrdemAutomatica == null) ? 0 : flgOrdemAutomatica.hashCode());
		result = prime * result + ((flgPortabilidade == null) ? 0 : flgPortabilidade.hashCode());
		result = prime * result + ((flgVendaBruta == null) ? 0 : flgVendaBruta.hashCode());
		result = prime * result + ((flgVendaDuplicada == null) ? 0 : flgVendaDuplicada.hashCode());
		result = prime * result + ((flgVendaLiquida == null) ? 0 : flgVendaLiquida.hashCode());
		result = prime * result + ((flgVendaSubmetida == null) ? 0 : flgVendaSubmetida.hashCode());
		result = prime * result + ((formaPagamento == null) ? 0 : formaPagamento.hashCode());
		result = prime * result + ((horCriacaoOrdem == null) ? 0 : horCriacaoOrdem.hashCode());
		result = prime * result + ((horJanela == null) ? 0 : horJanela.hashCode());
		result = prime * result + ((horStatusOrdem == null) ? 0 : horStatusOrdem.hashCode());
		result = prime * result + ((horVendaOrig == null) ? 0 : horVendaOrig.hashCode());
		result = prime * result + ((horaVenda == null) ? 0 : horaVenda.hashCode());
		result = prime * result + ((itemRoot == null) ? 0 : itemRoot.hashCode());
		result = prime * result + ((loginCancelamentoOrdem == null) ? 0 : loginCancelamentoOrdem.hashCode());
		result = prime * result + ((loginVendedor == null) ? 0 : loginVendedor.hashCode());
		result = prime * result + ((loginVendedorOrig == null) ? 0 : loginVendedorOrig.hashCode());
		result = prime * result + ((logradouro == null) ? 0 : logradouro.hashCode());
		result = prime * result + ((motivoCancelamento == null) ? 0 : motivoCancelamento.hashCode());
		result = prime * result + ((nomDescontoAtualItem == null) ? 0 : nomDescontoAtualItem.hashCode());
		result = prime * result + ((nomLoginResponsavel == null) ? 0 : nomLoginResponsavel.hashCode());
		result = prime * result + ((nomPlanoAtual == null) ? 0 : nomPlanoAtual.hashCode());
		result = prime * result + ((nomeCliente == null) ? 0 : nomeCliente.hashCode());
		result = prime * result + ((nomeParceiroVenda == null) ? 0 : nomeParceiroVenda.hashCode());
		result = prime * result + ((nomeParceiroVendaOrig == null) ? 0 : nomeParceiroVendaOrig.hashCode());
		result = prime * result + ((nroOrdem == null) ? 0 : nroOrdem.hashCode());
		result = prime * result + ((numOrdemSiebel == null) ? 0 : numOrdemSiebel.hashCode());
		result = prime * result + ((numOrdemSiebelOrig == null) ? 0 : numOrdemSiebelOrig.hashCode());
		result = prime * result + ((numProtocolo == null) ? 0 : numProtocolo.hashCode());
		result = prime * result + ((numTelefonePortado == null) ? 0 : numTelefonePortado.hashCode());
		result = prime * result + ((numero == null) ? 0 : numero.hashCode());
		result = prime * result + ((numeroAcesso == null) ? 0 : numeroAcesso.hashCode());
		result = prime * result + ((ont == null) ? 0 : ont.hashCode());
		result = prime * result + ((planoAtivacaoOferta == null) ? 0 : planoAtivacaoOferta.hashCode());
		result = prime * result + ((position == null) ? 0 : position.hashCode());
		result = prime * result + ((positionOrig == null) ? 0 : positionOrig.hashCode());
		result = prime * result + ((qtdContratos == null) ? 0 : qtdContratos.hashCode());
		result = prime * result + ((rowIdDoItemDaOrdem == null) ? 0 : rowIdDoItemDaOrdem.hashCode());
		result = prime * result + ((rowIdDoItemDaOrdemPai == null) ? 0 : rowIdDoItemDaOrdemPai.hashCode());
		result = prime * result + ((score == null) ? 0 : score.hashCode());
		result = prime * result + ((scoreConsumido == null) ? 0 : scoreConsumido.hashCode());
		result = prime * result + ((semanaVenda == null) ? 0 : semanaVenda.hashCode());
		result = prime * result + ((semanaVendaOrig == null) ? 0 : semanaVendaOrig.hashCode());
		result = prime * result + ((statusOrdem == null) ? 0 : statusOrdem.hashCode());
		result = prime * result + ((tecnologia == null) ? 0 : tecnologia.hashCode());
		result = prime * result + ((telefone == null) ? 0 : telefone.hashCode());
		result = prime * result + ((tipoConta == null) ? 0 : tipoConta.hashCode());
		result = prime * result + ((tipoDocumento == null) ? 0 : tipoDocumento.hashCode());
		result = prime * result + ((tipoLogradouro == null) ? 0 : tipoLogradouro.hashCode());
		result = prime * result + ((tipoProduto == null) ? 0 : tipoProduto.hashCode());
		result = prime * result + ((tipoVenda == null) ? 0 : tipoVenda.hashCode());
		result = prime * result + ((uf == null) ? 0 : uf.hashCode());
		result = prime * result + ((valDescontoAtualItem == null) ? 0 : valDescontoAtualItem.hashCode());
		result = prime * result + ((valPlanoAtualItem == null) ? 0 : valPlanoAtualItem.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Step1pt2Result other = (Step1pt2Result) obj;
		if (acessoRowId == null) {
			if (other.acessoRowId != null)
				return false;
		} else if (!acessoRowId.equals(other.acessoRowId))
			return false;
		if (acessoRowIdRoot == null) {
			if (other.acessoRowIdRoot != null)
				return false;
		} else if (!acessoRowIdRoot.equals(other.acessoRowIdRoot))
			return false;
		if (bairro == null) {
			if (other.bairro != null)
				return false;
		} else if (!bairro.equals(other.bairro))
			return false;
		if (canal == null) {
			if (other.canal != null)
				return false;
		} else if (!canal.equals(other.canal))
			return false;
		if (canalOrig == null) {
			if (other.canalOrig != null)
				return false;
		} else if (!canalOrig.equals(other.canalOrig))
			return false;
		if (categoriaItemOrdem == null) {
			if (other.categoriaItemOrdem != null)
				return false;
		} else if (!categoriaItemOrdem.equals(other.categoriaItemOrdem))
			return false;
		if (cep == null) {
			if (other.cep != null)
				return false;
		} else if (!cep.equals(other.cep))
			return false;
		if (cidade == null) {
			if (other.cidade != null)
				return false;
		} else if (!cidade.equals(other.cidade))
			return false;
		if (cnpjParceiro == null) {
			if (other.cnpjParceiro != null)
				return false;
		} else if (!cnpjParceiro.equals(other.cnpjParceiro))
			return false;
		if (cnpjParceiroOrig == null) {
			if (other.cnpjParceiroOrig != null)
				return false;
		} else if (!cnpjParceiroOrig.equals(other.cnpjParceiroOrig))
			return false;
		if (codAgenciaBanco == null) {
			if (other.codAgenciaBanco != null)
				return false;
		} else if (!codAgenciaBanco.equals(other.codAgenciaBanco))
			return false;
		if (codBanco == null) {
			if (other.codBanco != null)
				return false;
		} else if (!codBanco.equals(other.codBanco))
			return false;
		if (codContaCorrente == null) {
			if (other.codContaCorrente != null)
				return false;
		} else if (!codContaCorrente.equals(other.codContaCorrente))
			return false;
		if (codContaFinanceira == null) {
			if (other.codContaFinanceira != null)
				return false;
		} else if (!codContaFinanceira.equals(other.codContaFinanceira))
			return false;
		if (codContratoAtivacao == null) {
			if (other.codContratoAtivacao != null)
				return false;
		} else if (!codContratoAtivacao.equals(other.codContratoAtivacao))
			return false;
		if (codContratoOltp == null) {
			if (other.codContratoOltp != null)
				return false;
		} else if (!codContratoOltp.equals(other.codContratoOltp))
			return false;
		if (codDdd == null) {
			if (other.codDdd != null)
				return false;
		} else if (!codDdd.equals(other.codDdd))
			return false;
		if (codDebitoAutomatico == null) {
			if (other.codDebitoAutomatico != null)
				return false;
		} else if (!codDebitoAutomatico.equals(other.codDebitoAutomatico))
			return false;
		if (codigoProduto == null) {
			if (other.codigoProduto != null)
				return false;
		} else if (!codigoProduto.equals(other.codigoProduto))
			return false;
		if (complemento == null) {
			if (other.complemento != null)
				return false;
		} else if (!complemento.equals(other.complemento))
			return false;
		if (cpe == null) {
			if (other.cpe != null)
				return false;
		} else if (!cpe.equals(other.cpe))
			return false;
		if (custCode == null) {
			if (other.custCode != null)
				return false;
		} else if (!custCode.equals(other.custCode))
			return false;
		if (custCodeOrig == null) {
			if (other.custCodeOrig != null)
				return false;
		} else if (!custCodeOrig.equals(other.custCodeOrig))
			return false;
		if (customerId == null) {
			if (other.customerId != null)
				return false;
		} else if (!customerId.equals(other.customerId))
			return false;
		if (datCancVenda == null) {
			if (other.datCancVenda != null)
				return false;
		} else if (!datCancVenda.equals(other.datCancVenda))
			return false;
		if (datCriacaoOrdem == null) {
			if (other.datCriacaoOrdem != null)
				return false;
		} else if (!datCriacaoOrdem.equals(other.datCriacaoOrdem))
			return false;
		if (datFinalizacaoOrdem == null) {
			if (other.datFinalizacaoOrdem != null)
				return false;
		} else if (!datFinalizacaoOrdem.equals(other.datFinalizacaoOrdem))
			return false;
		if (datJanelaPortabilidade == null) {
			if (other.datJanelaPortabilidade != null)
				return false;
		} else if (!datJanelaPortabilidade.equals(other.datJanelaPortabilidade))
			return false;
		if (datRef == null) {
			if (other.datRef != null)
				return false;
		} else if (!datRef.equals(other.datRef))
			return false;
		if (datStatusOrdem == null) {
			if (other.datStatusOrdem != null)
				return false;
		} else if (!datStatusOrdem.equals(other.datStatusOrdem))
			return false;
		if (datVenda == null) {
			if (other.datVenda != null)
				return false;
		} else if (!datVenda.equals(other.datVenda))
			return false;
		if (datVendaOrig == null) {
			if (other.datVendaOrig != null)
				return false;
		} else if (!datVendaOrig.equals(other.datVendaOrig))
			return false;
		if (detalheRecusaCrivo == null) {
			if (other.detalheRecusaCrivo != null)
				return false;
		} else if (!detalheRecusaCrivo.equals(other.detalheRecusaCrivo))
			return false;
		if (diaVencimento == null) {
			if (other.diaVencimento != null)
				return false;
		} else if (!diaVencimento.equals(other.diaVencimento))
			return false;
		if (documento == null) {
			if (other.documento != null)
				return false;
		} else if (!documento.equals(other.documento))
			return false;
		if (dominioRoot == null) {
			if (other.dominioRoot != null)
				return false;
		} else if (!dominioRoot.equals(other.dominioRoot))
			return false;
		if (dscAreaVoip == null) {
			if (other.dscAreaVoip != null)
				return false;
		} else if (!dscAreaVoip.equals(other.dscAreaVoip))
			return false;
		if (dscEnderecoFatura == null) {
			if (other.dscEnderecoFatura != null)
				return false;
		} else if (!dscEnderecoFatura.equals(other.dscEnderecoFatura))
			return false;
		if (dscOperadoraDoadora == null) {
			if (other.dscOperadoraDoadora != null)
				return false;
		} else if (!dscOperadoraDoadora.equals(other.dscOperadoraDoadora))
			return false;
		if (dscStatusItem == null) {
			if (other.dscStatusItem != null)
				return false;
		} else if (!dscStatusItem.equals(other.dscStatusItem))
			return false;
		if (dscTxNaoRecorrente == null) {
			if (other.dscTxNaoRecorrente != null)
				return false;
		} else if (!dscTxNaoRecorrente.equals(other.dscTxNaoRecorrente))
			return false;
		if (dscTxRecorrente == null) {
			if (other.dscTxRecorrente != null)
				return false;
		} else if (!dscTxRecorrente.equals(other.dscTxRecorrente))
			return false;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (flgCancAntesVenda == null) {
			if (other.flgCancAntesVenda != null)
				return false;
		} else if (!flgCancAntesVenda.equals(other.flgCancAntesVenda))
			return false;
		if (flgCancDupl == null) {
			if (other.flgCancDupl != null)
				return false;
		} else if (!flgCancDupl.equals(other.flgCancDupl))
			return false;
		if (flgCancLiquido == null) {
			if (other.flgCancLiquido != null)
				return false;
		} else if (!flgCancLiquido.equals(other.flgCancLiquido))
			return false;
		if (flgCancPosVenda == null) {
			if (other.flgCancPosVenda != null)
				return false;
		} else if (!flgCancPosVenda.equals(other.flgCancPosVenda))
			return false;
		if (flgOrdemAutomatica == null) {
			if (other.flgOrdemAutomatica != null)
				return false;
		} else if (!flgOrdemAutomatica.equals(other.flgOrdemAutomatica))
			return false;
		if (flgPortabilidade == null) {
			if (other.flgPortabilidade != null)
				return false;
		} else if (!flgPortabilidade.equals(other.flgPortabilidade))
			return false;
		if (flgVendaBruta == null) {
			if (other.flgVendaBruta != null)
				return false;
		} else if (!flgVendaBruta.equals(other.flgVendaBruta))
			return false;
		if (flgVendaDuplicada == null) {
			if (other.flgVendaDuplicada != null)
				return false;
		} else if (!flgVendaDuplicada.equals(other.flgVendaDuplicada))
			return false;
		if (flgVendaLiquida == null) {
			if (other.flgVendaLiquida != null)
				return false;
		} else if (!flgVendaLiquida.equals(other.flgVendaLiquida))
			return false;
		if (flgVendaSubmetida == null) {
			if (other.flgVendaSubmetida != null)
				return false;
		} else if (!flgVendaSubmetida.equals(other.flgVendaSubmetida))
			return false;
		if (formaPagamento == null) {
			if (other.formaPagamento != null)
				return false;
		} else if (!formaPagamento.equals(other.formaPagamento))
			return false;
		if (horCriacaoOrdem == null) {
			if (other.horCriacaoOrdem != null)
				return false;
		} else if (!horCriacaoOrdem.equals(other.horCriacaoOrdem))
			return false;
		if (horJanela == null) {
			if (other.horJanela != null)
				return false;
		} else if (!horJanela.equals(other.horJanela))
			return false;
		if (horStatusOrdem == null) {
			if (other.horStatusOrdem != null)
				return false;
		} else if (!horStatusOrdem.equals(other.horStatusOrdem))
			return false;
		if (horVendaOrig == null) {
			if (other.horVendaOrig != null)
				return false;
		} else if (!horVendaOrig.equals(other.horVendaOrig))
			return false;
		if (horaVenda == null) {
			if (other.horaVenda != null)
				return false;
		} else if (!horaVenda.equals(other.horaVenda))
			return false;
		if (itemRoot == null) {
			if (other.itemRoot != null)
				return false;
		} else if (!itemRoot.equals(other.itemRoot))
			return false;
		if (loginCancelamentoOrdem == null) {
			if (other.loginCancelamentoOrdem != null)
				return false;
		} else if (!loginCancelamentoOrdem.equals(other.loginCancelamentoOrdem))
			return false;
		if (loginVendedor == null) {
			if (other.loginVendedor != null)
				return false;
		} else if (!loginVendedor.equals(other.loginVendedor))
			return false;
		if (loginVendedorOrig == null) {
			if (other.loginVendedorOrig != null)
				return false;
		} else if (!loginVendedorOrig.equals(other.loginVendedorOrig))
			return false;
		if (logradouro == null) {
			if (other.logradouro != null)
				return false;
		} else if (!logradouro.equals(other.logradouro))
			return false;
		if (motivoCancelamento == null) {
			if (other.motivoCancelamento != null)
				return false;
		} else if (!motivoCancelamento.equals(other.motivoCancelamento))
			return false;
		if (nomDescontoAtualItem == null) {
			if (other.nomDescontoAtualItem != null)
				return false;
		} else if (!nomDescontoAtualItem.equals(other.nomDescontoAtualItem))
			return false;
		if (nomLoginResponsavel == null) {
			if (other.nomLoginResponsavel != null)
				return false;
		} else if (!nomLoginResponsavel.equals(other.nomLoginResponsavel))
			return false;
		if (nomPlanoAtual == null) {
			if (other.nomPlanoAtual != null)
				return false;
		} else if (!nomPlanoAtual.equals(other.nomPlanoAtual))
			return false;
		if (nomeCliente == null) {
			if (other.nomeCliente != null)
				return false;
		} else if (!nomeCliente.equals(other.nomeCliente))
			return false;
		if (nomeParceiroVenda == null) {
			if (other.nomeParceiroVenda != null)
				return false;
		} else if (!nomeParceiroVenda.equals(other.nomeParceiroVenda))
			return false;
		if (nomeParceiroVendaOrig == null) {
			if (other.nomeParceiroVendaOrig != null)
				return false;
		} else if (!nomeParceiroVendaOrig.equals(other.nomeParceiroVendaOrig))
			return false;
		if (nroOrdem == null) {
			if (other.nroOrdem != null)
				return false;
		} else if (!nroOrdem.equals(other.nroOrdem))
			return false;
		if (numOrdemSiebel == null) {
			if (other.numOrdemSiebel != null)
				return false;
		} else if (!numOrdemSiebel.equals(other.numOrdemSiebel))
			return false;
		if (numOrdemSiebelOrig == null) {
			if (other.numOrdemSiebelOrig != null)
				return false;
		} else if (!numOrdemSiebelOrig.equals(other.numOrdemSiebelOrig))
			return false;
		if (numProtocolo == null) {
			if (other.numProtocolo != null)
				return false;
		} else if (!numProtocolo.equals(other.numProtocolo))
			return false;
		if (numTelefonePortado == null) {
			if (other.numTelefonePortado != null)
				return false;
		} else if (!numTelefonePortado.equals(other.numTelefonePortado))
			return false;
		if (numero == null) {
			if (other.numero != null)
				return false;
		} else if (!numero.equals(other.numero))
			return false;
		if (numeroAcesso == null) {
			if (other.numeroAcesso != null)
				return false;
		} else if (!numeroAcesso.equals(other.numeroAcesso))
			return false;
		if (ont == null) {
			if (other.ont != null)
				return false;
		} else if (!ont.equals(other.ont))
			return false;
		if (planoAtivacaoOferta == null) {
			if (other.planoAtivacaoOferta != null)
				return false;
		} else if (!planoAtivacaoOferta.equals(other.planoAtivacaoOferta))
			return false;
		if (position == null) {
			if (other.position != null)
				return false;
		} else if (!position.equals(other.position))
			return false;
		if (positionOrig == null) {
			if (other.positionOrig != null)
				return false;
		} else if (!positionOrig.equals(other.positionOrig))
			return false;
		if (qtdContratos == null) {
			if (other.qtdContratos != null)
				return false;
		} else if (!qtdContratos.equals(other.qtdContratos))
			return false;
		if (rowIdDoItemDaOrdem == null) {
			if (other.rowIdDoItemDaOrdem != null)
				return false;
		} else if (!rowIdDoItemDaOrdem.equals(other.rowIdDoItemDaOrdem))
			return false;
		if (rowIdDoItemDaOrdemPai == null) {
			if (other.rowIdDoItemDaOrdemPai != null)
				return false;
		} else if (!rowIdDoItemDaOrdemPai.equals(other.rowIdDoItemDaOrdemPai))
			return false;
		if (score == null) {
			if (other.score != null)
				return false;
		} else if (!score.equals(other.score))
			return false;
		if (scoreConsumido == null) {
			if (other.scoreConsumido != null)
				return false;
		} else if (!scoreConsumido.equals(other.scoreConsumido))
			return false;
		if (semanaVenda == null) {
			if (other.semanaVenda != null)
				return false;
		} else if (!semanaVenda.equals(other.semanaVenda))
			return false;
		if (semanaVendaOrig == null) {
			if (other.semanaVendaOrig != null)
				return false;
		} else if (!semanaVendaOrig.equals(other.semanaVendaOrig))
			return false;
		if (statusOrdem == null) {
			if (other.statusOrdem != null)
				return false;
		} else if (!statusOrdem.equals(other.statusOrdem))
			return false;
		if (tecnologia == null) {
			if (other.tecnologia != null)
				return false;
		} else if (!tecnologia.equals(other.tecnologia))
			return false;
		if (telefone == null) {
			if (other.telefone != null)
				return false;
		} else if (!telefone.equals(other.telefone))
			return false;
		if (tipoConta == null) {
			if (other.tipoConta != null)
				return false;
		} else if (!tipoConta.equals(other.tipoConta))
			return false;
		if (tipoDocumento == null) {
			if (other.tipoDocumento != null)
				return false;
		} else if (!tipoDocumento.equals(other.tipoDocumento))
			return false;
		if (tipoLogradouro == null) {
			if (other.tipoLogradouro != null)
				return false;
		} else if (!tipoLogradouro.equals(other.tipoLogradouro))
			return false;
		if (tipoProduto == null) {
			if (other.tipoProduto != null)
				return false;
		} else if (!tipoProduto.equals(other.tipoProduto))
			return false;
		if (tipoVenda == null) {
			if (other.tipoVenda != null)
				return false;
		} else if (!tipoVenda.equals(other.tipoVenda))
			return false;
		if (uf == null) {
			if (other.uf != null)
				return false;
		} else if (!uf.equals(other.uf))
			return false;
		if (valDescontoAtualItem == null) {
			if (other.valDescontoAtualItem != null)
				return false;
		} else if (!valDescontoAtualItem.equals(other.valDescontoAtualItem))
			return false;
		if (valPlanoAtualItem == null) {
			if (other.valPlanoAtualItem != null)
				return false;
		} else if (!valPlanoAtualItem.equals(other.valPlanoAtualItem))
			return false;
		return true;
	}


	@Override
	public String toString() {
		return "Step2pt1Result [datRef=" + datRef + ", datCriacaoOrdem=" + datCriacaoOrdem + ", horCriacaoOrdem="
				+ horCriacaoOrdem + ", datVenda=" + datVenda + ", horaVenda=" + horaVenda + ", datStatusOrdem="
				+ datStatusOrdem + ", horStatusOrdem=" + horStatusOrdem + ", numOrdemSiebel=" + numOrdemSiebel
				+ ", codContratoOltp=" + codContratoOltp + ", codContratoAtivacao=" + codContratoAtivacao
				+ ", numeroAcesso=" + numeroAcesso + ", customerId=" + customerId + ", tipoDocumento=" + tipoDocumento
				+ ", documento=" + documento + ", tipoVenda=" + tipoVenda + ", tipoProduto=" + tipoProduto
				+ ", planoAtivacaoOferta=" + planoAtivacaoOferta + ", loginVendedor=" + loginVendedor + ", canal="
				+ canal + ", cnpjParceiro=" + cnpjParceiro + ", custCode=" + custCode + ", position=" + position
				+ ", flgCancAntesVenda=" + flgCancAntesVenda + ", flgCancPosVenda=" + flgCancPosVenda
				+ ", datCancVenda=" + datCancVenda + ", motivoCancelamento=" + motivoCancelamento + ", nomeCliente="
				+ nomeCliente + ", telefone=" + telefone + ", email=" + email + ", uf=" + uf + ", tipoLogradouro="
				+ tipoLogradouro + ", logradouro=" + logradouro + ", numero=" + numero + ", complemento=" + complemento
				+ ", bairro=" + bairro + ", cep=" + cep + ", cidade=" + cidade + ", statusOrdem=" + statusOrdem
				+ ", tecnologia=" + tecnologia + ", formaPagamento=" + formaPagamento + ", tipoConta=" + tipoConta
				+ ", codBanco=" + codBanco + ", codAgenciaBanco=" + codAgenciaBanco + ", codContaCorrente="
				+ codContaCorrente + ", codDebitoAutomatico=" + codDebitoAutomatico + ", diaVencimento=" + diaVencimento
				+ ", semanaVenda=" + semanaVenda + ", score=" + score + ", scoreConsumido=" + scoreConsumido
				+ ", datFinalizacaoOrdem=" + datFinalizacaoOrdem + ", qtdContratos=" + qtdContratos + ", numProtocolo="
				+ numProtocolo + ", flgOrdemAutomatica=" + flgOrdemAutomatica + ", dscTxRecorrente=" + dscTxRecorrente
				+ ", dscTxNaoRecorrente=" + dscTxNaoRecorrente + ", dscStatusItem=" + dscStatusItem
				+ ", nomLoginResponsavel=" + nomLoginResponsavel + ", flgPortabilidade=" + flgPortabilidade
				+ ", dscOperadoraDoadora=" + dscOperadoraDoadora + ", codDdd=" + codDdd + ", numTelefonePortado="
				+ numTelefonePortado + ", datJanelaPortabilidade=" + datJanelaPortabilidade + ", horJanela=" + horJanela
				+ ", dscEnderecoFatura=" + dscEnderecoFatura + ", dscAreaVoip=" + dscAreaVoip + ", cpe=" + cpe
				+ ", ont=" + ont + ", detalheRecusaCrivo=" + detalheRecusaCrivo + ", itemRoot=" + itemRoot
				+ ", loginCancelamentoOrdem=" + loginCancelamentoOrdem + ", dominioRoot=" + dominioRoot
				+ ", codContaFinanceira=" + codContaFinanceira + ", nomPlanoAtual=" + nomPlanoAtual
				+ ", valPlanoAtualItem=" + valPlanoAtualItem + ", nomDescontoAtualItem=" + nomDescontoAtualItem
				+ ", valDescontoAtualItem=" + valDescontoAtualItem + ", nroOrdem=" + nroOrdem + ", acessoRowId="
				+ acessoRowId + ", acessoRowIdRoot=" + acessoRowIdRoot + ", codigoProduto=" + codigoProduto
				+ ", datVendaOrig=" + datVendaOrig + ", horVendaOrig=" + horVendaOrig + ", numOrdemSiebelOrig="
				+ numOrdemSiebelOrig + ", loginVendedorOrig=" + loginVendedorOrig + ", canalOrig=" + canalOrig
				+ ", cnpjParceiroOrig=" + cnpjParceiroOrig + ", custCodeOrig=" + custCodeOrig + ", positionOrig="
				+ positionOrig + ", flgVendaSubmetida=" + flgVendaSubmetida + ", flgVendaDuplicada=" + flgVendaDuplicada
				+ ", flgVendaBruta=" + flgVendaBruta + ", flgVendaLiquida=" + flgVendaLiquida + ", flgCancDupl="
				+ flgCancDupl + ", flgCancLiquido=" + flgCancLiquido + ", semanaVendaOrig=" + semanaVendaOrig
				+ ", nomeParceiroVenda=" + nomeParceiroVenda + ", nomeParceiroVendaOrig=" + nomeParceiroVendaOrig
				+ ", rowIdDoItemDaOrdem=" + rowIdDoItemDaOrdem + ", rowIdDoItemDaOrdemPai=" + rowIdDoItemDaOrdemPai
				+ ", categoriaItemOrdem=" + categoriaItemOrdem + "]";
	}
	
	
	

}
