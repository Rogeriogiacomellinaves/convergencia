package br.com.tim.mapreduce.itemordem.step1;

import br.com.tim.mapreduce.model.BAT509Item;
import br.com.tim.mapreduce.model.BAT509Order;
import br.com.tim.mapreduce.model.Wfmtoa;

import org.apache.hadoop.io.Writable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public class IOStep1Value implements Writable {

    protected TypeStep1 tipo;
    protected String nomBairro;
    protected String cep;
    protected String nomCidade;
    protected String numCNPJParcVenda;
    protected String dscComplemento;
    protected String datDesconexao;
    protected String datVenda;
    protected String dscLogradouro;
    protected String numLogradouro;
    protected String nomPlanoAtual;
    protected String nomPlanoNovo;
    protected String numTelefone;
    protected String dscTipoLogradouro;
    protected String nomProduto;
    protected String dscTipoMotivo;
    protected String sglUFInstalacao;
    protected String datRef;
    protected String dscAcaoItemOrdem;
    protected String dscStatusItem;
    protected String email;
    protected String dscTipoOrdem;
    protected String dscFormaPgto;
    protected String codCtaFinanceira;
    protected String codContratoOltp;
    protected String numProtocolo;
    protected String datCriacaoOrdem;
    protected String datStatusOrdem;
    protected String datSuspensao;
    protected String datReativacao;
    protected String codServiceId;
    protected String nomContato;
    protected String dscMotivoStatusItem;
    protected String nomLoginResponsavel;
    protected String nomLoginVendedor;
    protected String dscCanalVenda;
    protected String valPlanoAtual;
    protected String nomDescontoAtual;
    protected String valDescontoAtual;
    protected String valPlanoNovo;
    protected String nomDescontoNovo;
    protected String valDescontoNovo;
    protected String flgPortabilidade;
    protected String codDdd;
    protected String numTelefonePortado;
    protected String datJanelaPortabilidade;
    protected String dscEstorno;
    protected String numBilheteEstornado;
    protected String dscMotivoEstorno;
    protected String dscStatusOrdemWfm;
    protected String datHoraStatusWfm;
    protected String diaVencimento;
    protected String dscTipoConta;
    protected String dscEnderecoFatura;
    protected String dscAreaVoip;
    protected String codBanco;
    protected String codAgenciaBco;
    protected String codContaCorrente;
    protected String datAltFormaPgto;
    protected String codDebitoAutomatico;
    protected String codItemOrdem;
    protected String nomParceiroVenda;
    protected String idItemOrdPai;
    protected String idItemOrdem;
    protected String dscCategoriaItem;
    protected String tecnologia;
    protected String cpe;
    protected String ont;
    protected String numTelefone2;
    protected String numTelefone3;
    protected String dominioRoot;
    protected String codProduto;
    
    @Override
    public void write(DataOutput dataOutput) throws IOException {
        dataOutput.writeInt(tipo.ordinal());
        dataOutput.writeUTF(nomBairro);
        dataOutput.writeUTF(cep);
        dataOutput.writeUTF(nomCidade);
        dataOutput.writeUTF(numCNPJParcVenda);
        dataOutput.writeUTF(dscComplemento);
        dataOutput.writeUTF(datDesconexao);
        dataOutput.writeUTF(datVenda);
        dataOutput.writeUTF(dscLogradouro);
        dataOutput.writeUTF(numLogradouro);
        dataOutput.writeUTF(nomPlanoAtual);
        dataOutput.writeUTF(nomPlanoNovo);
        dataOutput.writeUTF(numTelefone);
        dataOutput.writeUTF(dscTipoLogradouro);
        dataOutput.writeUTF(nomProduto);
        dataOutput.writeUTF(dscTipoMotivo);
        dataOutput.writeUTF(sglUFInstalacao);
        dataOutput.writeUTF(datRef);
        dataOutput.writeUTF(dscAcaoItemOrdem);
        dataOutput.writeUTF(dscStatusItem);
        dataOutput.writeUTF(email);
        dataOutput.writeUTF(dscTipoOrdem);
        dataOutput.writeUTF(dscFormaPgto);
        dataOutput.writeUTF(codCtaFinanceira);
        dataOutput.writeUTF(codContratoOltp);
        dataOutput.writeUTF(numProtocolo);
        dataOutput.writeUTF(datCriacaoOrdem);
        dataOutput.writeUTF(datStatusOrdem);
        dataOutput.writeUTF(datSuspensao);
        dataOutput.writeUTF(datReativacao);
        dataOutput.writeUTF(codServiceId);
        dataOutput.writeUTF(nomContato);
        dataOutput.writeUTF(dscMotivoStatusItem);
        dataOutput.writeUTF(nomLoginResponsavel);
        dataOutput.writeUTF(nomLoginVendedor);
        dataOutput.writeUTF(dscCanalVenda);
        dataOutput.writeUTF(valPlanoAtual);
        dataOutput.writeUTF(nomDescontoAtual);
        dataOutput.writeUTF(valDescontoAtual);
        dataOutput.writeUTF(valPlanoNovo);
        dataOutput.writeUTF(nomDescontoNovo);
        dataOutput.writeUTF(valDescontoNovo);
        dataOutput.writeUTF(flgPortabilidade);
        dataOutput.writeUTF(codDdd);
        dataOutput.writeUTF(numTelefonePortado);
        dataOutput.writeUTF(datJanelaPortabilidade);
        dataOutput.writeUTF(dscEstorno);
        dataOutput.writeUTF(numBilheteEstornado);
        dataOutput.writeUTF(dscMotivoEstorno);
        dataOutput.writeUTF(dscStatusOrdemWfm);
        dataOutput.writeUTF(datHoraStatusWfm);
        dataOutput.writeUTF(diaVencimento);
        dataOutput.writeUTF(dscTipoConta);
        dataOutput.writeUTF(dscEnderecoFatura);
        dataOutput.writeUTF(dscAreaVoip);
        dataOutput.writeUTF(codBanco);
        dataOutput.writeUTF(codAgenciaBco);
        dataOutput.writeUTF(codContaCorrente);
        dataOutput.writeUTF(datAltFormaPgto);
        dataOutput.writeUTF(codDebitoAutomatico);
        dataOutput.writeUTF(codItemOrdem);
        dataOutput.writeUTF(nomParceiroVenda);
        dataOutput.writeUTF(idItemOrdPai);
        dataOutput.writeUTF(idItemOrdem);
        dataOutput.writeUTF(dscCategoriaItem);
        dataOutput.writeUTF(tecnologia);
        dataOutput.writeUTF(cpe);
        dataOutput.writeUTF(ont);
        dataOutput.writeUTF(numTelefone2);
        dataOutput.writeUTF(numTelefone3);
        dataOutput.writeUTF(dominioRoot);
        dataOutput.writeUTF(codProduto);
    }

    @Override
    public void readFields(DataInput dataInput) throws IOException {
        this.tipo = TypeStep1.values()[dataInput.readInt()];
        this.nomBairro = dataInput.readUTF();
        this.cep = dataInput.readUTF();
        this.nomCidade = dataInput.readUTF();
        this.numCNPJParcVenda = dataInput.readUTF();
        this.dscComplemento = dataInput.readUTF();
        this.datDesconexao = dataInput.readUTF();
        this.datVenda = dataInput.readUTF();
        this.dscLogradouro = dataInput.readUTF();
        this.numLogradouro = dataInput.readUTF();
        this.nomPlanoAtual = dataInput.readUTF();
        this.nomPlanoNovo = dataInput.readUTF();
        this.numTelefone = dataInput.readUTF();
        this.dscTipoLogradouro = dataInput.readUTF();
        this.nomProduto = dataInput.readUTF();
        this.dscTipoMotivo = dataInput.readUTF();
        this.sglUFInstalacao = dataInput.readUTF();
        this.datRef = dataInput.readUTF();
        this.dscAcaoItemOrdem = dataInput.readUTF();
        this.dscStatusItem = dataInput.readUTF();
        this.email = dataInput.readUTF();
        this.dscTipoOrdem = dataInput.readUTF();
        this.dscFormaPgto = dataInput.readUTF();
        this.codCtaFinanceira = dataInput.readUTF();
        this.codContratoOltp = dataInput.readUTF();
        this.numProtocolo = dataInput.readUTF();
        this.datCriacaoOrdem = dataInput.readUTF();
        this.datStatusOrdem = dataInput.readUTF();
        this.datSuspensao = dataInput.readUTF();
        this.datReativacao = dataInput.readUTF();
        this.codServiceId = dataInput.readUTF();
        this.nomContato = dataInput.readUTF();
        this.dscMotivoStatusItem = dataInput.readUTF();
        this.nomLoginResponsavel = dataInput.readUTF();
        this.nomLoginVendedor = dataInput.readUTF();
        this.dscCanalVenda = dataInput.readUTF();
        this.valPlanoAtual = dataInput.readUTF();
        this.nomDescontoAtual = dataInput.readUTF();
        this.valDescontoAtual = dataInput.readUTF();
        this.valPlanoNovo = dataInput.readUTF();
        this.nomDescontoNovo = dataInput.readUTF();
        this.valDescontoNovo = dataInput.readUTF();
        this.flgPortabilidade = dataInput.readUTF();
        this.codDdd = dataInput.readUTF();
        this.numTelefonePortado = dataInput.readUTF();
        this.datJanelaPortabilidade = dataInput.readUTF();
        this.dscEstorno = dataInput.readUTF();
        this.numBilheteEstornado = dataInput.readUTF();
        this.dscMotivoEstorno = dataInput.readUTF();
        this.dscStatusOrdemWfm = dataInput.readUTF();
        this.datHoraStatusWfm = dataInput.readUTF();
        this.diaVencimento = dataInput.readUTF();
        this.dscTipoConta = dataInput.readUTF();
        this.dscEnderecoFatura = dataInput.readUTF();
        this.dscAreaVoip = dataInput.readUTF();
        this.codBanco = dataInput.readUTF();
        this.codAgenciaBco = dataInput.readUTF();
        this.codContaCorrente = dataInput.readUTF();
        this.datAltFormaPgto = dataInput.readUTF();
        this.codDebitoAutomatico = dataInput.readUTF();
        this.codItemOrdem = dataInput.readUTF();
        this.nomParceiroVenda = dataInput.readUTF();
        this.idItemOrdPai = dataInput.readUTF();
        this.idItemOrdem = dataInput.readUTF();
        this.dscCategoriaItem = dataInput.readUTF();
        this.tecnologia = dataInput.readUTF();
        this.cpe = dataInput.readUTF();
        this.ont = dataInput.readUTF();
        this.numTelefone2 = dataInput.readUTF();
        this.numTelefone3 = dataInput.readUTF();
        this.dominioRoot = dataInput.readUTF();
        this.codProduto = dataInput.readUTF();
    }

    public void setItem(BAT509Item item) {
        this.clear();
        this.tipo = TypeStep1.ITEM;
        this.nomBairro = item.getBairro();
        this.cep = item.getCep();
        this.nomCidade = item.getCidade();
        this.dscComplemento = item.getComplemento();
        this.datDesconexao = item.getDataDesconexao();
        this.dscLogradouro = item.getLogradouroInstalacao();
        this.numLogradouro = item.getNumeroLogradouro();
        this.nomPlanoAtual = item.getPlanoAtual();
        this.nomPlanoNovo = item.getPlano();
        if(!item.getTipoItemOrdem().equals("BANDA_LARGA")) {
            this.numTelefone = item.getNumeroAcesso();
        }
        this.dscTipoLogradouro = item.getTipoLogradouro();
        this.nomProduto = item.getNomeProduto();
        this.dscTipoMotivo = item.getTipoMotivo();
        this.sglUFInstalacao = item.getUfInstalacao();
        this.dscAcaoItemOrdem = item.getAcaoItemOrdem();
        this.dscStatusItem = item.getStatusItem();
        this.email = item.getEmail();
        this.dscFormaPgto = item.getMetodoPagamento();
        this.codCtaFinanceira = item.getCodigoContaFinanceira();
        this.codContratoOltp = item.getIdAcessoBi();
        this.numProtocolo = item.getNumeroProtocolo();
        this.datSuspensao = item.getDataSuspensao();
        this.datReativacao = item.getDataReativacao();
        if(item.getTipoItemOrdem().equals("BANDA_LARGA")) {
            this.codServiceId = item.getNumeroAcesso();
        }
        this.dscMotivoStatusItem = item.getMotivoStatus();
        this.valPlanoAtual = item.getPrecoPlanoAtual();
        this.nomDescontoAtual = item.getDescontoAtual();
        this.valDescontoAtual = item.getPrecoDescontoAtual();
        this.valPlanoNovo = item.getPrecoPlano();
        this.nomDescontoNovo = item.getDesconto();
        this.valDescontoNovo = item.getPrecoDesconto();
        this.flgPortabilidade = item.getFlgPortabilidade();
        this.codDdd = item.getDdd();
        this.numTelefonePortado = item.getNumeroASerPortado();
        this.datJanelaPortabilidade = item.getDataJanela();
        this.dscEstorno = item.getEstorno();
        this.numBilheteEstornado = item.getBilheteASerEstornado();
        this.dscMotivoEstorno = item.getMotivoEstorno();
        this.diaVencimento = item.getDiaVencimento();
        this.dscTipoConta = item.getTipoConta();
        this.dscEnderecoFatura = item.getEnderecoRecebimentoFatura();
        this.dscAreaVoip = item.getArea();
        this.codBanco = item.getBanco();
        this.codAgenciaBco = item.getAgencia();
        this.codContaCorrente = item.getConta();
        this.datAltFormaPgto = item.getDataModalidade();
        this.codDebitoAutomatico = item.getCodDebitoAutomatico();
        this.codItemOrdem = item.getItensOrdem();
        this.idItemOrdPai = item.getRowidItemOrdemRoot();
        this.idItemOrdem = item.getRowidItemOrdem();
        this.dscCategoriaItem = item.getCategoriaItemOrdem();
        this.tecnologia = item.getDscTecnologia();
        this.cpe = item.getCpe();
        this.ont = item.getOnt();
        this.dominioRoot = item.getDominioRoot();
        this.codProduto = item.getCodigoProduto();
    }

    public void setOrdem(BAT509Order ordem) {
        this.clear();
        this.tipo = TypeStep1.ORDEM;
        this.numCNPJParcVenda = ordem.getCnpjParceiroVenda();
        this.datVenda = ordem.getDataVenda();
        this.datRef = ordem.getArquivo().substring(17, 25);
        this.dscTipoOrdem = ordem.getTipoOrdem();
        this.datCriacaoOrdem = ordem.getDataCriacaoOrdem();
        this.datStatusOrdem = ordem.getDataStatusOrdem();
        this.nomContato = ordem.getNomeContato();
        this.nomLoginResponsavel = ordem.getLoginResponsavel();
        this.nomLoginVendedor = ordem.getLoginVendedor();
        this.dscCanalVenda = ordem.getCanalVenda();
        this.nomParceiroVenda = ordem.getNomeParceiroVenda();
        this.numTelefone2 = ordem.getTelefoneContato2();
        this.numTelefone3 = ordem.getTelefoneContato3();
    }
    
    public void setWfmtoa(Wfmtoa wfm) {
    	this.clear();
    	this.tipo = TypeStep1.WFM_TOA;
    	this.dscStatusOrdemWfm = wfm.getAstatus();
    	
    	if (wfm.getAstatus().equals("pending")) {
    		this.datHoraStatusWfm = wfm.getAtimeOfBooking();
    	} else if (wfm.getAstatus().equals("suspended") 
    			|| wfm.getAstatus().equals("notdone") 
    			|| wfm.getAstatus().equals("completed")) {
    		this.datHoraStatusWfm = wfm.getQueueDate() + " " + wfm.getEndTime();
    	}
    }

    public void clear(){
        this.tipo = null;
        this.nomBairro = "";
        this.cep = "";
        this.nomCidade = "";
        this.numCNPJParcVenda = "";
        this.dscComplemento = "";
        this.datDesconexao = "";
        this.datVenda = "";
        this.dscLogradouro = "";
        this.numLogradouro = "";
        this.nomPlanoAtual = "";
        this.nomPlanoNovo = "";
        this.numTelefone = "";
        this.dscTipoLogradouro = "";
        this.nomProduto = "";
        this.dscTipoMotivo = "";
        this.sglUFInstalacao = "";
        this.datRef = "";
        this.dscAcaoItemOrdem = "";
        this.dscStatusItem = "";
        this.email = "";
        this.dscTipoOrdem = "";
        this.dscFormaPgto = "";
        this.codCtaFinanceira = "";
        this.codContratoOltp = "";
        this.numProtocolo = "";
        this.datCriacaoOrdem = "";
        this.datStatusOrdem = "";
        this.datSuspensao = "";
        this.datReativacao = "";
        this.codServiceId = "";
        this.nomContato = "";
        this.dscMotivoStatusItem = "";
        this.nomLoginResponsavel = "";
        this.nomLoginVendedor = "";
        this.dscCanalVenda = "";
        this.valPlanoAtual = "";
        this.nomDescontoAtual = "";
        this.valDescontoAtual = "";
        this.valPlanoNovo = "";
        this.nomDescontoNovo = "";
        this.valDescontoNovo = "";
        this.flgPortabilidade = "";
        this.codDdd = "";
        this.numTelefonePortado = "";
        this.datJanelaPortabilidade = "";
        this.dscEstorno = "";
        this.numBilheteEstornado = "";
        this.dscMotivoEstorno = "";
        this.dscStatusOrdemWfm = "";
        this.datHoraStatusWfm = "";
        this.diaVencimento = "";
        this.dscTipoConta = "";
        this.dscEnderecoFatura = "";
        this.dscAreaVoip = "";
        this.codBanco = "";
        this.codAgenciaBco = "";
        this.codContaCorrente = "";
        this.datAltFormaPgto = "";
        this.codDebitoAutomatico = "";
        this.codItemOrdem = "";
        this.nomParceiroVenda = "";
        this.idItemOrdPai = "";
        this.idItemOrdem = "";
        this.dscCategoriaItem = "";
        this.tecnologia = "";
        this.cpe = "";
        this.ont = "";
        this.numTelefone2 = "";
        this.numTelefone3 = "";
        this.dominioRoot = "";
        this.codProduto = "";
    }

    public String getDominioRoot() {
        return dominioRoot;
    }

    public void setDominioRoot(String dominioRoot) {
        this.dominioRoot = dominioRoot;
    }

    public TypeStep1 getTipo() {
        return tipo;
    }

    public String getNomBairro() {
        return nomBairro;
    }

    public String getCep() {
        return cep;
    }

    public String getNomCidade() {
        return nomCidade;
    }

    public String getNumCNPJParcVenda() {
        return numCNPJParcVenda;
    }

    public String getDscComplemento() {
        return dscComplemento;
    }

    public String getDatDesconexao() {
        return datDesconexao;
    }

      public String getDatVenda() {
        return datVenda;
    }

    public String getDscLogradouro() {
        return dscLogradouro;
    }

    public String getNumLogradouro() {
        return numLogradouro;
    }

    public String getNomPlanoAtual() {
        return nomPlanoAtual;
    }

    public String getNomPlanoNovo() {
        return nomPlanoNovo;
    }

    public String getNumTelefone() {
        return numTelefone;
    }

    public String getDscTipoLogradouro() {
        return dscTipoLogradouro;
    }

    public String getNomProduto() {
        return nomProduto;
    }

    public String getDscTipoMotivo() {
        return dscTipoMotivo;
    }

    public String getSglUFInstalacao() {
        return sglUFInstalacao;
    }

    public String getDatRef() {
        return datRef;
    }

    public String getDscAcaoItemOrdem() {
        return dscAcaoItemOrdem;
    }

    public String getDscStatusItem() {
        return dscStatusItem;
    }

    public String getEmail() {
        return email;
    }

    public String getDscTipoOrdem() {
        return dscTipoOrdem;
    }

    public String getDscFormaPgto() {
        return dscFormaPgto;
    }

    public String getCodCtaFinanceira() {
        return codCtaFinanceira;
    }

    public String getCodContratoOltp() {
        return codContratoOltp;
    }

    public String getNumProtocolo() {
        return numProtocolo;
    }

    public String getDatCriacaoOrdem() {
        return datCriacaoOrdem;
    }

    public String getDatStatusOrdem() {
        return datStatusOrdem;
    }

    public String getDatSuspensao() {
        return datSuspensao;
    }

    public String getDatReativacao() {
        return datReativacao;
    }

    public String getCodServiceId() {
        return codServiceId;
    }

    public String getNomContato() {
        return nomContato;
    }

    public String getDscMotivoStatusItem() {
        return dscMotivoStatusItem;
    }

    public String getNomLoginResponsavel() {
        return nomLoginResponsavel;
    }

    public String getNomLoginVendedor() {
        return nomLoginVendedor;
    }

    public String getDscCanalVenda() {
        return dscCanalVenda;
    }

    public String getValPlanoAtual() {
        return valPlanoAtual;
    }

    public String getNomDescontoAtual() {
        return nomDescontoAtual;
    }

    public String getValDescontoAtual() {
        return valDescontoAtual;
    }

    public String getValPlanoNovo() {
        return valPlanoNovo;
    }

    public String getNomDescontoNovo() {
        return nomDescontoNovo;
    }

    public String getValDescontoNovo() {
        return valDescontoNovo;
    }

    public String getFlgPortabilidade() {
        return flgPortabilidade;
    }

    public String getCodDdd() {
        return codDdd;
    }

    public String getNumTelefonePortado() {
        return numTelefonePortado;
    }

    public String getDatJanelaPortabilidade() {
        return datJanelaPortabilidade;
    }

    public String getDscEstorno() {
        return dscEstorno;
    }

    public String getNumBilheteEstornado() {
        return numBilheteEstornado;
    }

    public String getDscMotivoEstorno() {
        return dscMotivoEstorno;
    }

    public String getDiaVencimento() {
        return diaVencimento;
    }

    public String getDscTipoConta() {
        return dscTipoConta;
    }

    public String getDscEnderecoFatura() {
        return dscEnderecoFatura;
    }

    public String getDscAreaVoip() {
        return dscAreaVoip;
    }

    public String getCodBanco() {
        return codBanco;
    }

    public String getCodAgenciaBco() {
        return codAgenciaBco;
    }

    public String getCodContaCorrente() {
        return codContaCorrente;
    }

    public String getDatAltFormaPgto() {
        return datAltFormaPgto;
    }

    public String getCodDebitoAutomatico() {
        return codDebitoAutomatico;
    }

    public String getCodItemOrdem() {
        return codItemOrdem;
    }

    public String getNomParceiroVenda() {
        return nomParceiroVenda;
    }

    public String getIdItemOrdPai() {
        return idItemOrdPai;
    }

    public String getIdItemOrdem() {
        return idItemOrdem;
    }

    public String getDscCategoriaItem() {
        return dscCategoriaItem;
    }

    public String getTecnologia() {
        return tecnologia;
    }

    public String getCpe() {
        return cpe;
    }

    public String getOnt() {
        return ont;
    }

    public String getNumTelefone2() {
        return numTelefone2;
    }

    public String getNumTelefone3() {
        return numTelefone3;
    }

    public String getCodProduto() {
        return codProduto;
    }

    public void setCodProduto(String codProduto) {
        this.codProduto = codProduto;
    }

	public String getDscStatusOrdemWfm() {
		return dscStatusOrdemWfm;
	}

	public String getDatHoraStatusWfm() {
		return datHoraStatusWfm;
	}
   
}
