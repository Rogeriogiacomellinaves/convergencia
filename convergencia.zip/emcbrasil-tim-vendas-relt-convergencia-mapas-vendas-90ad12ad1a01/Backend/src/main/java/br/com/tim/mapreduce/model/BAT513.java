package br.com.tim.mapreduce.model;

import org.apache.commons.lang3.StringUtils;

public class BAT513 {

    private String abaEconfiguratior;
    private String acessoRaiz;
    private String categoria;
    private String datInicioVigencia;
    private String datFimVigencia;
    private String familia;
    private String idAmdocs;
    private String idBscs;
    private String idSiebel;
    private String nomProduto;
    private String taxaHabilitacao;
    private String taxaRecorrente;
    private String segmento;
    private String ufVigencia;
    private String subAcesso;
    private String subTipo;
    private String tipo;
    private String velocidadeDownload;
    private String velocidadeUpload;
    private String vendaClientesBase;
    private String vendaNovasClientes;
    private String vlrHabilitacao;
    private String vlrRecorrente;
    private String score;
    private String rowid;
    private String loteid;
    private String arquivo;
    private String arquivots;
    private String currentDate;

    public BAT513() {

        this.abaEconfiguratior = null;
        this.acessoRaiz = null;
        this.categoria = null;
        this.datInicioVigencia = null;
        this.datFimVigencia = null;
        this.familia = null;
        this.idAmdocs = null;
        this.idBscs = null;
        this.idSiebel = null;
        this.nomProduto = null;
        this.taxaHabilitacao = null;
        this.taxaRecorrente = null;
        this.segmento = null;
        this.ufVigencia = null;
        this.subAcesso = null;
        this.subTipo = null;
        this.tipo = null;
        this.velocidadeDownload = null;
        this.velocidadeUpload = null;
        this.vendaClientesBase = null;
        this.vendaNovasClientes = null;
        this.vlrHabilitacao = null;
        this.vlrRecorrente = null;
        this.score = null;
        this.rowid = null;
        this.loteid = null;
        this.arquivo = null;
        this.arquivots = null;
        this.currentDate = null;

    }

    public void setBAT513(String abaEconfiguratior, String acessoRaiz, String categoria, String datInicioVigencia, String datFimVigencia, String familia, String idAmdocs,
                          String idBscs, String idSiebel, String nomProduto, String taxaHabilitacao, String taxaRecorrente, String segmento, String ufVigencia,
                          String subAcesso, String subTipo, String tipo, String velocidadeDownload, String velocidadeUpload, String vendaClientesBase, String vendaNovasClientes,
                          String vlrHabilitacao, String vlrRecorrente, String score, String rowid, String loteid, String arquivo, String arquivots, String currentDate) {
        this.abaEconfiguratior = abaEconfiguratior;
        this.acessoRaiz = acessoRaiz;
        this.categoria = categoria;
        this.datInicioVigencia = datInicioVigencia;
        this.datFimVigencia = datFimVigencia;
        this.familia = familia;
        this.idAmdocs = idAmdocs;
        this.idBscs = idBscs;
        this.idSiebel = idSiebel;
        this.nomProduto = nomProduto;
        this.taxaHabilitacao = taxaHabilitacao;
        this.taxaRecorrente = taxaRecorrente;
        this.segmento = segmento;
        this.ufVigencia = ufVigencia;
        this.subAcesso = subAcesso;
        this.subTipo = subTipo;
        this.tipo = tipo;
        this.velocidadeDownload = velocidadeDownload;
        this.velocidadeUpload = velocidadeUpload;
        this.vendaClientesBase = vendaClientesBase;
        this.vendaNovasClientes = vendaNovasClientes;
        this.vlrHabilitacao = vlrHabilitacao;
        this.vlrRecorrente = vlrRecorrente;
        this.score = score;
        this.rowid = rowid;
        this.loteid = loteid;
        this.arquivo = arquivo;
        this.arquivots = arquivots;
        this.currentDate = currentDate;
    }

    public boolean parse(String textString) {
        if (StringUtils.isNotBlank(textString)) {
            String[] cols = textString.split("\\|", -1);
            int i = 0;
            this.setBAT513(cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                           cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                           cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++]);
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        String delimiter = "|";

        sb.append(abaEconfiguratior).append(delimiter)
          .append(acessoRaiz).append(delimiter)
          .append(categoria).append(delimiter)
          .append(datInicioVigencia).append(delimiter)
          .append(datFimVigencia).append(delimiter)
          .append(familia).append(delimiter)
          .append(idAmdocs).append(delimiter)
          .append(idBscs).append(delimiter)
          .append(idSiebel).append(delimiter)
          .append(nomProduto).append(delimiter)
          .append(taxaHabilitacao).append(delimiter)
          .append(taxaRecorrente).append(delimiter)
          .append(segmento).append(delimiter)
          .append(ufVigencia).append(delimiter)
          .append(subAcesso).append(delimiter)
          .append(subTipo).append(delimiter)
          .append(tipo).append(delimiter)
          .append(velocidadeDownload).append(delimiter)
          .append(velocidadeUpload).append(delimiter)
          .append(vendaClientesBase).append(delimiter)
          .append(vendaNovasClientes).append(delimiter)
          .append(vlrHabilitacao).append(delimiter)
          .append(vlrRecorrente).append(delimiter)
          .append(score).append(delimiter)
          .append(rowid).append(delimiter)
          .append(loteid).append(delimiter)
          .append(arquivo).append(delimiter)
          .append(arquivots).append(delimiter)
          .append(currentDate);

        return sb.toString();

    }

    public String getAbaEconfiguratior() {
        return abaEconfiguratior;
    }

    public void setAbaEconfiguratior(String abaEconfiguratior) {
        this.abaEconfiguratior = abaEconfiguratior;
    }

    public String getAcessoRaiz() {
        return acessoRaiz;
    }

    public void setAcessoRaiz(String acessoRaiz) {
        this.acessoRaiz = acessoRaiz;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getDatInicioVigencia() {
        return datInicioVigencia;
    }

    public void setDatInicioVigencia(String datInicioVigencia) {
        this.datInicioVigencia = datInicioVigencia;
    }

    public String getDatFimVigencia() {
        return datFimVigencia;
    }

    public void setDatFimVigencia(String datFimVigencia) {
        this.datFimVigencia = datFimVigencia;
    }

    public String getFamilia() {
        return familia;
    }

    public void setFamilia(String familia) {
        this.familia = familia;
    }

    public String getIdAmdocs() {
        return idAmdocs;
    }

    public void setIdAmdocs(String idAmdocs) {
        this.idAmdocs = idAmdocs;
    }

    public String getIdBscs() {
        return idBscs;
    }

    public void setIdBscs(String idBscs) {
        this.idBscs = idBscs;
    }

    public String getIdSiebel() {
        return idSiebel;
    }

    public void setIdSiebel(String idSiebel) {
        this.idSiebel = idSiebel;
    }

    public String getNomProduto() {
        return nomProduto;
    }

    public void setNomProduto(String nomProduto) {
        this.nomProduto = nomProduto;
    }

    public String getTaxaHabilitacao() {
        return taxaHabilitacao;
    }

    public void setTaxaHabilitacao(String taxaHabilitacao) {
        this.taxaHabilitacao = taxaHabilitacao;
    }

    public String getTaxaRecorrente() {
        return taxaRecorrente;
    }

    public void setTaxaRecorrente(String taxaRecorrente) {
        this.taxaRecorrente = taxaRecorrente;
    }

    public String getSegmento() {
        return segmento;
    }

    public void setSegmento(String segmento) {
        this.segmento = segmento;
    }

    public String getUfVigencia() {
        return ufVigencia;
    }

    public void setUfVigencia(String ufVigencia) {
        this.ufVigencia = ufVigencia;
    }

    public String getSubAcesso() {
        return subAcesso;
    }

    public void setSubAcesso(String subAcesso) {
        this.subAcesso = subAcesso;
    }

    public String getSubTipo() {
        return subTipo;
    }

    public void setSubTipo(String subTipo) {
        this.subTipo = subTipo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getVelocidadeDownload() {
        return velocidadeDownload;
    }

    public void setVelocidadeDownload(String velocidadeDownload) {
        this.velocidadeDownload = velocidadeDownload;
    }

    public String getVelocidadeUpload() {
        return velocidadeUpload;
    }

    public void setVelocidadeUpload(String velocidadeUpload) {
        this.velocidadeUpload = velocidadeUpload;
    }

    public String getVendaClientesBase() {
        return vendaClientesBase;
    }

    public void setVendaClientesBase(String vendaClientesBase) {
        this.vendaClientesBase = vendaClientesBase;
    }

    public String getVendaNovasClientes() {
        return vendaNovasClientes;
    }

    public void setVendaNovasClientes(String vendaNovasClientes) {
        this.vendaNovasClientes = vendaNovasClientes;
    }

    public String getVlrHabilitacao() {
        return vlrHabilitacao;
    }

    public void setVlrHabilitacao(String vlrHabilitacao) {
        this.vlrHabilitacao = vlrHabilitacao;
    }

    public String getVlrRecorrente() {
        return vlrRecorrente;
    }

    public void setVlrRecorrente(String vlrRecorrente) {
        this.vlrRecorrente = vlrRecorrente;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    public String getRowid() {
        return rowid;
    }

    public void setRowid(String rowid) {
        this.rowid = rowid;
    }

    public String getLoteid() {
        return loteid;
    }

    public void setLoteid(String loteid) {
        this.loteid = loteid;
    }

    public String getArquivo() {
        return arquivo;
    }

    public void setArquivo(String arquivo) {
        this.arquivo = arquivo;
    }

    public String getArquivots() {
        return arquivots;
    }

    public void setArquivots(String arquivots) {
        this.arquivots = arquivots;
    }

    public String getCurrentDate() {
        return currentDate;
    }

    public void setCurrentDate(String currentDate) {
        this.currentDate = currentDate;
    }
}
