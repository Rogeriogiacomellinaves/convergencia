
package br.com.tim.mapreduce.e2e.step4;

import br.com.tim.mapreduce.model.BAT230;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

import java.io.IOException;

public class MapperBAT230 extends org.apache.hadoop.mapreduce.Mapper<Writable,Text,E2EStep4Key,E2EStep4Value> {

	private E2EStep4Key outkey;
	private E2EStep4Value outValue;
	private BAT230 input;
	@Override
	protected void map(Writable key, Text value, Context context) throws IOException, InterruptedException {
		input.parse(value.toString());
		outkey.setCodContaFinanceira(input.getIdPublico());
		outkey.setTipo(TypeStep4.BAT230);
		outValue.setBAT230(input);
		context.write(outkey, outValue);
	}

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		super.setup(context);
		this.outkey = new E2EStep4Key();
		this.outValue = new E2EStep4Value();
		this.input = new BAT230();
	}

	@Override
	protected void cleanup(Context context) throws IOException, InterruptedException {
		super.cleanup(context);
		this.clear();
	}

	private void clear(){
	   this.outValue.clear();
	}

}