package br.com.tim.mapreduce.model;

import org.apache.commons.lang3.StringUtils;

public class FalloutOM {

    private String orderNum;
    private String created;
    private String orderCatCd;
    private String lastUpd;
    private String statusCd;
    private String ordemOm;
    private String dataOm;
    private String dataLastUpdt;
    private String status;
    private String tipo;
    private String orderType;
    private String fase;
    private String cancelamento;
    private String possivelCancel;
    private String destination;
    private String srProvState;
    private String dataMt;
    private String poolName;
    private String smtTaskName;
    private String mtCodErro;
    private String mtMsgErr;
    private String btCodErro;
    private String btMsgErro;
    private String sesEventType;
    private String serviceIdBb;
    private String winPort;
    private String wdnNpVersionId;
    private String wdnNpTimProtocol;
    private String codProtPortTim;
    private String statusPort;
    private String numTerm;
    private String datReqPortin;
    private String datPrevAtiv;
    private String rowid;
    private String loteid;
    private String arquivo;
    private String arquivots;
    private String currentdate;

    public FalloutOM() {

        this.orderNum = null;
        this.created = null;
        this.orderCatCd = null;
        this.lastUpd = null;
        this.statusCd = null;
        this.ordemOm = null;
        this.dataOm = null;
        this.dataLastUpdt = null;
        this.status = null;
        this.tipo = null;
        this.orderType = null;
        this.fase = null;
        this.cancelamento = null;
        this.possivelCancel = null;
        this.destination = null;
        this.srProvState = null;
        this.dataMt = null;
        this.poolName = null;
        this.smtTaskName = null;
        this.mtCodErro = null;
        this.mtMsgErr = null;
        this.btCodErro = null;
        this.btMsgErro = null;
        this.sesEventType = null;
        this.serviceIdBb = null;
        this.winPort = null;
        this.wdnNpVersionId = null;
        this.wdnNpTimProtocol = null;
        this.codProtPortTim = null;
        this.statusPort = null;
        this.numTerm = null;
        this.datReqPortin = null;
        this.datPrevAtiv = null;
        this.rowid = null;
        this.loteid = null;
        this.arquivo = null;
        this.arquivots = null;
        this.currentdate = null;
    }

    public void setFalloutOM(String orderNum, String created, String orderCatCd, String lastUpd, String statusCd, String ordemOm, String dataOm, String dataLastUpdt, String status,
                          String tipo, String orderType, String fase, String cancelamento, String possivelCancel, String destination, String srProvState, String dataMt,
                          String poolName, String smtTaskName, String mtCodErro, String mtMsgErr, String btCodErro, String btMsgErro, String sesEventType, String serviceIdBb,
                          String winPort, String wdnNpVersionId, String wdnNpTimProtocol, String codProtPortTim, String statusPort, String numTerm, String datReqPortin,
                          String datPrevAtiv, String rowid, String loteid, String arquivo, String arquivots, String currentdate) {
        this.orderNum = orderNum;
        this.created = created;
        this.orderCatCd = orderCatCd;
        this.lastUpd = lastUpd;
        this.statusCd = statusCd;
        this.ordemOm = ordemOm;
        this.dataOm = dataOm;
        this.dataLastUpdt = dataLastUpdt;
        this.status = status;
        this.tipo = tipo;
        this.orderType = orderType;
        this.fase = fase;
        this.cancelamento = cancelamento;
        this.possivelCancel = possivelCancel;
        this.destination = destination;
        this.srProvState = srProvState;
        this.dataMt = dataMt;
        this.poolName = poolName;
        this.smtTaskName = smtTaskName;
        this.mtCodErro = mtCodErro;
        this.mtMsgErr = mtMsgErr;
        this.btCodErro = btCodErro;
        this.btMsgErro = btMsgErro;
        this.sesEventType = sesEventType;
        this.serviceIdBb = serviceIdBb;
        this.winPort = winPort;
        this.wdnNpVersionId = wdnNpVersionId;
        this.wdnNpTimProtocol = wdnNpTimProtocol;
        this.codProtPortTim = codProtPortTim;
        this.statusPort = statusPort;
        this.numTerm = numTerm;
        this.datReqPortin = datReqPortin;
        this.datPrevAtiv = datPrevAtiv;
        this.rowid = rowid;
        this.loteid = loteid;
        this.arquivo = arquivo;
        this.arquivots = arquivots;
        this.currentdate = currentdate;
    }

    public boolean parse(String textString) {
        if (StringUtils.isNotBlank(textString)) {
            String[] cols = textString.split("\\|", -1);
            int i = 0;
            this.setFalloutOM(cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                              cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                              cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                              cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++]);
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        String delimiter = "|";

        sb.append(orderNum).append(delimiter)
          .append(created).append(delimiter)
          .append(orderCatCd).append(delimiter)
          .append(lastUpd).append(delimiter)
          .append(statusCd).append(delimiter)
          .append(ordemOm).append(delimiter)
          .append(dataOm).append(delimiter)
          .append(dataLastUpdt).append(delimiter)
          .append(status).append(delimiter)
          .append(tipo).append(delimiter)
          .append(orderType).append(delimiter)
          .append(fase).append(delimiter)
          .append(cancelamento).append(delimiter)
          .append(possivelCancel).append(delimiter)
          .append(destination).append(delimiter)
          .append(srProvState).append(delimiter)
          .append(dataMt).append(delimiter)
          .append(poolName).append(delimiter)
          .append(smtTaskName).append(delimiter)
          .append(mtCodErro).append(delimiter)
          .append(mtMsgErr).append(delimiter)
          .append(btCodErro).append(delimiter)
          .append(btMsgErro).append(delimiter)
          .append(sesEventType).append(delimiter)
          .append(serviceIdBb).append(delimiter)
          .append(winPort).append(delimiter)
          .append(wdnNpVersionId).append(delimiter)
          .append(wdnNpTimProtocol).append(delimiter)
          .append(codProtPortTim).append(delimiter)
          .append(statusPort).append(delimiter)
          .append(numTerm).append(delimiter)
          .append(datReqPortin).append(delimiter)
          .append(datPrevAtiv).append(delimiter)
          .append(rowid).append(delimiter)
          .append(loteid).append(delimiter)
          .append(arquivo).append(delimiter)
          .append(arquivots).append(delimiter)
          .append(currentdate);

        return sb.toString();

    }

    public String getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(String orderNum) {
        this.orderNum = orderNum;
    }

    public String getCreated() {
        return created;
    }

    public void setCreated(String created) {
        this.created = created;
    }

    public String getOrderCatCd() {
        return orderCatCd;
    }

    public void setOrderCatCd(String orderCatCd) {
        this.orderCatCd = orderCatCd;
    }

    public String getLastUpd() {
        return lastUpd;
    }

    public void setLastUpd(String lastUpd) {
        this.lastUpd = lastUpd;
    }

    public String getStatusCd() {
        return statusCd;
    }

    public void setStatusCd(String statusCd) {
        this.statusCd = statusCd;
    }

    public String getOrdemOm() {
        return ordemOm;
    }

    public void setOrdemOm(String ordemOm) {
        this.ordemOm = ordemOm;
    }

    public String getDataOm() {
        return dataOm;
    }

    public void setDataOm(String dataOm) {
        this.dataOm = dataOm;
    }

    public String getDataLastUpdt() {
        return dataLastUpdt;
    }

    public void setDataLastUpdt(String dataLastUpdt) {
        this.dataLastUpdt = dataLastUpdt;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getFase() {
        return fase;
    }

    public void setFase(String fase) {
        this.fase = fase;
    }

    public String getCancelamento() {
        return cancelamento;
    }

    public void setCancelamento(String cancelamento) {
        this.cancelamento = cancelamento;
    }

    public String getPossivelCancel() {
        return possivelCancel;
    }

    public void setPossivelCancel(String possivelCancel) {
        this.possivelCancel = possivelCancel;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getSrProvState() {
        return srProvState;
    }

    public void setSrProvState(String srProvState) {
        this.srProvState = srProvState;
    }

    public String getDataMt() {
        return dataMt;
    }

    public void setDataMt(String dataMt) {
        this.dataMt = dataMt;
    }

    public String getPoolName() {
        return poolName;
    }

    public void setPoolName(String poolName) {
        this.poolName = poolName;
    }

    public String getSmtTaskName() {
        return smtTaskName;
    }

    public void setSmtTaskName(String smtTaskName) {
        this.smtTaskName = smtTaskName;
    }

    public String getMtCodErro() {
        return mtCodErro;
    }

    public void setMtCodErro(String mtCodErro) {
        this.mtCodErro = mtCodErro;
    }

    public String getMtMsgErr() {
        return mtMsgErr;
    }

    public void setMtMsgErr(String mtMsgErr) {
        this.mtMsgErr = mtMsgErr;
    }

    public String getBtCodErro() {
        return btCodErro;
    }

    public void setBtCodErro(String btCodErro) {
        this.btCodErro = btCodErro;
    }

    public String getBtMsgErro() {
        return btMsgErro;
    }

    public void setBtMsgErro(String btMsgErro) {
        this.btMsgErro = btMsgErro;
    }

    public String getSesEventType() {
        return sesEventType;
    }

    public void setSesEventType(String sesEventType) {
        this.sesEventType = sesEventType;
    }

    public String getServiceIdBb() {
        return serviceIdBb;
    }

    public void setServiceIdBb(String serviceIdBb) {
        this.serviceIdBb = serviceIdBb;
    }

    public String getWinPort() {
        return winPort;
    }

    public void setWinPort(String winPort) {
        this.winPort = winPort;
    }

    public String getWdnNpVersionId() {
        return wdnNpVersionId;
    }

    public void setWdnNpVersionId(String wdnNpVersionId) {
        this.wdnNpVersionId = wdnNpVersionId;
    }

    public String getWdnNpTimProtocol() {
        return wdnNpTimProtocol;
    }

    public void setWdnNpTimProtocol(String wdnNpTimProtocol) {
        this.wdnNpTimProtocol = wdnNpTimProtocol;
    }

    public String getCodProtPortTim() {
        return codProtPortTim;
    }

    public void setCodProtPortTim(String codProtPortTim) {
        this.codProtPortTim = codProtPortTim;
    }

    public String getStatusPort() {
        return statusPort;
    }

    public void setStatusPort(String statusPort) {
        this.statusPort = statusPort;
    }

    public String getNumTerm() {
        return numTerm;
    }

    public void setNumTerm(String numTerm) {
        this.numTerm = numTerm;
    }

    public String getDatReqPortin() {
        return datReqPortin;
    }

    public void setDatReqPortin(String datReqPortin) {
        this.datReqPortin = datReqPortin;
    }

    public String getDatPrevAtiv() {
        return datPrevAtiv;
    }

    public void setDatPrevAtiv(String datPrevAtiv) {
        this.datPrevAtiv = datPrevAtiv;
    }

    public String getRowid() {
        return rowid;
    }

    public void setRowid(String rowid) {
        this.rowid = rowid;
    }

    public String getLoteid() {
        return loteid;
    }

    public void setLoteid(String loteid) {
        this.loteid = loteid;
    }

    public String getArquivo() {
        return arquivo;
    }

    public void setArquivo(String arquivo) {
        this.arquivo = arquivo;
    }

    public String getArquivots() {
        return arquivots;
    }

    public void setArquivots(String arquivots) {
        this.arquivots = arquivots;
    }

    public String getCurrentdate() {
        return currentdate;
    }

    public void setCurrentdate(String currentdate) {
        this.currentdate = currentdate;
    }
}
