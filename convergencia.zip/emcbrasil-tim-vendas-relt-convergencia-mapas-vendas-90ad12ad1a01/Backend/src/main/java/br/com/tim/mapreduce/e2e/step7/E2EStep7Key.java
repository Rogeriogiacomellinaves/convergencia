package br.com.tim.mapreduce.e2e.step7;

import br.com.tim.mapreduce.e2e.GroupComparable;
import com.google.common.collect.ComparisonChain;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Objects;

public class E2EStep7Key implements GroupComparable<E2EStep7Key> {

	private String loginVendedor;
	private TypeStep7 tipo;

	@Override
	public void write(DataOutput output) throws IOException {
		output.writeInt(tipo.ordinal());
		output.writeUTF(this.loginVendedor);
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		this.tipo = TypeStep7.values()[in.readInt()];
		this.loginVendedor = in.readUTF();
	}

	public void setTipo(TypeStep7 tipo) {
		this.tipo = tipo;
	}

	public String getLoginVendedor() {
		return loginVendedor;
	}

	public void setLoginVendedor(String loginVendedor) {
		this.loginVendedor = loginVendedor;
	}

	@Override
	public int compareTo(E2EStep7Key o) {
		return ComparisonChain.start().compare(this.loginVendedor, o.loginVendedor).compare(this.tipo, o.tipo)
				.result();
	}

	@Override
	public int compareToGrouping(E2EStep7Key o) {
		return ComparisonChain.start().compare(this.loginVendedor, o.loginVendedor).result();
	}

	public int hashCodeJoin() {

		return Objects.hash(loginVendedor);
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		E2EStep7Key key = (E2EStep7Key) o;
		return Objects.equals(loginVendedor, key.loginVendedor);
	}

	@Override
	public int hashCode() {

		return Objects.hash(loginVendedor);
	}
}