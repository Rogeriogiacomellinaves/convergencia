package br.com.tim.mapreduce.itemordem.step1;

import java.io.IOException;

import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import br.com.tim.mapreduce.model.Wfmtoa;
import br.com.tim.mr.utils.TaggedKey;

public class MapperWfmtoa extends Mapper<BytesWritable, Text, TaggedKey, IOStep1Value> {

	private TaggedKey outKey;
	private IOStep1Value outValue;
	private Wfmtoa input;

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {

		input = new Wfmtoa();
		outValue = new IOStep1Value();
		outKey = new TaggedKey();
	}

	@Override
	protected void map(BytesWritable key, Text value, Context context) throws IOException, InterruptedException {

		input.parseLineFromTable(value.toString());

		outValue.setWfmtoa(input);
		
		outKey.set(input.getApptNumber(), 1);

		context.write(outKey, outValue);
	}

	@Override
	protected void cleanup(Context context) throws IOException, InterruptedException {
		super.cleanup(context);
		this.clear();
	}
	
	private void clear() {
		this.outValue.clear();
	}
}
