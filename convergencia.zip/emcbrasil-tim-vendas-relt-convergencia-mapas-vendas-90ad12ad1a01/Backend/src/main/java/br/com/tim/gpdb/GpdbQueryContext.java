package br.com.tim.gpdb;

import java.sql.Connection;
import java.sql.DriverManager;

import org.apache.commons.dbutils.DbUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.log4j.Logger;
import org.joda.time.format.DateTimeFormat;

import br.com.tim.kerberos.KerberosAuth;

public class GpdbQueryContext extends GpdbIngestionContext {

	private static Logger _log = Logger.getLogger(GpdbIngestionContext.class);

    private Configuration config;
    private Path staging, archive, input, failed;
    private String insertStatement, managedTableSchema, managedTable, externalTable,
            managedTableName, url, driver,dataBase, user, password, partitionQuery, description,
            partitionCreatorClassName, inserterClassName, queryClassName, partitionTruncatorClassName, stagingHandlerClassName;
    private boolean activePgpass;
    private String pathPgpass;
    private FileSystem fs;
    private int maxInputToProcess, maxArchive, maxFailed, returnCodeError, returnCodeLoad, returnCodeNoLoad;
    private PartitionType partitionType;
    private Connection connection;
    private String[] args;
    private PgpassUtils pgpassUtils;
    private boolean flagOnlyQuery;
    private boolean flagAlwaysExecuteGpdbNamedQueriesAfter;
    private TypeIngestion typeIngestion;

    public GpdbQueryContext(){
        pgpassUtils = new PgpassUtils();
    }

    public GpdbIngestionContext init(String[] args, Configuration config)
                                                throws GPDBIngestionInitializationException {
        this.args = args;
        this.config = config;
        String execTs = DateTimeFormat.forPattern("yyyy-MM-dd-hh-mm-ss").print(new java.util.Date().getTime());
        this.config.set("username", System.getProperty("user.name"));
        this.config.set("timestamp", execTs);
        this.flagOnlyQuery = this.config.getBoolean("flag-only-query",false);
        this.flagAlwaysExecuteGpdbNamedQueriesAfter = this.config.getBoolean("flag-always-execute-gpdb-name-querys-after",false);

        this.driver = this.str("gpdb-driver");
        this.dataBase = this.str("gpdb-database");
        this.user = this.str("gpdb-user");
        this.password = this.str("gpdb-password");
        this.url = this.str("gpdb_connection_string");
        this.description = this.str("process-id");
        this.activePgpass = this.config.getBoolean("active-pgpass", true);
        this.pathPgpass = this.str("path-pgpass");
        this.returnCodeError = this.integer("return-code-error");
        this.returnCodeLoad = this.integer("return-code-load");
        this.returnCodeNoLoad = this.integer("return-code-no-load");

        //Configuração da data de exucução do rec icms para truncarmos apenas as partitions necessarias.
       /* if (this.args[0] != null) {
        	this.config.set("execution-date", this.args[0]);
        	_log.info("Setado execution-date: "+ this.args[0]);
        }*/
        
        if (!flagOnlyQuery){
            this.staging = this.path("staging-path");
            this.input = this.path("input-path");
            this.archive = this.path("archive-path");
            this.failed = this.path("failed-path");
            this.insertStatement = this.str("insert-statement");
            this.insertStatement = this.str("insert");
            this.maxInputToProcess = this.integer("max-input-to-process");
            this.maxArchive = this.integer("max-archive");
            this.maxFailed = this.integer("max-failed");
            this.partitionQuery = this.str("partition-query");
            this.partitionType = PartitionType.valueOf(this.config.get("partition-type"));
            this.managedTable = this.str("managed-table");
            this.externalTable = this.str("external-table");
            int schemaSeparator = this.managedTable.indexOf('.');
            this.managedTableSchema = this.managedTable.substring(0, schemaSeparator);
            this.managedTableName = this.managedTable.substring(schemaSeparator + 1);
        }

        try {

        	KerberosAuth.authenticate(this.config);
        
		} catch (Exception e) {
			throw new GPDBIngestionInitializationException(e);
		}  

        try {

            configurationPgpass();

            this.fs= FileSystem.get(this.config);
            Class.forName("org.postgresql.Driver");
            _log.info("Conectando no banco de dados...");
            this.connection = DriverManager.getConnection(this.url, this.user, this.password);
        } catch (Exception e) {
            throw new GPDBIngestionInitializationException(e);
        }

        this.partitionCreatorClassName = this.str("partition-creator-class");
        this.inserterClassName = this.str("inserter-class");
        this.partitionTruncatorClassName = this.str("partition-truncator-class");
        this.stagingHandlerClassName = this.str("staging-handler-class");
        this.queryClassName = this.str("querys-gpdb-class");
        this.typeIngestion = TypeIngestion.valueOf(this.str("type-ingestion","FULL").toUpperCase());
        return this;
    }

    /**
     * Método utilizado para montar informações dos usuário por pgpass
     */
    private void configurationPgpass() throws PgpassInitializationException {

        // Se flag de pgpass estiver ativa
        if (activePgpass){
            if (StringUtils.isEmpty(this.user)){
                throw new PgpassInitializationException("Usuário não encontrado no arquivo de configuração da aplicação.");
            }

            if (StringUtils.isEmpty(this.dataBase)){
                throw new PgpassInitializationException("Database não encontrado no arquivo de configuração da aplicação.");
            }

            //Inicializa as configurações necessários para utilização do pgpass
            pgpassUtils.init(pathPgpass);

            Pgpass pgpass = pgpassUtils.getPgpass(this.user,this.dataBase);
            if (null == pgpass)
                throw new PgpassInitializationException("Não foi possível encontrar o usuário " + this.user);

            this.password = pgpass.getPassword();
        }
    }

    private int integer(String key) {
        return this.config.getInt(key, 1);
    }

    @SuppressWarnings("unused")
	private boolean bln(String key) {
        return this.config.getBoolean(key, false);
    }

    private Path path(String key){
        return new Path(this.config.get(key));
    }

    private String str(String key){
        return this.config.get(key);
    }

    private String str(String key,String _default){
        return this.config.get(key,_default);
    }

    public void close(){
        DbUtils.closeQuietly(this.connection);
    }

    public Path getStaging() {
        return staging;
    }

    public Path getArchive() {
        return archive;
    }

    public Path getInput() {
        return input;
    }

    public Path getFailed() {
        return failed;
    }

    public String getInsertStatement() {
        return insertStatement;
    }

    public String getManagedTableSchema() {
        return managedTableSchema;
    }

    public String getManagedTable() {
        return managedTable;
    }

    public String getManagedTableName() {
        return managedTableName;
    }

    public String getUrl() {
        return url;
    }

    public String getDriver() {
        return driver;
    }

    public String getUser() {
        return user;
    }

    public String getPassword() {
        return password;
    }

    public String getPartitionQuery() {
        return partitionQuery;
    }

    public FileSystem getFs() {
        return fs;
    }

    public int getMaxInputToProcess() {
        return maxInputToProcess;
    }

    public int getMaxArchive() {
        return maxArchive;
    }

    public int getMaxFailed() {
        return maxFailed;
    }

    public int getReturnCodeError() {
        return returnCodeError;
    }

    public int getReturnCodeLoad() {
        return returnCodeLoad;
    }

    public int getReturnCodeNoLoad() {
        return returnCodeNoLoad;
    }

    public PartitionType getPartitionType() {
        return partitionType;
    }

    public Connection getConnection() {
        return connection;
    }

    public String getDescription() {
        return description;
    }

    public String getPartitionCreatorClassName() {
        return partitionCreatorClassName;
    }

    public String getInserterClassName() {
        return inserterClassName;
    }

    public String getPartitionTruncatorClassName() {
        return partitionTruncatorClassName;
    }

    public String getStagingHandlerClassName() {
        return stagingHandlerClassName;
    }

    public String getQueryClassName() {
        return queryClassName;
    }

    public void setQueryClassName(String queryClassName) {
        this.queryClassName = queryClassName;
    }

    public Configuration getConfig() {
        return config;
    }

    public String[] getArgs() {
        return args;
    }

	public String getExternalTable() {
		return externalTable;
	}

    public boolean isFlagOnlyQuery() {
        return flagOnlyQuery;
    }

    public boolean isFlagAlwaysExecuteGpdbNamedQueriesAfter() {
        return flagAlwaysExecuteGpdbNamedQueriesAfter;
    }

    public TypeIngestion getTypeIngestion() {
        return typeIngestion;
    }
	
}
