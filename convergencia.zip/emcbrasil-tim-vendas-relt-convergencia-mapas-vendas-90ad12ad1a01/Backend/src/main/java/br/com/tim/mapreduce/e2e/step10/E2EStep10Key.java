package br.com.tim.mapreduce.e2e.step10;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Objects;

import com.google.common.collect.ComparisonChain;

import br.com.tim.mapreduce.e2e.GroupComparable;

public class E2EStep10Key implements GroupComparable<E2EStep10Key> {

	private String numOrdemSiebel;
	private TypeStep10 tipo;
	private String dat_ref;

	@Override
	public void write(DataOutput output) throws IOException {
		output.writeInt(tipo.ordinal());
		output.writeUTF(this.numOrdemSiebel);
		output.writeUTF(this.dat_ref);
	}
	
	@Override
	public void readFields(DataInput in) throws IOException {
		this.tipo = TypeStep10.values()[in.readInt()];
		this.numOrdemSiebel = in.readUTF();
		this.dat_ref = in.readUTF();
	}
	
	@Override
	public int compareTo(E2EStep10Key o) {
		return ComparisonChain.start().compare(this.numOrdemSiebel, o.numOrdemSiebel).compare(this.tipo, o.tipo)
				.compare(this.dat_ref, o.dat_ref).result();
	}
	
	@Override
	public int compareToGrouping(E2EStep10Key o) {
		return ComparisonChain.start().compare(this.numOrdemSiebel, o.numOrdemSiebel).result();
	}
	
	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		E2EStep10Key key = (E2EStep10Key) o;
		return Objects.equals(numOrdemSiebel, key.numOrdemSiebel);
	}
	
	public int hashCodeJoin() {

		return Objects.hash(numOrdemSiebel);
	}
	
	@Override
	public int hashCode() {

		return Objects.hash(numOrdemSiebel);
	}
	
	public String getNumOrdemSiebel() {
		return numOrdemSiebel;
	}

	public void setNumOrdemSiebel(String numOrdemSiebel) {
		this.numOrdemSiebel = numOrdemSiebel;
	}

	public TypeStep10 getTipo() {
		return tipo;
	}

	public void setTipo(TypeStep10 tipo) {
		this.tipo = tipo;
	}
	
	public String getDat_ref() {
		return dat_ref;
	}

	public void setDat_ref(String dat_ref) {
		this.dat_ref = dat_ref;
	}
}
