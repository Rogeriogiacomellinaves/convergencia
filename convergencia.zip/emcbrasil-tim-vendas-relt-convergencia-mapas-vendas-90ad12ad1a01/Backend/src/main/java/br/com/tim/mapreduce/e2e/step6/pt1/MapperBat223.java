
package br.com.tim.mapreduce.e2e.step6.pt1;

import br.com.tim.mapreduce.e2e.step6.E2EStep6Key;
import br.com.tim.mapreduce.e2e.step6.TypeStep6;
import br.com.tim.mapreduce.e2e.step6.pt1.E2EStep6Value;
import br.com.tim.mapreduce.model.BAT223;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

import java.io.IOException;

public class MapperBat223 extends org.apache.hadoop.mapreduce.Mapper<Writable,Text,E2EStep6Key,E2EStep6Value> {

	private E2EStep6Key outkey;
	private E2EStep6Value outValue;
	private BAT223 input;
	@Override
	protected void map(Writable key, Text value, Context context) throws IOException, InterruptedException {
		input.parse(value.toString());
		outkey.setAcessoRowId(input.getRowIdAcesso());
		outkey.setDatRef(input.getArquivo().substring(17,25));
		outkey.setTipo(TypeStep6.BAT223);
		outValue.setBat223(input);
		context.write(outkey, outValue);
	}

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		super.setup(context);
		this.outkey = new E2EStep6Key();
		this.outValue = new E2EStep6Value();
		this.input = new BAT223();
	}

	@Override
	protected void cleanup(Context context) throws IOException, InterruptedException {
		super.cleanup(context);
		this.clear();
	}

	private void clear(){
	   this.outValue.clear();
	}

}