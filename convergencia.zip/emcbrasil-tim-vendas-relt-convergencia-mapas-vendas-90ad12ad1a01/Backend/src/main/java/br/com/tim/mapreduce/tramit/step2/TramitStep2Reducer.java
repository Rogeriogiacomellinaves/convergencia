package br.com.tim.mapreduce.tramit.step2;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.log4j.Logger;

import java.io.IOException;

public class TramitStep2Reducer extends org.apache.hadoop.mapreduce.Reducer<TramitStep2Key,TramitStep2Value,NullWritable,Text> {

    protected static final Logger LOG = Logger.getLogger(TramitStep2Reducer.class);
    private TramitStep2OutValue outValue;

    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        super.setup(context);
        outValue = new TramitStep2OutValue();
    }

    @Override
    protected void reduce(TramitStep2Key key, Iterable<TramitStep2Value> values, Context context) throws InterruptedException {

        outValue.clear();
        outValue.setDatRef(context.getConfiguration().get("dat-ref"));

        try {
            for (TramitStep2Value value : values) {
                if (value.getTipo().equals(TypeStep2.STEP1RESULT)){
                    outValue.clearResultStep1();
                    outValue.setResultStep1(value);
                    context.write(NullWritable.get(), new Text(outValue.toString()));
                }else if (value.getTipo().equals(TypeStep2.FALLOUT)){
                    outValue.setFallout(value);
                }
            }

        } catch (Exception e) {
            LOG.error(" ############ ERROR EXECUTION REDUCER ############ ");
            LOG.error(e.getMessage());
            throw new InterruptedException(e.getMessage());
        }
    }



    @Override
    protected void cleanup(Context context) throws IOException, InterruptedException {
        super.cleanup(context);

    }
}


