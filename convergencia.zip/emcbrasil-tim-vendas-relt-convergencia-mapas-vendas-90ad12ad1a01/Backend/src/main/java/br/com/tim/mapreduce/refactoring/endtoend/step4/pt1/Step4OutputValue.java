package br.com.tim.mapreduce.refactoring.endtoend.step4.pt1;

import org.apache.parquet.Strings;

import br.com.tim.mapreduce.refactoring.endtoend.step4.model.MapaHist;
import br.com.tim.utils.CommonsConstants;

public class Step4OutputValue {

	private String datref;
	private String datCriacaoOrdem;
	private String horaCriacaoDaOrdem;
	private String datVenda;
	private String horaDaVenda;
	private String datStatusOrdem;
	private String hrStatusOrdem;
	private String numOrdemSiebel;
	private String numOrdemSiebelOrig;
	private String codContratoOltp;
	private String codContratoAtivacao;
	private String numeroAcesso;
	private String customerId;
	private String tipoDocumento;
	private String documento;
	private String tipoVenda;
	private String tipoProduto;
	private String velocidadeDownload;
	private String velocidadeUpload;
	private String planoAtivacaoOferta;
	private String loginVendedor;
	private String canal;
	private String cnpjParceiro;
	private String custcode;
	private String position;
	private String flgCancAntesVenda;
	private String flgCancPosVenda;
	private String dtCancVenda;
	private String motivoCancelamento;
	private String nomeCliente;
	private String telefone;
	private String emailFatura;
	private String uf;
	private String tipoLogradouro;
	private String logradouro;
	private String numero;
	private String complemento;
	private String bairro;
	private String cep;
	private String cidade;
	private String statusOrdem;
	private String tecnologia;
	private String formaPagamento;
	private String tipoConta;
	private String codBanco;
	private String codAgengiaBco;
	private String codContaCorrente;
	private String codDebitoAutomatico;
	private String diaVencimento;
	private String semanaVenda;
	private String score;
	private String scoreConsumido;
	private String dtFinalizacaoOrdem;
	private String qdeContratos;
	private String numProtocolo;
	private String flgOrdemAutomatica;
	private double dscTxRecorrente;
	private double dscTxNaoRecorrente;
	private String dscStatusItem;
	private String nomLoginResponsavel;
	private String flgPortabilidade;
	private String dscOperadoraDoadora;
	private String codDdd;
	private String numTelefonePortado;
	private String datJanelaPortabilidade;
	private String horaDaJanela;
	private String dscEnderecoFatura;
	private String dscAreaVoip;
	private String cpe;
	private String ont;
	private String codigoConvergente;
	private String detalheRecusaCrivo;
	private String itemRoot;
	private String loginCancelamentoOrdem;
	private String custcodeCliente;
	private String dominioRoot;
	private String codContFinanceira;
	private String valPlanoAtualItem;
	private String nomDescontoAtualItem;
	private String valDescontoAtualItem;
	private String nroOrdem;
	private String acessoRowId;
	private String acessoRowIdRoot;
	private String codigoProduto;
	private String flgVendaSubmetida;
	private String flgVendaDuplicada;
	private String flgVendaBruta;
	private String flgVendaLiquida;
	private String flgCancDupl;
	private String flgCancLiquido;
	private String nomeParceiroVenda;
	private String nomeParceiroVendaOrig;
	private String rowIdItemOrdem;
	private String rowIdItemOrdemPai;
	private String categoriaItemOrder;
	private String msanOltVenda;
	private String dtConclusaoWfm;
	private String dscStatusOrdemWfm;
	private String datStatusWfm;
	private String horaStatusWfm;
	private String idRecursoWfm;
	private String nomRecursoWfm;
	private String idRecursoPaiWfm;
	private String datPrimeiroAgend;
	private String horaPrimeiroAgendamento;
	private String datAgendAtual;
	private String horaAgendamentoAtual;
	private String dscStatusAtivacao;
	private String msanOltTrafego;
	private String datVendaOrig;
	private String horaVendaOrig;
	private String loginVendedorOrig;
	private String canalOrig;
	private String cnpjParceiroOrig;
	private String custcodeOrig;
	private String positionOrig;
	private String semanaVendaOrig;
	private String codContratoAtual;
	private String nomPlanoAtual;
	private String nomeVendedorOrig;
	private String flVendaDuplicada;
	private String flGross;
	private String dtGross;
	private String flChurn;
	private String dtChurn;
	private String motivoChurn;
	private String codOrdemChurn;
	private String tipoChurn;
	private String dtCriacaoOrdemChurn;
	private String dtConclusaoOrdemChurn;
	private String nomeVendedor;
	private String nomeUsuarioCancOrdem;
	private String emailCliente;
	
	
	
	
	public void update(MapaHist mapaHist) {
		
		this.datref = !isNullOrEmpty(mapaHist.getDatref()) ? mapaHist.getDatref() : this.datref;
		this.datCriacaoOrdem = !isNullOrEmpty(mapaHist.getDatCriacaoOrdem()) ? mapaHist.getDatCriacaoOrdem() : this.datCriacaoOrdem;
		this.horaCriacaoDaOrdem = !isNullOrEmpty(mapaHist.getHoraCriacaoDaOrdem()) ? mapaHist.getHoraCriacaoDaOrdem() : this.horaCriacaoDaOrdem;
		this.datVenda = !isNullOrEmpty(mapaHist.getDatVenda()) ? mapaHist.getDatVenda() : this.datVenda;
		this.horaDaVenda = !isNullOrEmpty(mapaHist.getHoraDaVenda()) ? mapaHist.getHoraDaVenda() : this.horaDaVenda;
		this.datStatusOrdem = !isNullOrEmpty(mapaHist.getDatStatusOrdem()) ? mapaHist.getDatStatusOrdem() : this.datStatusOrdem;
		this.hrStatusOrdem = !isNullOrEmpty(mapaHist.getHrStatusOrdem()) ? mapaHist.getHrStatusOrdem() : this.hrStatusOrdem;
		this.numOrdemSiebel = !isNullOrEmpty(mapaHist.getNumOrdemSiebel()) ? mapaHist.getNumOrdemSiebel() : this.numOrdemSiebel;
		this.numOrdemSiebelOrig = !isNullOrEmpty(mapaHist.getNumOrdemSiebelOrig()) ? mapaHist.getNumOrdemSiebelOrig() : this.numOrdemSiebelOrig;
		this.codContratoOltp = !isNullOrEmpty(mapaHist.getCodContratoOltp()) ? mapaHist.getCodContratoOltp() : this.codContratoOltp;
		this.codContratoAtivacao = !isNullOrEmpty(mapaHist.getCodContratoAtivacao()) ? mapaHist.getCodContratoAtivacao() : this.codContratoAtivacao;
		this.numeroAcesso = !isNullOrEmpty(mapaHist.getNumeroAcesso()) ? mapaHist.getNumeroAcesso() : this.numeroAcesso;
		this.customerId = !isNullOrEmpty(mapaHist.getCustomerId()) ? mapaHist.getCustomerId() : this.customerId;
		this.tipoDocumento = !isNullOrEmpty(mapaHist.getTipoDocumento()) ? mapaHist.getTipoDocumento() : this.tipoDocumento;
		this.documento = !isNullOrEmpty(mapaHist.getDocumento()) ? mapaHist.getDocumento() : this.documento;
		this.tipoVenda = !isNullOrEmpty(mapaHist.getTipoVenda()) ? mapaHist.getTipoVenda() : this.tipoVenda;
		this.tipoProduto = !isNullOrEmpty(mapaHist.getTipoProduto()) ? mapaHist.getTipoProduto() : this.tipoProduto;
		this.velocidadeDownload = !isNullOrEmpty(mapaHist.getVelocidadeDownload()) ? mapaHist.getVelocidadeDownload() : this.velocidadeDownload;
		this.velocidadeUpload = !isNullOrEmpty(mapaHist.getVelocidadeUpload()) ? mapaHist.getVelocidadeUpload() : this.velocidadeUpload;
		this.planoAtivacaoOferta = !isNullOrEmpty(mapaHist.getPlanoAtivacaoOferta()) ? mapaHist.getPlanoAtivacaoOferta() : this.planoAtivacaoOferta;
		this.loginVendedor = !isNullOrEmpty(mapaHist.getLoginVendedor()) ? mapaHist.getLoginVendedor() : this.loginVendedor;
		this.canal = !isNullOrEmpty(mapaHist.getCanal()) ? mapaHist.getCanal() : this.canal;
		this.cnpjParceiro = !isNullOrEmpty(mapaHist.getCnpjParceiro()) ? mapaHist.getCnpjParceiro() : this.cnpjParceiro;
		this.custcode = !isNullOrEmpty(mapaHist.getCustcode()) ? mapaHist.getCustcode() : this.custcode;
		this.position = !isNullOrEmpty(mapaHist.getPosition()) ? mapaHist.getPosition() : this.position;
		this.flgCancAntesVenda = !isNullOrEmpty(mapaHist.getFlgCancAntesVenda()) ? mapaHist.getFlgCancAntesVenda() : this.flgCancAntesVenda;
		this.flgCancPosVenda = !isNullOrEmpty(mapaHist.getFlgCancPosVenda()) ? mapaHist.getFlgCancPosVenda() : this.flgCancPosVenda;
		this.dtCancVenda = !isNullOrEmpty(mapaHist.getDtCancVenda()) ? mapaHist.getDtCancVenda() : this.dtCancVenda;
		this.motivoCancelamento = !isNullOrEmpty(mapaHist.getMotivoCancelamento()) ? mapaHist.getMotivoCancelamento() : this.motivoCancelamento;
		this.nomeCliente = !isNullOrEmpty(mapaHist.getNomeCliente()) ? mapaHist.getNomeCliente() : this.nomeCliente;
		this.telefone = !isNullOrEmpty(mapaHist.getTelefone()) ? mapaHist.getTelefone() : this.telefone;
		this.emailFatura = !isNullOrEmpty(mapaHist.getEmailFatura()) ? mapaHist.getEmailFatura() : this.emailFatura;
		this.uf = !isNullOrEmpty(mapaHist.getUf()) ? mapaHist.getUf() : this.uf;
		this.tipoLogradouro = !isNullOrEmpty(mapaHist.getTipoLogradouro()) ? mapaHist.getTipoLogradouro() : this.tipoLogradouro;
		this.logradouro = !isNullOrEmpty(mapaHist.getLogradouro()) ? mapaHist.getLogradouro() : this.logradouro;
		this.numero = !isNullOrEmpty(mapaHist.getNumero()) ? mapaHist.getNumero() : this.numero;
		this.complemento = !isNullOrEmpty(mapaHist.getComplemento()) ? mapaHist.getComplemento() : this.complemento;
		this.bairro = !isNullOrEmpty(mapaHist.getBairro()) ? mapaHist.getBairro() : this.bairro;
		this.cep = !isNullOrEmpty(mapaHist.getCep()) ? mapaHist.getCep() : this.cep;
		this.cidade = !isNullOrEmpty(mapaHist.getCidade()) ? mapaHist.getCidade() : this.cidade;
		this.statusOrdem = !isNullOrEmpty(mapaHist.getStatusOrdem()) ? mapaHist.getStatusOrdem() : this.statusOrdem;
		this.tecnologia = !isNullOrEmpty(mapaHist.getTecnologia()) ? mapaHist.getTecnologia() : this.tecnologia;
		this.formaPagamento = !isNullOrEmpty(mapaHist.getFormaPagamento()) ? mapaHist.getFormaPagamento() : this.formaPagamento;
		this.tipoConta = !isNullOrEmpty(mapaHist.getTipoConta()) ? mapaHist.getTipoConta() : this.tipoConta;
		this.codBanco = !isNullOrEmpty(mapaHist.getCodBanco()) ? mapaHist.getCodBanco() : this.codBanco;
		this.codAgengiaBco = !isNullOrEmpty(mapaHist.getCodAgengiaBco()) ? mapaHist.getCodAgengiaBco() : this.codAgengiaBco;
		this.codContaCorrente = !isNullOrEmpty(mapaHist.getCodContaCorrente()) ? mapaHist.getCodContaCorrente() : this.codContaCorrente;
		this.codDebitoAutomatico = !isNullOrEmpty(mapaHist.getCodDebitoAutomatico()) ? mapaHist.getCodDebitoAutomatico() : this.codDebitoAutomatico;
		this.diaVencimento = !isNullOrEmpty(mapaHist.getDiaVencimento()) ? mapaHist.getDiaVencimento() : this.diaVencimento;
		this.semanaVenda = !isNullOrEmpty(mapaHist.getSemanaVenda()) ? mapaHist.getSemanaVenda() : this.semanaVenda;
		this.score = !isNullOrEmpty(mapaHist.getScore()) ? mapaHist.getScore() : this.score;
		this.scoreConsumido = !isNullOrEmpty(mapaHist.getScoreConsumido()) ? mapaHist.getScoreConsumido() : this.scoreConsumido;
		this.dtFinalizacaoOrdem = !isNullOrEmpty(mapaHist.getDtFinalizacaoOrdem()) ? mapaHist.getDtFinalizacaoOrdem() : this.dtFinalizacaoOrdem;
		this.qdeContratos = !isNullOrEmpty(mapaHist.getQdeContratos()) ? mapaHist.getQdeContratos() : this.qdeContratos;
		this.numProtocolo = !isNullOrEmpty(mapaHist.getNumProtocolo()) ? mapaHist.getNumProtocolo() : this.numProtocolo;
		this.flgOrdemAutomatica = !isNullOrEmpty(mapaHist.getFlgOrdemAutomatica()) ? mapaHist.getFlgOrdemAutomatica() : this.flgOrdemAutomatica;
		this.dscTxRecorrente = mapaHist.getDscTxRecorrente() != 0d ? mapaHist.getDscTxRecorrente() + this.dscTxRecorrente : this.dscTxRecorrente;
		this.dscTxNaoRecorrente = mapaHist.getDscTxNaoRecorrente() != 0d ? mapaHist.getDscTxNaoRecorrente() + this.dscTxNaoRecorrente: this.dscTxNaoRecorrente;
		this.dscStatusItem = !isNullOrEmpty(mapaHist.getDscStatusItem()) ? mapaHist.getDscStatusItem() : this.dscStatusItem;
		this.nomLoginResponsavel = !isNullOrEmpty(mapaHist.getNomLoginResponsavel()) ? mapaHist.getNomLoginResponsavel() : this.nomLoginResponsavel;
		this.flgPortabilidade = !isNullOrEmpty(mapaHist.getFlgPortabilidade()) ? mapaHist.getFlgPortabilidade() : this.flgPortabilidade;
		this.dscOperadoraDoadora = !isNullOrEmpty(mapaHist.getDscOperadoraDoadora()) ? mapaHist.getDscOperadoraDoadora() : this.dscOperadoraDoadora;
		this.codDdd = !isNullOrEmpty(mapaHist.getCodDdd()) ? mapaHist.getCodDdd() : this.codDdd;
		this.numTelefonePortado = !isNullOrEmpty(mapaHist.getNumTelefonePortado()) ? mapaHist.getNumTelefonePortado() : this.numTelefonePortado;
		this.datJanelaPortabilidade = !isNullOrEmpty(mapaHist.getDatJanelaPortabilidade()) ? mapaHist.getDatJanelaPortabilidade() : this.datJanelaPortabilidade;
		this.horaDaJanela = !isNullOrEmpty(mapaHist.getHoraDaJanela()) ? mapaHist.getHoraDaJanela() : this.horaDaJanela;
		this.dscEnderecoFatura = !isNullOrEmpty(mapaHist.getDscEnderecoFatura()) ? mapaHist.getDscEnderecoFatura() : this.dscEnderecoFatura;
		this.dscAreaVoip = !isNullOrEmpty(mapaHist.getDscAreaVoip()) ? mapaHist.getDscAreaVoip() : this.dscAreaVoip;
		this.cpe = !isNullOrEmpty(mapaHist.getCpe()) ? mapaHist.getCpe() : this.cpe;
		this.ont = !isNullOrEmpty(mapaHist.getOnt()) ? mapaHist.getOnt() : this.ont;
		this.codigoConvergente = !isNullOrEmpty(mapaHist.getCodigoConvergente()) ? mapaHist.getCodigoConvergente() : this.codigoConvergente;
		this.detalheRecusaCrivo = !isNullOrEmpty(mapaHist.getDetalheRecusaCrivo()) ? mapaHist.getDetalheRecusaCrivo() : this.detalheRecusaCrivo;
		this.itemRoot = !isNullOrEmpty(mapaHist.getItemRoot()) ? mapaHist.getItemRoot() : this.itemRoot;
		this.loginCancelamentoOrdem = !isNullOrEmpty(mapaHist.getLoginCancelamentoOrdem()) ? mapaHist.getLoginCancelamentoOrdem() : this.loginCancelamentoOrdem;
		this.custcodeCliente = !isNullOrEmpty(mapaHist.getCustcodeCliente()) ? mapaHist.getCustcodeCliente() : this.custcodeCliente;
		this.dominioRoot = !isNullOrEmpty(mapaHist.getDominioRoot()) ? mapaHist.getDominioRoot() : this.dominioRoot;
		this.codContFinanceira = !isNullOrEmpty(mapaHist.getCodContFinanceira()) ? mapaHist.getCodContFinanceira() : this.codContFinanceira;
		this.valPlanoAtualItem = !isNullOrEmpty(mapaHist.getValPlanoAtualItem()) ? mapaHist.getValPlanoAtualItem() : this.valPlanoAtualItem;
		this.nomDescontoAtualItem = !isNullOrEmpty(mapaHist.getNomDescontoAtualItem()) ? mapaHist.getNomDescontoAtualItem() : this.nomDescontoAtualItem;
		this.valDescontoAtualItem = !isNullOrEmpty(mapaHist.getValDescontoAtualItem()) ? mapaHist.getValDescontoAtualItem() : this.valDescontoAtualItem;
		this.nroOrdem = !isNullOrEmpty(mapaHist.getNroOrdem()) ? mapaHist.getNroOrdem() : this.nroOrdem;
		this.acessoRowId = !isNullOrEmpty(mapaHist.getAcessoRowId()) ? mapaHist.getAcessoRowId() : this.acessoRowId;
		this.acessoRowIdRoot = !isNullOrEmpty(mapaHist.getAcessoRowIdRoot()) ? mapaHist.getAcessoRowIdRoot() : this.acessoRowIdRoot;
		this.codigoProduto = !isNullOrEmpty(mapaHist.getCodigoProduto()) ? mapaHist.getCodigoProduto() : this.codigoProduto;
		this.flgVendaSubmetida = !isNullOrEmpty(mapaHist.getFlgVendaSubmetida()) ? mapaHist.getFlgVendaSubmetida() : this.flgVendaSubmetida;
		this.flgVendaDuplicada = !isNullOrEmpty(mapaHist.getFlgVendaDuplicada()) ? mapaHist.getFlgVendaDuplicada() : this.flgVendaDuplicada;
		this.flgVendaBruta = !isNullOrEmpty(mapaHist.getFlgVendaBruta()) ? mapaHist.getFlgVendaBruta() : this.flgVendaBruta;
		this.flgVendaLiquida = !isNullOrEmpty(mapaHist.getFlgVendaLiquida()) ? mapaHist.getFlgVendaLiquida() : this.flgVendaLiquida;
		this.flgCancDupl = !isNullOrEmpty(mapaHist.getFlgCancDupl()) ? mapaHist.getFlgCancDupl() : this.flgCancDupl;
		this.flgCancLiquido = !isNullOrEmpty(mapaHist.getFlgCancLiquido()) ? mapaHist.getFlgCancLiquido() : this.flgCancLiquido;
		this.nomeParceiroVenda = !isNullOrEmpty(mapaHist.getNomeParceiroVenda()) ? mapaHist.getNomeParceiroVenda() : this.nomeParceiroVenda;
		this.nomeParceiroVendaOrig = !isNullOrEmpty(mapaHist.getNomeParceiroVendaOrig()) ? mapaHist.getNomeParceiroVendaOrig() : this.nomeParceiroVendaOrig;
		this.rowIdItemOrdem = !isNullOrEmpty(mapaHist.getRowIdItemOrdem()) ? mapaHist.getRowIdItemOrdem() : this.rowIdItemOrdem;
		this.rowIdItemOrdemPai = !isNullOrEmpty(mapaHist.getRowIdItemOrdemPai()) ? mapaHist.getRowIdItemOrdemPai() : this.rowIdItemOrdemPai;
		this.categoriaItemOrder = !isNullOrEmpty(mapaHist.getCategoriaItemOrder()) ? mapaHist.getCategoriaItemOrder() : this.categoriaItemOrder;
		this.datVendaOrig = !isNullOrEmpty(mapaHist.getDatVendaOrig()) ? mapaHist.getDatVendaOrig() : this.datVendaOrig;
		this.horaVendaOrig = !isNullOrEmpty(mapaHist.getHoraVendaOrig()) ? mapaHist.getHoraVendaOrig() : this.horaVendaOrig;
		this.loginVendedorOrig = !isNullOrEmpty(mapaHist.getLoginVendedorOrig()) ? mapaHist.getLoginVendedorOrig() : this.loginVendedorOrig;
		this.canalOrig = !isNullOrEmpty(mapaHist.getCanalOrig()) ? mapaHist.getCanalOrig() : this.canalOrig;
		this.cnpjParceiroOrig = !isNullOrEmpty(mapaHist.getCnpjParceiroOrig()) ? mapaHist.getCnpjParceiroOrig() : this.cnpjParceiroOrig;
		this.custcodeOrig = !isNullOrEmpty(mapaHist.getCustcodeOrig()) ? mapaHist.getCustcodeOrig() : this.custcodeOrig;
		this.positionOrig = !isNullOrEmpty(mapaHist.getPositionOrig()) ? mapaHist.getPositionOrig() : this.positionOrig;
		this.semanaVendaOrig = !isNullOrEmpty(mapaHist.getSemanaVendaOrig()) ? mapaHist.getSemanaVendaOrig() : this.semanaVendaOrig;
		this.codContratoAtual = !isNullOrEmpty(mapaHist.getCodContratoAtual()) ? mapaHist.getCodContratoAtual() : this.codContratoAtual;
		this.nomPlanoAtual = !isNullOrEmpty(mapaHist.getNomPlanoAtual()) ? mapaHist.getNomPlanoAtual() : this.nomPlanoAtual;
		this.nomeVendedorOrig = !isNullOrEmpty(mapaHist.getNomeVendedorOrig()) ? mapaHist.getNomeVendedorOrig() : this.nomeVendedorOrig;
		this.flVendaDuplicada = !isNullOrEmpty(mapaHist.getFlVendaDuplicada()) ? mapaHist.getFlVendaDuplicada() : this.flVendaDuplicada;
		this.flGross = !isNullOrEmpty(mapaHist.getFlGross()) ? mapaHist.getFlGross() : this.flGross;
		this.dtGross = !isNullOrEmpty(mapaHist.getDtGross()) ? mapaHist.getDtGross() : this.dtGross;
		this.flChurn = !isNullOrEmpty(mapaHist.getFlChurn()) ? mapaHist.getFlChurn() : this.flChurn;
		this.dtChurn = !isNullOrEmpty(mapaHist.getDtChurn()) ? mapaHist.getDtChurn() : this.dtChurn;
		this.motivoChurn = !isNullOrEmpty(mapaHist.getMotivoChurn()) ? mapaHist.getMotivoChurn() : this.motivoChurn;
		this.codOrdemChurn = !isNullOrEmpty(mapaHist.getCodOrdemChurn()) ? mapaHist.getCodOrdemChurn() : this.codOrdemChurn;
		this.tipoChurn = !isNullOrEmpty(mapaHist.getTipoChurn()) ? mapaHist.getTipoChurn() : this.tipoChurn;
		this.dtCriacaoOrdemChurn = !isNullOrEmpty(mapaHist.getDtCriacaoOrdemChurn()) ? mapaHist.getDtCriacaoOrdemChurn() : this.dtCriacaoOrdemChurn;
		this.dtConclusaoOrdemChurn = !isNullOrEmpty(mapaHist.getDtConclusaoOrdemChurn()) ? mapaHist.getDtConclusaoOrdemChurn() : this.dtConclusaoOrdemChurn;
		this.msanOltVenda = !isNullOrEmpty(mapaHist.getMsanOltVenda()) ? mapaHist.getMsanOltVenda() : this.msanOltVenda;
		this.dtConclusaoWfm = !isNullOrEmpty(mapaHist.getDtConclusaoWfm()) ? mapaHist.getDtConclusaoWfm() : this.dtConclusaoWfm;
		this.dscStatusOrdemWfm = !isNullOrEmpty(mapaHist.getDscStatusOrdemWfm()) ? mapaHist.getDscStatusOrdemWfm() : this.dscStatusOrdemWfm;
		this.datStatusWfm = !isNullOrEmpty(mapaHist.getDatStatusWfm()) ? mapaHist.getDatStatusWfm() : this.datStatusWfm;
		this.horaStatusWfm = !isNullOrEmpty(mapaHist.getHoraStatusWfm()) ? mapaHist.getHoraStatusWfm() : this.horaStatusWfm;
		this.idRecursoWfm = !isNullOrEmpty(mapaHist.getIdRecursoWfm()) ? mapaHist.getIdRecursoWfm() : this.idRecursoWfm;
		this.nomRecursoWfm = !isNullOrEmpty(mapaHist.getNomRecursoWfm()) ? mapaHist.getNomRecursoWfm() : this.nomRecursoWfm;
		this.idRecursoPaiWfm = !isNullOrEmpty(mapaHist.getIdRecursoPaiWfm()) ? mapaHist.getIdRecursoPaiWfm() : this.idRecursoPaiWfm;
		this.datPrimeiroAgend = !isNullOrEmpty(mapaHist.getDatPrimeiroAgend()) ? mapaHist.getDatPrimeiroAgend() : this.datPrimeiroAgend;
		this.horaPrimeiroAgendamento = !isNullOrEmpty(mapaHist.getHoraPrimeiroAgendamento()) ? mapaHist.getHoraPrimeiroAgendamento() : this.horaPrimeiroAgendamento;
		this.datAgendAtual = !isNullOrEmpty(mapaHist.getDatAgendAtual()) ? mapaHist.getDatAgendAtual() : this.datAgendAtual;
		this.horaAgendamentoAtual = !isNullOrEmpty(mapaHist.getHoraAgendamentoAtual()) ? mapaHist.getHoraAgendamentoAtual() : this.horaAgendamentoAtual;
		this.dscStatusAtivacao = !isNullOrEmpty(mapaHist.getDscStatusAtivacao()) ? mapaHist.getDscStatusAtivacao() : this.dscStatusAtivacao;
		this.msanOltTrafego = !isNullOrEmpty(mapaHist.getMsanOltTrafego()) ? mapaHist.getMsanOltTrafego() : this.msanOltTrafego;
		this.nomeVendedor = !isNullOrEmpty(mapaHist.getNomeVendedor()) ? mapaHist.getNomeVendedor() : this.nomeVendedor;
		this.nomeUsuarioCancOrdem = !isNullOrEmpty(mapaHist.getNomeUsuarioCancOrdem()) ? mapaHist.getNomeUsuarioCancOrdem() : this.nomeUsuarioCancOrdem;
		this.emailCliente = !isNullOrEmpty(mapaHist.getEmailCliente()) ? mapaHist.getEmailCliente() : this.emailCliente;
		
	}
	
	
	public void clean() {
		
		this.datref = CommonsConstants.EMPTY;
		this.datCriacaoOrdem = CommonsConstants.EMPTY;
		this.horaCriacaoDaOrdem = CommonsConstants.EMPTY;
		this.datVenda = CommonsConstants.EMPTY;
		this.horaDaVenda = CommonsConstants.EMPTY;
		this.datStatusOrdem = CommonsConstants.EMPTY;
		this.hrStatusOrdem = CommonsConstants.EMPTY;
		this.numOrdemSiebel = CommonsConstants.EMPTY;
		this.numOrdemSiebelOrig = CommonsConstants.EMPTY;
		this.codContratoOltp = CommonsConstants.EMPTY;
		this.codContratoAtivacao = CommonsConstants.EMPTY;
		this.numeroAcesso = CommonsConstants.EMPTY;
		this.customerId = CommonsConstants.EMPTY;
		this.tipoDocumento = CommonsConstants.EMPTY;
		this.documento = CommonsConstants.EMPTY;
		this.tipoVenda = CommonsConstants.EMPTY;
		this.tipoProduto = CommonsConstants.EMPTY;
		this.velocidadeDownload = CommonsConstants.EMPTY;
		this.velocidadeUpload = CommonsConstants.EMPTY;
		this.planoAtivacaoOferta = CommonsConstants.EMPTY;
		this.loginVendedor = CommonsConstants.EMPTY;
		this.canal = CommonsConstants.EMPTY;
		this.cnpjParceiro = CommonsConstants.EMPTY;
		this.custcode = CommonsConstants.EMPTY;
		this.position = CommonsConstants.EMPTY;
		this.flgCancAntesVenda = CommonsConstants.EMPTY;
		this.flgCancPosVenda = CommonsConstants.EMPTY;
		this.dtCancVenda = CommonsConstants.EMPTY;
		this.motivoCancelamento = CommonsConstants.EMPTY;
		this.nomeCliente = CommonsConstants.EMPTY;
		this.telefone = CommonsConstants.EMPTY;
		this.emailFatura = CommonsConstants.EMPTY;
		this.uf = CommonsConstants.EMPTY;
		this.tipoLogradouro = CommonsConstants.EMPTY;
		this.logradouro = CommonsConstants.EMPTY;
		this.numero = CommonsConstants.EMPTY;
		this.complemento = CommonsConstants.EMPTY;
		this.bairro = CommonsConstants.EMPTY;
		this.cep = CommonsConstants.EMPTY;
		this.cidade = CommonsConstants.EMPTY;
		this.statusOrdem = CommonsConstants.EMPTY;
		this.tecnologia = CommonsConstants.EMPTY;
		this.formaPagamento = CommonsConstants.EMPTY;
		this.tipoConta = CommonsConstants.EMPTY;
		this.codBanco = CommonsConstants.EMPTY;
		this.codAgengiaBco = CommonsConstants.EMPTY;
		this.codContaCorrente = CommonsConstants.EMPTY;
		this.codDebitoAutomatico = CommonsConstants.EMPTY;
		this.diaVencimento = CommonsConstants.EMPTY;
		this.semanaVenda = CommonsConstants.EMPTY;
		this.score = CommonsConstants.EMPTY;
		this.scoreConsumido = CommonsConstants.EMPTY;
		this.dtFinalizacaoOrdem = CommonsConstants.EMPTY;
		this.qdeContratos = CommonsConstants.EMPTY;
		this.numProtocolo = CommonsConstants.EMPTY;
		this.flgOrdemAutomatica = CommonsConstants.EMPTY;
		this.dscTxRecorrente = 0d;
		this.dscTxNaoRecorrente = 0d;
		this.dscStatusItem = CommonsConstants.EMPTY;
		this.nomLoginResponsavel = CommonsConstants.EMPTY;
		this.flgPortabilidade = CommonsConstants.EMPTY;
		this.dscOperadoraDoadora = CommonsConstants.EMPTY;
		this.codDdd = CommonsConstants.EMPTY;
		this.numTelefonePortado = CommonsConstants.EMPTY;
		this.datJanelaPortabilidade = CommonsConstants.EMPTY;
		this.horaDaJanela = CommonsConstants.EMPTY;
		this.dscEnderecoFatura = CommonsConstants.EMPTY;
		this.dscAreaVoip = CommonsConstants.EMPTY;
		this.cpe = CommonsConstants.EMPTY;
		this.ont = CommonsConstants.EMPTY;
		this.codigoConvergente = CommonsConstants.EMPTY;
		this.detalheRecusaCrivo = CommonsConstants.EMPTY;
		this.itemRoot = CommonsConstants.EMPTY;
		this.loginCancelamentoOrdem = CommonsConstants.EMPTY;
		this.custcodeCliente = CommonsConstants.EMPTY;
		this.dominioRoot = CommonsConstants.EMPTY;
		this.codContFinanceira = CommonsConstants.EMPTY;
		this.valPlanoAtualItem = CommonsConstants.EMPTY;
		this.nomDescontoAtualItem = CommonsConstants.EMPTY;
		this.valDescontoAtualItem = CommonsConstants.EMPTY;
		this.nroOrdem = CommonsConstants.EMPTY;
		this.acessoRowId = CommonsConstants.EMPTY;
		this.acessoRowIdRoot = CommonsConstants.EMPTY;
		this.codigoProduto = CommonsConstants.EMPTY;
		this.flgVendaSubmetida = CommonsConstants.EMPTY;
		this.flgVendaDuplicada = CommonsConstants.EMPTY;
		this.flgVendaBruta = CommonsConstants.EMPTY;
		this.flgVendaLiquida = CommonsConstants.EMPTY;
		this.flgCancDupl = CommonsConstants.EMPTY;
		this.flgCancLiquido = CommonsConstants.EMPTY;
		this.nomeParceiroVenda = CommonsConstants.EMPTY;
		this.nomeParceiroVendaOrig = CommonsConstants.EMPTY;
		this.rowIdItemOrdem = CommonsConstants.EMPTY;
		this.rowIdItemOrdemPai = CommonsConstants.EMPTY;
		this.categoriaItemOrder = CommonsConstants.EMPTY;
		this.datVendaOrig = CommonsConstants.EMPTY;
		this.horaVendaOrig = CommonsConstants.EMPTY;
		this.loginVendedorOrig = CommonsConstants.EMPTY;
		this.canalOrig = CommonsConstants.EMPTY;
		this.cnpjParceiroOrig = CommonsConstants.EMPTY;
		this.custcodeOrig = CommonsConstants.EMPTY;
		this.positionOrig = CommonsConstants.EMPTY;
		this.semanaVendaOrig = CommonsConstants.EMPTY;
		this.codContratoAtual = CommonsConstants.EMPTY;
		this.nomPlanoAtual = CommonsConstants.EMPTY;
		this.nomeVendedorOrig = CommonsConstants.EMPTY;
		this.flVendaDuplicada = CommonsConstants.EMPTY;
		this.flGross = CommonsConstants.EMPTY;
		this.dtGross = CommonsConstants.EMPTY;
		this.flChurn = CommonsConstants.EMPTY;
		this.dtChurn = CommonsConstants.EMPTY;
		this.motivoChurn = CommonsConstants.EMPTY;
		this.codOrdemChurn = CommonsConstants.EMPTY;
		this.tipoChurn = CommonsConstants.EMPTY;
		this.dtCriacaoOrdemChurn = CommonsConstants.EMPTY;
		this.dtConclusaoOrdemChurn = CommonsConstants.EMPTY;
		this.msanOltVenda = CommonsConstants.EMPTY;
		this.dtConclusaoWfm = CommonsConstants.EMPTY;
		this.dscStatusOrdemWfm = CommonsConstants.EMPTY;
		this.datStatusWfm = CommonsConstants.EMPTY;
		this.horaStatusWfm = CommonsConstants.EMPTY;
		this.idRecursoWfm = CommonsConstants.EMPTY;
		this.nomRecursoWfm = CommonsConstants.EMPTY;
		this.idRecursoPaiWfm = CommonsConstants.EMPTY;
		this.datPrimeiroAgend = CommonsConstants.EMPTY;
		this.horaPrimeiroAgendamento = CommonsConstants.EMPTY;
		this.datAgendAtual = CommonsConstants.EMPTY;
		this.horaAgendamentoAtual = CommonsConstants.EMPTY;
		this.dscStatusAtivacao = CommonsConstants.EMPTY;
		this.msanOltTrafego = CommonsConstants.EMPTY;
		this.nomeVendedor = CommonsConstants.EMPTY;
		this.nomeUsuarioCancOrdem = CommonsConstants.EMPTY;
		this.emailCliente = CommonsConstants.EMPTY;
		
	}


	public String getDatref() {
		return datref;
	}


	public void setDatref(String datref) {
		this.datref = datref;
	}


	public String getDatCriacaoOrdem() {
		return datCriacaoOrdem;
	}


	public void setDatCriacaoOrdem(String datCriacaoOrdem) {
		this.datCriacaoOrdem = datCriacaoOrdem;
	}


	public String getHoraCriacaoDaOrdem() {
		return horaCriacaoDaOrdem;
	}


	public void setHoraCriacaoDaOrdem(String horaCriacaoDaOrdem) {
		this.horaCriacaoDaOrdem = horaCriacaoDaOrdem;
	}


	public String getDatVenda() {
		return datVenda;
	}


	public void setDatVenda(String datVenda) {
		this.datVenda = datVenda;
	}


	public String getHoraDaVenda() {
		return horaDaVenda;
	}


	public void setHoraDaVenda(String horaDaVenda) {
		this.horaDaVenda = horaDaVenda;
	}


	public String getDatStatusOrdem() {
		return datStatusOrdem;
	}


	public void setDatStatusOrdem(String datStatusOrdem) {
		this.datStatusOrdem = datStatusOrdem;
	}


	public String getHrStatusOrdem() {
		return hrStatusOrdem;
	}


	public void setHrStatusOrdem(String hrStatusOrdem) {
		this.hrStatusOrdem = hrStatusOrdem;
	}


	public String getNumOrdemSiebel() {
		return numOrdemSiebel;
	}


	public void setNumOrdemSiebel(String numOrdemSiebel) {
		this.numOrdemSiebel = numOrdemSiebel;
	}


	public String getNumOrdemSiebelOrig() {
		return numOrdemSiebelOrig;
	}


	public void setNumOrdemSiebelOrig(String numOrdemSiebelOrig) {
		this.numOrdemSiebelOrig = numOrdemSiebelOrig;
	}


	public String getCodContratoOltp() {
		return codContratoOltp;
	}


	public void setCodContratoOltp(String codContratoOltp) {
		this.codContratoOltp = codContratoOltp;
	}


	public String getCodContratoAtivacao() {
		return codContratoAtivacao;
	}


	public void setCodContratoAtivacao(String codContratoAtivacao) {
		this.codContratoAtivacao = codContratoAtivacao;
	}


	public String getNumeroAcesso() {
		return numeroAcesso;
	}


	public void setNumeroAcesso(String numeroAcesso) {
		this.numeroAcesso = numeroAcesso;
	}


	public String getCustomerId() {
		return customerId;
	}


	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}


	public String getTipoDocumento() {
		return tipoDocumento;
	}


	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}


	public String getDocumento() {
		return documento;
	}


	public void setDocumento(String documento) {
		this.documento = documento;
	}


	public String getTipoVenda() {
		return tipoVenda;
	}


	public void setTipoVenda(String tipoVenda) {
		this.tipoVenda = tipoVenda;
	}


	public String getTipoProduto() {
		return tipoProduto;
	}


	public void setTipoProduto(String tipoProduto) {
		this.tipoProduto = tipoProduto;
	}


	public String getVelocidadeDownload() {
		return velocidadeDownload;
	}


	public void setVelocidadeDownload(String velocidadeDownload) {
		this.velocidadeDownload = velocidadeDownload;
	}


	public String getVelocidadeUpload() {
		return velocidadeUpload;
	}


	public void setVelocidadeUpload(String velocidadeUpload) {
		this.velocidadeUpload = velocidadeUpload;
	}


	public String getPlanoAtivacaoOferta() {
		return planoAtivacaoOferta;
	}


	public void setPlanoAtivacaoOferta(String planoAtivacaoOferta) {
		this.planoAtivacaoOferta = planoAtivacaoOferta;
	}


	public String getLoginVendedor() {
		return loginVendedor;
	}


	public void setLoginVendedor(String loginVendedor) {
		this.loginVendedor = loginVendedor;
	}


	public String getCanal() {
		return canal;
	}


	public void setCanal(String canal) {
		this.canal = canal;
	}


	public String getCnpjParceiro() {
		return cnpjParceiro;
	}


	public void setCnpjParceiro(String cnpjParceiro) {
		this.cnpjParceiro = cnpjParceiro;
	}


	public String getCustcode() {
		return custcode;
	}


	public void setCustcode(String custcode) {
		this.custcode = custcode;
	}


	public String getPosition() {
		return position;
	}


	public void setPosition(String position) {
		this.position = position;
	}


	public String getFlgCancAntesVenda() {
		return flgCancAntesVenda;
	}


	public void setFlgCancAntesVenda(String flgCancAntesVenda) {
		this.flgCancAntesVenda = flgCancAntesVenda;
	}


	public String getFlgCancPosVenda() {
		return flgCancPosVenda;
	}


	public void setFlgCancPosVenda(String flgCancPosVenda) {
		this.flgCancPosVenda = flgCancPosVenda;
	}


	public String getDtCancVenda() {
		return dtCancVenda;
	}


	public void setDtCancVenda(String dtCancVenda) {
		this.dtCancVenda = dtCancVenda;
	}


	public String getMotivoCancelamento() {
		return motivoCancelamento;
	}


	public void setMotivoCancelamento(String motivoCancelamento) {
		this.motivoCancelamento = motivoCancelamento;
	}


	public String getNomeCliente() {
		return nomeCliente;
	}


	public void setNomeCliente(String nomeCliente) {
		this.nomeCliente = nomeCliente;
	}


	public String getTelefone() {
		return telefone;
	}


	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}


	public String getEmailFatura() {
		return emailFatura;
	}


	public void setEmailFatura(String emailFatura) {
		this.emailFatura = emailFatura;
	}


	public String getUf() {
		return uf;
	}


	public void setUf(String uf) {
		this.uf = uf;
	}


	public String getTipoLogradouro() {
		return tipoLogradouro;
	}


	public void setTipoLogradouro(String tipoLogradouro) {
		this.tipoLogradouro = tipoLogradouro;
	}


	public String getLogradouro() {
		return logradouro;
	}


	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}


	public String getNumero() {
		return numero;
	}


	public void setNumero(String numero) {
		this.numero = numero;
	}


	public String getComplemento() {
		return complemento;
	}


	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}


	public String getBairro() {
		return bairro;
	}


	public void setBairro(String bairro) {
		this.bairro = bairro;
	}


	public String getCep() {
		return cep;
	}


	public void setCep(String cep) {
		this.cep = cep;
	}


	public String getCidade() {
		return cidade;
	}


	public void setCidade(String cidade) {
		this.cidade = cidade;
	}


	public String getStatusOrdem() {
		return statusOrdem;
	}


	public void setStatusOrdem(String statusOrdem) {
		this.statusOrdem = statusOrdem;
	}


	public String getTecnologia() {
		return tecnologia;
	}


	public void setTecnologia(String tecnologia) {
		this.tecnologia = tecnologia;
	}


	public String getFormaPagamento() {
		return formaPagamento;
	}


	public void setFormaPagamento(String formaPagamento) {
		this.formaPagamento = formaPagamento;
	}


	public String getTipoConta() {
		return tipoConta;
	}


	public void setTipoConta(String tipoConta) {
		this.tipoConta = tipoConta;
	}


	public String getCodBanco() {
		return codBanco;
	}


	public void setCodBanco(String codBanco) {
		this.codBanco = codBanco;
	}


	public String getCodAgengiaBco() {
		return codAgengiaBco;
	}


	public void setCodAgengiaBco(String codAgengiaBco) {
		this.codAgengiaBco = codAgengiaBco;
	}


	public String getCodContaCorrente() {
		return codContaCorrente;
	}


	public void setCodContaCorrente(String codContaCorrente) {
		this.codContaCorrente = codContaCorrente;
	}


	public String getCodDebitoAutomatico() {
		return codDebitoAutomatico;
	}


	public void setCodDebitoAutomatico(String codDebitoAutomatico) {
		this.codDebitoAutomatico = codDebitoAutomatico;
	}


	public String getDiaVencimento() {
		return diaVencimento;
	}


	public void setDiaVencimento(String diaVencimento) {
		this.diaVencimento = diaVencimento;
	}


	public String getSemanaVenda() {
		return semanaVenda;
	}


	public void setSemanaVenda(String semanaVenda) {
		this.semanaVenda = semanaVenda;
	}


	public String getScore() {
		return score;
	}


	public void setScore(String score) {
		this.score = score;
	}


	public String getScoreConsumido() {
		return scoreConsumido;
	}


	public void setScoreConsumido(String scoreConsumido) {
		this.scoreConsumido = scoreConsumido;
	}


	public String getDtFinalizacaoOrdem() {
		return dtFinalizacaoOrdem;
	}


	public void setDtFinalizacaoOrdem(String dtFinalizacaoOrdem) {
		this.dtFinalizacaoOrdem = dtFinalizacaoOrdem;
	}


	public String getQdeContratos() {
		return qdeContratos;
	}


	public void setQdeContratos(String qdeContratos) {
		this.qdeContratos = qdeContratos;
	}


	public String getNumProtocolo() {
		return numProtocolo;
	}


	public void setNumProtocolo(String numProtocolo) {
		this.numProtocolo = numProtocolo;
	}


	public String getFlgOrdemAutomatica() {
		return flgOrdemAutomatica;
	}


	public void setFlgOrdemAutomatica(String flgOrdemAutomatica) {
		this.flgOrdemAutomatica = flgOrdemAutomatica;
	}


	public double getDscTxRecorrente() {
		return dscTxRecorrente;
	}


	public void setDscTxRecorrente(double dscTxRecorrente) {
		this.dscTxRecorrente = dscTxRecorrente;
	}


	public double getDscTxNaoRecorrente() {
		return dscTxNaoRecorrente;
	}


	public void setDscTxNaoRecorrente(double dscTxNaoRecorrente) {
		this.dscTxNaoRecorrente = dscTxNaoRecorrente;
	}


	public String getDscStatusItem() {
		return dscStatusItem;
	}


	public void setDscStatusItem(String dscStatusItem) {
		this.dscStatusItem = dscStatusItem;
	}


	public String getNomLoginResponsavel() {
		return nomLoginResponsavel;
	}


	public void setNomLoginResponsavel(String nomLoginResponsavel) {
		this.nomLoginResponsavel = nomLoginResponsavel;
	}


	public String getFlgPortabilidade() {
		return flgPortabilidade;
	}


	public void setFlgPortabilidade(String flgPortabilidade) {
		this.flgPortabilidade = flgPortabilidade;
	}


	public String getDscOperadoraDoadora() {
		return dscOperadoraDoadora;
	}


	public void setDscOperadoraDoadora(String dscOperadoraDoadora) {
		this.dscOperadoraDoadora = dscOperadoraDoadora;
	}


	public String getCodDdd() {
		return codDdd;
	}


	public void setCodDdd(String codDdd) {
		this.codDdd = codDdd;
	}


	public String getNumTelefonePortado() {
		return numTelefonePortado;
	}


	public void setNumTelefonePortado(String numTelefonePortado) {
		this.numTelefonePortado = numTelefonePortado;
	}


	public String getDatJanelaPortabilidade() {
		return datJanelaPortabilidade;
	}


	public void setDatJanelaPortabilidade(String datJanelaPortabilidade) {
		this.datJanelaPortabilidade = datJanelaPortabilidade;
	}


	public String getHoraDaJanela() {
		return horaDaJanela;
	}


	public void setHoraDaJanela(String horaDaJanela) {
		this.horaDaJanela = horaDaJanela;
	}


	public String getDscEnderecoFatura() {
		return dscEnderecoFatura;
	}


	public void setDscEnderecoFatura(String dscEnderecoFatura) {
		this.dscEnderecoFatura = dscEnderecoFatura;
	}


	public String getDscAreaVoip() {
		return dscAreaVoip;
	}


	public void setDscAreaVoip(String dscAreaVoip) {
		this.dscAreaVoip = dscAreaVoip;
	}


	public String getCpe() {
		return cpe;
	}


	public void setCpe(String cpe) {
		this.cpe = cpe;
	}


	public String getOnt() {
		return ont;
	}


	public void setOnt(String ont) {
		this.ont = ont;
	}


	public String getCodigoConvergente() {
		return codigoConvergente;
	}


	public void setCodigoConvergente(String codigoConvergente) {
		this.codigoConvergente = codigoConvergente;
	}


	public String getDetalheRecusaCrivo() {
		return detalheRecusaCrivo;
	}


	public void setDetalheRecusaCrivo(String detalheRecusaCrivo) {
		this.detalheRecusaCrivo = detalheRecusaCrivo;
	}


	public String getItemRoot() {
		return itemRoot;
	}


	public void setItemRoot(String itemRoot) {
		this.itemRoot = itemRoot;
	}


	public String getLoginCancelamentoOrdem() {
		return loginCancelamentoOrdem;
	}


	public void setLoginCancelamentoOrdem(String loginCancelamentoOrdem) {
		this.loginCancelamentoOrdem = loginCancelamentoOrdem;
	}


	public String getCustcodeCliente() {
		return custcodeCliente;
	}


	public void setCustcodeCliente(String custcodeCliente) {
		this.custcodeCliente = custcodeCliente;
	}


	public String getDominioRoot() {
		return dominioRoot;
	}


	public void setDominioRoot(String dominioRoot) {
		this.dominioRoot = dominioRoot;
	}


	public String getCodContFinanceira() {
		return codContFinanceira;
	}


	public void setCodContFinanceira(String codContFinanceira) {
		this.codContFinanceira = codContFinanceira;
	}


	public String getValPlanoAtualItem() {
		return valPlanoAtualItem;
	}


	public void setValPlanoAtualItem(String valPlanoAtualItem) {
		this.valPlanoAtualItem = valPlanoAtualItem;
	}


	public String getNomDescontoAtualItem() {
		return nomDescontoAtualItem;
	}


	public void setNomDescontoAtualItem(String nomDescontoAtualItem) {
		this.nomDescontoAtualItem = nomDescontoAtualItem;
	}


	public String getValDescontoAtualItem() {
		return valDescontoAtualItem;
	}


	public void setValDescontoAtualItem(String valDescontoAtualItem) {
		this.valDescontoAtualItem = valDescontoAtualItem;
	}


	public String getNroOrdem() {
		return nroOrdem;
	}


	public void setNroOrdem(String nroOrdem) {
		this.nroOrdem = nroOrdem;
	}


	public String getAcessoRowId() {
		return acessoRowId;
	}


	public void setAcessoRowId(String acessoRowId) {
		this.acessoRowId = acessoRowId;
	}


	public String getAcessoRowIdRoot() {
		return acessoRowIdRoot;
	}


	public void setAcessoRowIdRoot(String acessoRowIdRoot) {
		this.acessoRowIdRoot = acessoRowIdRoot;
	}


	public String getCodigoProduto() {
		return codigoProduto;
	}


	public void setCodigoProduto(String codigoProduto) {
		this.codigoProduto = codigoProduto;
	}


	public String getFlgVendaSubmetida() {
		return flgVendaSubmetida;
	}


	public void setFlgVendaSubmetida(String flgVendaSubmetida) {
		this.flgVendaSubmetida = flgVendaSubmetida;
	}


	public String getFlgVendaDuplicada() {
		return flgVendaDuplicada;
	}


	public void setFlgVendaDuplicada(String flgVendaDuplicada) {
		this.flgVendaDuplicada = flgVendaDuplicada;
	}


	public String getFlgVendaBruta() {
		return flgVendaBruta;
	}


	public void setFlgVendaBruta(String flgVendaBruta) {
		this.flgVendaBruta = flgVendaBruta;
	}


	public String getFlgVendaLiquida() {
		return flgVendaLiquida;
	}


	public void setFlgVendaLiquida(String flgVendaLiquida) {
		this.flgVendaLiquida = flgVendaLiquida;
	}


	public String getFlgCancDupl() {
		return flgCancDupl;
	}


	public void setFlgCancDupl(String flgCancDupl) {
		this.flgCancDupl = flgCancDupl;
	}


	public String getFlgCancLiquido() {
		return flgCancLiquido;
	}


	public void setFlgCancLiquido(String flgCancLiquido) {
		this.flgCancLiquido = flgCancLiquido;
	}


	public String getNomeParceiroVenda() {
		return nomeParceiroVenda;
	}


	public void setNomeParceiroVenda(String nomeParceiroVenda) {
		this.nomeParceiroVenda = nomeParceiroVenda;
	}


	public String getNomeParceiroVendaOrig() {
		return nomeParceiroVendaOrig;
	}


	public void setNomeParceiroVendaOrig(String nomeParceiroVendaOrig) {
		this.nomeParceiroVendaOrig = nomeParceiroVendaOrig;
	}


	public String getRowIdItemOrdem() {
		return rowIdItemOrdem;
	}


	public void setRowIdItemOrdem(String rowIdItemOrdem) {
		this.rowIdItemOrdem = rowIdItemOrdem;
	}


	public String getRowIdItemOrdemPai() {
		return rowIdItemOrdemPai;
	}


	public void setRowIdItemOrdemPai(String rowIdItemOrdemPai) {
		this.rowIdItemOrdemPai = rowIdItemOrdemPai;
	}


	public String getCategoriaItemOrder() {
		return categoriaItemOrder;
	}


	public void setCategoriaItemOrder(String categoriaItemOrder) {
		this.categoriaItemOrder = categoriaItemOrder;
	}


	public String getDatVendaOrig() {
		return datVendaOrig;
	}


	public void setDatVendaOrig(String datVendaOrig) {
		this.datVendaOrig = datVendaOrig;
	}


	public String getHoraVendaOrig() {
		return horaVendaOrig;
	}


	public void setHoraVendaOrig(String horaVendaOrig) {
		this.horaVendaOrig = horaVendaOrig;
	}


	public String getLoginVendedorOrig() {
		return loginVendedorOrig;
	}


	public void setLoginVendedorOrig(String loginVendedorOrig) {
		this.loginVendedorOrig = loginVendedorOrig;
	}


	public String getCanalOrig() {
		return canalOrig;
	}


	public void setCanalOrig(String canalOrig) {
		this.canalOrig = canalOrig;
	}


	public String getCnpjParceiroOrig() {
		return cnpjParceiroOrig;
	}


	public void setCnpjParceiroOrig(String cnpjParceiroOrig) {
		this.cnpjParceiroOrig = cnpjParceiroOrig;
	}


	public String getCustcodeOrig() {
		return custcodeOrig;
	}


	public void setCustcodeOrig(String custcodeOrig) {
		this.custcodeOrig = custcodeOrig;
	}


	public String getPositionOrig() {
		return positionOrig;
	}


	public void setPositionOrig(String positionOrig) {
		this.positionOrig = positionOrig;
	}


	public String getSemanaVendaOrig() {
		return semanaVendaOrig;
	}


	public void setSemanaVendaOrig(String semanaVendaOrig) {
		this.semanaVendaOrig = semanaVendaOrig;
	}


	public String getCodContratoAtual() {
		return codContratoAtual;
	}


	public void setCodContratoAtual(String codContratoAtual) {
		this.codContratoAtual = codContratoAtual;
	}


	public String getNomPlanoAtual() {
		return nomPlanoAtual;
	}


	public void setNomPlanoAtual(String nomPlanoAtual) {
		this.nomPlanoAtual = nomPlanoAtual;
	}


	public String getNomeVendedorOrig() {
		return nomeVendedorOrig;
	}


	public void setNomeVendedorOrig(String nomeVendedorOrig) {
		this.nomeVendedorOrig = nomeVendedorOrig;
	}


	public String getFlVendaDuplicada() {
		return flVendaDuplicada;
	}


	public void setFlVendaDuplicada(String flVendaDuplicada) {
		this.flVendaDuplicada = flVendaDuplicada;
	}


	public String getFlGross() {
		return flGross;
	}


	public void setFlGross(String flGross) {
		this.flGross = flGross;
	}


	public String getDtGross() {
		return dtGross;
	}


	public void setDtGross(String dtGross) {
		this.dtGross = dtGross;
	}


	public String getFlChurn() {
		return flChurn;
	}


	public void setFlChurn(String flChurn) {
		this.flChurn = flChurn;
	}


	public String getDtChurn() {
		return dtChurn;
	}


	public void setDtChurn(String dtChurn) {
		this.dtChurn = dtChurn;
	}


	public String getMotivoChurn() {
		return motivoChurn;
	}


	public void setMotivoChurn(String motivoChurn) {
		this.motivoChurn = motivoChurn;
	}


	public String getCodOrdemChurn() {
		return codOrdemChurn;
	}


	public void setCodOrdemChurn(String codOrdemChurn) {
		this.codOrdemChurn = codOrdemChurn;
	}


	public String getTipoChurn() {
		return tipoChurn;
	}


	public void setTipoChurn(String tipoChurn) {
		this.tipoChurn = tipoChurn;
	}


	public String getDtCriacaoOrdemChurn() {
		return dtCriacaoOrdemChurn;
	}


	public void setDtCriacaoOrdemChurn(String dtCriacaoOrdemChurn) {
		this.dtCriacaoOrdemChurn = dtCriacaoOrdemChurn;
	}


	public String getDtConclusaoOrdemChurn() {
		return dtConclusaoOrdemChurn;
	}


	public void setDtConclusaoOrdemChurn(String dtConclusaoOrdemChurn) {
		this.dtConclusaoOrdemChurn = dtConclusaoOrdemChurn;
	}


	public String getMsanOltVenda() {
		return msanOltVenda;
	}


	public void setMsanOltVenda(String msanOltVenda) {
		this.msanOltVenda = msanOltVenda;
	}


	public String getDtConclusaoWfm() {
		return dtConclusaoWfm;
	}


	public void setDtConclusaoWfm(String dtConclusaoWfm) {
		this.dtConclusaoWfm = dtConclusaoWfm;
	}


	public String getDscStatusOrdemWfm() {
		return dscStatusOrdemWfm;
	}


	public void setDscStatusOrdemWfm(String dscStatusOrdemWfm) {
		this.dscStatusOrdemWfm = dscStatusOrdemWfm;
	}


	public String getDatStatusWfm() {
		return datStatusWfm;
	}


	public void setDatStatusWfm(String datStatusWfm) {
		this.datStatusWfm = datStatusWfm;
	}


	public String getHoraStatusWfm() {
		return horaStatusWfm;
	}


	public void setHoraStatusWfm(String horaStatusWfm) {
		this.horaStatusWfm = horaStatusWfm;
	}


	public String getIdRecursoWfm() {
		return idRecursoWfm;
	}


	public void setIdRecursoWfm(String idRecursoWfm) {
		this.idRecursoWfm = idRecursoWfm;
	}


	public String getNomRecursoWfm() {
		return nomRecursoWfm;
	}


	public void setNomRecursoWfm(String nomRecursoWfm) {
		this.nomRecursoWfm = nomRecursoWfm;
	}


	public String getIdRecursoPaiWfm() {
		return idRecursoPaiWfm;
	}


	public void setIdRecursoPaiWfm(String idRecursoPaiWfm) {
		this.idRecursoPaiWfm = idRecursoPaiWfm;
	}


	public String getDatPrimeiroAgend() {
		return datPrimeiroAgend;
	}


	public void setDatPrimeiroAgend(String datPrimeiroAgend) {
		this.datPrimeiroAgend = datPrimeiroAgend;
	}


	public String getHoraPrimeiroAgendamento() {
		return horaPrimeiroAgendamento;
	}


	public void setHoraPrimeiroAgendamento(String horaPrimeiroAgendamento) {
		this.horaPrimeiroAgendamento = horaPrimeiroAgendamento;
	}


	public String getDatAgendAtual() {
		return datAgendAtual;
	}


	public void setDatAgendAtual(String datAgendAtual) {
		this.datAgendAtual = datAgendAtual;
	}


	public String getHoraAgendamentoAtual() {
		return horaAgendamentoAtual;
	}


	public void setHoraAgendamentoAtual(String horaAgendamentoAtual) {
		this.horaAgendamentoAtual = horaAgendamentoAtual;
	}


	public String getDscStatusAtivacao() {
		return dscStatusAtivacao;
	}


	public void setDscStatusAtivacao(String dscStatusAtivacao) {
		this.dscStatusAtivacao = dscStatusAtivacao;
	}


	public String getMsanOltTrafego() {
		return msanOltTrafego;
	}


	public void setMsanOltTrafego(String msanOltTrafego) {
		this.msanOltTrafego = msanOltTrafego;
	}


	public String getNomeVendedor() {
		return nomeVendedor;
	}


	public void setNomeVendedor(String nomeVendedor) {
		this.nomeVendedor = nomeVendedor;
	}


	public String getNomeUsuarioCancOrdem() {
		return nomeUsuarioCancOrdem;
	}


	public void setNomeUsuarioCancOrdem(String nomeUsuarioCancOrdem) {
		this.nomeUsuarioCancOrdem = nomeUsuarioCancOrdem;
	}


	public String getEmailCliente() {
		return emailCliente;
	}


	public void setEmailCliente(String emailCliente) {
		this.emailCliente = emailCliente;
	}

	
	public boolean isNullOrEmpty(String info) {
		
		if (Strings.isNullOrEmpty(info) || info.equals("\\N")) {
			return true;
		}else {
			return false;
		}
	}

}
