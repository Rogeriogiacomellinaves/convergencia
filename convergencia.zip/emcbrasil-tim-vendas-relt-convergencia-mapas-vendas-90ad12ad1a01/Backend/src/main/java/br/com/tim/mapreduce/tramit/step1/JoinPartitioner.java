package br.com.tim.mapreduce.tramit.step1;

import org.apache.hadoop.mapreduce.Partitioner;

public class JoinPartitioner extends Partitioner<TramitStep1Key, TramitStep1Value> {

    @Override
    public int getPartition(TramitStep1Key taggedKey, TramitStep1Value value, int numPartitions) {
        return Math.abs(taggedKey.hashCodeJoin() % numPartitions);
    }
}