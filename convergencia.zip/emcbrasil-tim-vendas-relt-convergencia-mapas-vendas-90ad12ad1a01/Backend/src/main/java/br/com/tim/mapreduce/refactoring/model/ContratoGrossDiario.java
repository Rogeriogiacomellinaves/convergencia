package br.com.tim.mapreduce.refactoring.model;

import br.com.tim.utils.CommonsConstants;

public class ContratoGrossDiario {
	
	private String skyContrato;
	private String codContratoOltp; 
	private String numTelefone;
	private String datGrossDate;
	private String indTipoPrePos;
	private String dscNivelPlano;
	private String dscTecnologia;
	private String dscTipoFamiliaPlano;
	private String skyPlanoTarifario;

	public ContratoGrossDiario() {
		this.clean();
	}
	
	public void setFromText(String text) {
		int i = 0;
		String[] columns = text.split(CommonsConstants.FILE_SPLIT_REGEX, -1);
		
		skyContrato = columns[i++];
		codContratoOltp = columns[i++];
		numTelefone = columns[i++];
		datGrossDate = columns[i++];
		indTipoPrePos = columns[i++];
		dscNivelPlano = columns[i++];
		dscTecnologia = columns[i++];
		dscTipoFamiliaPlano = columns[i++];
		skyPlanoTarifario = columns[i++];
	}
	
	public void clean() {
		skyContrato = CommonsConstants.EMPTY;
		codContratoOltp = CommonsConstants.EMPTY; 
		numTelefone = CommonsConstants.EMPTY;
		datGrossDate = CommonsConstants.EMPTY;
		indTipoPrePos = CommonsConstants.EMPTY;
		dscNivelPlano = CommonsConstants.EMPTY;
		dscTecnologia = CommonsConstants.EMPTY;
		dscTipoFamiliaPlano = CommonsConstants.EMPTY;
		skyPlanoTarifario = CommonsConstants.EMPTY;
	}

	public String getSkyContrato() {
		return skyContrato;
	}

	public void setSkyContrato(String skyContrato) {
		this.skyContrato = skyContrato;
	}

	public String getCodContratoOltp() {
		return codContratoOltp;
	}

	public void setCodContratoOltp(String codContratoOltp) {
		this.codContratoOltp = codContratoOltp;
	}

	public String getNumTelefone() {
		return numTelefone;
	}

	public void setNumTelefone(String numTelefone) {
		this.numTelefone = numTelefone;
	}

	public String getDatGrossDate() {
		return datGrossDate;
	}

	public void setDatGrossDate(String datGrossDate) {
		this.datGrossDate = datGrossDate;
	}

	public String getIndTipoPrePos() {
		return indTipoPrePos;
	}

	public void setIndTipoPrePos(String indTipoPrePos) {
		this.indTipoPrePos = indTipoPrePos;
	}

	public String getDscNivelPlano() {
		return dscNivelPlano;
	}

	public void setDscNivelPlano(String dscNivelPlano) {
		this.dscNivelPlano = dscNivelPlano;
	}

	public String getDscTecnologia() {
		return dscTecnologia;
	}

	public void setDscTecnologia(String dscTecnologia) {
		this.dscTecnologia = dscTecnologia;
	}

	public String getDscTipoFamiliaPlano() {
		return dscTipoFamiliaPlano;
	}

	public void setDscTipoFamiliaPlano(String dscTipoFamiliaPlano) {
		this.dscTipoFamiliaPlano = dscTipoFamiliaPlano;
	}

	public String getSkyPlanoTarifario() {
		return skyPlanoTarifario;
	}

	public void setSkyPlanoTarifario(String skyPlanoTarifario) {
		this.skyPlanoTarifario = skyPlanoTarifario;
	}
	
}
