package br.com.tim.mapreduce.refactoring.endtoend.step4.utils;

public enum Step4PT6Counters {
	
	STEP1PT4_REDUCER_WRITE, FIBER_MAPPER_WRITE, STEP1PT3_MAPPER_WRITE
}
