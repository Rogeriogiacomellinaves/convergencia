package br.com.tim.mapreduce.refactoring.endtoend.step4.pt1;

import java.time.LocalDate;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.CombineSequenceFileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import br.com.tim.driverutils.DriverUtils;
import br.com.tim.driverutils.Entry;
import br.com.tim.driverutils.Partition;
import br.com.tim.exception.CommonsException;
import br.com.tim.kerberos.KerberosAuth;
import br.com.tim.kerberos.KerberosAuthException;
import br.com.tim.mapreduce.refactoring.endtoend.step4.utils.Step4Constants;
import br.com.tim.metric.JobMetric;
import br.com.tim.metric.JobMetricHelper;
import br.com.tim.metric.MetricConstants;
import br.com.tim.mr.GenericMetricsDriver;
import br.com.tim.utils.CommonsConstants;
import br.com.tim.utils.PropertiesConfig;

public class Step4Driver extends GenericMetricsDriver{

	private static Logger log = Logger.getLogger(Step4Driver.class);
	private Configuration conf;
	private String[] args;
	private FileSystem fs;
	private String stagingPath;
	private static java.time.format.DateTimeFormatter dtf = java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private String dat_ref;

    public Step4Driver (String args[]) {
    	
    	this.args = args;
    	
    }
    
    public static void main(String[] args) throws Exception {
    	
		log.info("============================== BEGIN STEP 4 - HISTORICO JOB ======================================");
		Step4Driver driver = new Step4Driver(args);
		int exitCode = ToolRunner.run(driver, args);
		log.info("Exit code: " + exitCode);
		log.info("=============================== END STEP 4 - HISTORICO JOB =======================================");
		System.exit(exitCode);
    	
    }
	
    protected Job job1;
    
    protected JobMetric metrics = null;
	private int retorno = CommonsConstants.ERROR;

	public String timeExecution;
	public LocalDate dateRef;
    
    
	public int run(String[] arg) throws Exception {

		Date inicio = new Date();
		try {

			if (!PropertiesConfig.systemPropertiesValidate()) {
				if (StringUtils.isEmpty(System.getProperty(CommonsConstants.LOG4J_CONFIGURATION)))
					System.err.println("System property: " + CommonsConstants.LOG4J_CONFIGURATION + " is not set.");
				if (StringUtils.isEmpty(System.getProperty(CommonsConstants.PROJECT_CONFIGURATION)))
					System.err.println("System property: " + CommonsConstants.PROJECT_CONFIGURATION + " is not set.");
				if (StringUtils.isEmpty(System.getProperty(CommonsConstants.ENVIRONMENT_CONFIGURATION)))
					System.err.println("System property: " + CommonsConstants.ENVIRONMENT_CONFIGURATION + " is not set.");
				System.exit(CommonsConstants.ERROR);
			}

			PropertyConfigurator.configure(System.getProperty(CommonsConstants.LOG4J_CONFIGURATION));

			Configuration conf = getConf();
			conf.addResource(new Path(System.getProperty(CommonsConstants.ENVIRONMENT_CONFIGURATION)));
			conf.addResource(new Path(System.getProperty(MetricConstants.JOB_METRICS_CONFIGURATION)));
			conf.addResource(new Path(System.getProperty(CommonsConstants.PROJECT_CONFIGURATION)));
			

			// Kerberos Authentication MapReduce
			try {
				KerberosAuth.authenticate(conf);
			} catch (KerberosAuthException e) {
				throw new Exception(e);
			}

			
			/* ====== CONFIGURE STEP 1 ====== */
            this.job1 = Job.getInstance(conf);
			configureStep4();

			// Create metrics file
			String metricsFilePath = System.getProperty(MetricConstants.GENERIC_FILE_METRICS_DEFINITION);
			String customMetrics = System.getProperty(MetricConstants.CUSTOM_FILE_METRICS_DEFINITION);

			// create JobMetric main job
			if (customMetrics != null)
				metrics = new JobMetric(conf, metricsFilePath, customMetrics);
			else
				metrics = new JobMetric(conf, metricsFilePath);

			if (job1.waitForCompletion(true) && job1.isSuccessful()) {

				log.info("===== Job Finished SUCCESSFULY =====");
				Thread.sleep(Long.valueOf(conf.get(MetricConstants.MILLIS_TO_WAIT)));

				log.info("======================== Running post processing steps... =================================");
				postExecutionSteps();
				retorno = CommonsConstants.SUCCESS;


				log.info("===== Saving Job Metrics ======");
				JobMetricHelper.generateMetrics(this.job1, this.getStagingPath(), metrics);

			} else {
				// Roll back actions in case of any problem during the process.
				log.info("===== ROLLING BACK ======");
				rollback();
				log.info("===== Saving Job Metrics ======");
				JobMetricHelper.generateMetrics(this.job1, this.getStagingPath(), metrics);
			}

		} catch (Exception e) {
			log.error("Generic error executing driver... ", e);
			log.info("===== Saving Job Metrics ======");
			JobMetricHelper.generateMetrics(this.job1, this.getStagingPath(), metrics);
			log.info("===== ROLLING BACK ======");
			rollback();
			throw new CommonsException(e.getMessage(), e);
		}

		log.info("---- Elapsed Time: " + (new Date().getTime() - inicio.getTime()) / 1000 + " seconds.");

		return retorno;

	}
	
    
	@Override
	protected void configure() throws Exception {
		// TODO Auto-generated method stub
		
	}
	
	protected void configureStep4() throws Exception {
		
		conf = this.job1.getConfiguration();
		fs = FileSystem.get(conf);		
		
		try {
			this.configureCommonsStep4();
            this.setProcessDate();
            job1.getConfiguration().set("dat_ref", dat_ref);
		} catch (Exception ex) {
			throw new Exception("Error configuring JOB Commons :" + ex.getMessage());
		}
		
        @SuppressWarnings("rawtypes")
		Class<CombineSequenceFileInputFormat> inputClass = CombineSequenceFileInputFormat.class;
		
        int defaultMinusDays = Integer.valueOf(this.fs.getConf().get("lookback-days", "1"));
        
        Partition MapaHistPartition = new Partition(conf.get(Step4Constants.MAPA_HIST_FACT_PARTITION), Partition.Format.DATE_DAY, Step4Constants.YYYYMMDD, 400, 0, true);
        
		Entry MapaHistEntry = new Entry(conf.get(Step4Constants.STEP4), Step4Constants.MAPA_HIST_FACT_INPUT, false, true, inputClass, MapaHistMapper.class, MapaHistPartition);
		
		DriverUtils.addInputPaths(args, conf, job1, MapaHistEntry);
	    log.info("Data em execução: " + job1.getConfiguration().get("dat_ref"));

	    // Staging PATH
        this.stagingPath = conf.get(Step4Constants.STEP4_STAGING_OUTPUT);
	    Path stagingPathDir = new Path(this.stagingPath);
		
        if (fs.exists(stagingPathDir)) {
            log.info("WARN: Staging: " + stagingPathDir.toString() + " already exists, deleting it...");
            fs.delete(stagingPathDir, true);
        }
		
		log.info("Staging Path: " + stagingPathDir.toString());
		TextOutputFormat.setOutputPath(this.job1,stagingPathDir);
		
	}
	
	private void configureCommonsStep4() throws Exception{
		
		this.job1.setJobName(conf.get("process-id"));
		this.job1.setJarByClass(Step4Driver.class);
		this.job1.setReducerClass(Step4Reducer.class);
		this.job1.setMapOutputKeyClass(Step4Key.class);
		this.job1.setMapOutputValueClass(Step4Value.class);
		this.job1.setOutputKeyClass(NullWritable.class);
		this.job1.setOutputValueClass(Text.class);
		this.job1.setInputFormatClass(TextInputFormat.class);
		this.job1.setOutputFormatClass(TextOutputFormat.class);
		this.job1.setPartitionerClass(JoinPartitioner.class);
		this.job1.setGroupingComparatorClass(GroupingComparator.class);
		
	}
	
	
    private void setProcessDate() {
        dat_ref = dtf.format(LocalDate.now().minusDays(1));

        if (args.length == 1) {
            if (args[0].contains("reprocess-day")) {
                dat_ref = args[0].split("\\=")[1];
            } else if (args[0].contains("reprocess-month")) {
                dat_ref = args[0].split("\\=")[1] + "-01";
            }
        }

    }

}
