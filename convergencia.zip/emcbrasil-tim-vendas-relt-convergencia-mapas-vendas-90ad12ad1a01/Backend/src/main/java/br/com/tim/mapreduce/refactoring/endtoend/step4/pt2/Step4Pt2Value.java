package br.com.tim.mapreduce.refactoring.endtoend.step4.pt2;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.io.Writable;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import br.com.tim.mapreduce.refactoring.endtoend.step4.model.Step4;
import br.com.tim.mapreduce.refactoring.model.BAT509Order;
import br.com.tim.utils.CommonsConstants;

public class Step4Pt2Value implements Writable {
	
	
	

	private TypeStep4Pt2 tipo;
	private String datref;
	private String datCriacaoOrdem;
	private String horaCriacaoDaOrdem;
	private String datVenda;
	private String horaDaVenda;
	private String datStatusOrdem;
	private String hrStatusOrdem;
	private String numOrdemSiebel;
	private String numOrdemSiebelOrig;
	private String codContratoOltp;
	private String codContratoAtivacao;
	private String numeroAcesso;
	private String customerId;
	private String tipoDocumento;
	private String documento;
	private String tipoVenda;
	private String tipoProduto;
	private String velocidadeDownload;
	private String velocidadeUpload;
	private String planoAtivacaoOferta;
	private String loginVendedor;
	private String canal;
	private String cnpjParceiro;
	private String custcode;
	private String position;
	private String flgCancAntesVenda;
	private String flgCancPosVenda;
	private String dtCancVenda;
	private String motivoCancelamento;
	private String nomeCliente;
	private String telefone;
	private String emailFatura;
	private String uf;
	private String tipoLogradouro;
	private String logradouro;
	private String numero;
	private String complemento;
	private String bairro;
	private String cep;
	private String cidade;
	private String statusOrdem;
	private String tecnologia;
	private String formaPagamento;
	private String tipoConta;
	private String codBanco;
	private String codAgengiaBco;
	private String codContaCorrente;
	private String codDebitoAutomatico;
	private String diaVencimento;
	private String semanaVenda;
	private String score;
	private String scoreConsumido;
	private String dtFinalizacaoOrdem;
	private String qdeContratos;
	private String numProtocolo;
	private String flgOrdemAutomatica;
	private String dscTxRecorrente;
	private String dscTxNaoRecorrente;
	private String dscStatusItem;
	private String nomLoginResponsavel;
	private String flgPortabilidade;
	private String dscOperadoraDoadora;
	private String codDdd;
	private String numTelefonePortado;
	private String datJanelaPortabilidade;
	private String horaDaJanela;
	private String dscEnderecoFatura;
	private String dscAreaVoip;
	private String cpe;
	private String ont;
	private String codigoConvergente;
	private String detalheRecusaCrivo;
	private String itemRoot;
	private String loginCancelamentoOrdem;
	private String custcodeCliente;
	private String dominioRoot;
	private String codContFinanceira;
	private String valPlanoAtualItem;
	private String nomDescontoAtualItem;
	private String valDescontoAtualItem;
	private String nroOrdem;
	private String acessoRowId;
	private String acessoRowIdRoot;
	private String codigoProduto;
	private String flgVendaSubmetida;
	private String flgVendaDuplicada;
	private String flgVendaBruta;
	private String flgVendaLiquida;
	private String flgCancDupl;
	private String flgCancLiquido;
	private String nomeParceiroVenda;
	private String nomeParceiroVendaOrig;
	private String rowIdItemOrdem;
	private String rowIdItemOrdemPai;
	private String categoriaItemOrder;
	private String msanOltVenda;
	private String dtConclusaoWfm;
	private String dscStatusOrdemWfm;
	private String datStatusWfm;
	private String horaStatusWfm;
	private String idRecursoWfm;
	private String nomRecursoWfm;
	private String idRecursoPaiWfm;
	private String datPrimeiroAgend;
	private String horaPrimeiroAgendamento;
	private String datAgendAtual;
	private String horaAgendamentoAtual;
	private String dscStatusAtivacao;
	private String msanOltTrafego;
	private String datVendaOrig;
	private String horaVendaOrig;
	private String loginVendedorOrig;
	private String canalOrig;
	private String cnpjParceiroOrig;
	private String custcodeOrig;
	private String positionOrig;
	private String semanaVendaOrig;
	private String codContratoAtual;
	private String nomPlanoAtual;
	private String nomeVendedorOrig;
	private String flVendaDuplicada;
	private String flGross;
	private String dtGross;
	private String flChurn;
	private String dtChurn;
	private String motivoChurn;
	private String codOrdemChurn;
	private String tipoChurn;
	private String dtCriacaoOrdemChurn;
	private String dtConclusaoOrdemChurn;
	private String nomeVendedor;
	private String nomeUsuarioCancOrdem;
	private String emailCliente;

	    DateTimeFormatter dtf = DateTimeFormat.forPattern("MM/dd/yyyy HH:mm:ss");
	    DateTimeFormatter yyyyMMdd = DateTimeFormat.forPattern("yyyyMMdd");
	    Pattern pattern = Pattern.compile("\\d+");

	    @Override
	    public void write(DataOutput out) throws IOException {
	    	out.writeInt(tipo.ordinal());
	    	out.writeUTF(this.datref);
			out.writeUTF(this.datCriacaoOrdem);
			out.writeUTF(this.horaCriacaoDaOrdem);
			out.writeUTF(this.datVenda);
			out.writeUTF(this.horaDaVenda);
			out.writeUTF(this.datStatusOrdem);
			out.writeUTF(this.hrStatusOrdem);
			out.writeUTF(this.numOrdemSiebel);
			out.writeUTF(this.numOrdemSiebelOrig);
			out.writeUTF(this.codContratoOltp);
			out.writeUTF(this.codContratoAtivacao);
			out.writeUTF(this.numeroAcesso);
			out.writeUTF(this.customerId);
			out.writeUTF(this.tipoDocumento);
			out.writeUTF(this.documento);
			out.writeUTF(this.tipoVenda);
			out.writeUTF(this.tipoProduto);
			out.writeUTF(this.velocidadeDownload);
			out.writeUTF(this.velocidadeUpload);
			out.writeUTF(this.planoAtivacaoOferta);
			out.writeUTF(this.loginVendedor);
			out.writeUTF(this.canal);
			out.writeUTF(this.cnpjParceiro);
			out.writeUTF(this.custcode);
			out.writeUTF(this.position);
			out.writeUTF(this.flgCancAntesVenda);
			out.writeUTF(this.flgCancPosVenda);
			out.writeUTF(this.dtCancVenda);
			out.writeUTF(this.motivoCancelamento);
			out.writeUTF(this.nomeCliente);
			out.writeUTF(this.telefone);
			out.writeUTF(this.emailFatura);
			out.writeUTF(this.uf);
			out.writeUTF(this.tipoLogradouro);
			out.writeUTF(this.logradouro);
			out.writeUTF(this.numero);
			out.writeUTF(this.complemento);
			out.writeUTF(this.bairro);
			out.writeUTF(this.cep);
			out.writeUTF(this.cidade);
			out.writeUTF(this.statusOrdem);
			out.writeUTF(this.tecnologia);
			out.writeUTF(this.formaPagamento);
			out.writeUTF(this.tipoConta);
			out.writeUTF(this.codBanco);
			out.writeUTF(this.codAgengiaBco);
			out.writeUTF(this.codContaCorrente);
			out.writeUTF(this.codDebitoAutomatico);
			out.writeUTF(this.diaVencimento);
			out.writeUTF(this.semanaVenda);
			out.writeUTF(this.score);
			out.writeUTF(this.scoreConsumido);
			out.writeUTF(this.dtFinalizacaoOrdem);
			out.writeUTF(this.qdeContratos);
			out.writeUTF(this.numProtocolo);
			out.writeUTF(this.flgOrdemAutomatica);
			out.writeUTF(this.dscTxRecorrente);
			out.writeUTF(this.dscTxNaoRecorrente);
			out.writeUTF(this.dscStatusItem);
			out.writeUTF(this.nomLoginResponsavel);
			out.writeUTF(this.flgPortabilidade);
			out.writeUTF(this.dscOperadoraDoadora);
			out.writeUTF(this.codDdd);
			out.writeUTF(this.numTelefonePortado);
			out.writeUTF(this.datJanelaPortabilidade);
			out.writeUTF(this.horaDaJanela);
			out.writeUTF(this.dscEnderecoFatura);
			out.writeUTF(this.dscAreaVoip);
			out.writeUTF(this.cpe);
			out.writeUTF(this.ont);
			out.writeUTF(this.codigoConvergente);
			out.writeUTF(this.detalheRecusaCrivo);
			out.writeUTF(this.itemRoot);
			out.writeUTF(this.loginCancelamentoOrdem);
			out.writeUTF(this.custcodeCliente);
			out.writeUTF(this.dominioRoot);
			out.writeUTF(this.codContFinanceira);
			out.writeUTF(this.valPlanoAtualItem);
			out.writeUTF(this.nomDescontoAtualItem);
			out.writeUTF(this.valDescontoAtualItem);
			out.writeUTF(this.nroOrdem);
			out.writeUTF(this.acessoRowId);
			out.writeUTF(this.acessoRowIdRoot);
			out.writeUTF(this.codigoProduto);
			out.writeUTF(this.flgVendaSubmetida);
			out.writeUTF(this.flgVendaDuplicada);
			out.writeUTF(this.flgVendaBruta);
			out.writeUTF(this.flgVendaLiquida);
			out.writeUTF(this.flgCancDupl);
			out.writeUTF(this.flgCancLiquido);
			out.writeUTF(this.nomeParceiroVenda);
			out.writeUTF(this.nomeParceiroVendaOrig);
			out.writeUTF(this.rowIdItemOrdem);
			out.writeUTF(this.rowIdItemOrdemPai);
			out.writeUTF(this.categoriaItemOrder);
			out.writeUTF(this.datVendaOrig);
			out.writeUTF(this.horaVendaOrig);
			out.writeUTF(this.loginVendedorOrig);
			out.writeUTF(this.canalOrig);
			out.writeUTF(this.cnpjParceiroOrig);
			out.writeUTF(this.custcodeOrig);
			out.writeUTF(this.positionOrig);
			out.writeUTF(this.semanaVendaOrig);
			out.writeUTF(this.codContratoAtual);
			out.writeUTF(this.nomPlanoAtual);
			out.writeUTF(this.nomeVendedorOrig);
			out.writeUTF(this.flVendaDuplicada);
			out.writeUTF(this.flGross);
			out.writeUTF(this.dtGross);
			out.writeUTF(this.flChurn);
			out.writeUTF(this.dtChurn);
			out.writeUTF(this.motivoChurn);
			out.writeUTF(this.codOrdemChurn);
			out.writeUTF(this.tipoChurn);
			out.writeUTF(this.dtCriacaoOrdemChurn);
			out.writeUTF(this.dtConclusaoOrdemChurn);
			out.writeUTF(this.msanOltVenda);
			out.writeUTF(this.dtConclusaoWfm);
			out.writeUTF(this.dscStatusOrdemWfm);
			out.writeUTF(this.datStatusWfm);
			out.writeUTF(this.horaStatusWfm);
			out.writeUTF(this.idRecursoWfm);
			out.writeUTF(this.nomRecursoWfm);
			out.writeUTF(this.idRecursoPaiWfm);
			out.writeUTF(this.datPrimeiroAgend);
			out.writeUTF(this.horaPrimeiroAgendamento);
			out.writeUTF(this.datAgendAtual);
			out.writeUTF(this.horaAgendamentoAtual);
			out.writeUTF(this.dscStatusAtivacao);
			out.writeUTF(this.msanOltTrafego);
			out.writeUTF(this.nomeVendedor);
			out.writeUTF(this.nomeUsuarioCancOrdem);
			out.writeUTF(this.emailCliente);


	    }

	    @Override
	    public void readFields(DataInput in) throws IOException {
	        
	    	this.tipo = TypeStep4Pt2.values()[in.readInt()];
	        this.datref = in.readUTF();
			this.datCriacaoOrdem = in.readUTF();
			this.horaCriacaoDaOrdem = in.readUTF();
			this.datVenda = in.readUTF();
			this.horaDaVenda = in.readUTF();
			this.datStatusOrdem = in.readUTF();
			this.hrStatusOrdem = in.readUTF();
			this.numOrdemSiebel = in.readUTF();
			this.numOrdemSiebelOrig = in.readUTF();
			this.codContratoOltp = in.readUTF();
			this.codContratoAtivacao = in.readUTF();
			this.numeroAcesso = in.readUTF();
			this.customerId = in.readUTF();
			this.tipoDocumento = in.readUTF();
			this.documento = in.readUTF();
			this.tipoVenda = in.readUTF();
			this.tipoProduto = in.readUTF();
			this.velocidadeDownload = in.readUTF();
			this.velocidadeUpload = in.readUTF();
			this.planoAtivacaoOferta = in.readUTF();
			this.loginVendedor = in.readUTF();
			this.canal = in.readUTF();
			this.cnpjParceiro = in.readUTF();
			this.custcode = in.readUTF();
			this.position = in.readUTF();
			this.flgCancAntesVenda = in.readUTF();
			this.flgCancPosVenda = in.readUTF();
			this.dtCancVenda = in.readUTF();
			this.motivoCancelamento = in.readUTF();
			this.nomeCliente = in.readUTF();
			this.telefone = in.readUTF();
			this.emailFatura = in.readUTF();
			this.uf = in.readUTF();
			this.tipoLogradouro = in.readUTF();
			this.logradouro = in.readUTF();
			this.numero = in.readUTF();
			this.complemento = in.readUTF();
			this.bairro = in.readUTF();
			this.cep = in.readUTF();
			this.cidade = in.readUTF();
			this.statusOrdem = in.readUTF();
			this.tecnologia = in.readUTF();
			this.formaPagamento = in.readUTF();
			this.tipoConta = in.readUTF();
			this.codBanco = in.readUTF();
			this.codAgengiaBco = in.readUTF();
			this.codContaCorrente = in.readUTF();
			this.codDebitoAutomatico = in.readUTF();
			this.diaVencimento = in.readUTF();
			this.semanaVenda = in.readUTF();
			this.score = in.readUTF();
			this.scoreConsumido = in.readUTF();
			this.dtFinalizacaoOrdem = in.readUTF();
			this.qdeContratos = in.readUTF();
			this.numProtocolo = in.readUTF();
			this.flgOrdemAutomatica = in.readUTF();
			this.dscTxRecorrente = in.readUTF();
			this.dscTxNaoRecorrente = in.readUTF();
			this.dscStatusItem = in.readUTF();
			this.nomLoginResponsavel = in.readUTF();
			this.flgPortabilidade = in.readUTF();
			this.dscOperadoraDoadora = in.readUTF();
			this.codDdd = in.readUTF();
			this.numTelefonePortado = in.readUTF();
			this.datJanelaPortabilidade = in.readUTF();
			this.horaDaJanela = in.readUTF();
			this.dscEnderecoFatura = in.readUTF();
			this.dscAreaVoip = in.readUTF();
			this.cpe = in.readUTF();
			this.ont = in.readUTF();
			this.codigoConvergente = in.readUTF();
			this.detalheRecusaCrivo = in.readUTF();
			this.itemRoot = in.readUTF();
			this.loginCancelamentoOrdem = in.readUTF();
			this.custcodeCliente = in.readUTF();
			this.dominioRoot = in.readUTF();
			this.codContFinanceira = in.readUTF();
			this.valPlanoAtualItem = in.readUTF();
			this.nomDescontoAtualItem = in.readUTF();
			this.valDescontoAtualItem = in.readUTF();
			this.nroOrdem = in.readUTF();
			this.acessoRowId = in.readUTF();
			this.acessoRowIdRoot = in.readUTF();
			this.codigoProduto = in.readUTF();
			this.flgVendaSubmetida = in.readUTF();
			this.flgVendaDuplicada = in.readUTF();
			this.flgVendaBruta = in.readUTF();
			this.flgVendaLiquida = in.readUTF();
			this.flgCancDupl = in.readUTF();
			this.flgCancLiquido = in.readUTF();
			this.nomeParceiroVenda = in.readUTF();
			this.nomeParceiroVendaOrig = in.readUTF();
			this.rowIdItemOrdem = in.readUTF();
			this.rowIdItemOrdemPai = in.readUTF();
			this.categoriaItemOrder = in.readUTF();
			this.datVendaOrig = in.readUTF();
			this.horaVendaOrig = in.readUTF();
			this.loginVendedorOrig = in.readUTF();
			this.canalOrig = in.readUTF();
			this.cnpjParceiroOrig = in.readUTF();
			this.custcodeOrig = in.readUTF();
			this.positionOrig = in.readUTF();
			this.semanaVendaOrig = in.readUTF();
			this.codContratoAtual = in.readUTF();
			this.nomPlanoAtual = in.readUTF();
			this.nomeVendedorOrig = in.readUTF();
			this.flVendaDuplicada = in.readUTF();
			this.flGross = in.readUTF();
			this.dtGross = in.readUTF();
			this.flChurn = in.readUTF();
			this.dtChurn = in.readUTF();
			this.motivoChurn = in.readUTF();
			this.codOrdemChurn = in.readUTF();
			this.tipoChurn = in.readUTF();
			this.dtCriacaoOrdemChurn = in.readUTF();
			this.dtConclusaoOrdemChurn = in.readUTF();
			this.msanOltVenda = in.readUTF();
			this.dtConclusaoWfm = in.readUTF();
			this.dscStatusOrdemWfm = in.readUTF();
			this.datStatusWfm = in.readUTF();
			this.horaStatusWfm = in.readUTF();
			this.idRecursoWfm = in.readUTF();
			this.nomRecursoWfm = in.readUTF();
			this.idRecursoPaiWfm = in.readUTF();
			this.datPrimeiroAgend = in.readUTF();
			this.horaPrimeiroAgendamento = in.readUTF();
			this.datAgendAtual = in.readUTF();
			this.horaAgendamentoAtual = in.readUTF();
			this.dscStatusAtivacao = in.readUTF();
			this.msanOltTrafego = in.readUTF();
			this.nomeVendedor = in.readUTF();
			this.nomeUsuarioCancOrdem = in.readUTF();
			this.emailCliente = in.readUTF();
	    }
	    
	    
	    public void setStep4Pt1Result(Step4 v) {
	    this.clear();
	    this.tipo = TypeStep4Pt2.STEP4;
		this.datref = v.getDatref();
		this.datCriacaoOrdem = v.getDatCriacaoOrdem();
		this.horaCriacaoDaOrdem = v.getHoraCriacaoDaOrdem();
		this.datVenda = v.getDatVenda();
		this.horaDaVenda = v.getHoraDaVenda();
		this.datStatusOrdem = v.getDatStatusOrdem();
		this.hrStatusOrdem = v.getHrStatusOrdem();
		this.numOrdemSiebel = v.getNumOrdemSiebel();
		this.numOrdemSiebelOrig = v.getNumOrdemSiebelOrig();
		this.codContratoOltp = v.getCodContratoOltp();
		this.codContratoAtivacao = v.getCodContratoAtivacao();
		this.numeroAcesso = v.getNumeroAcesso();
		this.customerId = v.getCustomerId();
		this.tipoDocumento = v.getTipoDocumento();
		this.documento = v.getDocumento();
		this.tipoVenda = v.getTipoVenda();
		this.tipoProduto = v.getTipoProduto();
		this.velocidadeDownload = v.getVelocidadeDownload();
		this.velocidadeUpload = v.getVelocidadeUpload();
		this.planoAtivacaoOferta = v.getPlanoAtivacaoOferta();
		this.loginVendedor = v.getLoginVendedor();
		this.canal = v.getCanal();
		this.cnpjParceiro = v.getCnpjParceiro();
		this.custcode = v.getCustcode();
		this.position = v.getPosition();
		this.flgCancAntesVenda = v.getFlgCancAntesVenda();
		this.flgCancPosVenda = v.getFlgCancPosVenda();
		this.dtCancVenda = v.getDtCancVenda();
		this.motivoCancelamento = v.getMotivoCancelamento();
		this.nomeCliente = v.getNomeCliente();
		this.telefone = v.getTelefone();
		this.emailFatura = v.getEmailFatura();
		this.uf = v.getUf();
		this.tipoLogradouro = v.getTipoLogradouro();
		this.logradouro = v.getLogradouro();
		this.numero = v.getNumero();
		this.complemento = v.getComplemento();
		this.bairro = v.getBairro();
		this.cep = v.getCep();
		this.cidade = v.getCidade();
		this.statusOrdem = v.getStatusOrdem();
		this.tecnologia = v.getTecnologia();
		this.formaPagamento = v.getFormaPagamento();
		this.tipoConta = v.getTipoConta();
		this.codBanco = v.getCodBanco();
		this.codAgengiaBco = v.getCodAgengiaBco();
		this.codContaCorrente = v.getCodContaCorrente();
		this.codDebitoAutomatico = v.getCodDebitoAutomatico();
		this.diaVencimento = v.getDiaVencimento();
		this.semanaVenda = v.getSemanaVenda();
		this.score = v.getScore();
		this.scoreConsumido = v.getScoreConsumido();
		this.dtFinalizacaoOrdem = v.getDtFinalizacaoOrdem();
		this.qdeContratos = v.getQdeContratos();
		this.numProtocolo = v.getNumProtocolo();
		this.flgOrdemAutomatica = v.getFlgOrdemAutomatica();
		this.dscTxRecorrente = v.getDscTxRecorrente();
		this.dscTxNaoRecorrente = v.getDscTxNaoRecorrente();
		this.dscStatusItem = v.getDscStatusItem();
		this.nomLoginResponsavel = v.getNomLoginResponsavel();
		this.flgPortabilidade = v.getFlgPortabilidade();
		this.dscOperadoraDoadora = v.getDscOperadoraDoadora();
		this.codDdd = v.getCodDdd();
		this.numTelefonePortado = v.getNumTelefonePortado();
		this.datJanelaPortabilidade = v.getDatJanelaPortabilidade();
		this.horaDaJanela = v.getHoraDaJanela();
		this.dscEnderecoFatura = v.getDscEnderecoFatura();
		this.dscAreaVoip = v.getDscAreaVoip();
		this.cpe = v.getCpe();
		this.ont = v.getOnt();
		this.codigoConvergente = v.getCodigoConvergente();
		this.detalheRecusaCrivo = v.getDetalheRecusaCrivo();
		this.itemRoot = v.getItemRoot();
		this.loginCancelamentoOrdem = v.getLoginCancelamentoOrdem();
		this.custcodeCliente = v.getCustcodeCliente();
		this.dominioRoot = v.getDominioRoot();
		this.codContFinanceira = v.getCodContFinanceira();
		this.valPlanoAtualItem = v.getValPlanoAtualItem();
		this.nomDescontoAtualItem = v.getNomDescontoAtualItem();
		this.valDescontoAtualItem = v.getValDescontoAtualItem();
		this.nroOrdem = v.getNroOrdem();
		this.acessoRowId = v.getAcessoRowId();
		this.acessoRowIdRoot = v.getAcessoRowIdRoot();
		this.codigoProduto = v.getCodigoProduto();
		this.flgVendaSubmetida = v.getFlgVendaSubmetida();
		this.flgVendaDuplicada = v.getFlgVendaDuplicada();
		this.flgVendaBruta = v.getFlgVendaBruta();
		this.flgVendaLiquida = v.getFlgVendaLiquida();
		this.flgCancDupl = v.getFlgCancDupl();
		this.flgCancLiquido = v.getFlgCancLiquido();
		this.nomeParceiroVenda = v.getNomeParceiroVenda();
		this.nomeParceiroVendaOrig = v.getNomeParceiroVendaOrig();
		this.rowIdItemOrdem = v.getRowIdItemOrdem();
		this.rowIdItemOrdemPai = v.getRowIdItemOrdemPai();
		this.categoriaItemOrder = v.getCategoriaItemOrder();
		this.msanOltVenda = v.getMsanOltVenda();
		this.dtConclusaoWfm = v.getDtConclusaoWfm();
		this.dscStatusOrdemWfm = v.getDscStatusOrdemWfm();
		this.datStatusWfm = v.getDatStatusWfm();
		this.horaStatusWfm = v.getHoraStatusWfm();
		this.idRecursoWfm = v.getIdRecursoWfm();
		this.nomRecursoWfm = v.getNomRecursoWfm();
		this.idRecursoPaiWfm = v.getIdRecursoPaiWfm();
		this.datPrimeiroAgend = v.getDatPrimeiroAgend();
		this.horaPrimeiroAgendamento = v.getHoraPrimeiroAgendamento();
		this.datAgendAtual = v.getDatAgendAtual();
		this.horaAgendamentoAtual = v.getHoraAgendamentoAtual();
		this.dscStatusAtivacao = v.getDscStatusAtivacao();
		this.msanOltTrafego = v.getMsanOltTrafego();
		this.datVendaOrig = v.getDatVendaOrig();
		this.horaVendaOrig = v.getHoraVendaOrig();
		this.loginVendedorOrig = v.getLoginVendedorOrig();
		this.canalOrig = v.getCanalOrig();
		this.cnpjParceiroOrig = v.getCnpjParceiroOrig();
		this.custcodeOrig = v.getCustcodeOrig();
		this.positionOrig = v.getPositionOrig();
		this.semanaVendaOrig = v.getSemanaVendaOrig();
		this.codContratoAtual = v.getCodContratoAtual();
		this.nomPlanoAtual = v.getNomPlanoAtual();
		this.nomeVendedorOrig = v.getNomeVendedorOrig();
		this.flVendaDuplicada = v.getFlVendaDuplicada();
		this.flGross = v.getFlGross();
		this.dtGross = v.getDtGross();
		this.flChurn = v.getFlChurn();
		this.dtChurn = v.getDtChurn();
		this.motivoChurn = v.getMotivoChurn();
		this.codOrdemChurn = v.getCodOrdemChurn();
		this.tipoChurn = v.getTipoChurn();
		this.dtCriacaoOrdemChurn = v.getDtCriacaoOrdemChurn();
		this.dtConclusaoOrdemChurn = v.getDtConclusaoOrdemChurn();
		this.nomeVendedor = v.getNomeVendedor();
		this.nomeUsuarioCancOrdem = v.getNomeUsuarioCancOrdem();
		this.emailCliente = v.getEmailCliente();
    }
	    
	    public void setOrdem(BAT509Order ordem) {
		    this.clear();

	    	this.tipo = TypeStep4Pt2.ORDER;
	        if(StringUtils.isNotEmpty(ordem.getDataCriacaoOrdem())) {
	            this.datCriacaoOrdem = ordem.getDataCriacaoOrdem().substring(0, 10);
	            this.horaCriacaoDaOrdem = ordem.getDataCriacaoOrdem().substring(11, 19);
	        }
	        if(StringUtils.isNotEmpty(ordem.getDataVenda())) {
	            this.datVenda = ordem.getDataVenda().substring(0, 10);
	            this.horaDaVenda = ordem.getDataVenda().substring(11, 19);
	        }
	        if(StringUtils.isNotEmpty(ordem.getDataStatusOrdem())) {
	            this.datStatusOrdem = ordem.getDataStatusOrdem().substring(0, 10);
	            this.hrStatusOrdem = ordem.getDataStatusOrdem().substring(11, 19);
	        }
	        this.numOrdemSiebel = ordem.getNumeroOrdem();
	        if (ordem.getNumeroCliente().length() == 11)
	            this.tipoDocumento = "CPF";
	        else
	            this.tipoDocumento = "CNPJ";
	        this.documento = ordem.getNumeroCliente();
	        this.tipoVenda = ordem.getSubTipoOrdem();
	        this.loginVendedor = ordem.getLoginVendedor();
	        this.canal = ordem.getCanalVenda();
	        this.cnpjParceiro = ordem.getCnpjParceiroVenda();
	        this.custcode = ordem.getCustcodePDV();
	        this.position = ordem.getNomeParceiroVenda();

	        if(ordem.getStatusOrdem().equals("Cancelado") && StringUtils.isEmpty(ordem.getDataVenda()))
	            this.flgCancAntesVenda = "1";
	        else
	            this.flgCancAntesVenda = "0";

	        if(StringUtils.isEmpty(ordem.getDataVenda()))
	            this.flgVendaSubmetida = "0";
	        else
	            this.flgVendaSubmetida = "1";
	        
	        if(ordem.getStatusOrdem().equals("Cancelado"))
	            this.dtCancVenda = ordem.getDatafinalizacaoOrdem();
	        this.motivoCancelamento = ordem.getMotivoCancelamentoOrdem();
	        this.nomeCliente = ordem.getNomeCliente();
	        this.telefone = ordem.getTelefoneContato1();
	        this.statusOrdem = ordem.getStatusOrdem();
	        if(StringUtils.isNotEmpty(ordem.getDataVenda())) {
//	            Matcher m = pattern.matcher(Weeks.weeksBetween(dtf.parseLocalDate(ordem.getDataVenda()), yyyyMMdd.parseLocalDate(context.getConfiguration().get("dat-ref"))).toString());
//	            while (m.find()) {
//	                this.semanaVenda = m.group();
//	            }
	            this.semanaVenda = String.valueOf(dtf.parseLocalDate(ordem.getDataVenda()).getWeekOfWeekyear()).concat("-").concat(String.valueOf(dtf.parseLocalDate(ordem.getDataVenda()).getYear()));
	        } else
	            this.semanaVenda = StringUtils.EMPTY;

	        this.score = ordem.getScoreCliente();
	        this.scoreConsumido = ordem.getScoreConsumido();
	        this.dtFinalizacaoOrdem = ordem.getDatafinalizacaoOrdem();
	        this.qdeContratos = ordem.getNumeroContratos();
	        this.nomLoginResponsavel = ordem.getLoginResponsavel();
	        this.detalheRecusaCrivo = ordem.getMotivoRecusaCrivo();
	        this.loginCancelamentoOrdem = ordem.getLoginCancelamentoOrdem();
	        this.nomeParceiroVenda = ordem.getNomeParceiroVenda();
	    }

	    public void clear(){
	        this.tipo = null;
	        this.datref = CommonsConstants.EMPTY;
			this.datCriacaoOrdem = CommonsConstants.EMPTY;
			this.horaCriacaoDaOrdem = CommonsConstants.EMPTY;
			this.datVenda = CommonsConstants.EMPTY;
			this.horaDaVenda = CommonsConstants.EMPTY;
			this.datStatusOrdem = CommonsConstants.EMPTY;
			this.hrStatusOrdem = CommonsConstants.EMPTY;
			this.numOrdemSiebel = CommonsConstants.EMPTY;
			this.numOrdemSiebelOrig = CommonsConstants.EMPTY;
			this.codContratoOltp = CommonsConstants.EMPTY;
			this.codContratoAtivacao = CommonsConstants.EMPTY;
			this.numeroAcesso = CommonsConstants.EMPTY;
			this.customerId = CommonsConstants.EMPTY;
			this.tipoDocumento = CommonsConstants.EMPTY;
			this.documento = CommonsConstants.EMPTY;
			this.tipoVenda = CommonsConstants.EMPTY;
			this.tipoProduto = CommonsConstants.EMPTY;
			this.velocidadeDownload = CommonsConstants.EMPTY;
			this.velocidadeUpload = CommonsConstants.EMPTY;
			this.planoAtivacaoOferta = CommonsConstants.EMPTY;
			this.loginVendedor = CommonsConstants.EMPTY;
			this.canal = CommonsConstants.EMPTY;
			this.cnpjParceiro = CommonsConstants.EMPTY;
			this.custcode = CommonsConstants.EMPTY;
			this.position = CommonsConstants.EMPTY;
			this.flgCancAntesVenda = CommonsConstants.EMPTY;
			this.flgCancPosVenda = CommonsConstants.EMPTY;
			this.dtCancVenda = CommonsConstants.EMPTY;
			this.motivoCancelamento = CommonsConstants.EMPTY;
			this.nomeCliente = CommonsConstants.EMPTY;
			this.telefone = CommonsConstants.EMPTY;
			this.emailFatura = CommonsConstants.EMPTY;
			this.uf = CommonsConstants.EMPTY;
			this.tipoLogradouro = CommonsConstants.EMPTY;
			this.logradouro = CommonsConstants.EMPTY;
			this.numero = CommonsConstants.EMPTY;
			this.complemento = CommonsConstants.EMPTY;
			this.bairro = CommonsConstants.EMPTY;
			this.cep = CommonsConstants.EMPTY;
			this.cidade = CommonsConstants.EMPTY;
			this.statusOrdem = CommonsConstants.EMPTY;
			this.tecnologia = CommonsConstants.EMPTY;
			this.formaPagamento = CommonsConstants.EMPTY;
			this.tipoConta = CommonsConstants.EMPTY;
			this.codBanco = CommonsConstants.EMPTY;
			this.codAgengiaBco = CommonsConstants.EMPTY;
			this.codContaCorrente = CommonsConstants.EMPTY;
			this.codDebitoAutomatico = CommonsConstants.EMPTY;
			this.diaVencimento = CommonsConstants.EMPTY;
			this.semanaVenda = CommonsConstants.EMPTY;
			this.score = CommonsConstants.EMPTY;
			this.scoreConsumido = CommonsConstants.EMPTY;
			this.dtFinalizacaoOrdem = CommonsConstants.EMPTY;
			this.qdeContratos = CommonsConstants.EMPTY;
			this.numProtocolo = CommonsConstants.EMPTY;
			this.flgOrdemAutomatica = CommonsConstants.EMPTY;
			this.dscTxRecorrente = CommonsConstants.EMPTY;
			this.dscTxNaoRecorrente = CommonsConstants.EMPTY;
			this.dscStatusItem = CommonsConstants.EMPTY;
			this.nomLoginResponsavel = CommonsConstants.EMPTY;
			this.flgPortabilidade = CommonsConstants.EMPTY;
			this.dscOperadoraDoadora = CommonsConstants.EMPTY;
			this.codDdd = CommonsConstants.EMPTY;
			this.numTelefonePortado = CommonsConstants.EMPTY;
			this.datJanelaPortabilidade = CommonsConstants.EMPTY;
			this.horaDaJanela = CommonsConstants.EMPTY;
			this.dscEnderecoFatura = CommonsConstants.EMPTY;
			this.dscAreaVoip = CommonsConstants.EMPTY;
			this.cpe = CommonsConstants.EMPTY;
			this.ont = CommonsConstants.EMPTY;
			this.codigoConvergente = CommonsConstants.EMPTY;
			this.detalheRecusaCrivo = CommonsConstants.EMPTY;
			this.itemRoot = CommonsConstants.EMPTY;
			this.loginCancelamentoOrdem = CommonsConstants.EMPTY;
			this.custcodeCliente = CommonsConstants.EMPTY;
			this.dominioRoot = CommonsConstants.EMPTY;
			this.codContFinanceira = CommonsConstants.EMPTY;
			this.valPlanoAtualItem = CommonsConstants.EMPTY;
			this.nomDescontoAtualItem = CommonsConstants.EMPTY;
			this.valDescontoAtualItem = CommonsConstants.EMPTY;
			this.nroOrdem = CommonsConstants.EMPTY;
			this.acessoRowId = CommonsConstants.EMPTY;
			this.acessoRowIdRoot = CommonsConstants.EMPTY;
			this.codigoProduto = CommonsConstants.EMPTY;
			this.flgVendaSubmetida = CommonsConstants.EMPTY;
			this.flgVendaDuplicada = CommonsConstants.EMPTY;
			this.flgVendaBruta = CommonsConstants.EMPTY;
			this.flgVendaLiquida = CommonsConstants.EMPTY;
			this.flgCancDupl = CommonsConstants.EMPTY;
			this.flgCancLiquido = CommonsConstants.EMPTY;
			this.nomeParceiroVenda = CommonsConstants.EMPTY;
			this.nomeParceiroVendaOrig = CommonsConstants.EMPTY;
			this.rowIdItemOrdem = CommonsConstants.EMPTY;
			this.rowIdItemOrdemPai = CommonsConstants.EMPTY;
			this.categoriaItemOrder = CommonsConstants.EMPTY;
			this.datVendaOrig = CommonsConstants.EMPTY;
			this.horaVendaOrig = CommonsConstants.EMPTY;
			this.loginVendedorOrig = CommonsConstants.EMPTY;
			this.canalOrig = CommonsConstants.EMPTY;
			this.cnpjParceiroOrig = CommonsConstants.EMPTY;
			this.custcodeOrig = CommonsConstants.EMPTY;
			this.positionOrig = CommonsConstants.EMPTY;
			this.semanaVendaOrig = CommonsConstants.EMPTY;
			this.codContratoAtual = CommonsConstants.EMPTY;
			this.nomPlanoAtual = CommonsConstants.EMPTY;
			this.nomeVendedorOrig = CommonsConstants.EMPTY;
			this.flVendaDuplicada = CommonsConstants.EMPTY;
			this.flGross = CommonsConstants.EMPTY;
			this.dtGross = CommonsConstants.EMPTY;
			this.flChurn = CommonsConstants.EMPTY;
			this.dtChurn = CommonsConstants.EMPTY;
			this.motivoChurn = CommonsConstants.EMPTY;
			this.codOrdemChurn = CommonsConstants.EMPTY;
			this.tipoChurn = CommonsConstants.EMPTY;
			this.dtCriacaoOrdemChurn = CommonsConstants.EMPTY;
			this.dtConclusaoOrdemChurn = CommonsConstants.EMPTY;
			this.msanOltVenda = CommonsConstants.EMPTY;
			this.dtConclusaoWfm = CommonsConstants.EMPTY;
			this.dscStatusOrdemWfm = CommonsConstants.EMPTY;
			this.datStatusWfm = CommonsConstants.EMPTY;
			this.horaStatusWfm = CommonsConstants.EMPTY;
			this.idRecursoWfm = CommonsConstants.EMPTY;
			this.nomRecursoWfm = CommonsConstants.EMPTY;
			this.idRecursoPaiWfm = CommonsConstants.EMPTY;
			this.datPrimeiroAgend = CommonsConstants.EMPTY;
			this.horaPrimeiroAgendamento = CommonsConstants.EMPTY;
			this.datAgendAtual = CommonsConstants.EMPTY;
			this.horaAgendamentoAtual = CommonsConstants.EMPTY;
			this.dscStatusAtivacao = CommonsConstants.EMPTY;
			this.msanOltTrafego = CommonsConstants.EMPTY;
			this.nomeVendedor = CommonsConstants.EMPTY;
			this.nomeUsuarioCancOrdem = CommonsConstants.EMPTY;
			this.emailCliente = CommonsConstants.EMPTY;
	    }
	    
	    
	    

	    public Step4Pt2Value() {
	    				
		}

		public TypeStep4Pt2 getTipo() {
			return tipo;
		}

		public void setTipo(TypeStep4Pt2 tipo) {
			this.tipo = tipo;
		}

		public String getDatref() {
			return datref;
		}

		public void setDatref(String datref) {
			this.datref = datref;
		}

		public String getDatCriacaoOrdem() {
			return datCriacaoOrdem;
		}

		public void setDatCriacaoOrdem(String datCriacaoOrdem) {
			this.datCriacaoOrdem = datCriacaoOrdem;
		}

		public String getHoraCriacaoDaOrdem() {
			return horaCriacaoDaOrdem;
		}

		public void setHoraCriacaoDaOrdem(String horaCriacaoDaOrdem) {
			this.horaCriacaoDaOrdem = horaCriacaoDaOrdem;
		}

		public String getDatVenda() {
			return datVenda;
		}

		public void setDatVenda(String datVenda) {
			this.datVenda = datVenda;
		}

		public String getHoraDaVenda() {
			return horaDaVenda;
		}

		public void setHoraDaVenda(String horaDaVenda) {
			this.horaDaVenda = horaDaVenda;
		}

		public String getDatStatusOrdem() {
			return datStatusOrdem;
		}

		public void setDatStatusOrdem(String datStatusOrdem) {
			this.datStatusOrdem = datStatusOrdem;
		}

		public String getHrStatusOrdem() {
			return hrStatusOrdem;
		}

		public void setHrStatusOrdem(String hrStatusOrdem) {
			this.hrStatusOrdem = hrStatusOrdem;
		}

		public String getNumOrdemSiebel() {
			return numOrdemSiebel;
		}

		public void setNumOrdemSiebel(String numOrdemSiebel) {
			this.numOrdemSiebel = numOrdemSiebel;
		}

		public String getNumOrdemSiebelOrig() {
			return numOrdemSiebelOrig;
		}

		public void setNumOrdemSiebelOrig(String numOrdemSiebelOrig) {
			this.numOrdemSiebelOrig = numOrdemSiebelOrig;
		}

		public String getCodContratoOltp() {
			return codContratoOltp;
		}

		public void setCodContratoOltp(String codContratoOltp) {
			this.codContratoOltp = codContratoOltp;
		}

		public String getCodContratoAtivacao() {
			return codContratoAtivacao;
		}

		public void setCodContratoAtivacao(String codContratoAtivacao) {
			this.codContratoAtivacao = codContratoAtivacao;
		}

		public String getNumeroAcesso() {
			return numeroAcesso;
		}

		public void setNumeroAcesso(String numeroAcesso) {
			this.numeroAcesso = numeroAcesso;
		}

		public String getCustomerId() {
			return customerId;
		}

		public void setCustomerId(String customerId) {
			this.customerId = customerId;
		}

		public String getTipoDocumento() {
			return tipoDocumento;
		}

		public void setTipoDocumento(String tipoDocumento) {
			this.tipoDocumento = tipoDocumento;
		}

		public String getDocumento() {
			return documento;
		}

		public void setDocumento(String documento) {
			this.documento = documento;
		}

		public String getTipoVenda() {
			return tipoVenda;
		}

		public void setTipoVenda(String tipoVenda) {
			this.tipoVenda = tipoVenda;
		}

		public String getTipoProduto() {
			return tipoProduto;
		}

		public void setTipoProduto(String tipoProduto) {
			this.tipoProduto = tipoProduto;
		}

		public String getVelocidadeDownload() {
			return velocidadeDownload;
		}

		public void setVelocidadeDownload(String velocidadeDownload) {
			this.velocidadeDownload = velocidadeDownload;
		}

		public String getVelocidadeUpload() {
			return velocidadeUpload;
		}

		public void setVelocidadeUpload(String velocidadeUpload) {
			this.velocidadeUpload = velocidadeUpload;
		}

		public String getPlanoAtivacaoOferta() {
			return planoAtivacaoOferta;
		}

		public void setPlanoAtivacaoOferta(String planoAtivacaoOferta) {
			this.planoAtivacaoOferta = planoAtivacaoOferta;
		}

		public String getLoginVendedor() {
			return loginVendedor;
		}

		public void setLoginVendedor(String loginVendedor) {
			this.loginVendedor = loginVendedor;
		}

		public String getCanal() {
			return canal;
		}

		public void setCanal(String canal) {
			this.canal = canal;
		}

		public String getCnpjParceiro() {
			return cnpjParceiro;
		}

		public void setCnpjParceiro(String cnpjParceiro) {
			this.cnpjParceiro = cnpjParceiro;
		}

		public String getCustcode() {
			return custcode;
		}

		public void setCustcode(String custcode) {
			this.custcode = custcode;
		}

		public String getPosition() {
			return position;
		}

		public void setPosition(String position) {
			this.position = position;
		}

		public String getFlgCancAntesVenda() {
			return flgCancAntesVenda;
		}

		public void setFlgCancAntesVenda(String flgCancAntesVenda) {
			this.flgCancAntesVenda = flgCancAntesVenda;
		}

		public String getFlgCancPosVenda() {
			return flgCancPosVenda;
		}

		public void setFlgCancPosVenda(String flgCancPosVenda) {
			this.flgCancPosVenda = flgCancPosVenda;
		}

		public String getDtCancVenda() {
			return dtCancVenda;
		}

		public void setDtCancVenda(String dtCancVenda) {
			this.dtCancVenda = dtCancVenda;
		}

		public String getMotivoCancelamento() {
			return motivoCancelamento;
		}

		public void setMotivoCancelamento(String motivoCancelamento) {
			this.motivoCancelamento = motivoCancelamento;
		}

		public String getNomeCliente() {
			return nomeCliente;
		}

		public void setNomeCliente(String nomeCliente) {
			this.nomeCliente = nomeCliente;
		}

		public String getTelefone() {
			return telefone;
		}

		public void setTelefone(String telefone) {
			this.telefone = telefone;
		}

		public String getEmailFatura() {
			return emailFatura;
		}

		public void setEmailFatura(String emailFatura) {
			this.emailFatura = emailFatura;
		}

		public String getUf() {
			return uf;
		}

		public void setUf(String uf) {
			this.uf = uf;
		}

		public String getTipoLogradouro() {
			return tipoLogradouro;
		}

		public void setTipoLogradouro(String tipoLogradouro) {
			this.tipoLogradouro = tipoLogradouro;
		}

		public String getLogradouro() {
			return logradouro;
		}

		public void setLogradouro(String logradouro) {
			this.logradouro = logradouro;
		}

		public String getNumero() {
			return numero;
		}

		public void setNumero(String numero) {
			this.numero = numero;
		}

		public String getComplemento() {
			return complemento;
		}

		public void setComplemento(String complemento) {
			this.complemento = complemento;
		}

		public String getBairro() {
			return bairro;
		}

		public void setBairro(String bairro) {
			this.bairro = bairro;
		}

		public String getCep() {
			return cep;
		}

		public void setCep(String cep) {
			this.cep = cep;
		}

		public String getCidade() {
			return cidade;
		}

		public void setCidade(String cidade) {
			this.cidade = cidade;
		}

		public String getStatusOrdem() {
			return statusOrdem;
		}

		public void setStatusOrdem(String statusOrdem) {
			this.statusOrdem = statusOrdem;
		}

		public String getTecnologia() {
			return tecnologia;
		}

		public void setTecnologia(String tecnologia) {
			this.tecnologia = tecnologia;
		}

		public String getFormaPagamento() {
			return formaPagamento;
		}

		public void setFormaPagamento(String formaPagamento) {
			this.formaPagamento = formaPagamento;
		}

		public String getTipoConta() {
			return tipoConta;
		}

		public void setTipoConta(String tipoConta) {
			this.tipoConta = tipoConta;
		}

		public String getCodBanco() {
			return codBanco;
		}

		public void setCodBanco(String codBanco) {
			this.codBanco = codBanco;
		}

		public String getCodAgengiaBco() {
			return codAgengiaBco;
		}

		public void setCodAgengiaBco(String codAgengiaBco) {
			this.codAgengiaBco = codAgengiaBco;
		}

		public String getCodContaCorrente() {
			return codContaCorrente;
		}

		public void setCodContaCorrente(String codContaCorrente) {
			this.codContaCorrente = codContaCorrente;
		}

		public String getCodDebitoAutomatico() {
			return codDebitoAutomatico;
		}

		public void setCodDebitoAutomatico(String codDebitoAutomatico) {
			this.codDebitoAutomatico = codDebitoAutomatico;
		}

		public String getDiaVencimento() {
			return diaVencimento;
		}

		public void setDiaVencimento(String diaVencimento) {
			this.diaVencimento = diaVencimento;
		}

		public String getSemanaVenda() {
			return semanaVenda;
		}

		public void setSemanaVenda(String semanaVenda) {
			this.semanaVenda = semanaVenda;
		}

		public String getScore() {
			return score;
		}

		public void setScore(String score) {
			this.score = score;
		}

		public String getScoreConsumido() {
			return scoreConsumido;
		}

		public void setScoreConsumido(String scoreConsumido) {
			this.scoreConsumido = scoreConsumido;
		}

		public String getDtFinalizacaoOrdem() {
			return dtFinalizacaoOrdem;
		}

		public void setDtFinalizacaoOrdem(String dtFinalizacaoOrdem) {
			this.dtFinalizacaoOrdem = dtFinalizacaoOrdem;
		}

		public String getQdeContratos() {
			return qdeContratos;
		}

		public void setQdeContratos(String qdeContratos) {
			this.qdeContratos = qdeContratos;
		}

		public String getNumProtocolo() {
			return numProtocolo;
		}

		public void setNumProtocolo(String numProtocolo) {
			this.numProtocolo = numProtocolo;
		}

		public String getFlgOrdemAutomatica() {
			return flgOrdemAutomatica;
		}

		public void setFlgOrdemAutomatica(String flgOrdemAutomatica) {
			this.flgOrdemAutomatica = flgOrdemAutomatica;
		}

		public String getDscTxRecorrente() {
			return dscTxRecorrente;
		}

		public void setDscTxRecorrente(String dscTxRecorrente) {
			this.dscTxRecorrente = dscTxRecorrente;
		}

		public String getDscTxNaoRecorrente() {
			return dscTxNaoRecorrente;
		}

		public void setDscTxNaoRecorrente(String dscTxNaoRecorrente) {
			this.dscTxNaoRecorrente = dscTxNaoRecorrente;
		}

		public String getDscStatusItem() {
			return dscStatusItem;
		}

		public void setDscStatusItem(String dscStatusItem) {
			this.dscStatusItem = dscStatusItem;
		}

		public String getNomLoginResponsavel() {
			return nomLoginResponsavel;
		}

		public void setNomLoginResponsavel(String nomLoginResponsavel) {
			this.nomLoginResponsavel = nomLoginResponsavel;
		}

		public String getFlgPortabilidade() {
			return flgPortabilidade;
		}

		public void setFlgPortabilidade(String flgPortabilidade) {
			this.flgPortabilidade = flgPortabilidade;
		}

		public String getDscOperadoraDoadora() {
			return dscOperadoraDoadora;
		}

		public void setDscOperadoraDoadora(String dscOperadoraDoadora) {
			this.dscOperadoraDoadora = dscOperadoraDoadora;
		}

		public String getCodDdd() {
			return codDdd;
		}

		public void setCodDdd(String codDdd) {
			this.codDdd = codDdd;
		}

		public String getNumTelefonePortado() {
			return numTelefonePortado;
		}

		public void setNumTelefonePortado(String numTelefonePortado) {
			this.numTelefonePortado = numTelefonePortado;
		}

		public String getDatJanelaPortabilidade() {
			return datJanelaPortabilidade;
		}

		public void setDatJanelaPortabilidade(String datJanelaPortabilidade) {
			this.datJanelaPortabilidade = datJanelaPortabilidade;
		}

		public String getHoraDaJanela() {
			return horaDaJanela;
		}

		public void setHoraDaJanela(String horaDaJanela) {
			this.horaDaJanela = horaDaJanela;
		}

		public String getDscEnderecoFatura() {
			return dscEnderecoFatura;
		}

		public void setDscEnderecoFatura(String dscEnderecoFatura) {
			this.dscEnderecoFatura = dscEnderecoFatura;
		}

		public String getDscAreaVoip() {
			return dscAreaVoip;
		}

		public void setDscAreaVoip(String dscAreaVoip) {
			this.dscAreaVoip = dscAreaVoip;
		}

		public String getCpe() {
			return cpe;
		}

		public void setCpe(String cpe) {
			this.cpe = cpe;
		}

		public String getOnt() {
			return ont;
		}

		public void setOnt(String ont) {
			this.ont = ont;
		}

		public String getCodigoConvergente() {
			return codigoConvergente;
		}

		public void setCodigoConvergente(String codigoConvergente) {
			this.codigoConvergente = codigoConvergente;
		}

		public String getDetalheRecusaCrivo() {
			return detalheRecusaCrivo;
		}

		public void setDetalheRecusaCrivo(String detalheRecusaCrivo) {
			this.detalheRecusaCrivo = detalheRecusaCrivo;
		}

		public String getItemRoot() {
			return itemRoot;
		}

		public void setItemRoot(String itemRoot) {
			this.itemRoot = itemRoot;
		}

		public String getLoginCancelamentoOrdem() {
			return loginCancelamentoOrdem;
		}

		public void setLoginCancelamentoOrdem(String loginCancelamentoOrdem) {
			this.loginCancelamentoOrdem = loginCancelamentoOrdem;
		}

		public String getCustcodeCliente() {
			return custcodeCliente;
		}

		public void setCustcodeCliente(String custcodeCliente) {
			this.custcodeCliente = custcodeCliente;
		}

		public String getDominioRoot() {
			return dominioRoot;
		}

		public void setDominioRoot(String dominioRoot) {
			this.dominioRoot = dominioRoot;
		}

		public String getCodContFinanceira() {
			return codContFinanceira;
		}

		public void setCodContFinanceira(String codContFinanceira) {
			this.codContFinanceira = codContFinanceira;
		}

		public String getValPlanoAtualItem() {
			return valPlanoAtualItem;
		}

		public void setValPlanoAtualItem(String valPlanoAtualItem) {
			this.valPlanoAtualItem = valPlanoAtualItem;
		}

		public String getNomDescontoAtualItem() {
			return nomDescontoAtualItem;
		}

		public void setNomDescontoAtualItem(String nomDescontoAtualItem) {
			this.nomDescontoAtualItem = nomDescontoAtualItem;
		}

		public String getValDescontoAtualItem() {
			return valDescontoAtualItem;
		}

		public void setValDescontoAtualItem(String valDescontoAtualItem) {
			this.valDescontoAtualItem = valDescontoAtualItem;
		}

		public String getNroOrdem() {
			return nroOrdem;
		}

		public void setNroOrdem(String nroOrdem) {
			this.nroOrdem = nroOrdem;
		}

		public String getAcessoRowId() {
			return acessoRowId;
		}

		public void setAcessoRowId(String acessoRowId) {
			this.acessoRowId = acessoRowId;
		}

		public String getAcessoRowIdRoot() {
			return acessoRowIdRoot;
		}

		public void setAcessoRowIdRoot(String acessoRowIdRoot) {
			this.acessoRowIdRoot = acessoRowIdRoot;
		}

		public String getCodigoProduto() {
			return codigoProduto;
		}

		public void setCodigoProduto(String codigoProduto) {
			this.codigoProduto = codigoProduto;
		}

		public String getFlgVendaSubmetida() {
			return flgVendaSubmetida;
		}

		public void setFlgVendaSubmetida(String flgVendaSubmetida) {
			this.flgVendaSubmetida = flgVendaSubmetida;
		}

		public String getFlgVendaDuplicada() {
			return flgVendaDuplicada;
		}

		public void setFlgVendaDuplicada(String flgVendaDuplicada) {
			this.flgVendaDuplicada = flgVendaDuplicada;
		}

		public String getFlgVendaBruta() {
			return flgVendaBruta;
		}

		public void setFlgVendaBruta(String flgVendaBruta) {
			this.flgVendaBruta = flgVendaBruta;
		}

		public String getFlgVendaLiquida() {
			return flgVendaLiquida;
		}

		public void setFlgVendaLiquida(String flgVendaLiquida) {
			this.flgVendaLiquida = flgVendaLiquida;
		}

		public String getFlgCancDupl() {
			return flgCancDupl;
		}

		public void setFlgCancDupl(String flgCancDupl) {
			this.flgCancDupl = flgCancDupl;
		}

		public String getFlgCancLiquido() {
			return flgCancLiquido;
		}

		public void setFlgCancLiquido(String flgCancLiquido) {
			this.flgCancLiquido = flgCancLiquido;
		}

		public String getNomeParceiroVenda() {
			return nomeParceiroVenda;
		}

		public void setNomeParceiroVenda(String nomeParceiroVenda) {
			this.nomeParceiroVenda = nomeParceiroVenda;
		}

		public String getNomeParceiroVendaOrig() {
			return nomeParceiroVendaOrig;
		}

		public void setNomeParceiroVendaOrig(String nomeParceiroVendaOrig) {
			this.nomeParceiroVendaOrig = nomeParceiroVendaOrig;
		}

		public String getRowIdItemOrdem() {
			return rowIdItemOrdem;
		}

		public void setRowIdItemOrdem(String rowIdItemOrdem) {
			this.rowIdItemOrdem = rowIdItemOrdem;
		}

		public String getRowIdItemOrdemPai() {
			return rowIdItemOrdemPai;
		}

		public void setRowIdItemOrdemPai(String rowIdItemOrdemPai) {
			this.rowIdItemOrdemPai = rowIdItemOrdemPai;
		}

		public String getCategoriaItemOrder() {
			return categoriaItemOrder;
		}

		public void setCategoriaItemOrder(String categoriaItemOrder) {
			this.categoriaItemOrder = categoriaItemOrder;
		}

		public String getMsanOltVenda() {
			return msanOltVenda;
		}

		public void setMsanOltVenda(String msanOltVenda) {
			this.msanOltVenda = msanOltVenda;
		}

		public String getDtConclusaoWfm() {
			return dtConclusaoWfm;
		}

		public void setDtConclusaoWfm(String dtConclusaoWfm) {
			this.dtConclusaoWfm = dtConclusaoWfm;
		}

		public String getDscStatusOrdemWfm() {
			return dscStatusOrdemWfm;
		}

		public void setDscStatusOrdemWfm(String dscStatusOrdemWfm) {
			this.dscStatusOrdemWfm = dscStatusOrdemWfm;
		}

		public String getDatStatusWfm() {
			return datStatusWfm;
		}

		public void setDatStatusWfm(String datStatusWfm) {
			this.datStatusWfm = datStatusWfm;
		}

		public String getHoraStatusWfm() {
			return horaStatusWfm;
		}

		public void setHoraStatusWfm(String horaStatusWfm) {
			this.horaStatusWfm = horaStatusWfm;
		}

		public String getIdRecursoWfm() {
			return idRecursoWfm;
		}

		public void setIdRecursoWfm(String idRecursoWfm) {
			this.idRecursoWfm = idRecursoWfm;
		}

		public String getNomRecursoWfm() {
			return nomRecursoWfm;
		}

		public void setNomRecursoWfm(String nomRecursoWfm) {
			this.nomRecursoWfm = nomRecursoWfm;
		}

		public String getIdRecursoPaiWfm() {
			return idRecursoPaiWfm;
		}

		public void setIdRecursoPaiWfm(String idRecursoPaiWfm) {
			this.idRecursoPaiWfm = idRecursoPaiWfm;
		}

		public String getDatPrimeiroAgend() {
			return datPrimeiroAgend;
		}

		public void setDatPrimeiroAgend(String datPrimeiroAgend) {
			this.datPrimeiroAgend = datPrimeiroAgend;
		}

		public String getHoraPrimeiroAgendamento() {
			return horaPrimeiroAgendamento;
		}

		public void setHoraPrimeiroAgendamento(String horaPrimeiroAgendamento) {
			this.horaPrimeiroAgendamento = horaPrimeiroAgendamento;
		}

		public String getDatAgendAtual() {
			return datAgendAtual;
		}

		public void setDatAgendAtual(String datAgendAtual) {
			this.datAgendAtual = datAgendAtual;
		}

		public String getHoraAgendamentoAtual() {
			return horaAgendamentoAtual;
		}

		public void setHoraAgendamentoAtual(String horaAgendamentoAtual) {
			this.horaAgendamentoAtual = horaAgendamentoAtual;
		}

		public String getDscStatusAtivacao() {
			return dscStatusAtivacao;
		}

		public void setDscStatusAtivacao(String dscStatusAtivacao) {
			this.dscStatusAtivacao = dscStatusAtivacao;
		}

		public String getMsanOltTrafego() {
			return msanOltTrafego;
		}

		public void setMsanOltTrafego(String msanOltTrafego) {
			this.msanOltTrafego = msanOltTrafego;
		}

		public String getDatVendaOrig() {
			return datVendaOrig;
		}

		public void setDatVendaOrig(String datVendaOrig) {
			this.datVendaOrig = datVendaOrig;
		}

		public String getHoraVendaOrig() {
			return horaVendaOrig;
		}

		public void setHoraVendaOrig(String horaVendaOrig) {
			this.horaVendaOrig = horaVendaOrig;
		}

		public String getLoginVendedorOrig() {
			return loginVendedorOrig;
		}

		public void setLoginVendedorOrig(String loginVendedorOrig) {
			this.loginVendedorOrig = loginVendedorOrig;
		}

		public String getCanalOrig() {
			return canalOrig;
		}

		public void setCanalOrig(String canalOrig) {
			this.canalOrig = canalOrig;
		}

		public String getCnpjParceiroOrig() {
			return cnpjParceiroOrig;
		}

		public void setCnpjParceiroOrig(String cnpjParceiroOrig) {
			this.cnpjParceiroOrig = cnpjParceiroOrig;
		}

		public String getCustcodeOrig() {
			return custcodeOrig;
		}

		public void setCustcodeOrig(String custcodeOrig) {
			this.custcodeOrig = custcodeOrig;
		}

		public String getPositionOrig() {
			return positionOrig;
		}

		public void setPositionOrig(String positionOrig) {
			this.positionOrig = positionOrig;
		}

		public String getSemanaVendaOrig() {
			return semanaVendaOrig;
		}

		public void setSemanaVendaOrig(String semanaVendaOrig) {
			this.semanaVendaOrig = semanaVendaOrig;
		}

		public String getCodContratoAtual() {
			return codContratoAtual;
		}

		public void setCodContratoAtual(String codContratoAtual) {
			this.codContratoAtual = codContratoAtual;
		}

		public String getNomPlanoAtual() {
			return nomPlanoAtual;
		}

		public void setNomPlanoAtual(String nomPlanoAtual) {
			this.nomPlanoAtual = nomPlanoAtual;
		}

		public String getNomeVendedorOrig() {
			return nomeVendedorOrig;
		}

		public void setNomeVendedorOrig(String nomeVendedorOrig) {
			this.nomeVendedorOrig = nomeVendedorOrig;
		}

		public String getFlVendaDuplicada() {
			return flVendaDuplicada;
		}

		public void setFlVendaDuplicada(String flVendaDuplicada) {
			this.flVendaDuplicada = flVendaDuplicada;
		}

		public String getFlGross() {
			return flGross;
		}

		public void setFlGross(String flGross) {
			this.flGross = flGross;
		}

		public String getDtGross() {
			return dtGross;
		}

		public void setDtGross(String dtGross) {
			this.dtGross = dtGross;
		}

		public String getFlChurn() {
			return flChurn;
		}

		public void setFlChurn(String flChurn) {
			this.flChurn = flChurn;
		}

		public String getDtChurn() {
			return dtChurn;
		}

		public void setDtChurn(String dtChurn) {
			this.dtChurn = dtChurn;
		}

		public String getMotivoChurn() {
			return motivoChurn;
		}

		public void setMotivoChurn(String motivoChurn) {
			this.motivoChurn = motivoChurn;
		}

		public String getCodOrdemChurn() {
			return codOrdemChurn;
		}

		public void setCodOrdemChurn(String codOrdemChurn) {
			this.codOrdemChurn = codOrdemChurn;
		}

		public String getTipoChurn() {
			return tipoChurn;
		}

		public void setTipoChurn(String tipoChurn) {
			this.tipoChurn = tipoChurn;
		}

		public String getDtCriacaoOrdemChurn() {
			return dtCriacaoOrdemChurn;
		}

		public void setDtCriacaoOrdemChurn(String dtCriacaoOrdemChurn) {
			this.dtCriacaoOrdemChurn = dtCriacaoOrdemChurn;
		}

		public String getDtConclusaoOrdemChurn() {
			return dtConclusaoOrdemChurn;
		}

		public void setDtConclusaoOrdemChurn(String dtConclusaoOrdemChurn) {
			this.dtConclusaoOrdemChurn = dtConclusaoOrdemChurn;
		}

		public String getNomeVendedor() {
			return nomeVendedor;
		}

		public void setNomeVendedor(String nomeVendedor) {
			this.nomeVendedor = nomeVendedor;
		}

		public String getNomeUsuarioCancOrdem() {
			return nomeUsuarioCancOrdem;
		}

		public void setNomeUsuarioCancOrdem(String nomeUsuarioCancOrdem) {
			this.nomeUsuarioCancOrdem = nomeUsuarioCancOrdem;
		}

		public String getEmailCliente() {
			return emailCliente;
		}

		public void setEmailCliente(String emailCliente) {
			this.emailCliente = emailCliente;
		}

		public DateTimeFormatter getDtf() {
			return dtf;
		}

		public void setDtf(DateTimeFormatter dtf) {
			this.dtf = dtf;
		}

		public DateTimeFormatter getYyyyMMdd() {
			return yyyyMMdd;
		}

		public void setYyyyMMdd(DateTimeFormatter yyyyMMdd) {
			this.yyyyMMdd = yyyyMMdd;
		}

		public Pattern getPattern() {
			return pattern;
		}

		public void setPattern(Pattern pattern) {
			this.pattern = pattern;
		}

		


}
