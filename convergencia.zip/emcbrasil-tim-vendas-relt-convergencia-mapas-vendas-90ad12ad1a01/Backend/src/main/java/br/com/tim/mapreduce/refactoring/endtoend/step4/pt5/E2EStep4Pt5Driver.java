package br.com.tim.mapreduce.refactoring.endtoend.step4.pt5;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.InputFormat;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.CombineSequenceFileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import br.com.tim.driverutils.DriverUtils;
import br.com.tim.driverutils.Entry;
import br.com.tim.driverutils.Partition;
import br.com.tim.exception.CommonsException;
import br.com.tim.mapreduce.utils.Utils;
import br.com.tim.mr.GenericMetricsDriver;
import br.com.tim.utils.CommonsConstants;


public class E2EStep4Pt5Driver extends GenericMetricsDriver {

	private static Logger log = Logger.getLogger(E2EStep4Pt5Driver.class);
	private int retorno = CommonsConstants.ERROR;

	public Entry[] entrys;

	private Job job;
	private FileSystem fs;
	private Configuration conf;
	private Path outputPath;
    private org.joda.time.LocalDate lastestPartitionAvailableDay;
    private DateTimeFormatter dtf = DateTimeFormat.forPattern("yyyy-MM-dd");
    private String dat_ref_222;
    private DateTimeFormatter dtfPartitionDate = DateTimeFormat.forPattern("yyyyMMdd");
    
	@Override
	public int run(String[] args) throws Exception {
		try {
			setConfigurations(args);

			log.info("Running Pre Execution Steps.");
			preExecutionSteps();

			String jobName = fs.getConf().get("process-id");
			
			log.info("====================== JOB " + jobName + " ==============================");

			if (job.waitForCompletion(true)) {
				log.info("================== JOB " + jobName + " FINISHED SUCCESSFULY ====================");

				log.info("======================== Running post processing steps... =================================");

				retorno = CommonsConstants.SUCCESS;
			} else {
				log.info("============================= Executando o ROLLBACK... ====================================");
				rollback();
			}
		} catch (Exception e) {
			log.error("Erro genérico ao executar o Driver... ", e);
			log.info("============================= Executando o ROLLBACK... ====================================");
			rollback();
			throw new CommonsException(e.getMessage(), e);
		}

		return retorno;
	}

	public static void main(String[] args) throws Exception {
		log.info("=================== BEGIN PROCESS =========================");

		E2EStep4Pt5Driver driver = new E2EStep4Pt5Driver();
		int exitCode = ToolRunner.run(driver, args);
		log.info("Exit code: " + exitCode);
		log.info("=================== END PROCESS ==========================");
		System.exit(exitCode);
	}

	private void setConfigurations(String args[]) throws IOException, InterruptedException {


		PropertyConfigurator.configure(System.getProperty(CommonsConstants.LOG4J_CONFIGURATION));

		conf = new Configuration();
		conf.addResource(new Path(System.getProperty(CommonsConstants.ENVIRONMENT_CONFIGURATION)));
		conf.addResource(new Path(System.getProperty(CommonsConstants.PROJECT_CONFIGURATION)));

		fs = FileSystem.newInstance(conf);

		job = Job.getInstance(conf);
		job.setJarByClass(E2EStep4Pt5Driver.class);
		job.setMapOutputKeyClass(Step4Pt5Key.class);
		job.setPartitionerClass(JoinPartitioner.class);
		job.setGroupingComparatorClass(GroupingComparator.class);
		job.setMapOutputValueClass(E2EStep4Pt5Value.class);
		job.setReducerClass(E2EStep4Pt5Reducer.class);
		job.setOutputKeyClass(NullWritable.class);
		job.setOutputValueClass(Text.class);
		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);

		log.debug("Configuration file validated successfully!");
		String lastestPartitionAvailable = checkLastPartitionDateAvailable222(conf);
        lastestPartitionAvailableDay = dtfPartitionDate.parseLocalDate(lastestPartitionAvailable);
        this.dat_ref_222 = dtf.print(lastestPartitionAvailableDay);
        
		String[] arguments = new String[3];
		arguments[0] = "reprocess-day=" + this.dat_ref_222;
		
		
		
		outputPath = new Path(this.fs.getConf().get("output-path"));

		Utils.reprocessDay(args, job);

		log.info("Data em execução: " + job.getConfiguration().get("dat-ref"));

		entrys = getEntry(CombineSequenceFileInputFormat.class);

		TextOutputFormat.setOutputPath(job,outputPath);
		try{
			DriverUtils.addInputPaths(arguments, conf, this.job, 1, entrys);
		} catch (Exception e){}

	}

	protected Entry[] getEntry(Class<? extends InputFormat> inputFormat) {


		Entry bat222 = new Entry("BAT222", "input-path-222", true, false, false, true, inputFormat, Bat222Mapper.class,
				new Partition("dat_ref", Partition.Format.DATE_DAY, CommonsConstants.YYYYMMDD, 1, -1, false));

		Entry result = new Entry("step1Pt4", "input-path-step4Pt4", true, true, TextInputFormat.class, MapperStep4Pt4Result.class);


		return Arrays.asList(result, bat222).toArray(new Entry[] {});

	}


	protected void rollback() {

	}

	protected void preExecutionSteps() throws Exception {

		if (fs.exists(outputPath)){
			log.info("Removendo " + outputPath);
			fs.delete(outputPath,true);
		}
	}
	
	
public String checkLastPartitionDateAvailable222(Configuration conf) throws InterruptedException, IOException { 
    	
    	Process process;
    	String hadoopCommand = "hadoop fs -ls " + conf.get("input-path-222");
    	
    	log.info("Hadoop command: " + hadoopCommand);
		process = Runtime.getRuntime().exec(hadoopCommand);

		BufferedReader stdInput = new BufferedReader(new InputStreamReader(process.getInputStream()));
		String result;
		String lastLine = new String();
		
		while ((result = stdInput.readLine()) != null) {
			
			if (!result.contains("HIVE_DEFAULT_PARTITION")) {
				lastLine = result;
			}
			
		}

		try {
			String[] split = lastLine.split("=");
			String firstSplit = split[1];
			String[] lastSplit = firstSplit.split("/");

			log.info("Got lastest day " + lastSplit[0]);
			return lastSplit[0];
		} catch (Exception e) {

			log.info("");
			log.info("Aborting Execution. There is no data");
			log.info("");
			System.exit(0);

		}

		return lastLine;
    	
    	
    }

@Override
protected void configure() throws Exception {
	// TODO Auto-generated method stub
	
}

}
