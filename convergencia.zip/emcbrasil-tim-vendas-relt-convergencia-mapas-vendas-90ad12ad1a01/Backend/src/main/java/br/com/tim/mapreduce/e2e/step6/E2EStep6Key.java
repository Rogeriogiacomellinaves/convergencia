package br.com.tim.mapreduce.e2e.step6;

import br.com.tim.mapreduce.e2e.GroupComparable;
import com.google.common.collect.ComparisonChain;
import org.apache.hadoop.io.WritableComparable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Objects;

public class E2EStep6Key implements GroupComparable<E2EStep6Key> {

	private String acessoRowId;
	private String datRef;
	private TypeStep6 tipo;

	@Override
	public void write(DataOutput output) throws IOException {
		output.writeInt(tipo.ordinal());
		output.writeUTF(this.acessoRowId);
		output.writeUTF(this.datRef);
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		this.tipo = TypeStep6.values()[in.readInt()];
		this.acessoRowId = in.readUTF();
		this.datRef = in.readUTF();
	}

    public void setTipo(TypeStep6 tipo) {
        this.tipo = tipo;
    }

    public String getAcessoRowId() {
		return acessoRowId;
	}

	public void setAcessoRowId(String acessoRowId) {
		this.acessoRowId = acessoRowId;
	}

	public void setDatRef(String datRef) {
		this.datRef = datRef;
	}

	@Override
	public int compareTo(E2EStep6Key o) {
		return ComparisonChain.start().compare(this.acessoRowId, o.acessoRowId).compare(this.datRef, o.datRef).compare(this.tipo, o.tipo)
				.result();
	}

	@Override
	public int compareToGrouping(E2EStep6Key o) {
		return ComparisonChain.start().compare(this.acessoRowId, o.acessoRowId).result();
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		E2EStep6Key key = (E2EStep6Key) o;
		return Objects.equals(acessoRowId, key.acessoRowId);
	}

	public int hashCodeJoin() {

		return Objects.hash(acessoRowId);
	}

	@Override
	public int hashCode() {

		return Objects.hash(acessoRowId);
	}
}