package br.com.tim.mapreduce.itemordem.step1;

public enum TypeStep1 {

    ORDEM, ITEM, WFM_TOA
}
