
package br.com.tim.mapreduce.e2e.step9.pt1;

import br.com.tim.mapreduce.e2e.step9.E2EStep9Key;
import br.com.tim.mapreduce.e2e.step9.TypeStep9;
import br.com.tim.mapreduce.e2e.step9.model.Step8Result;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

import java.io.IOException;

public class MapperStep8Result extends org.apache.hadoop.mapreduce.Mapper<Writable,Text,E2EStep9Key,E2EStep9PT1Value> {

	private E2EStep9Key outkey;
	private E2EStep9PT1Value outValue;
	private Step8Result input;
	@Override
	protected void map(Writable key, Text value, Context context) throws IOException, InterruptedException {
		input.parse(value.toString());
		outkey.setNomParceiro(input.getNomeParceiroVenda());
		outkey.setTipo(TypeStep9.RELT);
		outValue.setStep8Result(input);
		context.write(outkey, outValue);
	}

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		super.setup(context);
		this.outkey = new E2EStep9Key();
		this.outValue = new E2EStep9PT1Value();
		this.input = new Step8Result();
	}

	@Override
	protected void cleanup(Context context) throws IOException, InterruptedException {
		super.cleanup(context);
		this.clear();
	}

	private void clear(){
	   this.outValue.clear();
	}

}