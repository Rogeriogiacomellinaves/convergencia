
package br.com.tim.mapreduce.refactoring.endtoend.step4.pt2;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.parquet.Strings;

import br.com.tim.mapreduce.refactoring.endtoend.step4.utils.Step4Pt2Counters;
import br.com.tim.mapreduce.refactoring.model.BAT509Order;

public class MapperOrdem extends Mapper<Writable,Text,Step4Pt2Key,Step4Pt2Value> {

	Step4Pt2Value outValue;
	private Step4Pt2Key outkey;
	private BAT509Order input;
	
	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		
		this.outValue = new Step4Pt2Value();
		this.outkey = new Step4Pt2Key();
		this.input = new BAT509Order();
	}
	
	protected void map(Writable key, Text value,  Mapper<Writable, Text, Step4Pt2Key,Step4Pt2Value>.Context context) throws IOException, InterruptedException {
		
		outValue.clear();
		
		input.parseFromText(value);
		
		if (!Strings.isNullOrEmpty(input.getNumeroOrdem())) {
			
			outkey.setNroOrdem(input.getNumeroOrdem());
			outkey.setDatRef(input.getArquivo().substring(17, 25));
			outkey.setTipo(TypeStep4Pt2.ORDER);
			
			outValue.setOrdem(input);
			
			context.write(outkey, outValue);
			context.getCounter(Step4Pt2Counters.ORDER_MAPPER_WRITE).increment(1l);
		}else {
			
			context.getCounter(Step4Pt2Counters.ORDER_MAPPER_DISCART).increment(1l);

		}

		
	}




}