package br.com.tim.mapreduce.refactoring.endtoend.step6.pt1;

import java.io.IOException;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.log4j.Logger;

import br.com.tim.mapreduce.refactoring.endtoend.step6.model.Step5;
import br.com.tim.mapreduce.refactoring.endtoend.step6.utils.Step6Counters;
import br.com.tim.utils.CommonsConstants;

public class Step6Reducer extends Reducer<Text, Step6Value, NullWritable, Text> {
	
	protected static final Logger LOG = Logger.getLogger(Step6Reducer.class);
	private final static String DELIMITER = CommonsConstants.FILE_FIELD_SEPARATOR;
	private NullWritable outKey;
	private Step5 step5;
	
    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
    	super.setup(context);
    	
    	outKey = NullWritable.get();
    	step5 = new Step5();
    	
    }
    
    
    @Override
    protected void reduce(Text key, Iterable<Step6Value> values, Context context)throws InterruptedException, IOException {
    	
    	this.clean();
    	
    	for (Step6Value value : values) {
			
    		switch (value.getType()) {
			case STEP5:
				step5 = (Step5) value.getValue();
				break;
			default:
				break;
			}
    		
		}
    
    	
    	prepareResponse(step5, context);
    	context.getCounter(Step6Counters.STEP6_REDUCER_WRITE).increment(1l);
    
    }
	
    
    @Override
    protected void cleanup(Context context) throws IOException, InterruptedException {
        super.cleanup(context);

    }
	
	private void prepareResponse(Step5 value, Context context) throws IOException, InterruptedException {
		
	
		StringBuffer sb = new StringBuffer();
		sb.setLength(0);
		sb.append(value.getDatref()).append(DELIMITER);
		sb.append(value.getDatCriacaoOrdem()).append(DELIMITER);
		sb.append(value.getHoraCriacaoDaOrdem()).append(DELIMITER);
		sb.append(value.getDatVenda()).append(DELIMITER);
		sb.append(value.getHoraDaVenda()).append(DELIMITER);
		sb.append(value.getDatStatusOrdem()).append(DELIMITER);
		sb.append(value.getHrStatusOrdem()).append(DELIMITER);
		sb.append(value.getNumOrdemSiebel()).append(DELIMITER);
		sb.append(value.getNumOrdemSiebelOrig()).append(DELIMITER);
		sb.append(value.getCodContratoOltp()).append(DELIMITER);
		sb.append(value.getCodContratoAtivacao()).append(DELIMITER);
		sb.append(value.getNumeroAcesso()).append(DELIMITER);
		sb.append(value.getCustomerId()).append(DELIMITER);
		sb.append(value.getTipoDocumento()).append(DELIMITER);
		sb.append(value.getDocumento()).append(DELIMITER);
		sb.append(value.getTipoVenda()).append(DELIMITER);
		sb.append(value.getTipoProduto()).append(DELIMITER);
		sb.append(value.getVelocidadeDownload()).append(DELIMITER);
		sb.append(value.getVelocidadeUpload()).append(DELIMITER);
		sb.append(value.getPlanoAtivacaoOferta()).append(DELIMITER);
		sb.append(value.getLoginVendedor()).append(DELIMITER);
		sb.append(value.getCanal()).append(DELIMITER);
		sb.append(value.getCnpjParceiro()).append(DELIMITER);
		sb.append(value.getCustcode()).append(DELIMITER);
		sb.append(value.getPosition()).append(DELIMITER);
		sb.append(value.getFlgCancAntesVenda()).append(DELIMITER);
		sb.append(value.getFlgCancPosVenda()).append(DELIMITER);
		sb.append(value.getDtCancVenda()).append(DELIMITER);
		sb.append(value.getMotivoCancelamento()).append(DELIMITER);
		sb.append(value.getNomeCliente()).append(DELIMITER);
		sb.append(value.getTelefone()).append(DELIMITER);
		sb.append(value.getEmailFatura()).append(DELIMITER);
		sb.append(value.getUf()).append(DELIMITER);
		sb.append(value.getTipoLogradouro()).append(DELIMITER);
		sb.append(value.getLogradouro()).append(DELIMITER);
		sb.append(value.getNumero()).append(DELIMITER);
		sb.append(value.getComplemento()).append(DELIMITER);
		sb.append(value.getBairro()).append(DELIMITER);
		sb.append(value.getCep()).append(DELIMITER);
		sb.append(value.getCidade()).append(DELIMITER);
		sb.append(value.getStatusOrdem()).append(DELIMITER);
		sb.append(value.getTecnologia()).append(DELIMITER);
		sb.append(value.getFormaPagamento()).append(DELIMITER);
		sb.append(value.getTipoConta()).append(DELIMITER);
		sb.append(value.getCodBanco()).append(DELIMITER);
		sb.append(value.getCodAgengiaBco()).append(DELIMITER);
		sb.append(value.getCodContaCorrente()).append(DELIMITER);
		sb.append(value.getCodDebitoAutomatico()).append(DELIMITER);
		sb.append(value.getDiaVencimento()).append(DELIMITER);
		sb.append(value.getSemanaVenda()).append(DELIMITER);
		sb.append(value.getScore()).append(DELIMITER);
		sb.append(value.getScoreConsumido()).append(DELIMITER);
		sb.append(value.getDtFinalizacaoOrdem()).append(DELIMITER);
		sb.append(value.getQdeContratos()).append(DELIMITER);
		sb.append(value.getNumProtocolo()).append(DELIMITER);
		sb.append(value.getFlgOrdemAutomatica()).append(DELIMITER);
		sb.append(value.getDscTxRecorrente()).append(DELIMITER);
		sb.append(value.getDscTxNaoRecorrente()).append(DELIMITER);
		sb.append(value.getDscStatusItem()).append(DELIMITER);
		sb.append(value.getNomLoginResponsavel()).append(DELIMITER);
		sb.append(value.getFlgPortabilidade()).append(DELIMITER);
		sb.append(value.getDscOperadoraDoadora()).append(DELIMITER);
		sb.append(value.getCodDdd()).append(DELIMITER);
		sb.append(value.getNumTelefonePortado()).append(DELIMITER);
		sb.append(value.getDatJanelaPortabilidade()).append(DELIMITER);
		sb.append(value.getHoraDaJanela()).append(DELIMITER);
		sb.append(value.getDscEnderecoFatura()).append(DELIMITER);
		sb.append(value.getDscAreaVoip()).append(DELIMITER);
		sb.append(value.getCpe()).append(DELIMITER);
		sb.append(value.getOnt()).append(DELIMITER);
		sb.append(value.getCodigoConvergente()).append(DELIMITER);
		sb.append(value.getDetalheRecusaCrivo()).append(DELIMITER);
		sb.append(value.getItemRoot()).append(DELIMITER);
		sb.append(value.getLoginCancelamentoOrdem()).append(DELIMITER);
		sb.append(value.getCustcodeCliente()).append(DELIMITER);
		sb.append(value.getDominioRoot()).append(DELIMITER);
		sb.append(value.getCodContFinanceira()).append(DELIMITER);
		sb.append(value.getValPlanoAtualItem()).append(DELIMITER);
		sb.append(value.getNomDescontoAtualItem()).append(DELIMITER);
		sb.append(value.getValDescontoAtualItem()).append(DELIMITER);
		sb.append(value.getNroOrdem()).append(DELIMITER);
		sb.append(value.getAcessoRowId()).append(DELIMITER);
		sb.append(value.getAcessoRowIdRoot()).append(DELIMITER);
		sb.append(value.getCodigoProduto()).append(DELIMITER);
		sb.append(value.getFlgVendaSubmetida()).append(DELIMITER);
		sb.append(value.getFlgVendaDuplicada()).append(DELIMITER);
		sb.append(value.getFlgVendaBruta()).append(DELIMITER);
		sb.append(value.getFlgVendaLiquida()).append(DELIMITER);
		sb.append(value.getFlgCancDupl()).append(DELIMITER);
		sb.append(value.getFlgCancLiquido()).append(DELIMITER);
		sb.append(value.getNomeParceiroVenda()).append(DELIMITER);
		sb.append(value.getNomeParceiroVendaOrig()).append(DELIMITER);
		sb.append(value.getRowIdItemOrdem()).append(DELIMITER);
		sb.append(value.getRowIdItemOrdemPai()).append(DELIMITER);
		sb.append(value.getCategoriaItemOrder()).append(DELIMITER);
		sb.append(value.getMsanOltVenda()).append(DELIMITER);
		sb.append(value.getDtConclusaoWfm()).append(DELIMITER);
		sb.append(value.getDscStatusOrdemWfm()).append(DELIMITER);
		sb.append(value.getDatStatusWfm()).append(DELIMITER);
		sb.append(value.getHoraStatusWfm()).append(DELIMITER);
		sb.append(value.getIdRecursoWfm()).append(DELIMITER);
		sb.append(value.getNomRecursoWfm()).append(DELIMITER);
		sb.append(value.getIdRecursoPaiWfm()).append(DELIMITER);
		sb.append(value.getDatPrimeiroAgend()).append(DELIMITER);
		sb.append(value.getHoraPrimeiroAgendamento()).append(DELIMITER);
		sb.append(value.getDatAgendAtual()).append(DELIMITER);
		sb.append(value.getHoraAgendamentoAtual()).append(DELIMITER);
		sb.append(value.getDscStatusAtivacao()).append(DELIMITER);
		sb.append(value.getMsanOltTrafego()).append(DELIMITER);
		sb.append(value.getDatVendaOrig()).append(DELIMITER);
		sb.append(value.getHoraVendaOrig()).append(DELIMITER);
		sb.append(value.getLoginVendedorOrig()).append(DELIMITER);
		sb.append(value.getCanalOrig()).append(DELIMITER);
		sb.append(value.getCnpjParceiroOrig()).append(DELIMITER);
		sb.append(value.getCustcodeOrig()).append(DELIMITER);
		sb.append(value.getPositionOrig()).append(DELIMITER);
		sb.append(value.getSemanaVendaOrig()).append(DELIMITER);
		sb.append(value.getCodContratoAtual()).append(DELIMITER);
		sb.append(value.getNomPlanoAtual()).append(DELIMITER);
		sb.append(value.getNomeVendedorOrig()).append(DELIMITER);
		sb.append(value.getFlVendaDuplicada()).append(DELIMITER);
		sb.append(value.getFlGross()).append(DELIMITER);
		sb.append(value.getDtGross()).append(DELIMITER);
		sb.append(value.getFlChurn()).append(DELIMITER);
		sb.append(value.getDtChurn()).append(DELIMITER);
		sb.append(value.getMotivoChurn()).append(DELIMITER);
		sb.append(value.getCodOrdemChurn()).append(DELIMITER);
		sb.append(value.getTipoChurn()).append(DELIMITER);
		sb.append(value.getDtCriacaoOrdemChurn()).append(DELIMITER);
		sb.append(value.getDtConclusaoOrdemChurn()).append(DELIMITER);
		sb.append(value.getNomeVendedor()).append(DELIMITER);
		sb.append(value.getNomeUsuarioCancOrdem()).append(DELIMITER);
		sb.append(value.getEmailCliente());
		context.write(outKey, new Text(sb.toString()));
	
	
	}
	
	public void clean() {
		
		step5.clean();
		
	}


}
