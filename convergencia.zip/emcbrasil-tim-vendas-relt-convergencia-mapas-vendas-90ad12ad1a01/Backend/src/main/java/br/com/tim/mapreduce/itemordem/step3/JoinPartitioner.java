package br.com.tim.mapreduce.itemordem.step3;


import org.apache.hadoop.mapreduce.Partitioner;

public class JoinPartitioner extends Partitioner<IOStep3Key, IOStep3Value> {

    @Override
    public int getPartition(IOStep3Key taggedKey, IOStep3Value value, int numPartitions) {
        return Math.abs(taggedKey.hashCodeJoin() % numPartitions);
    }
}