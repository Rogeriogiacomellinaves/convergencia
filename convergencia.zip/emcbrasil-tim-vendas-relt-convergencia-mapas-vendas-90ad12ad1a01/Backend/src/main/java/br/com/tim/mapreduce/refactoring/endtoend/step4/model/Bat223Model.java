package br.com.tim.mapreduce.refactoring.endtoend.step4.model;

import br.com.tim.mapreduce.refactoring.endtoend.step4.enums.Bat223;
import br.com.tim.utils.CommonsConstants;

public class Bat223Model {
    private String customer_id;
    private String cpf_cliente;
    private String tipo_logradouro_instalacao;
    private String logradouro_instalacao;
    private String numero_endereco_instalacao;
    private String complemento_instalacao;
    private String bairro_instalacao;
    private String cidade_instalacao;
    private String uf_instalacao;
    private String cep_instalacao;
    private String caixa_postal_instalacao;
    private String rowid_endereco_instalacao;
    private String codigo_nacional_localidade;
    private String tipo_acesso;
    private String numero_contrato;
    private String data_hora_ativacao;
    private String codigo_comercial_plano;
    private String nome_plano;
    private String msisdn;
    private String status_contrato;
    private String data_hora_ultimo_status;
    private String data_hora_ultima_atualizacao_contrato;
    private String data_aging_cliente;
    private String codigo_pdv_ativacao;
    private String codigo_pdv_ultima_modificacao;
    private String numero_simcard;
    private String subtipo_acesso;
    private String motivo_status;
    private String cliente_permite_divulgacao_lista_telefonica;
    private String login_responsavel_ativacao;
    private String perfil_login_responsavel_ativacao;
    private String perfil_login_modif;
    private String login_resp_ultima_modif;
    private String flag_contrato_pertence_grupo_acapulco;
    private String flag_contrato_administrador_grupo_acapulco;
    private String rowid;
    private String loteid;
    private String arquivo;
    private String arquivots;
    private String currentdate;
    private String ide_promocao;
    private String dsc_segmento_linha;
    private String row_id_acesso;
    private String pais_cliente;
    private String row_id_cliente;
    private String row_id_root_acesso;
    private String rod_id_perfil_fatura_acesso;


    public void parseFromText(String text) {

        String[] fields = text.split(CommonsConstants.FILE_SPLIT_REGEX, -1);

        this.customer_id = fields[Bat223.CUSTOMER_ID.ordinal()];
        this.cpf_cliente = fields[Bat223.CPF_CLIENTE.ordinal()];
        this.tipo_logradouro_instalacao = fields[Bat223.TIPO_LOGRADOURO_INSTALACAO.ordinal()];
        this.logradouro_instalacao = fields[Bat223.LOGRADOURO_INSTALACAO.ordinal()];
        this.numero_endereco_instalacao = fields[Bat223.NUMERO_ENDERECO_INSTALACAO.ordinal()];
        this.complemento_instalacao = fields[Bat223.COMPLEMENTO_INSTALACAO.ordinal()];
        this.bairro_instalacao = fields[Bat223.BAIRRO_INSTALACAO.ordinal()];
        this.cidade_instalacao = fields[Bat223.CIDADE_INSTALACAO.ordinal()];
        this.uf_instalacao = fields[Bat223.UF_INSTALACAO.ordinal()];
        this.cep_instalacao = fields[Bat223.CEP_INSTALACAO.ordinal()];
        this.caixa_postal_instalacao = fields[Bat223.CAIXA_POSTAL_INSTALACAO.ordinal()];
        this.rowid_endereco_instalacao = fields[Bat223.ROWID_ENDERECO_INSTALACAO.ordinal()];
        this.codigo_nacional_localidade = fields[Bat223.CODIGO_NACIONAL_LOCALIDADE.ordinal()];
        this.tipo_acesso = fields[Bat223.TIPO_ACESSO.ordinal()];
        this.numero_contrato = fields[Bat223.NUMERO_CONTRATO.ordinal()];
        this.data_hora_ativacao = fields[Bat223.DATA_HORA_ATIVACAO.ordinal()];
        this.codigo_comercial_plano = fields[Bat223.CODIGO_COMERCIAL_PLANO.ordinal()];
        this.nome_plano = fields[Bat223.NOME_PLANO.ordinal()];
        this.msisdn = fields[Bat223.MSISDN.ordinal()];
        this.status_contrato = fields[Bat223.STATUS_CONTRATO.ordinal()];
        this.data_hora_ultimo_status = fields[Bat223.DATA_HORA_ULTIMO_STATUS.ordinal()];
        this.data_hora_ultima_atualizacao_contrato = fields[Bat223.DATA_HORA_ULTIMA_ATUALIZACAO_CONTRATO.ordinal()];
        this.data_aging_cliente = fields[Bat223.DATA_AGING_CLIENTE.ordinal()];
        this.codigo_pdv_ativacao = fields[Bat223.CODIGO_PDV_ATIVACAO.ordinal()];
        this.codigo_pdv_ultima_modificacao = fields[Bat223.CODIGO_PDV_ULTIMA_MODIFICACAO.ordinal()];
        this.numero_simcard = fields[Bat223.NUMERO_SIMCARD.ordinal()];
        this.subtipo_acesso = fields[Bat223.SUBTIPO_ACESSO.ordinal()];
        this.motivo_status = fields[Bat223.MOTIVO_STATUS.ordinal()];
        this.cliente_permite_divulgacao_lista_telefonica = fields[Bat223.CLIENTE_PERMITE_DIVULGACAO_LISTA_TELEFONICA.ordinal()];
        this.login_responsavel_ativacao = fields[Bat223.LOGIN_RESPONSAVEL_ATIVACAO.ordinal()];
        this.perfil_login_responsavel_ativacao = fields[Bat223.PERFIL_LOGIN_RESPONSAVEL_ATIVACAO.ordinal()];
        this.perfil_login_modif = fields[Bat223.PERFIL_LOGIN_MODIF.ordinal()];
        this.login_resp_ultima_modif = fields[Bat223.LOGIN_RESP_ULTIMA_MODIF.ordinal()];
        this.flag_contrato_pertence_grupo_acapulco = fields[Bat223.FLAG_CONTRATO_PERTENCE_GRUPO_ACAPULCO.ordinal()];
        this.flag_contrato_administrador_grupo_acapulco = fields[Bat223.FLAG_CONTRATO_ADMINISTRADOR_GRUPO_ACAPULCO.ordinal()];
        this.rowid = fields[Bat223.ROWID.ordinal()];
        this.loteid = fields[Bat223.LOTEID.ordinal()];
        this.arquivo = fields[Bat223.ARQUIVO.ordinal()];
        this.arquivots = fields[Bat223.ARQUIVOTS.ordinal()];
        this.currentdate = fields[Bat223.CURRENTDATE.ordinal()];
        this.ide_promocao = fields[Bat223.IDE_PROMOCAO.ordinal()];
        this.dsc_segmento_linha = fields[Bat223.DSC_SEGMENTO_LINHA.ordinal()];
        this.row_id_acesso = fields[Bat223.ROW_ID_ACESSO.ordinal()];
        this.pais_cliente = fields[Bat223.PAIS_CLIENTE.ordinal()];
        this.row_id_cliente = fields[Bat223.ROW_ID_CLIENTE.ordinal()];
        this.row_id_root_acesso = fields[Bat223.ROW_ID_ROOT_ACESSO.ordinal()];
        this.rod_id_perfil_fatura_acesso = fields[Bat223.ROD_ID_PERFIL_FATURA_ACESSO.ordinal()];
    }

    public String getCustomer_id() {
        return customer_id;
    }

    public void setCustomer_id(String customer_id) {
        this.customer_id = customer_id;
    }

    public String getCpf_cliente() {
        return cpf_cliente;
    }

    public void setCpf_cliente(String cpf_cliente) {
        this.cpf_cliente = cpf_cliente;
    }

    public String getTipo_logradouro_instalacao() {
        return tipo_logradouro_instalacao;
    }

    public void setTipo_logradouro_instalacao(String tipo_logradouro_instalacao) {
        this.tipo_logradouro_instalacao = tipo_logradouro_instalacao;
    }

    public String getLogradouro_instalacao() {
        return logradouro_instalacao;
    }

    public void setLogradouro_instalacao(String logradouro_instalacao) {
        this.logradouro_instalacao = logradouro_instalacao;
    }

    public String getNumero_endereco_instalacao() {
        return numero_endereco_instalacao;
    }

    public void setNumero_endereco_instalacao(String numero_endereco_instalacao) {
        this.numero_endereco_instalacao = numero_endereco_instalacao;
    }

    public String getComplemento_instalacao() {
        return complemento_instalacao;
    }

    public void setComplemento_instalacao(String complemento_instalacao) {
        this.complemento_instalacao = complemento_instalacao;
    }

    public String getBairro_instalacao() {
        return bairro_instalacao;
    }

    public void setBairro_instalacao(String bairro_instalacao) {
        this.bairro_instalacao = bairro_instalacao;
    }

    public String getCidade_instalacao() {
        return cidade_instalacao;
    }

    public void setCidade_instalacao(String cidade_instalacao) {
        this.cidade_instalacao = cidade_instalacao;
    }

    public String getUf_instalacao() {
        return uf_instalacao;
    }

    public void setUf_instalacao(String uf_instalacao) {
        this.uf_instalacao = uf_instalacao;
    }

    public String getCep_instalacao() {
        return cep_instalacao;
    }

    public void setCep_instalacao(String cep_instalacao) {
        this.cep_instalacao = cep_instalacao;
    }

    public String getCaixa_postal_instalacao() {
        return caixa_postal_instalacao;
    }

    public void setCaixa_postal_instalacao(String caixa_postal_instalacao) {
        this.caixa_postal_instalacao = caixa_postal_instalacao;
    }

    public String getRowid_endereco_instalacao() {
        return rowid_endereco_instalacao;
    }

    public void setRowid_endereco_instalacao(String rowid_endereco_instalacao) {
        this.rowid_endereco_instalacao = rowid_endereco_instalacao;
    }

    public String getCodigo_nacional_localidade() {
        return codigo_nacional_localidade;
    }

    public void setCodigo_nacional_localidade(String codigo_nacional_localidade) {
        this.codigo_nacional_localidade = codigo_nacional_localidade;
    }

    public String getTipo_acesso() {
        return tipo_acesso;
    }

    public void setTipo_acesso(String tipo_acesso) {
        this.tipo_acesso = tipo_acesso;
    }

    public String getNumero_contrato() {
        return numero_contrato;
    }

    public void setNumero_contrato(String numero_contrato) {
        this.numero_contrato = numero_contrato;
    }

    public String getData_hora_ativacao() {
        return data_hora_ativacao;
    }

    public void setData_hora_ativacao(String data_hora_ativacao) {
        this.data_hora_ativacao = data_hora_ativacao;
    }

    public String getCodigo_comercial_plano() {
        return codigo_comercial_plano;
    }

    public void setCodigo_comercial_plano(String codigo_comercial_plano) {
        this.codigo_comercial_plano = codigo_comercial_plano;
    }

    public String getNome_plano() {
        return nome_plano;
    }

    public void setNome_plano(String nome_plano) {
        this.nome_plano = nome_plano;
    }

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    public String getStatus_contrato() {
        return status_contrato;
    }

    public void setStatus_contrato(String status_contrato) {
        this.status_contrato = status_contrato;
    }

    public String getData_hora_ultimo_status() {
        return data_hora_ultimo_status;
    }

    public void setData_hora_ultimo_status(String data_hora_ultimo_status) {
        this.data_hora_ultimo_status = data_hora_ultimo_status;
    }

    public String getData_hora_ultima_atualizacao_contrato() {
        return data_hora_ultima_atualizacao_contrato;
    }

    public void setData_hora_ultima_atualizacao_contrato(String data_hora_ultima_atualizacao_contrato) {
        this.data_hora_ultima_atualizacao_contrato = data_hora_ultima_atualizacao_contrato;
    }

    public String getData_aging_cliente() {
        return data_aging_cliente;
    }

    public void setData_aging_cliente(String data_aging_cliente) {
        this.data_aging_cliente = data_aging_cliente;
    }

    public String getCodigo_pdv_ativacao() {
        return codigo_pdv_ativacao;
    }

    public void setCodigo_pdv_ativacao(String codigo_pdv_ativacao) {
        this.codigo_pdv_ativacao = codigo_pdv_ativacao;
    }

    public String getCodigo_pdv_ultima_modificacao() {
        return codigo_pdv_ultima_modificacao;
    }

    public void setCodigo_pdv_ultima_modificacao(String codigo_pdv_ultima_modificacao) {
        this.codigo_pdv_ultima_modificacao = codigo_pdv_ultima_modificacao;
    }

    public String getNumero_simcard() {
        return numero_simcard;
    }

    public void setNumero_simcard(String numero_simcard) {
        this.numero_simcard = numero_simcard;
    }

    public String getSubtipo_acesso() {
        return subtipo_acesso;
    }

    public void setSubtipo_acesso(String subtipo_acesso) {
        this.subtipo_acesso = subtipo_acesso;
    }

    public String getMotivo_status() {
        return motivo_status;
    }

    public void setMotivo_status(String motivo_status) {
        this.motivo_status = motivo_status;
    }

    public String getCliente_permite_divulgacao_lista_telefonica() {
        return cliente_permite_divulgacao_lista_telefonica;
    }

    public void setCliente_permite_divulgacao_lista_telefonica(String cliente_permite_divulgacao_lista_telefonica) {
        this.cliente_permite_divulgacao_lista_telefonica = cliente_permite_divulgacao_lista_telefonica;
    }

    public String getLogin_responsavel_ativacao() {
        return login_responsavel_ativacao;
    }

    public void setLogin_responsavel_ativacao(String login_responsavel_ativacao) {
        this.login_responsavel_ativacao = login_responsavel_ativacao;
    }

    public String getPerfil_login_responsavel_ativacao() {
        return perfil_login_responsavel_ativacao;
    }

    public void setPerfil_login_responsavel_ativacao(String perfil_login_responsavel_ativacao) {
        this.perfil_login_responsavel_ativacao = perfil_login_responsavel_ativacao;
    }

    public String getPerfil_login_modif() {
        return perfil_login_modif;
    }

    public void setPerfil_login_modif(String perfil_login_modif) {
        this.perfil_login_modif = perfil_login_modif;
    }

    public String getLogin_resp_ultima_modif() {
        return login_resp_ultima_modif;
    }

    public void setLogin_resp_ultima_modif(String login_resp_ultima_modif) {
        this.login_resp_ultima_modif = login_resp_ultima_modif;
    }

    public String getFlag_contrato_pertence_grupo_acapulco() {
        return flag_contrato_pertence_grupo_acapulco;
    }

    public void setFlag_contrato_pertence_grupo_acapulco(String flag_contrato_pertence_grupo_acapulco) {
        this.flag_contrato_pertence_grupo_acapulco = flag_contrato_pertence_grupo_acapulco;
    }

    public String getFlag_contrato_administrador_grupo_acapulco() {
        return flag_contrato_administrador_grupo_acapulco;
    }

    public void setFlag_contrato_administrador_grupo_acapulco(String flag_contrato_administrador_grupo_acapulco) {
        this.flag_contrato_administrador_grupo_acapulco = flag_contrato_administrador_grupo_acapulco;
    }

    public String getRowid() {
        return rowid;
    }

    public void setRowid(String rowid) {
        this.rowid = rowid;
    }

    public String getLoteid() {
        return loteid;
    }

    public void setLoteid(String loteid) {
        this.loteid = loteid;
    }

    public String getArquivo() {
        return arquivo;
    }

    public void setArquivo(String arquivo) {
        this.arquivo = arquivo;
    }

    public String getArquivots() {
        return arquivots;
    }

    public void setArquivots(String arquivots) {
        this.arquivots = arquivots;
    }

    public String getCurrentdate() {
        return currentdate;
    }

    public void setCurrentdate(String currentdate) {
        this.currentdate = currentdate;
    }

    public String getIde_promocao() {
        return ide_promocao;
    }

    public void setIde_promocao(String ide_promocao) {
        this.ide_promocao = ide_promocao;
    }

    public String getDsc_segmento_linha() {
        return dsc_segmento_linha;
    }

    public void setDsc_segmento_linha(String dsc_segmento_linha) {
        this.dsc_segmento_linha = dsc_segmento_linha;
    }

    public String getRow_id_acesso() {
        return row_id_acesso;
    }

    public void setRow_id_acesso(String row_id_acesso) {
        this.row_id_acesso = row_id_acesso;
    }

    public String getPais_cliente() {
        return pais_cliente;
    }

    public void setPais_cliente(String pais_cliente) {
        this.pais_cliente = pais_cliente;
    }

    public String getRow_id_cliente() {
        return row_id_cliente;
    }

    public void setRow_id_cliente(String row_id_cliente) {
        this.row_id_cliente = row_id_cliente;
    }

    public String getRow_id_root_acesso() {
        return row_id_root_acesso;
    }

    public void setRow_id_root_acesso(String row_id_root_acesso) {
        this.row_id_root_acesso = row_id_root_acesso;
    }

    public String getRod_id_perfil_fatura_acesso() {
        return rod_id_perfil_fatura_acesso;
    }

    public void setRod_id_perfil_fatura_acesso(String rod_id_perfil_fatura_acesso) {
        this.rod_id_perfil_fatura_acesso = rod_id_perfil_fatura_acesso;
    }

	@Override
	public String toString() {
		return "Bat223Model [customer_id=" + customer_id + ", cpf_cliente=" + cpf_cliente
				+ ", tipo_logradouro_instalacao=" + tipo_logradouro_instalacao + ", logradouro_instalacao="
				+ logradouro_instalacao + ", numero_endereco_instalacao=" + numero_endereco_instalacao
				+ ", complemento_instalacao=" + complemento_instalacao + ", bairro_instalacao=" + bairro_instalacao
				+ ", cidade_instalacao=" + cidade_instalacao + ", uf_instalacao=" + uf_instalacao + ", cep_instalacao="
				+ cep_instalacao + ", caixa_postal_instalacao=" + caixa_postal_instalacao
				+ ", rowid_endereco_instalacao=" + rowid_endereco_instalacao + ", codigo_nacional_localidade="
				+ codigo_nacional_localidade + ", tipo_acesso=" + tipo_acesso + ", numero_contrato=" + numero_contrato
				+ ", data_hora_ativacao=" + data_hora_ativacao + ", codigo_comercial_plano=" + codigo_comercial_plano
				+ ", nome_plano=" + nome_plano + ", msisdn=" + msisdn + ", status_contrato=" + status_contrato
				+ ", data_hora_ultimo_status=" + data_hora_ultimo_status + ", data_hora_ultima_atualizacao_contrato="
				+ data_hora_ultima_atualizacao_contrato + ", data_aging_cliente=" + data_aging_cliente
				+ ", codigo_pdv_ativacao=" + codigo_pdv_ativacao + ", codigo_pdv_ultima_modificacao="
				+ codigo_pdv_ultima_modificacao + ", numero_simcard=" + numero_simcard + ", subtipo_acesso="
				+ subtipo_acesso + ", motivo_status=" + motivo_status + ", cliente_permite_divulgacao_lista_telefonica="
				+ cliente_permite_divulgacao_lista_telefonica + ", login_responsavel_ativacao="
				+ login_responsavel_ativacao + ", perfil_login_responsavel_ativacao="
				+ perfil_login_responsavel_ativacao + ", perfil_login_modif=" + perfil_login_modif
				+ ", login_resp_ultima_modif=" + login_resp_ultima_modif + ", flag_contrato_pertence_grupo_acapulco="
				+ flag_contrato_pertence_grupo_acapulco + ", flag_contrato_administrador_grupo_acapulco="
				+ flag_contrato_administrador_grupo_acapulco + ", rowid=" + rowid + ", loteid=" + loteid + ", arquivo="
				+ arquivo + ", arquivots=" + arquivots + ", currentdate=" + currentdate + ", ide_promocao="
				+ ide_promocao + ", dsc_segmento_linha=" + dsc_segmento_linha + ", row_id_acesso=" + row_id_acesso
				+ ", pais_cliente=" + pais_cliente + ", row_id_cliente=" + row_id_cliente + ", row_id_root_acesso="
				+ row_id_root_acesso + ", rod_id_perfil_fatura_acesso=" + rod_id_perfil_fatura_acesso + "]";
	}

    

}
