package br.com.tim.mapreduce.utils;

public class ReducerRules {

}
