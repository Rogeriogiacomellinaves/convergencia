package br.com.tim.mapreduce.e2e.step1;

public enum TypeStep1 {

   HIST, ROOT, PLANO, DESCONTO, LIVE, MOVEL
   
}