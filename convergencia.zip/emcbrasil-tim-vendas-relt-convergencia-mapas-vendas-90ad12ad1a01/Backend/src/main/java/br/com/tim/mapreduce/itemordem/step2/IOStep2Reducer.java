package br.com.tim.mapreduce.itemordem.step2;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.log4j.Logger;

import java.io.IOException;

public class IOStep2Reducer extends org.apache.hadoop.mapreduce.Reducer<IOStep2Key,IOStep2Value,NullWritable,Text> {

    protected static final Logger LOG = Logger.getLogger(IOStep2Reducer.class);
    private IOStep2OutValue outValue;

    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        super.setup(context);
        outValue = new IOStep2OutValue();
    }

    @Override
    protected void reduce(IOStep2Key key, Iterable<IOStep2Value> values, Context context) throws InterruptedException {

        outValue.clear();

        try {
            for (IOStep2Value value : values) {
                if (value.getTipo().equals(TypeStep2.BAT513)){
                    outValue.setBAT513(value);
                }else if (value.getTipo().equals(TypeStep2.RESULTSTEP1)){
                    outValue.clearStep1Result();
                    outValue.setStep1Result(value);
                    context.write(NullWritable.get(),new Text(outValue.toString()));
                }
            }

        } catch (Exception e) {
            LOG.error(" ############ ERROR EXECUTION REDUCER ############ ");
            LOG.error(e.getMessage());
            throw new InterruptedException(e.getMessage());
        }
    }



    @Override
    protected void cleanup(Context context) throws IOException, InterruptedException {
        super.cleanup(context);

    }
}


