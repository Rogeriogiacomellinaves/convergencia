package br.com.tim.mapreduce.refactoring.endtoend.step1;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.CombineSequenceFileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import br.com.tim.driverutils.DriverUtils;
import br.com.tim.driverutils.Entry;
import br.com.tim.driverutils.Partition;
import br.com.tim.exception.CommonsException;
import br.com.tim.kerberos.KerberosAuth;
import br.com.tim.kerberos.KerberosAuthException;
import br.com.tim.mapreduce.refactoring.endtoend.step1.pt1.E2EStep1Pt1Key;
import br.com.tim.mapreduce.refactoring.endtoend.step1.pt1.E2EStep1Pt1Reducer;
import br.com.tim.mapreduce.refactoring.endtoend.step1.pt1.E2EStep1Pt1Value;
import br.com.tim.mapreduce.refactoring.endtoend.step1.pt1.GroupingComparator;
import br.com.tim.mapreduce.refactoring.endtoend.step1.pt1.JoinPartitioner;
import br.com.tim.mapreduce.refactoring.endtoend.step1.pt1.MapperItem;
import br.com.tim.mapreduce.refactoring.endtoend.step1.pt1.utils.Step1pt1Constants;
import br.com.tim.mapreduce.refactoring.endtoend.step1.pt2.MapperOrdem;
import br.com.tim.mapreduce.refactoring.endtoend.step1.pt2.MapperStep1;
import br.com.tim.mapreduce.refactoring.endtoend.step1.pt2.Step1Pt2Key;
import br.com.tim.mapreduce.refactoring.endtoend.step1.pt2.Step1Pt2Reducer;
import br.com.tim.mapreduce.refactoring.endtoend.step1.pt2.Step1Pt2Value;
import br.com.tim.mapreduce.refactoring.endtoend.step1.pt3.E2EStep1pt3Key;
import br.com.tim.mapreduce.refactoring.endtoend.step1.pt3.E2EStep1pt3Reducer;
import br.com.tim.mapreduce.refactoring.endtoend.step1.pt3.E2EStep1pt3Value;
import br.com.tim.mapreduce.refactoring.endtoend.step1.pt3.MapperStep1PT2Result;
import br.com.tim.mapreduce.refactoring.endtoend.step1.pt3.MapperWfmtoa;
import br.com.tim.mapreduce.refactoring.endtoend.step1.pt3.utils.Step1Pt3Constants;
import br.com.tim.mapreduce.refactoring.endtoend.step1.pt4.E2EStep1Pt4Key;
import br.com.tim.mapreduce.refactoring.endtoend.step1.pt4.E2EStep1Pt4Reducer;
import br.com.tim.mapreduce.refactoring.endtoend.step1.pt4.E2EStep1Pt4Value;
import br.com.tim.mapreduce.refactoring.endtoend.step1.pt4.MapperFiber;
import br.com.tim.mapreduce.refactoring.endtoend.step1.pt4.MapperStep1Pt3Result;
import br.com.tim.mapreduce.refactoring.endtoend.step1.pt4.utils.Step1Pt4Constants;
import br.com.tim.mapreduce.refactoring.endtoend.utils.Step1Pt2Constants;
import br.com.tim.metric.JobMetric;
import br.com.tim.metric.JobMetricHelper;
import br.com.tim.metric.MetricConstants;
import br.com.tim.mr.GenericMetricsDriver;
import br.com.tim.utils.CommonsConstants;

public class Step1Driver extends GenericMetricsDriver {

	private static Logger log = Logger.getLogger(Step1Driver.class);
	private Configuration conf;
	private String[] args;
	private FileSystem fs;
	private String stagingPath;
	private String dat_ref;
	private static DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	private int retorno = 1;

	private Job job1, job2, job3, job4;
	private String outputStep1;

	public Step1Driver(String[] args) {
		this.args = args;
	}

	public static void main(String[] args) throws Exception {
		log.info("============================== BEGIN STEP1 ======================================");
		Step1Driver driver = new Step1Driver(args);
		int exitCode = ToolRunner.run(driver, args);
		log.info("Exit code: " + exitCode);
		log.info(
				"=============================== END MODELO CARING CLIENTE JOB =======================================");
		System.exit(exitCode);
	}

	@Override
	public int run(String[] arg) throws Exception {
		  Date inicio = new Date();

	        try {
	            if (!systemPropertiesValidate()) {
	                System.exit(1);
	            }

	            PropertyConfigurator.configure(System.getProperty("log4j"));
	            Configuration configuration = this.getConf();
	            configuration.addResource(new Path(System.getProperty("env_configuration")));
	            configuration.addResource(new Path(System.getProperty("job_metrics_configuration")));
	            configuration.addResource(new Path(System.getProperty("configuration")));

	            try {
	                KerberosAuth.authenticate(configuration);
	            } catch (KerberosAuthException var6) {
	                throw new Exception(var6);
	            }

	            this.job1 = Job.getInstance(configuration);
	            this.configureStep1();

	            log.info("Running Pre Execution Steps.");
	            String metricsFilePath = System.getProperty("metrics-definition");
	            String customMetrics = System.getProperty("custom_metrics");

	            if (customMetrics != null) {
	                this.metrics = new JobMetric(configuration, new String[]{metricsFilePath, customMetrics});
	            } else {
	                this.metrics = new JobMetric(configuration, new String[]{metricsFilePath});
	            }


	            log.info(
	                    "============================== CARING CLIENTE STEP1 ======================================");

	            if (this.job1.waitForCompletion(true) && job1.isSuccessful()) {

	                log.info(
	                        "=============================== CARING CLIENTE STEP1 FINISHED SUCCESSFULY ==================================");
	                Thread.sleep(Long.valueOf(configuration.get(MetricConstants.MILLIS_TO_WAIT)));

	                log.info("=============================== Saving Job Metrics ========================================");
	                JobMetricHelper.generateMetrics(this.job1, null, metrics);

	                log.info("================================== CARING CLIENTE STEP2 ===========================================");

	                try {
	                    KerberosAuth.authenticate(configuration);
	                } catch (KerberosAuthException var6) {
	                    throw new Exception(var6);
	                }


	                job2 = Job.getInstance(configuration);
	                this.configureStep2();

	                // Configura metricas do JobB
	                if (customMetrics != null)
	                    metrics = new JobMetric(configuration, metricsFilePath, customMetrics);
	                else
	                    metrics = new JobMetric(configuration, metricsFilePath);

	                if (job2.waitForCompletion(true) && job2.isSuccessful()) {

	                    log.info(
	                            "=============================== CARING CLIENTE STEP2 FINISHED SUCCESSFULY ==================================");
	                    Thread.sleep(Long.valueOf(configuration.get(MetricConstants.MILLIS_TO_WAIT)));

	                    log.info("=============================== Saving Job Metrics ========================================");
	                    JobMetricHelper.generateMetrics(this.job2, null, metrics);

	                    log.info("================================== CARING CLIENTE STEP3 ===========================================");

	                    try {
	                        KerberosAuth.authenticate(configuration);
	                    } catch (KerberosAuthException var6) {
	                        throw new Exception(var6);
	                    }


	                    this.job3 = Job.getInstance(configuration);
	                    this.configureStep3();

	                    // Configura metricas do JobB
	                    if (customMetrics != null)
	                        metrics = new JobMetric(configuration, metricsFilePath, customMetrics);
	                    else
	                        metrics = new JobMetric(configuration, metricsFilePath);

	                    if( this.job3.waitForCompletion(true) && job3.isSuccessful()){

	                        log.info(
	                                "=============================== CARING CLIENTE STEP3 FINISHED SUCCESSFULY ==================================");
	                        Thread.sleep(Long.valueOf(configuration.get(MetricConstants.MILLIS_TO_WAIT)));

	                        log.info("=============================== Saving Job Metrics ========================================");
	                        JobMetricHelper.generateMetrics(this.job3, null, metrics);


	                        this.postExecutionSteps();

	                        retorno = CommonsConstants.SUCCESS;;

	                    }else {
	                        log.info("===== ROLLING BACK ======");
	                        this.rollback();
	                        log.info("===== Saving Job Metrics ======");
	                        JobMetricHelper.generateMetrics(this.job3, this.getStagingPath(), this.metrics);
	                    }

	                } else {
	                    log.info(
	                            "=============================== SAVING STAGE METRICS ========================================");
	                    JobMetricHelper.generateMetrics(this.job2, null, metrics);

	                    log.info(
	                            "========================= STAGE 02 FINISHED UNSUCCESSFULY ===================================");
	                    retorno = CommonsConstants.ERROR;
	                }

	            } else {
	                log.info("===== ROLLING BACK ======");
	                this.rollback();
	                log.info("===== Saving Job Metrics ======");
	                JobMetricHelper.generateMetrics(this.job1, this.getStagingPath(), this.metrics);
	            }
	        } catch (Exception var7) {
	            log.error("Generic error executing driver... ", var7);
	            log.info("===== Saving Job Metrics ======");

	            JobMetricHelper.generateMetrics(this.job1, this.getStagingPath(), this.metrics);
	            if(this.job2 != null)
	            JobMetricHelper.generateMetrics(this.job2, this.getStagingPath(), this.metrics);
	            if(this.job3 != null)
	            JobMetricHelper.generateMetrics(this.job3, this.getStagingPath(), this.metrics);
	            log.info("===== ROLLING BACK ======");
	            this.rollback();
	            throw new CommonsException(var7.getMessage(), var7);
	        }

	        log.info("---- Elapsed Time: " + ((new Date()).getTime() - inicio.getTime()) / 1000L + " seconds.");
	        return this.retorno;
	}

	protected void configureStep1() throws Exception {

		conf = this.job1.getConfiguration();
		fs = FileSystem.get(conf);

		try {
			this.configureCommonsStep1();
			this.setProcessDate();
			job1.getConfiguration().set("dat_ref", dat_ref);
		} catch (Exception ex) {
			throw new Exception("Error configuring JOB Commons :" + ex.getMessage());
		}

		@SuppressWarnings("rawtypes")
		Class<CombineSequenceFileInputFormat> inputClass = CombineSequenceFileInputFormat.class;

		int defaultMinusDays = Integer.valueOf(this.fs.getConf().get(Step1pt1Constants.STEP1PT1_LOOK_BACK_DAYS, "1"));

		Entry itemEntry = new Entry(Step1pt1Constants.STEP1PT1_ITEM, Step1pt1Constants.STEP1PT1_ITEM_FACT_INPUT, true,
				false, false, true, inputClass, MapperItem.class, new Partition("dat_ref", Partition.Format.DATE_DAY,
						CommonsConstants.YYYYMMDD, defaultMinusDays, -1, true));

		DriverUtils.addInputPaths(args, conf, job1,1 ,itemEntry);

		outputStep1 = this.fs.getConf().get(Step1pt1Constants.STEP1PT1_OUTPUT);
		Path stagingPathDir = new Path(outputStep1);

		log.info("Data em execução: " + job1.getConfiguration().get("dat_ref"));

		if (fs.exists(stagingPathDir)) {
			log.info("WARN: Staging: " + stagingPathDir.toString() + " already exists, deleting it...");
			fs.delete(stagingPathDir, true);
		}

		log.info("Staging Path: " + stagingPathDir.toString());

		TextOutputFormat.setOutputPath(this.job1, stagingPathDir);

	}

	protected void configureStep2() throws Exception {

		conf = this.job2.getConfiguration();
		fs = FileSystem.get(conf);

		try {
			log.info("ENTROU NO CONFIGURE");
			this.configureCommonsStep2();
			this.setProcessDate();
			job2.getConfiguration().set("dat_ref", dat_ref);
		} catch (Exception ex) {
			throw new Exception("Error configuring JOB Commons :" + ex.getMessage());
		}

		@SuppressWarnings("rawtypes")
		Class<CombineSequenceFileInputFormat> inputClass = CombineSequenceFileInputFormat.class;
		Class<TextInputFormat> textInputClass = TextInputFormat.class;

		int defaultMinusDays = Integer.valueOf(this.fs.getConf().get(Step1Pt2Constants.STEP1PT2_LOOK_BACK_DAYS, "1"));

		Partition ordemPartition = new Partition(conf.get(Step1Pt2Constants.STEP1PT2ORDER_FACT_PARTITION),
				Partition.Format.DATE_DAY, Step1Pt2Constants.YYYYMMDD, defaultMinusDays, -1, true);
		Entry ordemEntry = new Entry(conf.get(Step1Pt2Constants.STEP1PT2ORDER),
				Step1Pt2Constants.STEP1PT2ORDER_FACT_INPUT, false, true, inputClass, MapperOrdem.class, ordemPartition);

		Entry Step1ResultEntry = new Entry(conf.get(Step1Pt2Constants.STEP2PT1), Step1Pt2Constants.STEP1PT1_FACT_INPUT,
				true, true, textInputClass, MapperStep1.class);

		DriverUtils.addInputPaths(args, conf, job2, ordemEntry, Step1ResultEntry);

		log.info("Data em execução: " + job2.getConfiguration().get("dat_ref"));

		// Staging PATH
		this.stagingPath = conf.get(Step1Pt2Constants.STEP2PT1_STAGING_OUTPUT);
		Path stagingPathDir = new Path(this.stagingPath);

		if (fs.exists(stagingPathDir)) {
			log.info("WARN: Staging: " + stagingPathDir.toString() + " already exists, deleting it...");
			fs.delete(stagingPathDir, true);
		}

		log.info("Staging Path: " + stagingPathDir.toString());
		TextOutputFormat.setOutputPath(this.job2, stagingPathDir);

	}

	protected void configureStep3() throws Exception {

		conf = this.job3.getConfiguration();
		fs = FileSystem.get(conf);

		this.job3.getConfiguration().set("dat_ref", this.job2.getConfiguration().get("dat_ref"));

		try {
			this.configureCommonsStep3();
			this.setProcessDate();
			job3.getConfiguration().set("dat_ref", dat_ref);
		} catch (Exception ex) {
			throw new Exception("Error configuring JOB Commons :" + ex.getMessage());
		}

		@SuppressWarnings("rawtypes")
		Class<CombineSequenceFileInputFormat> inputClass = CombineSequenceFileInputFormat.class;
		Class<TextInputFormat> textInputClass = TextInputFormat.class;

		int defaultMinusDays = Integer.valueOf(this.fs.getConf().get(Step1Pt3Constants.WFTMOA_LOOK_BACK_DAYS, "1"));

		Entry wfmtoa = new Entry(Step1Pt3Constants.WFTMOA_NAME, Step1Pt3Constants.WFTMOA_FACT_INPUT, false, false,
				false, true, inputClass, MapperWfmtoa.class, new Partition("dat_ref", Partition.Format.DATE_DAY,
						CommonsConstants.YYYYMMDD, defaultMinusDays, -1, true));

		Entry result = new Entry(Step1Pt3Constants.STEP1PT2_NAME, Step1Pt3Constants.STEP1PT2_FACT_INPUT, true, true,
				textInputClass, MapperStep1PT2Result.class);

		DriverUtils.addInputPaths(args, conf, this.job3, wfmtoa, result);

		log.info("Data em execução: " + job3.getConfiguration().get("dat_ref"));

		// Staging PATH
		this.stagingPath = this.fs.getConf().get(Step1Pt3Constants.STEP1PT3_OUTPUT);
		Path stagingPathDir = new Path(this.stagingPath);

		if (fs.exists(stagingPathDir)) {
			log.info("WARN: Staging: " + stagingPathDir.toString() + " already exists, deleting it...");
			fs.delete(stagingPathDir, true);
		}

		log.info("Staging Path: " + stagingPathDir.toString());
		TextOutputFormat.setOutputPath(this.job3, stagingPathDir);

	}

	protected void configureStep4() throws Exception {

		conf = this.job4.getConfiguration();
		fs = FileSystem.get(conf);

		try {
			log.info("ENTROU NO CONFIGURE");
			this.configureCommonsStep4();
			this.setProcessDate();
			job4.getConfiguration().set("dat_ref", dat_ref);
		} catch (Exception ex) {
			throw new Exception("Error configuring JOB Commons :" + ex.getMessage());
		}

		@SuppressWarnings("rawtypes")
		Class<CombineSequenceFileInputFormat> inputClass = CombineSequenceFileInputFormat.class;
		Class<TextInputFormat> textInputClass = TextInputFormat.class;

		int defaultMinusDays = Integer.valueOf(this.fs.getConf().get(Step1Pt4Constants.LOOK_BACK_DAYS_FIBER, "1"));

		Entry EntryFiber = new Entry(Step1Pt4Constants.FIBER, Step1Pt4Constants.FIBER_INPUT_FACT, true, false, false, true, inputClass,
				MapperFiber.class, new Partition("dat_ref", Partition.Format.DATE_DAY, CommonsConstants.YYMMDD,
						defaultMinusDays, -1, false),
				new Partition("sist_origem", Partition.Format.FIXED, CommonsConstants.ALL));

		Entry EntryStep1Pt3 = new Entry(Step1Pt4Constants.STEP1PT3, Step1Pt4Constants.STEP1PT3_INPUT_FACT, true, true, textInputClass,
				MapperStep1Pt3Result.class);

		DriverUtils.addInputPaths(args, conf, this.job4, EntryFiber, EntryStep1Pt3);

		log.info("Data em execução: " + job4.getConfiguration().get("dat_ref"));

		// Staging PATH
		this.stagingPath = this.fs.getConf().get(Step1Pt4Constants.STEP1PT4_OUTPUT_PATH);
		Path stagingPathDir = new Path(this.stagingPath);

		if (fs.exists(stagingPathDir)) {
			log.info("WARN: Staging: " + stagingPathDir.toString() + " already exists, deleting it...");
			fs.delete(stagingPathDir, true);
		}

		log.info("Staging Path: " + stagingPathDir.toString());
		TextOutputFormat.setOutputPath(this.job4, stagingPathDir);
	}

	private void setProcessDate() {
		dat_ref = dtf.format(LocalDate.now().minusMonths(1));

		if (args.length == 1) {
			if (args[0].contains("reprocess-day")) {
				dat_ref = args[0].split("\\=")[1];
			} else if (args[0].contains("reprocess-month")) {
				dat_ref = args[0].split("\\=")[1] + "-01";
			}
		}

	}

	protected void configureCommonsStep1() throws Exception {

		this.job1.setJobName(conf.get(Step1pt1Constants.STEP1PT1_NAME));
		this.job1.setJarByClass(getClass());
		this.job1.setMapOutputKeyClass(E2EStep1Pt1Key.class);
		this.job1.setMapOutputValueClass(E2EStep1Pt1Value.class);
		this.job1.setReducerClass(E2EStep1Pt1Reducer.class);
		this.job1.setOutputKeyClass(NullWritable.class);
		this.job1.setOutputValueClass(Text.class);
		this.job1.setInputFormatClass(TextInputFormat.class);
		this.job1.setOutputFormatClass(TextOutputFormat.class);
		this.job1.setPartitionerClass(JoinPartitioner.class);
		this.job1.setGroupingComparatorClass(GroupingComparator.class);

	}

	protected void configureCommonsStep2() throws Exception {

		this.job2.setJobName(conf.get(Step1Pt2Constants.STEP1PT2_NAME));
		this.job2.setJarByClass(getClass());
		this.job2.setReducerClass(Step1Pt2Reducer.class);
		this.job2.setMapOutputKeyClass(Step1Pt2Key.class);
		this.job2.setMapOutputValueClass(Step1Pt2Value.class);
		this.job2.setOutputKeyClass(NullWritable.class);
		this.job2.setOutputValueClass(Text.class);
		this.job2.setInputFormatClass(TextInputFormat.class);
		this.job2.setOutputFormatClass(TextOutputFormat.class);
		this.job2.setPartitionerClass(br.com.tim.mapreduce.refactoring.endtoend.step1.pt2.JoinPartitioner.class);
		this.job2.setGroupingComparatorClass(br.com.tim.mapreduce.refactoring.endtoend.step1.pt2.GroupingComparator.class);

	}

	protected void configureCommonsStep3() throws Exception {

		this.job3.setJobName(conf.get(Step1Pt3Constants.STEP1PT3_NAME));
		this.job3.setJarByClass(getClass());
		this.job3.setMapOutputKeyClass(E2EStep1pt3Key.class);
		this.job3.setMapOutputValueClass(E2EStep1pt3Value.class);
		this.job3.setReducerClass(E2EStep1pt3Reducer.class);
		this.job3.setOutputKeyClass(NullWritable.class);
		this.job3.setOutputValueClass(Text.class);
		this.job3.setInputFormatClass(TextInputFormat.class);
		this.job3.setOutputFormatClass(TextOutputFormat.class);
		this.job3.setPartitionerClass(br.com.tim.mapreduce.refactoring.endtoend.step1.pt3.JoinPartitioner.class);
		this.job3.setGroupingComparatorClass(br.com.tim.mapreduce.refactoring.endtoend.step1.pt3.GroupingComparator.class);

	}

	protected void configureCommonsStep4() throws Exception {
		
		this.job4.setJobName(conf.get(Step1Pt4Constants.STEP1PT4_NAME));
		this.job4.setJarByClass(getClass());
		this.job4.setMapOutputKeyClass(E2EStep1Pt4Key.class);
		this.job4.setMapOutputValueClass(E2EStep1Pt4Value.class);
		this.job4.setReducerClass(E2EStep1Pt4Reducer.class);
		this.job4.setOutputKeyClass(NullWritable.class);
		this.job4.setOutputValueClass(Text.class);
		this.job4.setInputFormatClass(TextInputFormat.class);
		this.job4.setOutputFormatClass(TextOutputFormat.class);
		this.job4.setPartitionerClass(br.com.tim.mapreduce.refactoring.endtoend.step1.pt4.JoinPartitioner.class);
		this.job4.setGroupingComparatorClass(br.com.tim.mapreduce.refactoring.endtoend.step1.pt4.GroupingComparator.class);

	}

	@Override
	protected void postExecutionSteps() throws Exception {

	}

	@Override
	protected void configure() throws Exception {

	}

}
