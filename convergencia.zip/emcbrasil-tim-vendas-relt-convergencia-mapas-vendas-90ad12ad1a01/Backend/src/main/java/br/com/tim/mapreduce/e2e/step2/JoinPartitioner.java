package br.com.tim.mapreduce.e2e.step2;

import org.apache.hadoop.mapreduce.Partitioner;

public class JoinPartitioner extends Partitioner<E2EStep2Key, E2EStep2Value> {

    @Override
    public int getPartition(E2EStep2Key taggedKey, E2EStep2Value value, int numPartitions) {
        return Math.abs(taggedKey.hashCodeJoin() % numPartitions);
    }
}