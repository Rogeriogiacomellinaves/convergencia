
package br.com.tim.mapreduce.e2e.step2;

import br.com.tim.mapreduce.model.BAT509Order;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

import java.io.IOException;

public class MapperOrdem extends org.apache.hadoop.mapreduce.Mapper<Writable,Text,E2EStep2Key,E2EStep2Value> {

	private E2EStep2Key outkey;
	private E2EStep2Value outValue;
	private BAT509Order input;
	@Override
	protected void map(Writable key, Text value, Context context) throws IOException, InterruptedException {
		input.parse(value.toString());
		outkey.setNroOrdem(input.getNumeroOrdem());
		outkey.setDatRef(input.getArquivo().substring(17, 25));
		outkey.setTipo(TypeStep2.ORDEM);
		outValue.setOrdem(input, context);
		context.write(outkey, outValue);
	}

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		super.setup(context);
		this.outkey = new E2EStep2Key();
		this.outValue = new E2EStep2Value();
		this.input = new BAT509Order();
	}

	@Override
	protected void cleanup(Context context) throws IOException, InterruptedException {
		super.cleanup(context);
		this.clear();
	}

	private void clear(){
	   this.outValue.clear();
	}

}