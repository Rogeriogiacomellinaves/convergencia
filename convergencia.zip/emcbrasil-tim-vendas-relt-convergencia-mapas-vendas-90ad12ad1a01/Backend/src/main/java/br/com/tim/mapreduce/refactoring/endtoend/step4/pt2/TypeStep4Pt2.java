package br.com.tim.mapreduce.refactoring.endtoend.step4.pt2;

public enum TypeStep4Pt2 {
	
	ORDER, STEP4, DEFAULT

}
