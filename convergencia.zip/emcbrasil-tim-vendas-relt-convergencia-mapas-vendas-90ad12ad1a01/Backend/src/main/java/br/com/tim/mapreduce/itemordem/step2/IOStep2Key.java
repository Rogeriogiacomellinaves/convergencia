package br.com.tim.mapreduce.itemordem.step2;

import br.com.tim.mapreduce.itemordem.GroupComparable;
import br.com.tim.mapreduce.itemordem.step2.model.Step1Result;
import br.com.tim.mapreduce.model.BAT513;
import com.google.common.collect.ComparisonChain;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Objects;


public class IOStep2Key implements GroupComparable<IOStep2Key> {

	private String codProduto;
	private TypeStep2 tipo;

	@Override
	public void write(DataOutput output) throws IOException {
		output.writeInt(this.tipo.ordinal());
		output.writeUTF(this.codProduto);
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		this.tipo = TypeStep2.values()[in.readInt()];
		this.codProduto = in.readUTF();
	}

	public void setKey(BAT513 obj) {
		this.clear();
		this.tipo = TypeStep2.BAT513;
		this.codProduto = obj.getIdSiebel();
	}

	public void setKey(Step1Result obj) {
		this.clear();
		this.tipo = TypeStep2.RESULTSTEP1;
		this.codProduto = obj.getCodProduto();
	}

	@Override
	public int compareTo(IOStep2Key o) {
		return ComparisonChain.start().compare(this.codProduto, o.codProduto).compare(this.tipo , o.tipo)
				.result();
	}


	@Override
	public int compareToGrouping(IOStep2Key o) {
		return ComparisonChain.start().compare(this.codProduto, o.codProduto).result();
	}

	public int hashCodeJoin() {

		return Objects.hash(codProduto);
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		IOStep2Key key = (IOStep2Key) o;
		return Objects.equals(codProduto, key.codProduto) && Objects.equals(tipo, key.tipo);
	}

	@Override
	public int hashCode() {

		return Objects.hash(codProduto);
	}

	public void clear(){
		this.codProduto = "";
	}
}