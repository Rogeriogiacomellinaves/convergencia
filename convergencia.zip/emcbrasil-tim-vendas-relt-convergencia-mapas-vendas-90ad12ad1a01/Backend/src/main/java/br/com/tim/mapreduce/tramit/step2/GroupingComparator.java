package br.com.tim.mapreduce.tramit.step2;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

public class GroupingComparator extends WritableComparator {

    public GroupingComparator() {
        super(TramitStep2Key.class, true);
    }

    @SuppressWarnings({"rawtypes"})
    @Override
    public int compare(WritableComparable a, WritableComparable b) {
        TramitStep2Key keyA = (TramitStep2Key) a;
        TramitStep2Key keyB = (TramitStep2Key) b;

        return keyA.compareToGrouping(keyB);
    }

}
