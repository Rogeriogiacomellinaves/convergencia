package br.com.tim.mapreduce.refactoring.endtoend.step4.pt2;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

public class GroupingComparator extends WritableComparator {

    public GroupingComparator() {
        super(Step4Pt2Key.class, true);
    }

    @SuppressWarnings({"rawtypes"})
    @Override
    public int compare(WritableComparable a, WritableComparable b) {
    	Step4Pt2Key keyA = (Step4Pt2Key) a;
    	Step4Pt2Key keyB = (Step4Pt2Key) b;

        return keyA.compareToGrouping(keyB);
    }

}
