package br.com.tim.mapreduce.e2e.step9;

public enum TypeStep9 {

    BAT226, RELT
}
