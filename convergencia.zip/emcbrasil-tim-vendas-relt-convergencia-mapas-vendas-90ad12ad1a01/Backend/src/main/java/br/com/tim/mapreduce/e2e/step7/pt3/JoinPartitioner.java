package br.com.tim.mapreduce.e2e.step7.pt3;

import br.com.tim.mapreduce.e2e.step7.E2EStep7Key;
import org.apache.hadoop.mapreduce.Partitioner;

public class JoinPartitioner extends Partitioner<E2EStep7Key, E2EStep7PT3Value> {

    @Override
    public int getPartition(E2EStep7Key taggedKey, E2EStep7PT3Value value, int numPartitions) {
        return Math.abs(taggedKey.hashCodeJoin() % numPartitions);
    }
}