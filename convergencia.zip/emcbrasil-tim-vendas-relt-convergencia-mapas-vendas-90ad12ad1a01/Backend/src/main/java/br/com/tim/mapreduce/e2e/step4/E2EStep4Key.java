package br.com.tim.mapreduce.e2e.step4;

import br.com.tim.mapreduce.e2e.GroupComparable;
import com.google.common.collect.ComparisonChain;
import org.apache.hadoop.io.WritableComparable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Objects;


public class E2EStep4Key implements GroupComparable<E2EStep4Key> {

	private String codContaFinanceira;
	private TypeStep4 tipo;

	@Override
	public void write(DataOutput output) throws IOException {
		output.writeInt(tipo.ordinal());
		output.writeUTF(this.codContaFinanceira);
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		this.tipo = TypeStep4.values()[in.readInt()];
		this.codContaFinanceira = in.readUTF();
	}

	public String getCodContaFinanceira() {
		return codContaFinanceira;
	}

	public void setTipo(TypeStep4 tipo) {
		this.tipo = tipo;
	}

	public void setCodContaFinanceira(String codContaFinanceira) {
		this.codContaFinanceira = codContaFinanceira;
	}

	@Override
	public int compareTo(E2EStep4Key o) {
		return ComparisonChain.start().compare(this.codContaFinanceira, o.codContaFinanceira).compare(this.tipo, o.tipo)
				.result();
	}

	@Override
	public int compareToGrouping(E2EStep4Key o) {
		return ComparisonChain.start().compare(this.codContaFinanceira, o.codContaFinanceira).result();
	}

	public int hashCodeJoin() {

		return Objects.hash(codContaFinanceira);
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		E2EStep4Key key = (E2EStep4Key) o;
		return Objects.equals(codContaFinanceira, key.codContaFinanceira);
	}


	@Override
	public int hashCode() {

		return Objects.hash(codContaFinanceira);
	}
}