package br.com.tim.mapreduce.e2e.step5;

public enum TypeStep5 {

    Fiber, RELT
}
