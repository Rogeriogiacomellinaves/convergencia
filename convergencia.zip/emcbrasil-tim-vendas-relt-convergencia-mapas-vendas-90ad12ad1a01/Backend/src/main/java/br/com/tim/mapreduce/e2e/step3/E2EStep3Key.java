package br.com.tim.mapreduce.e2e.step3;

import br.com.tim.mapreduce.e2e.GroupComparable;
import com.google.common.collect.ComparisonChain;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Objects;


public class E2EStep3Key implements GroupComparable<E2EStep3Key> {

	private String idSiebel;
	private TypeStep3 tipo;

	@Override
	public void write(DataOutput output) throws IOException {
		output.writeInt(tipo.ordinal());
		output.writeUTF(this.idSiebel);
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		this.tipo = TypeStep3.values()[in.readInt()];
		this.idSiebel = in.readUTF();
	}

	public void setTipo(TypeStep3 tipo) {
		this.tipo = tipo;
	}

	public void setIdSiebel(String idSiebel) {
		this.idSiebel = idSiebel;
	}

	@Override
	public int compareTo(E2EStep3Key o) {
		return ComparisonChain.start().compare(this.idSiebel, o.idSiebel).compare(this.tipo, o.tipo)
				.result();
	}

	@Override
	public int compareToGrouping(E2EStep3Key o) {
		return ComparisonChain.start().compare(this.idSiebel, o.idSiebel).result();
	}

	public int hashCodeJoin() {

		return Objects.hash(idSiebel);
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		E2EStep3Key key = (E2EStep3Key) o;
		return Objects.equals(idSiebel, key.idSiebel);
	}


	@Override
	public int hashCode() {

		return Objects.hash(idSiebel);
	}
}