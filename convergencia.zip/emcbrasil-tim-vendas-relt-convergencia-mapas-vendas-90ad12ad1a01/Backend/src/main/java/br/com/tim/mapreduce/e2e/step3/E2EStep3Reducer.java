package br.com.tim.mapreduce.e2e.step3;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.log4j.Logger;

import java.io.IOException;

public class E2EStep3Reducer extends org.apache.hadoop.mapreduce.Reducer<E2EStep3Key,E2EStep3Value,NullWritable,Text> {

    protected static final Logger LOG = Logger.getLogger(E2EStep3Reducer.class);
    private E2EStep3OutValue outValue;


    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        super.setup(context);
        outValue = new E2EStep3OutValue();
    }

    @Override
    protected void reduce(E2EStep3Key key, Iterable<E2EStep3Value> values, Context context) throws InterruptedException {

        outValue.clear();

        try {
            for (E2EStep3Value value : values) {
                if (value.getTipo().equals(TypeStep3.RELT)){
                    outValue.clearRelt();
                    outValue.setRelt(value);
                    context.write(NullWritable.get(), new Text(outValue.toString()));
                }else if (value.getTipo().equals(TypeStep3.BAT513)){
                    outValue.setBAT513(value);
                }
            }

        } catch (Exception e) {
            LOG.error(" ############ ERROR EXECUTION REDUCER ############ ");
            LOG.error(e.getMessage());
            throw new InterruptedException(e.getMessage());
        }
    }



    @Override
    protected void cleanup(Context context) throws IOException, InterruptedException {
        super.cleanup(context);

    }
}


