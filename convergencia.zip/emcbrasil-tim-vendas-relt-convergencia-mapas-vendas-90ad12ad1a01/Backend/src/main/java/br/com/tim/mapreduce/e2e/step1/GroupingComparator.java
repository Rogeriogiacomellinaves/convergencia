package br.com.tim.mapreduce.e2e.step1;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

public class GroupingComparator extends WritableComparator {

    public GroupingComparator() {
        super(E2EStep1Key.class, true);
    }

    @SuppressWarnings({"rawtypes"})
    @Override
    public int compare(WritableComparable a, WritableComparable b) {
        E2EStep1Key keyA = (E2EStep1Key) a;
        E2EStep1Key keyB = (E2EStep1Key) b;

        return keyA.compareToGrouping(keyB);
    }

}
