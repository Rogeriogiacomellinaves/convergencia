
package br.com.tim.mapreduce.refactoring.endtoend.step1.pt1;

import br.com.tim.mapreduce.refactoring.endtoend.step1.pt1.utils.Step1Pt1Counters;
import br.com.tim.mapreduce.refactoring.model.BAT509Item;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

public class MapperItem extends org.apache.hadoop.mapreduce.Mapper<Writable, Text, E2EStep1Pt1Key, E2EStep1Pt1Value> {

	private E2EStep1Pt1Key outkey;
	private E2EStep1Pt1Value outValue;
	private BAT509Item input;
	private List<String> tiposDeItemDeOrdem;

	@Override
	protected void map(Writable key, Text value, Context context) throws IOException, InterruptedException {
		input.parse(value.toString());
		outkey.setDatRef(input.getArquivo());

		if (outkey.getDatRef().equals(context.getConfiguration().get("dat-ref"))) {
			outkey.clear();
			outValue.clear();

			if (input.getAcaoItemOrdem().toUpperCase().trim().equals("NOVA")) {

				if (input.getCategoriaItemOrdem().toUpperCase().trim().equals("SUB_ACESSO")) {

					outkey.clear();
					outValue.clear();
					
					outkey.setRowIdItem(input.getNumeroOrdem());
					outkey.setTipo(TypeStep1Pt1.LIVE);

					outValue.setItem(input, TypeStep1Pt1.LIVE);

					context.write(outkey, outValue);
					context.getCounter(Step1Pt1Counters.STEP1_MAPPER_WRITE).increment(1l);
				} else if (input.getCategoriaItemOrdem().toUpperCase().trim().equals("ACESSO")
						&& (input.getMotivoStatus().toUpperCase().trim().equals("ATIVAÇÃO") 
								|| input.getMotivoStatus().toUpperCase().trim().equals(""))
						&& tiposDeItemDeOrdem.contains(input.getTipoItemOrdem().toUpperCase().trim())) {

					outkey.clear();
					outValue.clear();
					
					outkey.setRowIdItem(input.getNumeroOrdem());
					outkey.setTipo(TypeStep1Pt1.MOVEL);

					outValue.setItem(input, TypeStep1Pt1.MOVEL);

					context.write(outkey, outValue);
					context.getCounter(Step1Pt1Counters.STEP1_MAPPER_WRITE).increment(1l);

				} else if (input.getCategoriaItemOrdem().toUpperCase().trim().equals("PLANO")) {

					outkey.clear();
					outValue.clear();
					
					outkey.setRowIdItem(input.getNumeroOrdem());
					outkey.setTipo(TypeStep1Pt1.PLANO_ATUAL);

					outValue.setItem(input, TypeStep1Pt1.PLANO_ATUAL);

					context.write(outkey, outValue);
					context.getCounter(Step1Pt1Counters.STEP1_MAPPER_WRITE).increment(1l);

				}else if (input.getCategoriaItemOrdem().toUpperCase().trim().equals("DESCONTO")) {

					outkey.clear();
					outValue.clear();
					
					outkey.setRowIdItem(input.getNumeroOrdem());
					outkey.setTipo(TypeStep1Pt1.DESCONTO);

					outValue.setItem(input, TypeStep1Pt1.DESCONTO);

					context.write(outkey, outValue);
					context.getCounter(Step1Pt1Counters.STEP1_MAPPER_WRITE).increment(1l);

				}else if (input.getMotivoStatus().toUpperCase().trim().equals("ATIVAÇÃO") 
						|| input.getMotivoStatus().toUpperCase().trim().equals("")) {
					
					outkey.clear();
					outValue.clear();
					
					outkey.setRowIdItem(input.getNumeroOrdem());
					outkey.setTipo(TypeStep1Pt1.ROOT);
					
					outValue.setItem(input, TypeStep1Pt1.ROOT);
					
					context.write(outkey, outValue);
					context.getCounter(Step1Pt1Counters.STEP1_MAPPER_WRITE).increment(1l);

				}
			}
			
		}		
		
		if (input.getCategoriaItemOrdem().toUpperCase().trim().equals("PLANO")) {

			outkey.clear();
			outValue.clear();
			
			outkey.setRowIdItem(input.getNumeroOrdem());
			outkey.setTipo(TypeStep1Pt1.PLANO);

			outValue.setItem(input, TypeStep1Pt1.PLANO);

			context.write(outkey, outValue);
			context.getCounter(Step1Pt1Counters.STEP1_MAPPER_WRITE_PLANO).increment(1l);

		}
		
		
		if(input.getCategoriaItemOrdem().toUpperCase().trim().equals("SUB_ACESSO")
				&& input.getAcaoItemOrdem().toUpperCase().trim().equals("EXCLUIR")
				&& input.getStatusItem().toUpperCase().trim().equals("CONCLUÍDO")) {
			
			outkey.clear();
			outValue.clear();
			
			outkey.setRowIdItem(input.getNumeroOrdem());
			outkey.setTipo(TypeStep1Pt1.HIST);
			outkey.setDatRef(input.getArquivo());
			outValue.setItem(input, TypeStep1Pt1.HIST);
			context.write(outkey, outValue);
			context.getCounter(Step1Pt1Counters.STEP1_MAPPER_WRITE).increment(1l);

		}
	}

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		super.setup(context);
		this.outkey = new E2EStep1Pt1Key();
		this.outValue = new E2EStep1Pt1Value();
		this.input = new BAT509Item();
		this.tiposDeItemDeOrdem = Arrays.asList("DADOS_MOVEL", "VOZ_FIXO", "VOZ_MOVEL");
	}

	@Override
	protected void cleanup(Context context) throws IOException, InterruptedException {
		super.cleanup(context);
		this.clear();
	}

	private void clear() {
		this.outValue.clear();
	}

}