package br.com.tim.mapreduce.refactoring.endtoend.step4.utils;

public enum Step4Pt2Counters {
	ORDER_MAPPER_WRITE, ORDER_MAPPER_DISCART, STEP4PT2_REDUCER_WIRTE, STEP4PT2_REDUCER_CANCEL_DATA_NULL

}
