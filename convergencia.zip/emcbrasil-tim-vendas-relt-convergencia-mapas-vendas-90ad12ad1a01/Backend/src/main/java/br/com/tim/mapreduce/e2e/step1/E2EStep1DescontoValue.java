package br.com.tim.mapreduce.e2e.step1;

public class E2EStep1DescontoValue {

	private String nomDescontoAtual;
	private String valDescontoAtual;
	private String rowIdDoItemDaOrdemPai;
	
	public E2EStep1DescontoValue(E2EStep1Value value) {
		super();
		this.nomDescontoAtual = value.getNomDescontoAtualItem();
		this.valDescontoAtual = value.getValDescontoAtualItem();
		this.rowIdDoItemDaOrdemPai = value.getRowIdDoItemDaOrdemPai();
	}
	
	public String getNomDescontoAtual() {
		return nomDescontoAtual;
	}
	public void setNomDescontoAtual(String nomDescontoAtual) {
		this.nomDescontoAtual = nomDescontoAtual;
	}
	public String getValDescontoAtual() {
		return valDescontoAtual;
	}
	public void setValDescontoAtual(String valDescontoAtual) {
		this.valDescontoAtual = valDescontoAtual;
	}
	public String getRowIdDoItemDaOrdemPai() {
		return rowIdDoItemDaOrdemPai;
	}
	public void setRowIdDoItemDaOrdemPai(String rowIdDoItemDaOrdemPai) {
		this.rowIdDoItemDaOrdemPai = rowIdDoItemDaOrdemPai;
	}
}
