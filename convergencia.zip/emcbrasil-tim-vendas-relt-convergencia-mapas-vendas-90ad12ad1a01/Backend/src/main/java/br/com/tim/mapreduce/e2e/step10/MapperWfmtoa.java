package br.com.tim.mapreduce.e2e.step10;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

import br.com.tim.mapreduce.model.Wfmtoa;

public class MapperWfmtoa extends org.apache.hadoop.mapreduce.Mapper<Writable, Text, E2EStep10Key, E2EStep10Value> {

	private E2EStep10Key outkey;
	private E2EStep10Value outValue;
	private Wfmtoa input;
	
	@Override
	protected void map(Writable key, Text value, Context context) throws IOException, InterruptedException {
		input.parseLineFromTable(value.toString());

		outkey.setNumOrdemSiebel(input.getApptNumber().trim());
		outkey.setTipo(TypeStep10.WFMTOA);
		try {
			outkey.setDat_ref(input.getArquivo().trim().substring(5, 19));
		}catch(Exception e) {
			outkey.setDat_ref(input.getQueueDate());
		}
		outValue.setWfmtoa(input);
		context.write(outkey, outValue);
	}

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		super.setup(context);
		this.outkey = new E2EStep10Key();
		this.outValue = new E2EStep10Value();
		this.input = new Wfmtoa();
	}

	@Override
	protected void cleanup(Context context) throws IOException, InterruptedException {
		super.cleanup(context);
		this.clear();
	}

	private void clear() {
		this.outValue.clear();
	}

}
