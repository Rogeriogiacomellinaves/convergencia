package br.com.tim.mapreduce.itemordem.step2.model;

import org.apache.commons.lang3.StringUtils;

public class Step1Result {

    private String nroOrdem;
    private String nomBairro;
    private String cep;
    private String nomCidade;
    private String numCNPJParcVenda;
    private String dscComplemento;
    private String datDesconexao;
    private String datVenda;
    private String dscLogradouro;
    private String numLogradouro;
    private String nomPlanoAtual;
    private String nomPlanoNovo;
    private String numTelefone;
    private String dscTipoLogradouro;
    private String nomProduto;
    private String dscTipoMotivo;
    private String sglUFInstalacao;
    private String datRef;
    private String dscAcaoItemOrdem;
    private String dscStatusItem;
    private String email;
    private String dscTipoOrdem;
    private String dscFormaPgto;
    private String codCtaFinanceira;
    private String codContratoOltp;
    private String numProtocolo;
    private String datCriacaoOrdem;
    private String datStatusOrdem;
    private String datSuspensao;
    private String datReativacao;
    private String codServiceId;
    private String nomContato;
    private String dscMotivoStatusItem;
    private String nomLoginResponsavel;
    private String nomLoginVendedor;
    private String dscCanalVenda;
    private String valPlanoAtual;
    private String nomDescontoAtual;
    private String valDescontoAtual;
    private String valPlanoNovo;
    private String nomDescontoNovo;
    private String valDescontoNovo;
    private String flgPortabilidade;
    private String codDdd;
    private String numTelefonePortado;
    private String datJanelaPortabilidade;
    private String dscEstorno;
    private String numBilheteEstornado;
    private String dscMotivoEstorno;
    private String dscStatusOrdemWfm;
    private String datHoraStatusWfm;
    private String diaVencimento;
    private String dscTipoConta;
    private String dscEnderecoFatura;
    private String dscAreaVoip;
    private String codBanco;
    private String codAgenciaBco;
    private String codContaCorrente;
    private String datAltFormaPgto;
    private String codDebitoAutomatico;
    private String codItemOrdem;
    private String nomParceiroVenda;
    private String idItemOrdPai;
    private String idItemOrdem;
    private String dscCategoriaItem;
    private String tecnologia;
    private String cpe;
    private String ont;
    private String numTelefone2;
    private String numTelefone3;
    private String dominioRoot;
    private String codProduto;

    public Step1Result(){
        this.nroOrdem = null;
        this.nomBairro = null;
        this.cep = null;
        this.nomCidade = null;
        this.numCNPJParcVenda = null;
        this.dscComplemento = null;
        this.datDesconexao = null;
        this.datVenda = null;
        this.dscLogradouro = null;
        this.numLogradouro = null;
        this.nomPlanoAtual = null;
        this.nomPlanoNovo = null;
        this.numTelefone = null;
        this.dscTipoLogradouro = null;
        this.nomProduto = null;
        this.dscTipoMotivo = null;
        this.sglUFInstalacao = null;
        this.datRef = null;
        this.dscAcaoItemOrdem = null;
        this.dscStatusItem = null;
        this.email = null;
        this.dscTipoOrdem = null;
        this.dscFormaPgto = null;
        this.codCtaFinanceira = null;
        this.codContratoOltp = null;
        this.numProtocolo = null;
        this.datCriacaoOrdem = null;
        this.datStatusOrdem = null;
        this.datSuspensao = null;
        this.datReativacao = null;
        this.codServiceId = null;
        this.nomContato = null;
        this.dscMotivoStatusItem = null;
        this.nomLoginResponsavel = null;
        this.nomLoginVendedor = null;
        this.dscCanalVenda = null;
        this.valPlanoAtual = null;
        this.nomDescontoAtual = null;
        this.valDescontoAtual = null;
        this.valPlanoNovo = null;
        this.nomDescontoNovo = null;
        this.valDescontoNovo = null;
        this.flgPortabilidade = null;
        this.codDdd = null;
        this.numTelefonePortado = null;
        this.datJanelaPortabilidade = null;
        this.dscEstorno = null;
        this.numBilheteEstornado = null;
        this.dscMotivoEstorno = null;
        this.dscStatusOrdemWfm = null;
        this.datHoraStatusWfm = null;
        this.diaVencimento = null;
        this.dscTipoConta = null;
        this.dscEnderecoFatura = null;
        this.dscAreaVoip = null;
        this.codBanco = null;
        this.codAgenciaBco = null;
        this.codContaCorrente = null;
        this.datAltFormaPgto = null;
        this.codDebitoAutomatico = null;
        this.codItemOrdem = null;
        this.nomParceiroVenda = null;
        this.idItemOrdPai = null;
        this.idItemOrdem = null;
        this.dscCategoriaItem = null;
        this.tecnologia = null;
        this.cpe = null;
        this.ont = null;
        this.numTelefone2 = null;
        this.numTelefone3 = null;
        this.dominioRoot = null;
        this.codProduto = null;
    }

	public void setStep1Result(String nroOrdem, String nomBairro, String cep, String nomCidade, String numCNPJParcVenda,
			String dscComplemento, String datDesconexao, String datVenda, String dscLogradouro, String numLogradouro,
			String nomPlanoAtual, String nomPlanoNovo, String numTelefone, String dscTipoLogradouro, String nomProduto,
			String dscTipoMotivo, String sglUFInstalacao, String datRef, String dscAcaoItemOrdem, String dscStatusItem,
			String email, String dscTipoOrdem, String dscFormaPgto, String codCtaFinanceira, String codContratoOltp,
			String numProtocolo, String datCriacaoOrdem, String datStatusOrdem, String datSuspensao,
			String datReativacao, String codServiceId, String nomContato, String dscMotivoStatusItem,
			String nomLoginResponsavel, String nomLoginVendedor, String dscCanalVenda, String valPlanoAtual,
			String nomDescontoAtual, String valDescontoAtual, String valPlanoNovo, String nomDescontoNovo,
			String valDescontoNovo, String flgPortabilidade, String codDdd, String numTelefonePortado,
			String datJanelaPortabilidade, String dscEstorno, String numBilheteEstornado, String dscMotivoEstorno,
			String dscStatusOrdemWfm, String datHoraStatusWfm, String diaVencimento, String dscTipoConta,
			String dscEnderecoFatura, String dscAreaVoip, String codBanco, String codAgenciaBco,
			String codContaCorrente, String datAltFormaPgto, String codDebitoAutomatico, String codItemOrdem,
			String nomParceiroVenda, String idItemOrdPai, String idItemOrdem, String dscCategoriaItem,
			String tecnologia, String cpe, String ont, String numTelefone2, String numTelefone3, String dominioRoot,
			String codProduto) {
        this.nroOrdem = nroOrdem;
        this.nomBairro = nomBairro;
        this.cep = cep;
        this.nomCidade = nomCidade;
        this.numCNPJParcVenda = numCNPJParcVenda;
        this.dscComplemento = dscComplemento;
        this.datDesconexao = datDesconexao;
        this.datVenda = datVenda;
        this.dscLogradouro = dscLogradouro;
        this.numLogradouro = numLogradouro;
        this.nomPlanoAtual = nomPlanoAtual;
        this.nomPlanoNovo = nomPlanoNovo;
        this.numTelefone = numTelefone;
        this.dscTipoLogradouro = dscTipoLogradouro;
        this.nomProduto = nomProduto;
        this.dscTipoMotivo = dscTipoMotivo;
        this.sglUFInstalacao = sglUFInstalacao;
        this.datRef = datRef;
        this.dscAcaoItemOrdem = dscAcaoItemOrdem;
        this.dscStatusItem = dscStatusItem;
        this.email = email;
        this.dscTipoOrdem = dscTipoOrdem;
        this.dscFormaPgto = dscFormaPgto;
        this.codCtaFinanceira = codCtaFinanceira;
        this.codContratoOltp = codContratoOltp;
        this.numProtocolo = numProtocolo;
        this.datCriacaoOrdem = datCriacaoOrdem;
        this.datStatusOrdem = datStatusOrdem;
        this.datSuspensao = datSuspensao;
        this.datReativacao = datReativacao;
        this.codServiceId = codServiceId;
        this.nomContato = nomContato;
        this.dscMotivoStatusItem = dscMotivoStatusItem;
        this.nomLoginResponsavel = nomLoginResponsavel;
        this.nomLoginVendedor = nomLoginVendedor;
        this.dscCanalVenda = dscCanalVenda;
        this.valPlanoAtual = valPlanoAtual;
        this.nomDescontoAtual = nomDescontoAtual;
        this.valDescontoAtual = valDescontoAtual;
        this.valPlanoNovo = valPlanoNovo;
        this.nomDescontoNovo = nomDescontoNovo;
        this.valDescontoNovo = valDescontoNovo;
        this.flgPortabilidade = flgPortabilidade;
        this.codDdd = codDdd;
        this.numTelefonePortado = numTelefonePortado;
        this.datJanelaPortabilidade = datJanelaPortabilidade;
        this.dscEstorno = dscEstorno;
        this.numBilheteEstornado = numBilheteEstornado;
        this.dscMotivoEstorno = dscMotivoEstorno;
        this.dscStatusOrdemWfm = dscStatusOrdemWfm;
        this.datHoraStatusWfm = datHoraStatusWfm;
        this.diaVencimento = diaVencimento;
        this.dscTipoConta = dscTipoConta;
        this.dscEnderecoFatura = dscEnderecoFatura;
        this.dscAreaVoip = dscAreaVoip;
        this.codBanco = codBanco;
        this.codAgenciaBco = codAgenciaBco;
        this.codContaCorrente = codContaCorrente;
        this.datAltFormaPgto = datAltFormaPgto;
        this.codDebitoAutomatico = codDebitoAutomatico;
        this.codItemOrdem = codItemOrdem;
        this.nomParceiroVenda = nomParceiroVenda;
        this.idItemOrdPai = idItemOrdPai;
        this.idItemOrdem = idItemOrdem;
        this.dscCategoriaItem = dscCategoriaItem;
        this.tecnologia = tecnologia;
        this.cpe = cpe;
        this.ont = ont;
        this.numTelefone2 = numTelefone2;
        this.numTelefone3 = numTelefone3;
        this.dominioRoot = dominioRoot;
        this.codProduto = codProduto;
    }

    public boolean parse(String textString) {
        if (StringUtils.isNotBlank(textString)) {
            String[] cols = textString.split("\\|", -1);
            int i = 0;
            this.setStep1Result(cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                                cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                                cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                                cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                                cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                                cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                                cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                                cols[i++], cols[i++]);
            return true;
        }
        return false;
    }

    public String getNroOrdem() {
        return nroOrdem;
    }

    public void setNroOrdem(String nroOrdem) {
        this.nroOrdem = nroOrdem;
    }

    public String getNomBairro() {
        return nomBairro;
    }

    public void setNomBairro(String nomBairro) {
        this.nomBairro = nomBairro;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getNomCidade() {
        return nomCidade;
    }

    public void setNomCidade(String nomCidade) {
        this.nomCidade = nomCidade;
    }

    public String getNumCNPJParcVenda() {
        return numCNPJParcVenda;
    }

    public void setNumCNPJParcVenda(String numCNPJParcVenda) {
        this.numCNPJParcVenda = numCNPJParcVenda;
    }

    public String getDscComplemento() {
        return dscComplemento;
    }

    public void setDscComplemento(String dscComplemento) {
        this.dscComplemento = dscComplemento;
    }

    public String getDatDesconexao() {
        return datDesconexao;
    }

    public void setDatDesconexao(String datDesconexao) {
        this.datDesconexao = datDesconexao;
    }

    public String getDatVenda() {
        return datVenda;
    }

    public void setDatVenda(String datVenda) {
        this.datVenda = datVenda;
    }

    public String getDscLogradouro() {
        return dscLogradouro;
    }

    public void setDscLogradouro(String dscLogradouro) {
        this.dscLogradouro = dscLogradouro;
    }

    public String getNumLogradouro() {
        return numLogradouro;
    }

    public void setNumLogradouro(String numLogradouro) {
        this.numLogradouro = numLogradouro;
    }

    public String getNomPlanoAtual() {
        return nomPlanoAtual;
    }

    public void setNomPlanoAtual(String nomPlanoAtual) {
        this.nomPlanoAtual = nomPlanoAtual;
    }

    public String getNomPlanoNovo() {
        return nomPlanoNovo;
    }

    public void setNomPlanoNovo(String nomPlanoNovo) {
        this.nomPlanoNovo = nomPlanoNovo;
    }

    public String getNumTelefone() {
        return numTelefone;
    }

    public void setNumTelefone(String numTelefone) {
        this.numTelefone = numTelefone;
    }

    public String getDscTipoLogradouro() {
        return dscTipoLogradouro;
    }

    public void setDscTipoLogradouro(String dscTipoLogradouro) {
        this.dscTipoLogradouro = dscTipoLogradouro;
    }

    public String getNomProduto() {
        return nomProduto;
    }

    public void setNomProduto(String nomProduto) {
        this.nomProduto = nomProduto;
    }

    public String getDscTipoMotivo() {
        return dscTipoMotivo;
    }

    public void setDscTipoMotivo(String dscTipoMotivo) {
        this.dscTipoMotivo = dscTipoMotivo;
    }

    public String getSglUFInstalacao() {
        return sglUFInstalacao;
    }

    public void setSglUFInstalacao(String sglUFInstalacao) {
        this.sglUFInstalacao = sglUFInstalacao;
    }

    public String getDatRef() {
        return datRef;
    }

    public void setDatRef(String datRef) {
        this.datRef = datRef;
    }

    public String getDscAcaoItemOrdem() {
        return dscAcaoItemOrdem;
    }

    public void setDscAcaoItemOrdem(String dscAcaoItemOrdem) {
        this.dscAcaoItemOrdem = dscAcaoItemOrdem;
    }

    public String getDscStatusItem() {
        return dscStatusItem;
    }

    public void setDscStatusItem(String dscStatusItem) {
        this.dscStatusItem = dscStatusItem;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDscTipoOrdem() {
        return dscTipoOrdem;
    }

    public void setDscTipoOrdem(String dscTipoOrdem) {
        this.dscTipoOrdem = dscTipoOrdem;
    }

    public String getDscFormaPgto() {
        return dscFormaPgto;
    }

    public void setDscFormaPgto(String dscFormaPgto) {
        this.dscFormaPgto = dscFormaPgto;
    }

    public String getCodCtaFinanceira() {
        return codCtaFinanceira;
    }

    public void setCodCtaFinanceira(String codCtaFinanceira) {
        this.codCtaFinanceira = codCtaFinanceira;
    }

    public String getCodContratoOltp() {
        return codContratoOltp;
    }

    public void setCodContratoOltp(String codContratoOltp) {
        this.codContratoOltp = codContratoOltp;
    }

    public String getNumProtocolo() {
        return numProtocolo;
    }

    public void setNumProtocolo(String numProtocolo) {
        this.numProtocolo = numProtocolo;
    }

    public String getDatCriacaoOrdem() {
        return datCriacaoOrdem;
    }

    public void setDatCriacaoOrdem(String datCriacaoOrdem) {
        this.datCriacaoOrdem = datCriacaoOrdem;
    }

    public String getDatStatusOrdem() {
        return datStatusOrdem;
    }

    public void setDatStatusOrdem(String datStatusOrdem) {
        this.datStatusOrdem = datStatusOrdem;
    }

    public String getDatSuspensao() {
        return datSuspensao;
    }

    public void setDatSuspensao(String datSuspensao) {
        this.datSuspensao = datSuspensao;
    }

    public String getDatReativacao() {
        return datReativacao;
    }

    public void setDatReativacao(String datReativacao) {
        this.datReativacao = datReativacao;
    }

    public String getCodServiceId() {
        return codServiceId;
    }

    public void setCodServiceId(String codServiceId) {
        this.codServiceId = codServiceId;
    }

    public String getNomContato() {
        return nomContato;
    }

    public void setNomContato(String nomContato) {
        this.nomContato = nomContato;
    }

    public String getDscMotivoStatusItem() {
        return dscMotivoStatusItem;
    }

    public void setDscMotivoStatusItem(String dscMotivoStatusItem) {
        this.dscMotivoStatusItem = dscMotivoStatusItem;
    }

    public String getNomLoginResponsavel() {
        return nomLoginResponsavel;
    }

    public void setNomLoginResponsavel(String nomLoginResponsavel) {
        this.nomLoginResponsavel = nomLoginResponsavel;
    }

    public String getNomLoginVendedor() {
        return nomLoginVendedor;
    }

    public void setNomLoginVendedor(String nomLoginVendedor) {
        this.nomLoginVendedor = nomLoginVendedor;
    }

    public String getDscCanalVenda() {
        return dscCanalVenda;
    }

    public void setDscCanalVenda(String dscCanalVenda) {
        this.dscCanalVenda = dscCanalVenda;
    }

    public String getValPlanoAtual() {
        return valPlanoAtual;
    }

    public void setValPlanoAtual(String valPlanoAtual) {
        this.valPlanoAtual = valPlanoAtual;
    }

    public String getNomDescontoAtual() {
        return nomDescontoAtual;
    }

    public void setNomDescontoAtual(String nomDescontoAtual) {
        this.nomDescontoAtual = nomDescontoAtual;
    }

    public String getValDescontoAtual() {
        return valDescontoAtual;
    }

    public void setValDescontoAtual(String valDescontoAtual) {
        this.valDescontoAtual = valDescontoAtual;
    }

    public String getValPlanoNovo() {
        return valPlanoNovo;
    }

    public void setValPlanoNovo(String valPlanoNovo) {
        this.valPlanoNovo = valPlanoNovo;
    }

    public String getNomDescontoNovo() {
        return nomDescontoNovo;
    }

    public void setNomDescontoNovo(String nomDescontoNovo) {
        this.nomDescontoNovo = nomDescontoNovo;
    }

    public String getValDescontoNovo() {
        return valDescontoNovo;
    }

    public void setValDescontoNovo(String valDescontoNovo) {
        this.valDescontoNovo = valDescontoNovo;
    }

    public String getFlgPortabilidade() {
        return flgPortabilidade;
    }

    public void setFlgPortabilidade(String flgPortabilidade) {
        this.flgPortabilidade = flgPortabilidade;
    }

    public String getCodDdd() {
        return codDdd;
    }

    public void setCodDdd(String codDdd) {
        this.codDdd = codDdd;
    }

    public String getNumTelefonePortado() {
        return numTelefonePortado;
    }

    public void setNumTelefonePortado(String numTelefonePortado) {
        this.numTelefonePortado = numTelefonePortado;
    }

    public String getDatJanelaPortabilidade() {
        return datJanelaPortabilidade;
    }

    public void setDatJanelaPortabilidade(String datJanelaPortabilidade) {
        this.datJanelaPortabilidade = datJanelaPortabilidade;
    }

    public String getDscEstorno() {
        return dscEstorno;
    }

    public void setDscEstorno(String dscEstorno) {
        this.dscEstorno = dscEstorno;
    }

    public String getNumBilheteEstornado() {
        return numBilheteEstornado;
    }

    public void setNumBilheteEstornado(String numBilheteEstornado) {
        this.numBilheteEstornado = numBilheteEstornado;
    }

    public String getDscMotivoEstorno() {
        return dscMotivoEstorno;
    }

    public void setDscMotivoEstorno(String dscMotivoEstorno) {
        this.dscMotivoEstorno = dscMotivoEstorno;
    }

    public String getDiaVencimento() {
        return diaVencimento;
    }

    public void setDiaVencimento(String diaVencimento) {
        this.diaVencimento = diaVencimento;
    }

    public String getDscTipoConta() {
        return dscTipoConta;
    }

    public void setDscTipoConta(String dscTipoConta) {
        this.dscTipoConta = dscTipoConta;
    }

    public String getDscEnderecoFatura() {
        return dscEnderecoFatura;
    }

    public void setDscEnderecoFatura(String dscEnderecoFatura) {
        this.dscEnderecoFatura = dscEnderecoFatura;
    }

    public String getDscAreaVoip() {
        return dscAreaVoip;
    }

    public void setDscAreaVoip(String dscAreaVoip) {
        this.dscAreaVoip = dscAreaVoip;
    }

    public String getCodBanco() {
        return codBanco;
    }

    public void setCodBanco(String codBanco) {
        this.codBanco = codBanco;
    }

    public String getCodAgenciaBco() {
        return codAgenciaBco;
    }

    public void setCodAgenciaBco(String codAgenciaBco) {
        this.codAgenciaBco = codAgenciaBco;
    }

    public String getCodContaCorrente() {
        return codContaCorrente;
    }

    public void setCodContaCorrente(String codContaCorrente) {
        this.codContaCorrente = codContaCorrente;
    }

    public String getDatAltFormaPgto() {
        return datAltFormaPgto;
    }

    public void setDatAltFormaPgto(String datAltFormaPgto) {
        this.datAltFormaPgto = datAltFormaPgto;
    }

    public String getCodDebitoAutomatico() {
        return codDebitoAutomatico;
    }

    public void setCodDebitoAutomatico(String codDebitoAutomatico) {
        this.codDebitoAutomatico = codDebitoAutomatico;
    }

    public String getCodItemOrdem() {
        return codItemOrdem;
    }

    public void setCodItemOrdem(String codItemOrdem) {
        this.codItemOrdem = codItemOrdem;
    }

    public String getNomParceiroVenda() {
        return nomParceiroVenda;
    }

    public void setNomParceiroVenda(String nomParceiroVenda) {
        this.nomParceiroVenda = nomParceiroVenda;
    }

    public String getIdItemOrdPai() {
        return idItemOrdPai;
    }

    public void setIdItemOrdPai(String idItemOrdPai) {
        this.idItemOrdPai = idItemOrdPai;
    }

    public String getIdItemOrdem() {
        return idItemOrdem;
    }

    public void setIdItemOrdem(String idItemOrdem) {
        this.idItemOrdem = idItemOrdem;
    }

    public String getDscCategoriaItem() {
        return dscCategoriaItem;
    }

    public void setDscCategoriaItem(String dscCategoriaItem) {
        this.dscCategoriaItem = dscCategoriaItem;
    }

    public String getTecnologia() {
        return tecnologia;
    }

    public void setTecnologia(String tecnologia) {
        this.tecnologia = tecnologia;
    }

    public String getCpe() {
        return cpe;
    }

    public void setCpe(String cpe) {
        this.cpe = cpe;
    }

    public String getOnt() {
        return ont;
    }

    public void setOnt(String ont) {
        this.ont = ont;
    }

    public String getNumTelefone2() {
        return numTelefone2;
    }

    public void setNumTelefone2(String numTelefone2) {
        this.numTelefone2 = numTelefone2;
    }

    public String getNumTelefone3() {
        return numTelefone3;
    }

    public void setNumTelefone3(String numTelefone3) {
        this.numTelefone3 = numTelefone3;
    }

    public String getDominioRoot() {
        return dominioRoot;
    }

    public void setDominioRoot(String dominioRoot) {
        this.dominioRoot = dominioRoot;
    }

    public String getCodProduto() {
        return codProduto;
    }

    public void setCodProduto(String codProduto) {
        this.codProduto = codProduto;
    }

	public String getDscStatusOrdemWfm() {
		return dscStatusOrdemWfm;
	}

	public void setDscStatusOrdemWfm(String dscStatusOrdemWfm) {
		this.dscStatusOrdemWfm = dscStatusOrdemWfm;
	}

	public String getDatHoraStatusWfm() {
		return datHoraStatusWfm;
	}

	public void setDatHoraStatusWfm(String datHoraStatusWfm) {
		this.datHoraStatusWfm = datHoraStatusWfm;
	}
    
}
