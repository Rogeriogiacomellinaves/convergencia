
package br.com.tim.mapreduce.e2e.step5;

import br.com.tim.mapreduce.model.CDRFiber;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

import java.io.IOException;

public class MapperFiber extends org.apache.hadoop.mapreduce.Mapper<Writable,Text,E2EStep5Key,E2EStep5Value> {

	private E2EStep5Key outkey;
	private E2EStep5Value outValue;
	private CDRFiber input;
	@Override
	protected void map(Writable key, Text value, Context context) throws IOException, InterruptedException {
		input.parse(value.toString());
		outkey.setNumAcesso(input.getChargeableuseridentity());
		outkey.setTipo(TypeStep5.Fiber);
		outValue.setFiber(input);
		context.write(outkey, outValue);
	}

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		super.setup(context);
		this.outkey = new E2EStep5Key();
		this.outValue = new E2EStep5Value();
		this.input = new CDRFiber();
	}

	@Override
	protected void cleanup(Context context) throws IOException, InterruptedException {
		super.cleanup(context);
		this.clear();
	}

	private void clear(){
	   this.outValue.clear();
	}

}