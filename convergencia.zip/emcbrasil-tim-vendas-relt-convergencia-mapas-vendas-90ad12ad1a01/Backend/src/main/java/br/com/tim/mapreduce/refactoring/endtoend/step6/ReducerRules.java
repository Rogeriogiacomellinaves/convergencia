package br.com.tim.mapreduce.refactoring.endtoend.step6;

public class ReducerRules {

}
