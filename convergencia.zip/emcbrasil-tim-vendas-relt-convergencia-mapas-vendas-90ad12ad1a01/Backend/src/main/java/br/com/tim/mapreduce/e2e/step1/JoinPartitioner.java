package br.com.tim.mapreduce.e2e.step1;

import org.apache.hadoop.mapreduce.Partitioner;

public class JoinPartitioner extends Partitioner<E2EStep1Key, E2EStep1Value> {

    @Override
    public int getPartition(E2EStep1Key taggedKey, E2EStep1Value value, int numPartitions) {
        return Math.abs(taggedKey.hashCodeJoin() % numPartitions);
    }
}