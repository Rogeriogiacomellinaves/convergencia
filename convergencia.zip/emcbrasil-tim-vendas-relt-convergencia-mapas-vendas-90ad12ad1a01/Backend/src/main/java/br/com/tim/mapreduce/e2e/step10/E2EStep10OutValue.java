
package br.com.tim.mapreduce.e2e.step10;

public class E2EStep10OutValue{
	
	protected String datRef;
	protected String datCriacaoOrdem;
	protected String horCriacaoOrdem;
	protected String datVenda;
	protected String horaVenda;
	protected String datVendaOrig;
	protected String horVendaOrig;
	protected String datStatusOrdem;
	protected String horStatusOrdem;
	protected String numOrdemSiebel;
	protected String numOrdemSiebelOrig;
	protected String codContratoOltp;
	protected String codContratoAtivacao;
	protected String codContratoAtual;
	protected String numeroAcesso;
	protected String customerId;
	protected String tipoDocumento;
	protected String documento;
	protected String tipoVenda;
	protected String tipoProduto;
	protected String velocidadeDownload;
	protected String velocidadeUpload;
	protected String planoAtivacaoOferta;
	protected String loginVendedor;
	protected String loginVendedorOrig;
	protected String nomeVendedor;
	protected String nomeVendedorOrig;
	protected String canal;
	protected String canalOrig;
	protected String cnpjParceiro;
	protected String cnpjParceiroOrig;
	protected String custCode;
	protected String custCodeOrig;
	protected String position;
	protected String positionOrig;
	protected String parceiro;
	protected String parceiroOrig;
	protected String flgCancAntesVenda;
	protected String flgVendaSubmetida;
	protected String flgVendaDuplicada;
	protected String flgVendaBruta;
	protected String flgVendaLiquida;
	protected String flgGross;
	protected String flgChurn;
	protected String flgCancPosVenda;
	protected String flgCancDupl;
	protected String flgCancLiquido;
	protected String datGross;
	protected String datChurn;
	protected String motivoChurn;
	protected String tipoChurn;
	protected String datCancVenda;
	protected String motivoCancelamento;
	protected String nomeCliente;
	protected String telefone;
	protected String email;
	protected String uf;
	protected String tipoLogradouro;
	protected String logradouro;
	protected String numero;
	protected String complemento;
	protected String bairro;
	protected String cep;
	protected String cidade;
	protected String msanOltTrafego;
	protected String statusOrdem;
	protected String tecnologia;
	protected String formaPagamento;
	protected String tipoConta;
	protected String codBanco;
	protected String codAgenciaBanco;
	protected String codContaCorrente;
	protected String codDebitoAutomatico;
	protected String diaVencimento;
	protected String semanaVenda;
	protected String semanaVendaOrig;
	protected String score;
	protected String scoreConsumido;
	protected String datFinalizacaoOrdem;
	protected String qtdContratos;
	protected String codContaFinanceira;
	protected String numProtocolo;
	protected String flgOrdemAutomatica;
	protected String dscTxRecorrente;
	protected String dscTxNaoRecorrente;
	protected String dscStatusItem;
	protected String nomLoginResponsavel;
	protected String nomPlanoAtual;
	protected String valPlanoAtualItem;
	protected String nomDescontoAtualItem;
	protected String valDescontoAtualItem;
	protected String flgPortabilidade;
	protected String dscOperadoraDoadora;
	protected String codDdd;
	protected String numTelefonePortado;
	protected String datJanelaPortabilidade;
	protected String horJanela;
	protected String dscEnderecoFatura;
	protected String dscAreaVoip;
	protected String cpe;
	protected String ont;
	protected String codConvergente;
	protected String detalheRecusaCrivo;
	protected String itemRoot;
	protected String loginCancelamentoOrdem;
	protected String nomeUsuarioCancelouOrdem;
	protected String custcodeCliente;
	protected String dominioRoot;
	protected String datRefRelt;
	protected String msan_olt_venda;
	protected String dt_conclusao_wfm;
	protected String dscStatusOrdemWfm;
	protected String datStatusWfm;
	protected String horaStatusWfm;
	protected String idRecursoWfm;
	protected String nomRecursoWfm;
	protected String idRecursoPaiWfm;
	protected String datPrimeiroAgend;
	protected String horaPrimeiroAgendamento;
	protected String datAgendAtual;
	protected String horaAgendamentoAtual;
	protected String dscStatusAtivacao;
	
	
	public void setRelt(E2EStep10Value value) {
		this.datRef = value.getDatRef();
		this.datCriacaoOrdem = value.getDatCriacaoOrdem();
		this.horCriacaoOrdem = value.getHorCriacaoOrdem();
		this.datVenda = value.getDatVenda();
		this.horaVenda = value.getHoraVenda();
		this.datVendaOrig = value.getDatVendaOrig();
		this.horVendaOrig = value.getHorVendaOrig();
		this.datStatusOrdem = value.getDatStatusOrdem();
		this.horStatusOrdem = value.getHorStatusOrdem();
		this.numOrdemSiebel = value.getNumOrdemSiebel();
		this.numOrdemSiebelOrig = value.getNumOrdemSiebelOrig();
		this.codContratoOltp = value.getCodContratoOltp();
		this.codContratoAtivacao = value.getCodContratoAtivacao();
		this.codContratoAtual = value.getCodContratoAtual();
		this.numeroAcesso = value.getNumeroAcesso();
		this.customerId = value.getCustomerId();
		this.tipoDocumento = value.getTipoDocumento();
		this.documento = value.getDocumento();
		this.tipoVenda = value.getTipoVenda();
		this.tipoProduto = value.getTipoProduto();
		this.velocidadeDownload = value.getVelocidadeDownload();
		this.velocidadeUpload = value.getVelocidadeUpload();
		this.planoAtivacaoOferta = value.getPlanoAtivacaoOferta();
		this.loginVendedor = value.getLoginVendedor();
		this.loginVendedorOrig = value.getLoginVendedorOrig();
		this.nomeVendedor = value.getNomeVendedor();
		this.nomeVendedorOrig = value.getNomeVendedorOrig();
		this.canal = value.getCanal();
		this.canalOrig = value.getCanalOrig();
		this.cnpjParceiro = value.getCnpjParceiro();
		this.cnpjParceiroOrig = value.getCnpjParceiroOrig();
		this.custCode = value.getCustCode();
		this.custCodeOrig = value.getCustCodeOrig();
		this.position = value.getPosition();
		this.positionOrig = value.getPositionOrig();
		this.parceiro = value.getParceiro();
		this.parceiroOrig = value.getParceiroOrig();
		this.flgCancAntesVenda = value.getFlgCancAntesVenda();
		this.flgVendaSubmetida = value.getFlgVendaSubmetida();
		this.flgVendaDuplicada = value.getFlgVendaDuplicada();
		this.flgVendaBruta = value.getFlgVendaBruta();
		this.flgVendaLiquida = value.getFlgVendaLiquida();
		this.flgGross = value.getFlgGross();
		this.flgChurn = value.getFlgChurn();
		this.flgCancPosVenda = value.getFlgCancPosVenda();
		this.flgCancDupl = value.getFlgCancDupl();
		this.flgCancLiquido = value.getFlgCancLiquido();
		this.datGross = value.getDatGross();
		this.datChurn = value.getDatChurn();
		this.motivoChurn = value.getMotivoChurn();
		this.tipoChurn = value.getTipoChurn();
		this.datCancVenda = value.getDatCancVenda();
		this.motivoCancelamento = value.getMotivoCancelamento();
		this.nomeCliente = value.getNomeCliente();
		this.telefone = value.getTelefone();
		this.email = value.getEmail();
		this.uf = value.getUf();
		this.tipoLogradouro = value.getTipoLogradouro();
		this.logradouro = value.getLogradouro();
		this.numero = value.getNumero();
		this.complemento = value.getComplemento();
		this.bairro = value.getBairro();
		this.cep = value.getCep();
		this.cidade = value.getCidade();
		this.msanOltTrafego = value.getMsanOltTrafego();
		this.statusOrdem = value.getStatusOrdem();
		this.tecnologia = value.getTecnologia();
		this.formaPagamento = value.getFormaPagamento();
		this.tipoConta = value.getTipoConta();
		this.codBanco = value.getCodBanco();
		this.codAgenciaBanco = value.getCodAgenciaBanco();
		this.codContaCorrente = value.getCodContaCorrente();
		this.codDebitoAutomatico = value.getCodDebitoAutomatico();
		this.diaVencimento = value.getDiaVencimento();
		this.semanaVenda = value.getSemanaVenda();
		this.semanaVendaOrig = value.getSemanaVendaOrig();
		this.score = value.getScore();
		this.scoreConsumido = value.getScoreConsumido();
		this.datFinalizacaoOrdem = value.getDatFinalizacaoOrdem();
		this.qtdContratos = value.getQtdContratos();
		this.codContaFinanceira = value.getCodContaFinanceira();
		this.numProtocolo = value.getNumProtocolo();
		this.flgOrdemAutomatica = value.getFlgOrdemAutomatica();
		this.dscTxRecorrente = value.getDscTxRecorrente();
		this.dscTxNaoRecorrente = value.getDscTxNaoRecorrente();
		this.dscStatusItem = value.getDscStatusItem();
		this.nomLoginResponsavel = value.getNomLoginResponsavel();
		this.nomPlanoAtual = value.getNomPlanoAtual();
		this.valPlanoAtualItem = value.getValPlanoAtualItem();
		this.nomDescontoAtualItem = value.getNomDescontoAtualItem();
		this.valDescontoAtualItem = value.getValDescontoAtualItem();
		this.flgPortabilidade = value.getFlgPortabilidade();
		this.dscOperadoraDoadora = value.getDscOperadoraDoadora();
		this.codDdd = value.getCodDdd();
		this.numTelefonePortado = value.getNumTelefonePortado();
		this.datJanelaPortabilidade = value.getDatJanelaPortabilidade();
		this.horJanela = value.getHorJanela();
		this.dscEnderecoFatura = value.getDscEnderecoFatura();
		this.dscAreaVoip = value.getDscAreaVoip();
		this.cpe = value.getCpe();
		this.ont = value.getOnt();
		this.codConvergente = value.getCodConvergente();
		this.detalheRecusaCrivo = value.getDetalheRecusaCrivo();
		this.itemRoot = value.getItemRoot();
		this.loginCancelamentoOrdem = value.getLoginCancelamentoOrdem();
		this.nomeUsuarioCancelouOrdem = value.getNomeUsuarioCancelouOrdem();
		this.custcodeCliente = value.getCustcodeCliente();
		this.dominioRoot = value.getDominioRoot();
		this.datRefRelt = value.getDatRefRelt();
	}
	
	public void setWfmtoa(E2EStep10Value value) {
		this.msan_olt_venda = value.getMsan_olt_venda();
		this.dt_conclusao_wfm = value.getDt_conclusao_wfm();
		this.dscStatusOrdemWfm = value.getDscStatusOrdemWfm();
		this.datStatusWfm = value.getDatStatusWfm();
		this.horaStatusWfm = value.getHoraStatusWfm();
		this.idRecursoWfm = value.getIdRecursoWfm();
		this.nomRecursoWfm = value.getNomRecursoWfm();
		this.idRecursoPaiWfm = value.getIdRecursoPaiWfm();
		this.datPrimeiroAgend = value.getDatPrimeiroAgend();
		this.horaPrimeiroAgendamento = value.getHoraPrimeiroAgendamento();
		this.datAgendAtual = value.getDatAgendAtual();
		this.horaAgendamentoAtual = value.getHoraAgendamentoAtual();
		this.dscStatusAtivacao = value.getDscStatusAtivacao();
	}
	
	
	public void clearRelt() {
		this.datRef = "";
		this.datCriacaoOrdem = "";
		this.horCriacaoOrdem = "";
		this.datVenda = "";
		this.horaVenda = "";
		this.datVendaOrig = "";
		this.horVendaOrig = "";
		this.datStatusOrdem = "";
		this.horStatusOrdem = "";
		this.numOrdemSiebelOrig = "";
		this.codContratoOltp = "";
		this.codContratoAtivacao = "";
		this.codContratoAtual = "";
		this.numeroAcesso = "";
		this.customerId = "";
		this.tipoDocumento = "";
		this.documento = "";
		this.tipoVenda = "";
		this.tipoProduto = "";
		this.velocidadeDownload = "";
		this.velocidadeUpload = "";
		this.planoAtivacaoOferta = "";
		this.loginVendedor = "";
		this.loginVendedorOrig = "";
		this.nomeVendedor = "";
		this.nomeVendedorOrig = "";
		this.canal = "";
		this.canalOrig = "";
		this.cnpjParceiro = "";
		this.cnpjParceiroOrig = "";
		this.custCode = "";
		this.custCodeOrig = "";
		this.position = "";
		this.positionOrig = "";
		this.parceiro = "";
		this.parceiroOrig = "";
		this.flgCancAntesVenda = "";
		this.flgVendaSubmetida = "";
		this.flgVendaDuplicada = "";
		this.flgVendaBruta = "";
		this.flgVendaLiquida = "";
		this.flgGross = "";
		this.flgChurn = "";
		this.flgCancPosVenda = "";
		this.flgCancDupl = "";
		this.flgCancLiquido = "";
		this.datGross = "";
		this.datChurn = "";
		this.motivoChurn = "";
		this.tipoChurn = "";
		this.datCancVenda = "";
		this.motivoCancelamento = "";
		this.nomeCliente = "";
		this.telefone = "";
		this.email = "";
		this.uf = "";
		this.tipoLogradouro = "";
		this.logradouro = "";
		this.numero = "";
		this.complemento = "";
		this.bairro = "";
		this.cep = "";
		this.cidade = "";
		this.msanOltTrafego = "";
		this.statusOrdem = "";
		this.tecnologia = "";
		this.formaPagamento = "";
		this.tipoConta = "";
		this.codBanco = "";
		this.codAgenciaBanco = "";
		this.codContaCorrente = "";
		this.codDebitoAutomatico = "";
		this.diaVencimento = "";
		this.semanaVenda = "";
		this.semanaVendaOrig = "";
		this.score = "";
		this.scoreConsumido = "";
		this.datFinalizacaoOrdem = "";
		this.qtdContratos = "";
		this.codContaFinanceira = "";
		this.numProtocolo = "";
		this.flgOrdemAutomatica = "";
		this.dscTxRecorrente = "";
		this.dscTxNaoRecorrente = "";
		this.dscStatusItem = "";
		this.nomLoginResponsavel = "";
		this.nomPlanoAtual = "";
		this.valPlanoAtualItem = "";
		this.nomDescontoAtualItem = "";
		this.valDescontoAtualItem = "";
		this.flgPortabilidade = "";
		this.dscOperadoraDoadora = "";
		this.codDdd = "";
		this.numTelefonePortado = "";
		this.datJanelaPortabilidade = "";
		this.horJanela = "";
		this.dscEnderecoFatura = "";
		this.dscAreaVoip = "";
		this.cpe = "";
		this.ont = "";
		this.codConvergente = "";
		this.detalheRecusaCrivo = "";
		this.itemRoot = "";
		this.loginCancelamentoOrdem = "";
		this.nomeUsuarioCancelouOrdem = "";
		this.custcodeCliente = "";
		this.dominioRoot = "";
		this.datRefRelt = "";

		
	}
	
	public void clearWfmtoa() {
		this.msan_olt_venda = "";
		this.dt_conclusao_wfm = "";
		this.dscStatusOrdemWfm = "";
		this.datStatusWfm = "";
		this.horaStatusWfm = "";
		this.idRecursoWfm = "";
		this.nomRecursoWfm = "";
		this.idRecursoPaiWfm = "";
		this.datPrimeiroAgend = "";
		this.horaPrimeiroAgendamento = "";
		this.datAgendAtual = "";
		this.horaAgendamentoAtual = "";
		this.dscStatusAtivacao = "";
	}
	
	
	
	public void clear(){
        this.datRef = "";
        this.datCriacaoOrdem = "";
        this.horCriacaoOrdem = "";
        this.datVenda = "";
        this.horaVenda = "";
        this.datVendaOrig = "";
        this.horVendaOrig = "";
        this.datStatusOrdem = "";
        this.horStatusOrdem = "";
        this.numOrdemSiebelOrig = "";
        this.codContratoOltp = "";
        this.codContratoAtivacao = "";
        this.codContratoAtual = "";
        this.numeroAcesso = "";
        this.customerId = "";
        this.tipoDocumento = "";
        this.documento = "";
        this.tipoVenda = "";
        this.tipoProduto = "";
        this.velocidadeDownload = "";
        this.velocidadeUpload = "";
        this.planoAtivacaoOferta = "";
        this.loginVendedor = "";
        this.loginVendedorOrig = "";
        this.nomeVendedor = "";
        this.nomeVendedorOrig = "";
        this.canal = "";
        this.canalOrig = "";
        this.cnpjParceiro = "";
        this.cnpjParceiroOrig = "";
        this.custCode = "";
        this.custCodeOrig = "";
        this.position = "";
        this.positionOrig = "";
        this.parceiro = "";
        this.parceiroOrig = "";
        this.flgCancAntesVenda = "";
        this.flgVendaSubmetida = "";
        this.flgVendaDuplicada = "";
        this.flgVendaBruta = "";
        this.flgVendaLiquida = "";
        this.flgGross = "";
        this.flgChurn = "";
        this.flgCancPosVenda = "";
        this.flgCancDupl = "";
        this.flgCancLiquido = "";
        this.datGross = "";
        this.datChurn = "";
        this.motivoChurn = "";
        this.tipoChurn = "";
        this.datCancVenda = "";
        this.motivoCancelamento = "";
        this.nomeCliente = "";
        this.telefone = "";
        this.email = "";
        this.uf = "";
        this.tipoLogradouro = "";
        this.logradouro = "";
        this.numero = "";
        this.complemento = "";
        this.bairro = "";
        this.cep = "";
        this.cidade = "";
        this.msanOltTrafego = "";
        this.statusOrdem = "";
        this.tecnologia = "";
        this.formaPagamento = "";
        this.tipoConta = "";
        this.codBanco = "";
        this.codAgenciaBanco = "";
        this.codContaCorrente = "";
        this.codDebitoAutomatico = "";
        this.diaVencimento = "";
        this.semanaVenda = "";
        this.semanaVendaOrig = "";
        this.score = "";
        this.scoreConsumido = "";
        this.datFinalizacaoOrdem = "";
        this.qtdContratos = "";
        this.codContaFinanceira = "";
        this.numProtocolo = "";
        this.flgOrdemAutomatica = "";
        this.dscTxRecorrente = "";
        this.dscTxNaoRecorrente = "";
        this.dscStatusItem = "";
        this.nomLoginResponsavel = "";
        this.nomPlanoAtual = "";
        this.valPlanoAtualItem = "";
        this.nomDescontoAtualItem = "";
        this.valDescontoAtualItem = "";
        this.flgPortabilidade = "";
        this.dscOperadoraDoadora = "";
        this.codDdd = "";
        this.numTelefonePortado = "";
        this.datJanelaPortabilidade = "";
        this.horJanela = "";
        this.dscEnderecoFatura = "";
        this.dscAreaVoip = "";
        this.cpe = "";
        this.ont = "";
        this.codConvergente = "";
        this.detalheRecusaCrivo = "";
        this.itemRoot = "";
        this.loginCancelamentoOrdem = "";
        this.nomeUsuarioCancelouOrdem = "";
        this.custcodeCliente = "";
        this.dominioRoot = "";
        this.datRefRelt = "";
        this.msan_olt_venda = "";
        this.dt_conclusao_wfm = "";
        this.dscStatusOrdemWfm = "";
        this.datStatusWfm = "";
        this.horaStatusWfm = "";
        this.idRecursoWfm = "";
        this.nomRecursoWfm = "";
        this.idRecursoPaiWfm = "";
        this.datPrimeiroAgend = "";
        this.horaPrimeiroAgendamento = "";
        this.datAgendAtual = "";
        this.horaAgendamentoAtual = "";
        this.dscStatusAtivacao = "";        
	}


	public String getDatRef() {
		return datRef;
	}

	public void setDatRef(String datRef) {
		this.datRef = datRef;
	}

	public String getDatCriacaoOrdem() {
		return datCriacaoOrdem;
	}

	public void setDatCriacaoOrdem(String datCriacaoOrdem) {
		this.datCriacaoOrdem = datCriacaoOrdem;
	}

	public String getHorCriacaoOrdem() {
		return horCriacaoOrdem;
	}

	public void setHorCriacaoOrdem(String horCriacaoOrdem) {
		this.horCriacaoOrdem = horCriacaoOrdem;
	}

	public String getDatVenda() {
		return datVenda;
	}

	public void setDatVenda(String datVenda) {
		this.datVenda = datVenda;
	}

	public String getHoraVenda() {
		return horaVenda;
	}

	public void setHoraVenda(String horaVenda) {
		this.horaVenda = horaVenda;
	}

	public String getDatVendaOrig() {
		return datVendaOrig;
	}

	public void setDatVendaOrig(String datVendaOrig) {
		this.datVendaOrig = datVendaOrig;
	}

	public String getHorVendaOrig() {
		return horVendaOrig;
	}

	public void setHorVendaOrig(String horVendaOrig) {
		this.horVendaOrig = horVendaOrig;
	}

	public String getDatStatusOrdem() {
		return datStatusOrdem;
	}

	public void setDatStatusOrdem(String datStatusOrdem) {
		this.datStatusOrdem = datStatusOrdem;
	}

	public String getHorStatusOrdem() {
		return horStatusOrdem;
	}

	public void setHorStatusOrdem(String horStatusOrdem) {
		this.horStatusOrdem = horStatusOrdem;
	}

	public String getNumOrdemSiebelOrig() {
		return numOrdemSiebelOrig;
	}

	public void setNumOrdemSiebelOrig(String numOrdemSiebelOrig) {
		this.numOrdemSiebelOrig = numOrdemSiebelOrig;
	}

	public String getCodContratoOltp() {
		return codContratoOltp;
	}

	public void setCodContratoOltp(String codContratoOltp) {
		this.codContratoOltp = codContratoOltp;
	}

	public String getCodContratoAtivacao() {
		return codContratoAtivacao;
	}

	public void setCodContratoAtivacao(String codContratoAtivacao) {
		this.codContratoAtivacao = codContratoAtivacao;
	}

	public String getCodContratoAtual() {
		return codContratoAtual;
	}

	public void setCodContratoAtual(String codContratoAtual) {
		this.codContratoAtual = codContratoAtual;
	}

	public String getNumeroAcesso() {
		return numeroAcesso;
	}

	public void setNumeroAcesso(String numeroAcesso) {
		this.numeroAcesso = numeroAcesso;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public String getDocumento() {
		return documento;
	}

	public void setDocumento(String documento) {
		this.documento = documento;
	}

	public String getTipoVenda() {
		return tipoVenda;
	}

	public void setTipoVenda(String tipoVenda) {
		this.tipoVenda = tipoVenda;
	}

	public String getTipoProduto() {
		return tipoProduto;
	}

	public void setTipoProduto(String tipoProduto) {
		this.tipoProduto = tipoProduto;
	}

	public String getVelocidadeDownload() {
		return velocidadeDownload;
	}

	public void setVelocidadeDownload(String velocidadeDownload) {
		this.velocidadeDownload = velocidadeDownload;
	}

	public String getVelocidadeUpload() {
		return velocidadeUpload;
	}

	public void setVelocidadeUpload(String velocidadeUpload) {
		this.velocidadeUpload = velocidadeUpload;
	}

	public String getPlanoAtivacaoOferta() {
		return planoAtivacaoOferta;
	}

	public void setPlanoAtivacaoOferta(String planoAtivacaoOferta) {
		this.planoAtivacaoOferta = planoAtivacaoOferta;
	}

	public String getLoginVendedor() {
		return loginVendedor;
	}

	public void setLoginVendedor(String loginVendedor) {
		this.loginVendedor = loginVendedor;
	}

	public String getLoginVendedorOrig() {
		return loginVendedorOrig;
	}

	public void setLoginVendedorOrig(String loginVendedorOrig) {
		this.loginVendedorOrig = loginVendedorOrig;
	}

	public String getNomeVendedor() {
		return nomeVendedor;
	}

	public void setNomeVendedor(String nomeVendedor) {
		this.nomeVendedor = nomeVendedor;
	}

	public String getNomeVendedorOrig() {
		return nomeVendedorOrig;
	}

	public void setNomeVendedorOrig(String nomeVendedorOrig) {
		this.nomeVendedorOrig = nomeVendedorOrig;
	}

	public String getCanal() {
		return canal;
	}

	public void setCanal(String canal) {
		this.canal = canal;
	}

	public String getCanalOrig() {
		return canalOrig;
	}

	public void setCanalOrig(String canalOrig) {
		this.canalOrig = canalOrig;
	}

	public String getCnpjParceiro() {
		return cnpjParceiro;
	}

	public void setCnpjParceiro(String cnpjParceiro) {
		this.cnpjParceiro = cnpjParceiro;
	}

	public String getCnpjParceiroOrig() {
		return cnpjParceiroOrig;
	}

	public void setCnpjParceiroOrig(String cnpjParceiroOrig) {
		this.cnpjParceiroOrig = cnpjParceiroOrig;
	}

	public String getCustCode() {
		return custCode;
	}

	public void setCustCode(String custCode) {
		this.custCode = custCode;
	}

	public String getCustCodeOrig() {
		return custCodeOrig;
	}

	public void setCustCodeOrig(String custCodeOrig) {
		this.custCodeOrig = custCodeOrig;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getPositionOrig() {
		return positionOrig;
	}

	public void setPositionOrig(String positionOrig) {
		this.positionOrig = positionOrig;
	}

	public String getParceiro() {
		return parceiro;
	}

	public void setParceiro(String parceiro) {
		this.parceiro = parceiro;
	}

	public String getParceiroOrig() {
		return parceiroOrig;
	}

	public void setParceiroOrig(String parceiroOrig) {
		this.parceiroOrig = parceiroOrig;
	}

	public String getFlgCancAntesVenda() {
		return flgCancAntesVenda;
	}

	public void setFlgCancAntesVenda(String flgCancAntesVenda) {
		this.flgCancAntesVenda = flgCancAntesVenda;
	}

	public String getFlgVendaSubmetida() {
		return flgVendaSubmetida;
	}

	public void setFlgVendaSubmetida(String flgVendaSubmetida) {
		this.flgVendaSubmetida = flgVendaSubmetida;
	}

	public String getFlgVendaDuplicada() {
		return flgVendaDuplicada;
	}

	public void setFlgVendaDuplicada(String flgVendaDuplicada) {
		this.flgVendaDuplicada = flgVendaDuplicada;
	}

	public String getFlgVendaBruta() {
		return flgVendaBruta;
	}

	public void setFlgVendaBruta(String flgVendaBruta) {
		this.flgVendaBruta = flgVendaBruta;
	}

	public String getFlgVendaLiquida() {
		return flgVendaLiquida;
	}

	public void setFlgVendaLiquida(String flgVendaLiquida) {
		this.flgVendaLiquida = flgVendaLiquida;
	}

	public String getFlgGross() {
		return flgGross;
	}

	public void setFlgGross(String flgGross) {
		this.flgGross = flgGross;
	}

	public String getFlgChurn() {
		return flgChurn;
	}

	public void setFlgChurn(String flgChurn) {
		this.flgChurn = flgChurn;
	}

	public String getFlgCancPosVenda() {
		return flgCancPosVenda;
	}

	public void setFlgCancPosVenda(String flgCancPosVenda) {
		this.flgCancPosVenda = flgCancPosVenda;
	}

	public String getFlgCancDupl() {
		return flgCancDupl;
	}

	public void setFlgCancDupl(String flgCancDupl) {
		this.flgCancDupl = flgCancDupl;
	}

	public String getFlgCancLiquido() {
		return flgCancLiquido;
	}

	public void setFlgCancLiquido(String flgCancLiquido) {
		this.flgCancLiquido = flgCancLiquido;
	}

	public String getDatGross() {
		return datGross;
	}

	public void setDatGross(String datGross) {
		this.datGross = datGross;
	}

	public String getDatChurn() {
		return datChurn;
	}

	public void setDatChurn(String datChurn) {
		this.datChurn = datChurn;
	}

	public String getMotivoChurn() {
		return motivoChurn;
	}

	public void setMotivoChurn(String motivoChurn) {
		this.motivoChurn = motivoChurn;
	}

	public String getTipoChurn() {
		return tipoChurn;
	}

	public void setTipoChurn(String tipoChurn) {
		this.tipoChurn = tipoChurn;
	}

	public String getDatCancVenda() {
		return datCancVenda;
	}

	public void setDatCancVenda(String datCancVenda) {
		this.datCancVenda = datCancVenda;
	}

	public String getMotivoCancelamento() {
		return motivoCancelamento;
	}

	public void setMotivoCancelamento(String motivoCancelamento) {
		this.motivoCancelamento = motivoCancelamento;
	}

	public String getNomeCliente() {
		return nomeCliente;
	}

	public void setNomeCliente(String nomeCliente) {
		this.nomeCliente = nomeCliente;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	public String getTipoLogradouro() {
		return tipoLogradouro;
	}

	public void setTipoLogradouro(String tipoLogradouro) {
		this.tipoLogradouro = tipoLogradouro;
	}

	public String getLogradouro() {
		return logradouro;
	}

	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getComplemento() {
		return complemento;
	}

	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getMsanOltTrafego() {
		return msanOltTrafego;
	}

	public void setMsanOltTrafego(String msanOltTrafego) {
		this.msanOltTrafego = msanOltTrafego;
	}

	public String getStatusOrdem() {
		return statusOrdem;
	}

	public void setStatusOrdem(String statusOrdem) {
		this.statusOrdem = statusOrdem;
	}

	public String getTecnologia() {
		return tecnologia;
	}

	public void setTecnologia(String tecnologia) {
		this.tecnologia = tecnologia;
	}

	public String getFormaPagamento() {
		return formaPagamento;
	}

	public void setFormaPagamento(String formaPagamento) {
		this.formaPagamento = formaPagamento;
	}

	public String getTipoConta() {
		return tipoConta;
	}

	public void setTipoConta(String tipoConta) {
		this.tipoConta = tipoConta;
	}

	public String getCodBanco() {
		return codBanco;
	}

	public void setCodBanco(String codBanco) {
		this.codBanco = codBanco;
	}

	public String getCodAgenciaBanco() {
		return codAgenciaBanco;
	}

	public void setCodAgenciaBanco(String codAgenciaBanco) {
		this.codAgenciaBanco = codAgenciaBanco;
	}

	public String getCodContaCorrente() {
		return codContaCorrente;
	}

	public void setCodContaCorrente(String codContaCorrente) {
		this.codContaCorrente = codContaCorrente;
	}

	public String getCodDebitoAutomatico() {
		return codDebitoAutomatico;
	}

	public void setCodDebitoAutomatico(String codDebitoAutomatico) {
		this.codDebitoAutomatico = codDebitoAutomatico;
	}

	public String getDiaVencimento() {
		return diaVencimento;
	}

	public void setDiaVencimento(String diaVencimento) {
		this.diaVencimento = diaVencimento;
	}

	public String getSemanaVenda() {
		return semanaVenda;
	}

	public void setSemanaVenda(String semanaVenda) {
		this.semanaVenda = semanaVenda;
	}

	public String getSemanaVendaOrig() {
		return semanaVendaOrig;
	}

	public void setSemanaVendaOrig(String semanaVendaOrig) {
		this.semanaVendaOrig = semanaVendaOrig;
	}

	public String getScore() {
		return score;
	}

	public void setScore(String score) {
		this.score = score;
	}

	public String getScoreConsumido() {
		return scoreConsumido;
	}

	public void setScoreConsumido(String scoreConsumido) {
		this.scoreConsumido = scoreConsumido;
	}

	public String getDatFinalizacaoOrdem() {
		return datFinalizacaoOrdem;
	}

	public void setDatFinalizacaoOrdem(String datFinalizacaoOrdem) {
		this.datFinalizacaoOrdem = datFinalizacaoOrdem;
	}

	public String getQtdContratos() {
		return qtdContratos;
	}

	public void setQtdContratos(String qtdContratos) {
		this.qtdContratos = qtdContratos;
	}

	public String getCodContaFinanceira() {
		return codContaFinanceira;
	}

	public void setCodContaFinanceira(String codContaFinanceira) {
		this.codContaFinanceira = codContaFinanceira;
	}

	public String getNumProtocolo() {
		return numProtocolo;
	}

	public void setNumProtocolo(String numProtocolo) {
		this.numProtocolo = numProtocolo;
	}

	public String getFlgOrdemAutomatica() {
		return flgOrdemAutomatica;
	}

	public void setFlgOrdemAutomatica(String flgOrdemAutomatica) {
		this.flgOrdemAutomatica = flgOrdemAutomatica;
	}

	public String getDscTxRecorrente() {
		return dscTxRecorrente;
	}

	public void setDscTxRecorrente(String dscTxRecorrente) {
		this.dscTxRecorrente = dscTxRecorrente;
	}

	public String getDscTxNaoRecorrente() {
		return dscTxNaoRecorrente;
	}

	public void setDscTxNaoRecorrente(String dscTxNaoRecorrente) {
		this.dscTxNaoRecorrente = dscTxNaoRecorrente;
	}

	public String getDscStatusItem() {
		return dscStatusItem;
	}

	public void setDscStatusItem(String dscStatusItem) {
		this.dscStatusItem = dscStatusItem;
	}

	public String getNomLoginResponsavel() {
		return nomLoginResponsavel;
	}

	public void setNomLoginResponsavel(String nomLoginResponsavel) {
		this.nomLoginResponsavel = nomLoginResponsavel;
	}

	public String getNomPlanoAtual() {
		return nomPlanoAtual;
	}

	public void setNomPlanoAtual(String nomPlanoAtual) {
		this.nomPlanoAtual = nomPlanoAtual;
	}

	public String getValPlanoAtualItem() {
		return valPlanoAtualItem;
	}

	public void setValPlanoAtualItem(String valPlanoAtualItem) {
		this.valPlanoAtualItem = valPlanoAtualItem;
	}

	public String getNomDescontoAtualItem() {
		return nomDescontoAtualItem;
	}

	public void setNomDescontoAtualItem(String nomDescontoAtualItem) {
		this.nomDescontoAtualItem = nomDescontoAtualItem;
	}

	public String getValDescontoAtualItem() {
		return valDescontoAtualItem;
	}

	public void setValDescontoAtualItem(String valDescontoAtualItem) {
		this.valDescontoAtualItem = valDescontoAtualItem;
	}

	public String getFlgPortabilidade() {
		return flgPortabilidade;
	}

	public void setFlgPortabilidade(String flgPortabilidade) {
		this.flgPortabilidade = flgPortabilidade;
	}

	public String getDscOperadoraDoadora() {
		return dscOperadoraDoadora;
	}

	public void setDscOperadoraDoadora(String dscOperadoraDoadora) {
		this.dscOperadoraDoadora = dscOperadoraDoadora;
	}

	public String getCodDdd() {
		return codDdd;
	}

	public void setCodDdd(String codDdd) {
		this.codDdd = codDdd;
	}

	public String getNumTelefonePortado() {
		return numTelefonePortado;
	}

	public void setNumTelefonePortado(String numTelefonePortado) {
		this.numTelefonePortado = numTelefonePortado;
	}

	public String getDatJanelaPortabilidade() {
		return datJanelaPortabilidade;
	}

	public void setDatJanelaPortabilidade(String datJanelaPortabilidade) {
		this.datJanelaPortabilidade = datJanelaPortabilidade;
	}

	public String getHorJanela() {
		return horJanela;
	}

	public void setHorJanela(String horJanela) {
		this.horJanela = horJanela;
	}

	public String getDscEnderecoFatura() {
		return dscEnderecoFatura;
	}

	public void setDscEnderecoFatura(String dscEnderecoFatura) {
		this.dscEnderecoFatura = dscEnderecoFatura;
	}

	public String getDscAreaVoip() {
		return dscAreaVoip;
	}

	public void setDscAreaVoip(String dscAreaVoip) {
		this.dscAreaVoip = dscAreaVoip;
	}

	public String getCpe() {
		return cpe;
	}

	public void setCpe(String cpe) {
		this.cpe = cpe;
	}

	public String getOnt() {
		return ont;
	}

	public void setOnt(String ont) {
		this.ont = ont;
	}

	public String getCodConvergente() {
		return codConvergente;
	}

	public void setCodConvergente(String codConvergente) {
		this.codConvergente = codConvergente;
	}

	public String getDetalheRecusaCrivo() {
		return detalheRecusaCrivo;
	}

	public void setDetalheRecusaCrivo(String detalheRecusaCrivo) {
		this.detalheRecusaCrivo = detalheRecusaCrivo;
	}

	public String getItemRoot() {
		return itemRoot;
	}

	public void setItemRoot(String itemRoot) {
		this.itemRoot = itemRoot;
	}

	public String getLoginCancelamentoOrdem() {
		return loginCancelamentoOrdem;
	}

	public void setLoginCancelamentoOrdem(String loginCancelamentoOrdem) {
		this.loginCancelamentoOrdem = loginCancelamentoOrdem;
	}

	public String getNomeUsuarioCancelouOrdem() {
		return nomeUsuarioCancelouOrdem;
	}

	public void setNomeUsuarioCancelouOrdem(String nomeUsuarioCancelouOrdem) {
		this.nomeUsuarioCancelouOrdem = nomeUsuarioCancelouOrdem;
	}

	public String getCustcodeCliente() {
		return custcodeCliente;
	}

	public void setCustcodeCliente(String custcodeCliente) {
		this.custcodeCliente = custcodeCliente;
	}

	public String getDominioRoot() {
		return dominioRoot;
	}

	public void setDominioRoot(String dominioRoot) {
		this.dominioRoot = dominioRoot;
	}

	public String getDatRefRelt() {
		return datRefRelt;
	}

	public void setDatRefRelt(String datRefRelt) {
		this.datRefRelt = datRefRelt;
	}

	public String getMsan_olt_venda() {
		return msan_olt_venda;
	}

	public void setMsan_olt_venda(String msan_olt_venda) {
		this.msan_olt_venda = msan_olt_venda;
	}

	public String getDt_conclusao_wfm() {
		return dt_conclusao_wfm;
	}

	public void setDt_conclusao_wfm(String dt_conclusao_wfm) {
		this.dt_conclusao_wfm = dt_conclusao_wfm;
	}

	public String getDscStatusOrdemWfm() {
		return dscStatusOrdemWfm;
	}

	public void setDscStatusOrdemWfm(String dscStatusOrdemWfm) {
		this.dscStatusOrdemWfm = dscStatusOrdemWfm;
	}

	public String getDatStatusWfm() {
		return datStatusWfm;
	}

	public void setDatStatusWfm(String datStatusWfm) {
		this.datStatusWfm = datStatusWfm;
	}

	public String getHoraStatusWfm() {
		return horaStatusWfm;
	}

	public void setHoraStatusWfm(String horaStatusWfm) {
		this.horaStatusWfm = horaStatusWfm;
	}

	public String getIdRecursoWfm() {
		return idRecursoWfm;
	}

	public void setIdRecursoWfm(String idRecursoWfm) {
		this.idRecursoWfm = idRecursoWfm;
	}

	public String getNomRecursoWfm() {
		return nomRecursoWfm;
	}

	public void setNomRecursoWfm(String nomRecursoWfm) {
		this.nomRecursoWfm = nomRecursoWfm;
	}

	public String getIdRecursoPaiWfm() {
		return idRecursoPaiWfm;
	}

	public void setIdRecursoPaiWfm(String idRecursoPaiWfm) {
		this.idRecursoPaiWfm = idRecursoPaiWfm;
	}

	public String getDatPrimeiroAgend() {
		return datPrimeiroAgend;
	}

	public void setDatPrimeiroAgend(String datPrimeiroAgend) {
		this.datPrimeiroAgend = datPrimeiroAgend;
	}

	public String getHoraPrimeiroAgendamento() {
		return horaPrimeiroAgendamento;
	}

	public void setHoraPrimeiroAgendamento(String horaPrimeiroAgendamento) {
		this.horaPrimeiroAgendamento = horaPrimeiroAgendamento;
	}

	public String getDatAgendAtual() {
		return datAgendAtual;
	}

	public void setDatAgendAtual(String datAgendAtual) {
		this.datAgendAtual = datAgendAtual;
	}

	public String getHoraAgendamentoAtual() {
		return horaAgendamentoAtual;
	}

	public void setHoraAgendamentoAtual(String horaAgendamentoAtual) {
		this.horaAgendamentoAtual = horaAgendamentoAtual;
	}

	public String getDscStatusAtivacao() {
		return dscStatusAtivacao;
	}

	public void setDscStatusAtivacao(String dscStatusAtivacao) {
		this.dscStatusAtivacao = dscStatusAtivacao;
	}

	@Override
	public String toString(){
		 return new StringBuilder()
		 .append(datRef).append("|")
		 .append(datCriacaoOrdem).append("|")
		 .append(horCriacaoOrdem).append("|")
		 .append(datVenda).append("|")
		 .append(horaVenda).append("|")
		 .append(datVendaOrig).append("|")
		 .append(horVendaOrig).append("|")
		 .append(datStatusOrdem).append("|")
		 .append(horStatusOrdem).append("|")
		 .append(numOrdemSiebel).append("|")
		 .append(numOrdemSiebelOrig).append("|")
		 .append(codContratoOltp).append("|")
		 .append(codContratoAtivacao).append("|")
		 .append(codContratoAtual).append("|")
		 .append(numeroAcesso).append("|")
		 .append(customerId).append("|")
		 .append(tipoDocumento).append("|")
		 .append(documento).append("|")
		 .append(tipoVenda).append("|")
		 .append(tipoProduto).append("|")
		 .append(velocidadeDownload).append("|")
		 .append(velocidadeUpload).append("|")
		 .append(planoAtivacaoOferta).append("|")
		 .append(loginVendedor).append("|")
		 .append(loginVendedorOrig).append("|")
		 .append(nomeVendedor).append("|")
		 .append(nomeVendedorOrig).append("|")
		 .append(canal).append("|")
		 .append(canalOrig).append("|")
		 .append(cnpjParceiro).append("|")
		 .append(cnpjParceiroOrig).append("|")
		 .append(custCode).append("|")
		 .append(custCodeOrig).append("|")
		 .append(position).append("|")
		 .append(positionOrig).append("|")
		 .append(parceiro).append("|")
		 .append(parceiroOrig).append("|")
		 .append(flgCancAntesVenda).append("|")
		 .append(flgVendaSubmetida).append("|")
		 .append(flgVendaDuplicada).append("|")
		 .append(flgVendaBruta).append("|")
		 .append(flgVendaLiquida).append("|")
		 .append(flgGross).append("|")
		 .append(flgChurn).append("|")
		 .append(flgCancPosVenda).append("|")
		 .append(flgCancDupl).append("|")
		 .append(flgCancLiquido).append("|")
		 .append(datGross).append("|")
		 .append(datChurn).append("|")
		 .append(motivoChurn).append("|")
		 .append(tipoChurn).append("|")
		 .append(datCancVenda).append("|")
		 .append(motivoCancelamento).append("|")
		 .append(nomeCliente).append("|")
		 .append(telefone).append("|")
		 .append(email).append("|")
		 .append(uf).append("|")
		 .append(tipoLogradouro).append("|")
		 .append(logradouro).append("|")
		 .append(numero).append("|")
		 .append(complemento).append("|")
		 .append(bairro).append("|")
		 .append(cep).append("|")
		 .append(cidade).append("|")
		 .append(msan_olt_venda).append("|")
		 .append(msanOltTrafego).append("|")
		 .append(statusOrdem).append("|")
		 .append(tecnologia).append("|")
		 .append(formaPagamento).append("|")
		 .append(tipoConta).append("|")
		 .append(codBanco).append("|")
		 .append(codAgenciaBanco).append("|")
		 .append(codContaCorrente).append("|")
		 .append(codDebitoAutomatico).append("|")
		 .append(diaVencimento).append("|")
		 .append(semanaVenda).append("|")
		 .append(semanaVendaOrig).append("|")
		 .append(score).append("|")
		 .append(scoreConsumido).append("|")
		 .append(datFinalizacaoOrdem).append("|")
		 .append(dt_conclusao_wfm).append("|")
		 .append(qtdContratos).append("|")
		 .append(codContaFinanceira).append("|")
		 .append(numProtocolo).append("|")
		 .append(flgOrdemAutomatica).append("|")
		 .append(dscTxRecorrente).append("|")
		 .append(dscTxNaoRecorrente).append("|")
		 .append(dscStatusItem).append("|")
		 .append(nomLoginResponsavel).append("|")
		 .append(nomPlanoAtual).append("|")
		 .append(valPlanoAtualItem).append("|")
		 .append(nomDescontoAtualItem).append("|")
		 .append(valDescontoAtualItem).append("|")
		 .append(flgPortabilidade).append("|")
		 .append(dscOperadoraDoadora).append("|")
		 .append(codDdd).append("|")
		 .append(numTelefonePortado).append("|")
		 .append(datJanelaPortabilidade).append("|")
		 .append(horJanela).append("|")
		 .append(dscStatusOrdemWfm).append("|")
		 .append(datStatusWfm).append("|")
		 .append(horaStatusWfm).append("|")
		 .append(idRecursoWfm).append("|")
		 .append(nomRecursoWfm).append("|")
		 .append(idRecursoPaiWfm).append("|")
		 .append(datPrimeiroAgend).append("|")
		 .append(horaPrimeiroAgendamento).append("|")
		 .append(datAgendAtual).append("|")
		 .append(horaAgendamentoAtual).append("|")
		 .append(dscStatusAtivacao).append("|")
		 .append(dscEnderecoFatura).append("|")
		 .append(dscAreaVoip).append("|")
		 .append(cpe).append("|")
		 .append(ont).append("|")
		 .append(codConvergente).append("|")
		 .append(detalheRecusaCrivo).append("|")
		 .append(itemRoot).append("|")
		 .append(loginCancelamentoOrdem).append("|")
		 .append(nomeUsuarioCancelouOrdem).append("|")
		 .append(custcodeCliente).append("|")
		 .append(dominioRoot).append("|")
		 .append(datRefRelt).toString();
	}

	public String getNumOrdemSiebel() {
		return numOrdemSiebel;
	}

	public void setNumOrdemSiebel(String numOrdemSiebel) {
		this.numOrdemSiebel = numOrdemSiebel;
	}
	
}
