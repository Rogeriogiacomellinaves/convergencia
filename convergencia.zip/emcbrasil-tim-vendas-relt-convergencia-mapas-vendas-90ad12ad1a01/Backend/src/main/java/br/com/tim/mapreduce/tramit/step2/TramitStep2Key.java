package br.com.tim.mapreduce.tramit.step2;

import br.com.tim.mapreduce.tramit.GroupComparable;
import com.google.common.collect.ComparisonChain;
import org.apache.hadoop.io.WritableComparable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Objects;


public class TramitStep2Key implements GroupComparable<TramitStep2Key> {

	private String ordemSiebel;
	private TypeStep2 tipo;

	@Override
	public void write(DataOutput output) throws IOException {
		output.writeInt(tipo.ordinal());
		output.writeUTF(this.ordemSiebel);
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		this.tipo = TypeStep2.values()[in.readInt()];
		this.ordemSiebel = in.readUTF();
	}

	public String getOrdemSiebel() {
		return ordemSiebel;
	}

	public void setTipo(TypeStep2 tipo) {
		this.tipo = tipo;
	}

	public void setOrdemSiebel(String ordemSiebel) {
		this.ordemSiebel = ordemSiebel;
	}

	@Override
	public int compareTo(TramitStep2Key o) {
		return ComparisonChain.start().compare(this.ordemSiebel, o.ordemSiebel).compare(this.tipo, o.tipo)
				.result();
	}

	@Override
	public int compareToGrouping(TramitStep2Key o) {
		return ComparisonChain.start().compare(this.ordemSiebel, o.ordemSiebel).result();
	}

	public int hashCodeJoin() {

		return Objects.hash(ordemSiebel);
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		TramitStep2Key key = (TramitStep2Key) o;
		return Objects.equals(ordemSiebel, key.ordemSiebel) && Objects.equals(tipo, key.tipo);
	}

	@Override
	public int hashCode() {

		return Objects.hash(ordemSiebel);
	}
}