package br.com.tim.mapreduce.e2e.step8;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

public class GroupingComparator extends WritableComparator {

    public GroupingComparator() {
        super(E2EStep8Key.class, true);
    }

    @SuppressWarnings({"rawtypes"})
    @Override
    public int compare(WritableComparable a, WritableComparable b) {
        E2EStep8Key keyA = (E2EStep8Key) a;
        E2EStep8Key keyB = (E2EStep8Key) b;

        return keyA.compareToGrouping(keyB);
    }

}
