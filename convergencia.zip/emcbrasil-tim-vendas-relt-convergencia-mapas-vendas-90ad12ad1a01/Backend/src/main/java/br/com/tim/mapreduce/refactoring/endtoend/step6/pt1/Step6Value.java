package br.com.tim.mapreduce.refactoring.endtoend.step6.pt1;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Writable;

import br.com.tim.mapreduce.refactoring.endtoend.step6.model.Step5;


public class Step6Value implements Writable{
	

	TypeStep6 type;
	private Writable value;

	@Override
	public void write(DataOutput out) throws IOException {

		out.writeInt(type.ordinal());
		if (null != value)
			this.value.write(out);

	}

	@Override
	public void readFields(DataInput in) throws IOException {

		this.type = TypeStep6.values()[in.readInt()];

		switch (this.type) {
		case STEP5:
			this.value = new Step5();
			break;
		default:
			break;
		}

		if (null != value) {
			this.value.readFields(in);
		}

	}

	public void update(TypeStep6 type, Writable value) {

		this.setType(type);
		this.setValue(value);

	}

	public void reset() {
		this.type = null;
		this.value = null;
	}

	public TypeStep6 getType() {
		return type;
	}

	public void setType(TypeStep6 type) {
		this.type = type;
	}

	public Writable getValue() {
		return value;
	}

	public void setValue(Writable value) {
		this.value = value;
	}

	public Step6Value() {
		this.reset();
	}
	
	


}
