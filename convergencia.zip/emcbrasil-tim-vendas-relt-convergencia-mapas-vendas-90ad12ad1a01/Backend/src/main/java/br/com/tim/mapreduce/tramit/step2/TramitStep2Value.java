package br.com.tim.mapreduce.tramit.step2;

import br.com.tim.mapreduce.model.FalloutOM;
import br.com.tim.mapreduce.tramit.step2.model.Step1Result;
import org.apache.hadoop.io.Writable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public class TramitStep2Value implements Writable {

	protected TypeStep2 tipo;
	protected String ordemSiebel;
	protected String cpfCNPJ;
	protected String contrato;
	protected String datCriacaoOrdem;
	protected String login;
	protected String statusSiebel;
	protected String motivoCancelamento;
	protected String tipoOrdem;
	protected String subtipoOrdem;
	protected String parceiroVendaSiebel;
	protected String tipoErro;
	protected String erroNormalizado;
	protected String owner;
	protected String aging;
	protected String agingFaixa;
	protected String tecnologia;
	protected String cpe;
	protected String ont;
	protected String produto;
	protected String uf;
	protected String statusWfmToa;
    protected String resourceWfmToa; 
    protected String dateWfmToa;
    protected String stepErro;
	protected String msan;

	@Override
	public void write(DataOutput dataOutput) throws IOException {
		dataOutput.writeInt(tipo.ordinal());
		dataOutput.writeUTF(ordemSiebel);
		dataOutput.writeUTF(cpfCNPJ);
		dataOutput.writeUTF(contrato);
		dataOutput.writeUTF(datCriacaoOrdem);
		dataOutput.writeUTF(login);
		dataOutput.writeUTF(statusSiebel);
		dataOutput.writeUTF(motivoCancelamento);
		dataOutput.writeUTF(tipoOrdem);
		dataOutput.writeUTF(subtipoOrdem);
		dataOutput.writeUTF(parceiroVendaSiebel);
		dataOutput.writeUTF(tipoErro);
		dataOutput.writeUTF(erroNormalizado);
		dataOutput.writeUTF(owner);
		dataOutput.writeUTF(aging);
		dataOutput.writeUTF(agingFaixa);
		dataOutput.writeUTF(tecnologia);
		dataOutput.writeUTF(cpe);
		dataOutput.writeUTF(ont);
		dataOutput.writeUTF(produto);
		dataOutput.writeUTF(uf);
        dataOutput.writeUTF(statusWfmToa);
        dataOutput.writeUTF(resourceWfmToa);
        dataOutput.writeUTF(dateWfmToa);
        dataOutput.writeUTF(stepErro);
        dataOutput.writeUTF(msan);
	}

	@Override
	public void readFields(DataInput dataInput) throws IOException {
		this.tipo = TypeStep2.values()[dataInput.readInt()];
		this.ordemSiebel = dataInput.readUTF();
		this.cpfCNPJ = dataInput.readUTF();
		this.contrato = dataInput.readUTF();
		this.datCriacaoOrdem = dataInput.readUTF();
		this.login = dataInput.readUTF();
		this.statusSiebel = dataInput.readUTF();
		this.motivoCancelamento = dataInput.readUTF();
		this.tipoOrdem = dataInput.readUTF();
		this.subtipoOrdem = dataInput.readUTF();
		this.parceiroVendaSiebel = dataInput.readUTF();
		this.tipoErro = dataInput.readUTF();
		this.erroNormalizado = dataInput.readUTF();
		this.owner = dataInput.readUTF();
		this.aging = dataInput.readUTF();
		this.agingFaixa = dataInput.readUTF();
		this.tecnologia = dataInput.readUTF();
		this.cpe = dataInput.readUTF();
		this.ont = dataInput.readUTF();
		this.produto = dataInput.readUTF();
		this.uf = dataInput.readUTF();
        this.statusWfmToa = dataInput.readUTF();
        this.resourceWfmToa = dataInput.readUTF();
        this.dateWfmToa = dataInput.readUTF();
        this.stepErro = dataInput.readUTF();
        this.msan = dataInput.readUTF();
	}

	public void setResultStep1(Step1Result result) {
		this.clear();
		this.tipo = TypeStep2.STEP1RESULT;
		this.ordemSiebel = result.getOrdemSiebel();
		this.cpfCNPJ = result.getCpfCNPJ();
		this.contrato = result.getContrato();
		this.datCriacaoOrdem = result.getDatCriacaoOrdem();
		this.login = result.getLogin();
		this.statusSiebel = result.getStatusSiebel();
		this.motivoCancelamento = result.getMotivoCancelamento();
		this.tipoOrdem = result.getTipoOrdem();
		this.subtipoOrdem = result.getSubtipoOrdem();
		this.parceiroVendaSiebel = result.getParceiroVendaSiebel();
		this.tipoErro = result.getTipoErro();
		this.aging = result.getAging();
		this.agingFaixa = result.getAgingFaixa();
		this.tecnologia = result.getTecnologia();
		this.cpe = result.getCpe();
		this.ont = result.getOnt();
		this.produto = result.getProduto();
		this.uf = result.getUf();
		this.statusWfmToa = result.getStatusWfmToa();
    	this.resourceWfmToa = result.getResourceWfmToa();
    	this.dateWfmToa = result.getDateWfmToa();
    	this.stepErro = result.getStepErro();
    	this.msan = result.getMsan();

	}

	public void setFallout(FalloutOM fallout) {
		this.clear();
		this.tipo = TypeStep2.FALLOUT;
		this.erroNormalizado = fallout.getDestination();

		if (fallout.getStatusPort().equals("P") && fallout.getDestination().equals("WLI"))
			this.owner = "Aguardando Janela";
		else if ((fallout.getStatusPort().equals("CP") || fallout.getStatusPort().equals("PF")
				|| fallout.getStatusPort().equals("DP")) && fallout.getDestination().equals("WLI"))
			this.owner = "Aguardando Fluxo";
		else if ((fallout.getStatusPort().equals("A") || fallout.getStatusPort().equals("C")
				|| fallout.getStatusPort().equals("O")) && fallout.getDestination().equals("WLI"))
			this.owner = "WLI - TI";
		else if ((fallout.getStatusPort().equals("X") || fallout.getStatusPort().equals("S"))
				&& fallout.getDestination().equals("WLI"))
			this.owner = "WLI - CRC";
		else if ((fallout.getStatus().equals("Analisar") || fallout.getStatus().equals("MT")
				|| fallout.getStatus().equals("BT") || fallout.getStatus().equals("Complet_KO")
				|| fallout.getStatus().equals("Complet_OK"))
				&& (fallout.getMtCodErro().equals("") || fallout.getMtCodErro() == null))
			this.owner = "N/A (Não Analisada)";
		else if (fallout.getStatus().equals("Async"))
			this.owner = "Async";
		else {
			this.owner = fallout.getPoolName();
			if (this.owner.equals(""))
				this.owner = "N/A (Não Analisada)";
		}
	}

	public void clear() {
		this.tipo = null;
		this.ordemSiebel = "";
		this.cpfCNPJ = "";
		this.contrato = "";
		this.datCriacaoOrdem = "";
		this.login = "";
		this.statusSiebel = "";
		this.motivoCancelamento = "";
		this.tipoOrdem = "";
		this.subtipoOrdem = "";
		this.parceiroVendaSiebel = "";
		this.tipoErro = "";
		this.erroNormalizado = "";
		this.owner = "";
		this.aging = "";
		this.agingFaixa = "";
		this.tecnologia = "";
		this.cpe = "";
		this.ont = "";
		this.produto = "";
		this.uf = "";
		this.statusWfmToa = "";
    	this.resourceWfmToa = "";
    	this.dateWfmToa = "";
    	this.stepErro = "";
    	this.msan = "";
	}

	public TypeStep2 getTipo() {
		return tipo;
	}

	public void setTipo(TypeStep2 tipo) {
		this.tipo = tipo;
	}

	public String getOrdemSiebel() {
		return ordemSiebel;
	}

	public void setOrdemSiebel(String ordemSiebel) {
		this.ordemSiebel = ordemSiebel;
	}

	public String getCpfCNPJ() {
		return cpfCNPJ;
	}

	public void setCpfCNPJ(String cpfCNPJ) {
		this.cpfCNPJ = cpfCNPJ;
	}

	public String getContrato() {
		return contrato;
	}

	public void setContrato(String contrato) {
		this.contrato = contrato;
	}

	public String getDatCriacaoOrdem() {
		return datCriacaoOrdem;
	}

	public void setDatCriacaoOrdem(String datCriacaoOrdem) {
		this.datCriacaoOrdem = datCriacaoOrdem;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getStatusSiebel() {
		return statusSiebel;
	}

	public void setStatusSiebel(String statusSiebel) {
		this.statusSiebel = statusSiebel;
	}

	public String getMotivoCancelamento() {
		return motivoCancelamento;
	}

	public void setMotivoCancelamento(String motivoCancelamento) {
		this.motivoCancelamento = motivoCancelamento;
	}

	public String getTipoOrdem() {
		return tipoOrdem;
	}

	public void setTipoOrdem(String tipoOrdem) {
		this.tipoOrdem = tipoOrdem;
	}

	public String getSubtipoOrdem() {
		return subtipoOrdem;
	}

	public void setSubtipoOrdem(String subtipoOrdem) {
		this.subtipoOrdem = subtipoOrdem;
	}

	public String getParceiroVendaSiebel() {
		return parceiroVendaSiebel;
	}

	public void setParceiroVendaSiebel(String parceiroVendaSiebel) {
		this.parceiroVendaSiebel = parceiroVendaSiebel;
	}

	public String getTipoErro() {
		return tipoErro;
	}

	public void setTipoErro(String tipoErro) {
		this.tipoErro = tipoErro;
	}

	public String getErroNormalizado() {
		return erroNormalizado;
	}

	public void setErroNormalizado(String erroNormalizado) {
		this.erroNormalizado = erroNormalizado;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getAging() {
		return aging;
	}

	public void setAging(String aging) {
		this.aging = aging;
	}

	public String getAgingFaixa() {
		return agingFaixa;
	}

	public void setAgingFaixa(String agingFaixa) {
		this.agingFaixa = agingFaixa;
	}

	public String getTecnologia() {
		return tecnologia;
	}

	public void setTecnologia(String tecnologia) {
		this.tecnologia = tecnologia;
	}

	public String getCpe() {
		return cpe;
	}

	public void setCpe(String cpe) {
		this.cpe = cpe;
	}

	public String getOnt() {
		return ont;
	}

	public void setOnt(String ont) {
		this.ont = ont;
	}

	public String getProduto() {
		return produto;
	}

	public void setProduto(String produto) {
		this.produto = produto;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}
	public String getStatusWfmToa() {
		return statusWfmToa;
	}

	public void setStatusWfmToa(String statusWfmToa) {
		this.statusWfmToa = statusWfmToa;
	}

	public String getResourceWfmToa() {
		return resourceWfmToa;
	}

	public void setResourceWfmToa(String resourceWfmToa) {
		this.resourceWfmToa = resourceWfmToa;
	}

	public String getDateWfmToa() {
		return dateWfmToa;
	}

	public void setDateWfmToa(String dateWfmToa) {
		this.dateWfmToa = dateWfmToa;
	}

	public String getStepErro() {
		return stepErro;
	}

	public void setStepErro(String stepErro) {
		this.stepErro = stepErro;
	}

	public String getMsan() {
		return msan;
	}

	public void setMsan(String msan) {
		this.msan = msan;
	}

}
