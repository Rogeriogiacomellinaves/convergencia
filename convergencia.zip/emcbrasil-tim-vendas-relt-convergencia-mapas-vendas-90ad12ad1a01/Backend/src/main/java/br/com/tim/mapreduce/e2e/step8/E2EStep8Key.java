package br.com.tim.mapreduce.e2e.step8;

import com.google.common.collect.ComparisonChain;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Objects;

public class E2EStep8Key implements GroupComparable<E2EStep8Key> {

	private String numAcesso;
	private String codContrato;
	private TypeStep8 tipo;

	@Override
	public void write(DataOutput output) throws IOException {
		output.writeInt(tipo.ordinal());
		output.writeUTF(this.numAcesso);
		output.writeUTF(this.codContrato);
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		this.tipo = TypeStep8.values()[in.readInt()];
		this.numAcesso = in.readUTF();
		this.codContrato = in.readUTF();
	}

	public void setNumAcesso(String numAcesso) {
		this.numAcesso = numAcesso;
	}

	public void setCodContrato(String codContrato) {
		this.codContrato = codContrato;
	}

	public TypeStep8 getTipo() {
		return tipo;
	}

	public void setTipo(TypeStep8 tipo) {
		this.tipo = tipo;
	}

	@Override
	public int compareTo(E2EStep8Key o) {
		return ComparisonChain.start().compare(this.numAcesso, o.numAcesso).compare(this.codContrato, o.codContrato).compare(this.tipo, o.tipo)
				.result();
	}

	@Override
	public int compareToGrouping(E2EStep8Key o) {
		return ComparisonChain.start().compare(this.numAcesso, o.numAcesso).compare(this.codContrato, o.codContrato).result();
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		E2EStep8Key key = (E2EStep8Key) o;
		return Objects.equals(numAcesso, key.numAcesso) && Objects.equals(codContrato, key.codContrato) && Objects.equals(tipo, key.tipo);
	}

	public int hashCodeJoin() {

		return Objects.hash(numAcesso, codContrato);
	}

	@Override
	public int hashCode() {

		return Objects.hash(numAcesso, codContrato);
	}
}