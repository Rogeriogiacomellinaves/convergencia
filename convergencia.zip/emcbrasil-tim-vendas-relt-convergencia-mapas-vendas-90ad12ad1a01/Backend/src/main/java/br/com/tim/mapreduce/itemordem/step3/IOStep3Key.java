package br.com.tim.mapreduce.itemordem.step3;

import br.com.tim.mapreduce.itemordem.GroupComparable;
import br.com.tim.mapreduce.itemordem.step3.model.Step2Result;
import br.com.tim.mapreduce.model.BAT230;
import com.google.common.collect.ComparisonChain;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Objects;


public class IOStep3Key implements GroupComparable<IOStep3Key> {

	private String codConta;
	private TypeStep3 tipo;

	@Override
	public void write(DataOutput output) throws IOException {
		output.writeInt(this.tipo.ordinal());
		output.writeUTF(this.codConta);
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		this.tipo = TypeStep3.values()[in.readInt()];
		this.codConta = in.readUTF();
	}

	public void setKey(BAT230 obj) {
		this.clear();
		this.tipo = TypeStep3.BAT230;
		this.codConta = obj.getIdPublico();
	}

	public void setKey(Step2Result obj) {
		this.clear();
		this.tipo = TypeStep3.RESULTSTEP2;
		this.codConta = obj.getCodCtaFinanceira();
	}

	@Override
	public int compareTo(IOStep3Key o) {
		return ComparisonChain.start().compare(this.codConta, o.codConta).compare(this.tipo, o.tipo)
				.result();
	}

	@Override
	public int compareToGrouping(IOStep3Key o) {
		return ComparisonChain.start().compare(this.codConta, o.codConta).result();
	}

	public int hashCodeJoin() {

		return Objects.hash(codConta);
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		IOStep3Key key = (IOStep3Key) o;
		return Objects.equals(codConta, key.codConta) && Objects.equals(tipo, key.tipo);
	}

	@Override
	public int hashCode() {

		return Objects.hash(codConta);
	}

	public void clear(){
		this.codConta = "";
	}
}