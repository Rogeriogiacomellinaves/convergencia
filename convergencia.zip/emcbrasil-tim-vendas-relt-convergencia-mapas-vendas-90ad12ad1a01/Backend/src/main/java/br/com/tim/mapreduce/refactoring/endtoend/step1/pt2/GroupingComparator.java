package br.com.tim.mapreduce.refactoring.endtoend.step1.pt2;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

public class GroupingComparator extends WritableComparator {

    public GroupingComparator() {
        super(Step1Pt2Key.class, true);
    }

    @SuppressWarnings({"rawtypes"})
    @Override
    public int compare(WritableComparable a, WritableComparable b) {
    	Step1Pt2Key keyA = (Step1Pt2Key) a;
    	Step1Pt2Key keyB = (Step1Pt2Key) b;

        return keyA.compareToGrouping(keyB);
    }

}
