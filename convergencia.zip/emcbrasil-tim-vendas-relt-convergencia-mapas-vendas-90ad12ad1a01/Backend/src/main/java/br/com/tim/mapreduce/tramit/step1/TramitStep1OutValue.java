package br.com.tim.mapreduce.tramit.step1;

public class TramitStep1OutValue {

	protected String ordemSiebel;
	protected String cpfCNPJ;
	protected String contrato;
	protected String datCriacaoOrdem;
	protected String login;
	protected String statusSiebel;
	protected String motivoCancelamento;
	protected String tipoOrdem;
	protected String subtipoOrdem;
	protected String parceiroVendaSiebel;
	protected String tipoErro;
	protected String aging;
	protected String agingFaixa;
	protected String tecnologia;
	protected String cpe;
	protected String ont;
	protected String produto;
	protected String uf;
	protected String nomLoginResponsavel;
	protected String acaoItemOrdem;
	protected String statusWfmToa;
	protected String resourceWfmToa;
	protected String dateWfmToa;
	protected String stepErro;
	protected String msan;

	public void setTipoErro() {

		if (this.tipoOrdem.trim().toUpperCase().equals("ORDEM DE REATIVACAO") && this.nomLoginResponsavel.trim().toUpperCase().equals("SADMIN")
				&& this.acaoItemOrdem.trim().toUpperCase().equals("EXCLUIR") && !this.statusSiebel.trim().toUpperCase().equals("CONCLUÍDO")
				&& !this.statusSiebel.trim().toUpperCase().equals("CANCELADO")) {
			
			this.tipoErro = "RMCA_REAT_IDA";
			
		} else if (this.tipoOrdem.trim().toUpperCase().equals("ORDEM DE MODIFICACAO") && this.nomLoginResponsavel.trim().toUpperCase().equals("SADMIN")
				&& this.acaoItemOrdem.trim().toUpperCase().equals("EXCLUIR") && !this.statusSiebel.trim().toUpperCase().equals("CONCLUÍDO")
				&& !this.statusSiebel.trim().toUpperCase().equals("CANCELADO")) {
			
			this.tipoErro = "RMCA_RET_VEL_IDA";
			
		} else if (this.statusSiebel.trim().toUpperCase().equals("ERRO_NO_ENVIO") || this.statusSiebel.trim().toUpperCase().equals("ERRO NO ENVIO") ) {
			
			this.tipoErro = "ERRO_NO_ENVIO";
			
		} else if (this.tipoOrdem.trim().toUpperCase().equals("ORDEM DE VENDA") && this.subtipoOrdem.trim().toUpperCase().equals("VOZ FIXO VOIP")
				&& !this.statusSiebel.trim().toUpperCase().equals("CONCLUÍDO") && !this.statusSiebel.trim().toUpperCase().equals("CANCELADO")
				&& this.statusWfmToa.trim().toUpperCase().equals("COMPLETED")) {
			
			this.tipoErro = "VENDAS_VOIP_VOLTA";
			
		} else if (this.statusSiebel.trim().toUpperCase().equals("CONCLUÍDO") && !this.statusWfmToa.trim().toUpperCase().equals("COMPLETED")) {
			
			this.tipoErro = "CONCLUSAO_INDEVIDA";
			
		} else if ((this.statusSiebel.trim().toUpperCase().equals("EM CANCELAMENTO") || this.statusSiebel.trim().toUpperCase().equals("ERRO NO CANCELAMENTO"))
				&& this.tipoOrdem.trim().toUpperCase().equals("ORDEM DE VENDA") && this.statusWfmToa.trim().toUpperCase().equals("CANCELLED")) {
			
			this.tipoErro = "VENDA_CANCELAMENTO_PENDENTE";
			
		} else if (this.tipoOrdem.trim().toUpperCase().equals("ORDEM DE VENDA") && this.subtipoOrdem.trim().toUpperCase().equals("BANDA LARGA + VOIP")
				&& !this.statusSiebel.trim().toUpperCase().equals("CONCLUÍDO") && !this.statusSiebel.trim().toUpperCase().equals("CANCELADO") 
				&& this.statusWfmToa.trim().toUpperCase().equals("COMPLETED")) {
			
			this.tipoErro = "VENDAS_BL_BLVOIP_VOLTA";
			
		} else if (this.tipoOrdem.trim().toUpperCase().equals("ORDEM DE MODIFICACAO") && this.subtipoOrdem.trim().toUpperCase().equals("TROCA DE ENDEREÇO")
				&& !this.statusSiebel.trim().toUpperCase().equals("CONCLUÍDO") && !this.statusSiebel.trim().toUpperCase().equals("CANCELADO") 
				&& this.statusWfmToa.trim().toUpperCase().equals("COMPLETED")) {
			
			this.tipoErro = "TROCA_DE_ENDERECO_VOLTA";
			
		} else if (this.tipoOrdem.trim().toUpperCase().equals("ORDEM DE MODIFICACAO") && this.subtipoOrdem.trim().toUpperCase().equals("MODEM")
				&& !this.statusSiebel.trim().toUpperCase().equals("CONCLUÍDO") && !this.statusSiebel.trim().toUpperCase().equals("CANCELADO")) {
			
			this.tipoErro = "TROCA_DE_MODEM";
			
		} else if (this.tipoOrdem.trim().toUpperCase().equals("ORDEM DE DESCONEXAO") && this.nomLoginResponsavel.trim().toUpperCase().equals("SADMIN")
				&& !this.statusSiebel.trim().toUpperCase().equals("CONCLUÍDO") && !this.statusSiebel.trim().toUpperCase().equals("CANCELADO")
				&& this.statusWfmToa.trim().toUpperCase().equals("COMPLETED")) {
			
			this.tipoErro = "RMCA_DESC_VOLTA";
			
		} else if (this.tipoOrdem.trim().toUpperCase().equals("ORDEM DE DESCONEXAO") && !this.nomLoginResponsavel.trim().toUpperCase().equals("SADMIN")
				&& !this.statusSiebel.trim().toUpperCase().equals("CONCLUÍDO") && !this.statusSiebel.trim().toUpperCase().equals("CANCELADO")
				&& (this.statusWfmToa.trim().equals("") || this.statusWfmToa.trim() == null)) {
			
			this.tipoErro = "DESCONEXAO_IDA";
			
		} else if (this.tipoOrdem.trim().toUpperCase().equals("ORDEM DE DESCONEXAO") && !this.nomLoginResponsavel.trim().toUpperCase().equals("SADMIN")
				&& !this.statusSiebel.trim().toUpperCase().equals("CONCLUÍDO") && !this.statusSiebel.trim().toUpperCase().equals("CANCELADO")
				&& this.statusWfmToa.trim().toUpperCase().equals("COMPLETED")) {
			
			this.tipoErro = "DESCONEXAO_VOLTA";
			
		} else if (this.tipoOrdem.trim().toUpperCase().equals("ORDEM DE MODIFICACAO") && !this.subtipoOrdem.trim().toUpperCase().equals("MODEM")
				&& !this.subtipoOrdem.trim().toUpperCase().equals("TROCA DE ENDEREÇO") && !this.nomLoginResponsavel.trim().toUpperCase().equals("SADMIN")
				&& !this.statusSiebel.trim().toUpperCase().equals("CONCLUÍDO") && !this.statusSiebel.trim().toUpperCase().equals("CANCELADO")) {
			
			this.tipoErro = "MUDANCA_PRODUTO";
			
		} else if (this.tipoOrdem.trim().toUpperCase().equals("ORDEM DE SUSPENSAO") && this.nomLoginResponsavel.trim().toUpperCase().equals("SADMIN")
				&& this.acaoItemOrdem.trim().toUpperCase().equals("NOVA") && !this.statusSiebel.trim().toUpperCase().equals("CONCLUÍDO")
				&& !this.statusSiebel.trim().toUpperCase().equals("CANCELADO")) {
			
			this.tipoErro = "RMCA_SUSP_IDA";
		
		} else if (this.tipoOrdem.trim().toUpperCase().equals("ORDEM DE VENDA") && this.subtipoOrdem.trim().toUpperCase().equals("VOZ FIXO VOIP")
				&& !this.statusSiebel.trim().toUpperCase().equals("CONCLUÍDO") && !this.statusSiebel.trim().toUpperCase().equals("CANCELADO")
				&& (this.statusWfmToa.trim().equals("") || this.statusWfmToa.trim() == null)) {
			
			this.tipoErro = "VENDAS_VOIP_IDA";
			
		} else if (this.tipoOrdem.trim().toUpperCase().equals("ORDEM DE VENDA") && this.subtipoOrdem.trim().toUpperCase().equals("TROCA DE ENDEREÇO")
				&& !this.statusSiebel.trim().toUpperCase().equals("CONCLUÍDO") && !this.statusSiebel.trim().toUpperCase().equals("CANCELADO")
				&& (this.statusWfmToa.trim().equals("") || this.statusWfmToa.trim() == null)) {
			
			this.tipoErro = "TROCA_DE_ENDERECO_IDA";
			
		} else if (this.tipoOrdem.trim().toUpperCase().equals("ORDEM DE VENDA") && this.statusSiebel.trim().toUpperCase().equals("CANCELADO")
				&& this.statusWfmToa.trim().toUpperCase().equals("CANCELLED")) {
			
			this.tipoErro = "VENDA_CANCELAMENTO_INDEVIDO";
			
		} else if (this.tipoOrdem.trim().toUpperCase().equals("ORDEM DE MODIFICACAO") && this.nomLoginResponsavel.trim().toUpperCase().equals("SADMIN")
				&& this.acaoItemOrdem.trim().toUpperCase().equals("NOVA") && !this.statusSiebel.trim().toUpperCase().equals("CONCLUÍDO")
				&& !this.statusSiebel.trim().toUpperCase().equals("CANCELADO")) {
			
			this.tipoErro = "RMCA_RED_VEL_IDA";
			
		} else if (this.tipoOrdem.trim().toUpperCase().equals("ORDEM DE DESCONEXAO") && this.nomLoginResponsavel.trim().toUpperCase().equals("SADMIN")
				&& !this.statusSiebel.trim().toUpperCase().equals("CONCLUÍDO") && !this.statusSiebel.trim().toUpperCase().equals("CANCELADO")
				&& (this.statusWfmToa.trim().equals("") || this.statusWfmToa.trim() == null)) {
			
			this.tipoErro = "RMCA_DESC_IDA";
			
		} else if (this.tipoOrdem.trim().toUpperCase().equals("ORDEM DE VENDA") && this.subtipoOrdem.trim().toUpperCase().equals("BANDA LARGA + VOIP")
				&& !this.statusSiebel.trim().toUpperCase().equals("CONCLUÍDO") && !this.statusSiebel.trim().toUpperCase().equals("CANCELADO")
				&& (this.statusWfmToa.trim().equals("") || this.statusWfmToa.trim() == null)) {
			
			this.tipoErro = "VENDAS_BL_BLVOIP_IDA";
			
		} else if (this.statusSiebel.trim().toUpperCase().equals("PENDENTE DE ENVIO")) {
			
			this.tipoErro = "PENDENTE_DE_ENVIO";
			
		} else if (this.tipoOrdem.trim().toUpperCase().equals("ORDEM DE DESCONEXAO") && !this.nomLoginResponsavel.trim().toUpperCase().equals("SADMIN")
				&& this.statusSiebel.trim().toUpperCase().equals("CANCELADO") && !this.statusWfmToa.trim().toUpperCase().equals("CANCELLED")) {
			
			this.tipoErro = "DESCONEXAO_CANCELAMENTO_INDEVIDO";
		}

		if (this.statusWfmToa.trim().equals("") || this.statusWfmToa.trim() == null) {
			this.stepErro = "PRE_TOA";
		} else {
			this.stepErro = "POS_TOA";
		}
	}

	public void setItem(TramitStep1Value item) {
		this.contrato = item.getContrato();
		this.tecnologia = item.getTecnologia();
		this.cpe = item.getCpe();
		this.ont = item.getOnt();
		this.produto = item.getProduto();
		this.uf = item.getUf();
		this.acaoItemOrdem = item.getAcaoItemOrdem();
	}

	public void setOrdem(TramitStep1Value ordem) {
		this.ordemSiebel = ordem.getOrdemSiebel();
		this.cpfCNPJ = ordem.getCpfCNPJ();
		this.datCriacaoOrdem = ordem.getDatCriacaoOrdem();
		this.login = ordem.getLogin();
		this.statusSiebel = ordem.getStatusSiebel();
		this.motivoCancelamento = ordem.getMotivoCancelamento();
		this.tipoOrdem = ordem.getTipoOrdem();
		this.subtipoOrdem = ordem.getSubtipoOrdem();
		this.parceiroVendaSiebel = ordem.getParceiroVendaSiebel();
		this.aging = ordem.getAging();
		this.agingFaixa = ordem.getAgingFaixa();
		this.nomLoginResponsavel = ordem.getNomLoginResponsavel();
	}

	public void setWfmtoa(TramitStep1Value wfmtoa) {
		this.statusWfmToa = wfmtoa.getStatusWfmToa();
		this.resourceWfmToa = wfmtoa.getResourceWfmToa();
		this.dateWfmToa = wfmtoa.getDateWfmToa();
		this.msan = wfmtoa.getMsan();
	}

	public void clearWfmtoa() {
		this.statusWfmToa = "";
		this.resourceWfmToa = "";
		this.dateWfmToa = "";
		this.msan = "";
	}

	public void clear() {
		this.ordemSiebel = "";
		this.cpfCNPJ = "";
		this.contrato = "";
		this.datCriacaoOrdem = "";
		this.login = "";
		this.statusSiebel = "";
		this.motivoCancelamento = "";
		this.tipoOrdem = "";
		this.subtipoOrdem = "";
		this.parceiroVendaSiebel = "";
		this.tipoErro = "";
		this.aging = "";
		this.agingFaixa = "";
		this.tecnologia = "";
		this.cpe = "";
		this.ont = "";
		this.produto = "";
		this.uf = "";
		this.acaoItemOrdem = "";
		this.nomLoginResponsavel = "";
		this.statusWfmToa = "";
		this.resourceWfmToa = "";
		this.dateWfmToa = "";
		this.stepErro = "";
		this.msan = "";
	}

	public void clearItem() {
		this.contrato = "";
		this.tecnologia = "";
		this.cpe = "";
		this.ont = "";
		this.produto = "";
		this.uf = "";
		this.acaoItemOrdem = "";
	}

	@Override
	public String toString() {
		return new StringBuilder()
				.append(ordemSiebel).append("|")
                .append(cpfCNPJ).append("|")
                .append(contrato).append("|")
                .append(datCriacaoOrdem).append("|")
                .append(login).append("|")
                .append(statusSiebel).append("|")
                .append(motivoCancelamento).append("|")
                .append(tipoOrdem).append("|")
                .append(subtipoOrdem).append("|")
                .append(parceiroVendaSiebel).append("|")
                .append(tipoErro).append("|")
                .append(aging).append("|")
                .append(agingFaixa).append("|")
                .append(tecnologia).append("|")
                .append(cpe).append("|")
                .append(ont).append("|")
                .append(produto).append("|")
                .append(uf).append("|")
                .append(statusWfmToa).append("|")
                .append(resourceWfmToa).append("|")
                .append(dateWfmToa).append("|")
                .append(stepErro).append("|")
                .append(msan).append("|").toString().toString();
	}

}
