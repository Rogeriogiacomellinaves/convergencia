package br.com.tim.mapreduce.refactoring.endtoend.step4.pt5;

public enum TypeStep4Pt5 {

    BAT222, RELT
}
