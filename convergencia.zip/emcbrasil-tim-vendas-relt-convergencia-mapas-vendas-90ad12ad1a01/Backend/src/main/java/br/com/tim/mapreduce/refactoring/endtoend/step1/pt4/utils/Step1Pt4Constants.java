package br.com.tim.mapreduce.refactoring.endtoend.step1.pt4.utils;

public class Step1Pt4Constants {
	
	
	public static final String STEP1PT4_NAME = "process-id-pt4";
	
	public static final String LOOK_BACK_DAYS_FIBER = "lookback-days-fiber";
	
	public static final String FIBER = "fiber";
	public static final String FIBER_INPUT_FACT = "input-path-fiber";
	public static final String STEP1PT3 = "step1pt3";
	public static final String STEP1PT3_INPUT_FACT = "input-path-step1-pt3";
	public static final String STEP1PT4_OUTPUT_PATH = "output-path-step1-pt4";

}
