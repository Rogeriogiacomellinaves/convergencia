package br.com.tim.mapreduce.refactoring.endtoend.step1.pt4;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.io.Writable;

import br.com.tim.mapreduce.refactoring.model.CDRFiber;
import br.com.tim.mapreduce.refactoring.endtoend.step1.pt4.model.Step1Pt3Result;

public class E2EStep1Pt4Value implements Writable {

    protected TypeStep1Pt4 tipo;

    private String datRef;
	private String datCriacaoOrdem;
	private String horCriacaoOrdem;
	private String datVenda;
	private String horaVenda;
	private String datStatusOrdem;
	private String horStatusOrdem;
	private String numOrdemSiebel;
	private String codContratoOltp;
	private String codContratoAtivacao;
	private String numeroAcesso;
	private String customerId;
	private String tipoDocumento;
	private String documento;
	private String tipoVenda;
	private String tipoProduto;
	private String planoAtivacaoOferta;
	private String loginVendedor;
	private String canal;
	private String cnpjParceiro;
	private String custCode;
	private String position;
	private String flgCancAntesVenda;
	private String flgCancPosVenda;
	private String datCancVenda;
	private String motivoCancelamento;
	private String nomeCliente;
	private String telefone;
	private String email;
	private String uf;
	private String tipoLogradouro;
	private String logradouro;
	private String numero;
	private String complemento;
	private String bairro;
	private String cep;
	private String cidade;
	private String statusOrdem;
	private String tecnologia;
	private String formaPagamento;
	private String tipoConta;
	private String codBanco;
	private String codAgenciaBanco;
	private String codContaCorrente;
	private String codDebitoAutomatico;
	private String diaVencimento;
	private String semanaVenda;
	private String score;
	private String scoreConsumido;
	private String datFinalizacaoOrdem;
	private String qtdContratos;
	private String numProtocolo;
	private String flgOrdemAutomatica;
	private String dscTxRecorrente;
	private String dscTxNaoRecorrente;
	private String dscStatusItem;
	private String nomLoginResponsavel;
	private String flgPortabilidade;
	private String dscOperadoraDoadora;
	private String codDdd;
	private String numTelefonePortado;
	private String datJanelaPortabilidade;
	private String horJanela;
	private String dscEnderecoFatura;
	private String dscAreaVoip;
	private String cpe;
	private String ont;
	private String detalheRecusaCrivo;
	private String itemRoot;
	private String loginCancelamentoOrdem;
	private String dominioRoot;
	private String codContaFinanceira;
	private String nomPlanoAtual;
	private String valPlanoAtualItem;
	private String nomDescontoAtualItem;
	private String valDescontoAtualItem;
	private String nroOrdem;
	private String acessoRowId;
	private String acessoRowIdRoot;
	private String codigoProduto;
	private String datVendaOrig;
	private String horVendaOrig;
	private String numOrdemSiebelOrig;
	private String loginVendedorOrig;
	private String canalOrig;
	private String cnpjParceiroOrig;
	private String custCodeOrig;
	private String positionOrig;
	private String flgVendaSubmetida;
	private String flgVendaDuplicada;
	private String flgVendaBruta;
	private String flgVendaLiquida;
	private String flgCancDupl;
	private String flgCancLiquido;
	private String semanaVendaOrig;
	private String nomeParceiroVenda;
	private String nomeParceiroVendaOrig;
	private String rowIdDoItemDaOrdem;
	private String rowIdDoItemDaOrdemPai;
	private String categoriaItemOrdem;
	private String msan_olt_venda;
	private String dt_conclusao_wfm;
	private String dscStatusOrdemWfm;
	private String datStatusWfm;
	private String horaStatusWfm;
	private String idRecursoWfm;
	private String nomRecursoWfm;
	private String idRecursoPaiWfm;
	private String datPrimeiroAgend;
	private String horaPrimeiroAgendamento;
	private String datAgendAtual;
	private String horaAgendamentoAtual;
	private String dscStatusAtivacao;


    protected String msanOltTrafego;

    @Override
    public void write(DataOutput dataOutput) throws IOException {
        dataOutput.writeInt(tipo.ordinal());
        dataOutput.writeUTF(datRef);
        dataOutput.writeUTF(datCriacaoOrdem);
        dataOutput.writeUTF(horCriacaoOrdem);
        dataOutput.writeUTF(datVenda);
        dataOutput.writeUTF(horaVenda);
        dataOutput.writeUTF(datStatusOrdem);
        dataOutput.writeUTF(horStatusOrdem);
        dataOutput.writeUTF(numOrdemSiebel);
        dataOutput.writeUTF(codContratoOltp);
        dataOutput.writeUTF(codContratoAtivacao);
        dataOutput.writeUTF(numeroAcesso);
        dataOutput.writeUTF(customerId);
        dataOutput.writeUTF(tipoDocumento);
        dataOutput.writeUTF(documento);
        dataOutput.writeUTF(tipoVenda);
        dataOutput.writeUTF(tipoProduto);
        dataOutput.writeUTF(planoAtivacaoOferta);
        dataOutput.writeUTF(loginVendedor);
        dataOutput.writeUTF(canal);
        dataOutput.writeUTF(cnpjParceiro);
        dataOutput.writeUTF(custCode);
        dataOutput.writeUTF(position);
        dataOutput.writeUTF(flgCancAntesVenda);
        dataOutput.writeUTF(flgCancPosVenda);
        dataOutput.writeUTF(datCancVenda);
        dataOutput.writeUTF(motivoCancelamento);
        dataOutput.writeUTF(nomeCliente);
        dataOutput.writeUTF(telefone);
        dataOutput.writeUTF(email);
        dataOutput.writeUTF(uf);
        dataOutput.writeUTF(tipoLogradouro);
        dataOutput.writeUTF(logradouro);
        dataOutput.writeUTF(numero);
        dataOutput.writeUTF(complemento);
        dataOutput.writeUTF(bairro);
        dataOutput.writeUTF(cep);
        dataOutput.writeUTF(cidade);
        dataOutput.writeUTF(statusOrdem);
        dataOutput.writeUTF(tecnologia);
        dataOutput.writeUTF(formaPagamento);
        dataOutput.writeUTF(tipoConta);
        dataOutput.writeUTF(codBanco);
        dataOutput.writeUTF(codAgenciaBanco);
        dataOutput.writeUTF(codContaCorrente);
        dataOutput.writeUTF(codDebitoAutomatico);
        dataOutput.writeUTF(diaVencimento);
        dataOutput.writeUTF(semanaVenda);
        dataOutput.writeUTF(score);
        dataOutput.writeUTF(scoreConsumido);
        dataOutput.writeUTF(datFinalizacaoOrdem);
        dataOutput.writeUTF(qtdContratos);
        dataOutput.writeUTF(numProtocolo);
        dataOutput.writeUTF(flgOrdemAutomatica);
        dataOutput.writeUTF(dscTxRecorrente);
        dataOutput.writeUTF(dscTxNaoRecorrente);
        dataOutput.writeUTF(dscStatusItem);
        dataOutput.writeUTF(nomLoginResponsavel);
        dataOutput.writeUTF(flgPortabilidade);
        dataOutput.writeUTF(dscOperadoraDoadora);
        dataOutput.writeUTF(codDdd);
        dataOutput.writeUTF(numTelefonePortado);
        dataOutput.writeUTF(datJanelaPortabilidade);
        dataOutput.writeUTF(horJanela);
        dataOutput.writeUTF(dscEnderecoFatura);
        dataOutput.writeUTF(dscAreaVoip);
        dataOutput.writeUTF(cpe);
        dataOutput.writeUTF(ont);
        dataOutput.writeUTF(detalheRecusaCrivo);
        dataOutput.writeUTF(itemRoot);
        dataOutput.writeUTF(loginCancelamentoOrdem);
        dataOutput.writeUTF(dominioRoot);
        dataOutput.writeUTF(codContaFinanceira);
        dataOutput.writeUTF(nomPlanoAtual);
        dataOutput.writeUTF(valPlanoAtualItem);
        dataOutput.writeUTF(nomDescontoAtualItem);
        dataOutput.writeUTF(valDescontoAtualItem);
        dataOutput.writeUTF(nroOrdem);
        dataOutput.writeUTF(acessoRowId);
        dataOutput.writeUTF(acessoRowIdRoot);
        dataOutput.writeUTF(codigoProduto);
        dataOutput.writeUTF(datVendaOrig);
        dataOutput.writeUTF(horVendaOrig);
        dataOutput.writeUTF(numOrdemSiebelOrig);
        dataOutput.writeUTF(loginVendedorOrig);
        dataOutput.writeUTF(canalOrig);
        dataOutput.writeUTF(cnpjParceiroOrig);
        dataOutput.writeUTF(custCodeOrig);
        dataOutput.writeUTF(positionOrig);
        dataOutput.writeUTF(flgVendaSubmetida);
        dataOutput.writeUTF(flgVendaDuplicada);
        dataOutput.writeUTF(flgVendaBruta);
        dataOutput.writeUTF(flgVendaLiquida);
        dataOutput.writeUTF(flgCancDupl);
        dataOutput.writeUTF(flgCancLiquido);
        dataOutput.writeUTF(semanaVendaOrig);
        dataOutput.writeUTF(nomeParceiroVenda);
        dataOutput.writeUTF(nomeParceiroVendaOrig);
        dataOutput.writeUTF(rowIdDoItemDaOrdem);
        dataOutput.writeUTF(rowIdDoItemDaOrdemPai);
        dataOutput.writeUTF(categoriaItemOrdem);
        dataOutput.writeUTF(msan_olt_venda);
        dataOutput.writeUTF(dt_conclusao_wfm);
        dataOutput.writeUTF(dscStatusOrdemWfm);
        dataOutput.writeUTF(datStatusWfm);
        dataOutput.writeUTF(horaStatusWfm);
        dataOutput.writeUTF(idRecursoWfm);
        dataOutput.writeUTF(nomRecursoWfm);
        dataOutput.writeUTF(idRecursoPaiWfm);
        dataOutput.writeUTF(datPrimeiroAgend);
        dataOutput.writeUTF(horaPrimeiroAgendamento);
        dataOutput.writeUTF(datAgendAtual);
        dataOutput.writeUTF(horaAgendamentoAtual);
        dataOutput.writeUTF(dscStatusAtivacao);
        dataOutput.writeUTF(msanOltTrafego);
    }

    @Override
    public void readFields(DataInput dataInput) throws IOException {
        this.tipo = TypeStep1Pt4.values()[dataInput.readInt()];
        this.datRef = dataInput.readUTF();
        this.datCriacaoOrdem = dataInput.readUTF();
        this.horCriacaoOrdem = dataInput.readUTF();
        this.datVenda = dataInput.readUTF();
        this.horaVenda = dataInput.readUTF();
        this.datStatusOrdem = dataInput.readUTF();
        this.horStatusOrdem = dataInput.readUTF();
        this.numOrdemSiebel = dataInput.readUTF();
        this.codContratoOltp = dataInput.readUTF();
        this.codContratoAtivacao = dataInput.readUTF();
        this.numeroAcesso = dataInput.readUTF();
        this.customerId = dataInput.readUTF();
        this.tipoDocumento = dataInput.readUTF();
        this.documento = dataInput.readUTF();
        this.tipoVenda = dataInput.readUTF();
        this.tipoProduto = dataInput.readUTF();
        this.planoAtivacaoOferta = dataInput.readUTF();
        this.loginVendedor = dataInput.readUTF();
        this.canal = dataInput.readUTF();
        this.cnpjParceiro = dataInput.readUTF();
        this.custCode = dataInput.readUTF();
        this.position = dataInput.readUTF();
        this.flgCancAntesVenda = dataInput.readUTF();
        this.flgCancPosVenda = dataInput.readUTF();
        this.datCancVenda = dataInput.readUTF();
        this.motivoCancelamento = dataInput.readUTF();
        this.nomeCliente = dataInput.readUTF();
        this.telefone = dataInput.readUTF();
        this.email = dataInput.readUTF();
        this.uf = dataInput.readUTF();
        this.tipoLogradouro = dataInput.readUTF();
        this.logradouro = dataInput.readUTF();
        this.numero = dataInput.readUTF();
        this.complemento = dataInput.readUTF();
        this.bairro = dataInput.readUTF();
        this.cep = dataInput.readUTF();
        this.cidade = dataInput.readUTF();
        this.statusOrdem = dataInput.readUTF();
        this.tecnologia = dataInput.readUTF();
        this.formaPagamento = dataInput.readUTF();
        this.tipoConta = dataInput.readUTF();
        this.codBanco = dataInput.readUTF();
        this.codAgenciaBanco = dataInput.readUTF();
        this.codContaCorrente = dataInput.readUTF();
        this.codDebitoAutomatico = dataInput.readUTF();
        this.diaVencimento = dataInput.readUTF();
        this.semanaVenda = dataInput.readUTF();
        this.score = dataInput.readUTF();
        this.scoreConsumido = dataInput.readUTF();
        this.datFinalizacaoOrdem = dataInput.readUTF();
        this.qtdContratos = dataInput.readUTF();
        this.numProtocolo = dataInput.readUTF();
        this.flgOrdemAutomatica = dataInput.readUTF();
        this.dscTxRecorrente = dataInput.readUTF();
        this.dscTxNaoRecorrente = dataInput.readUTF();
        this.dscStatusItem = dataInput.readUTF();
        this.nomLoginResponsavel = dataInput.readUTF();
        this.flgPortabilidade = dataInput.readUTF();
        this.dscOperadoraDoadora = dataInput.readUTF();
        this.codDdd = dataInput.readUTF();
        this.numTelefonePortado = dataInput.readUTF();
        this.datJanelaPortabilidade = dataInput.readUTF();
        this.horJanela = dataInput.readUTF();
        this.dscEnderecoFatura = dataInput.readUTF();
        this.dscAreaVoip = dataInput.readUTF();
        this.cpe = dataInput.readUTF();
        this.ont = dataInput.readUTF();
        this.detalheRecusaCrivo = dataInput.readUTF();
        this.itemRoot = dataInput.readUTF();
        this.loginCancelamentoOrdem = dataInput.readUTF();
        this.dominioRoot = dataInput.readUTF();
        this.codContaFinanceira = dataInput.readUTF();
        this.nomPlanoAtual = dataInput.readUTF();
        this.valPlanoAtualItem = dataInput.readUTF();
        this.nomDescontoAtualItem = dataInput.readUTF();
        this.valDescontoAtualItem = dataInput.readUTF();
        this.nroOrdem = dataInput.readUTF();
        this.acessoRowId = dataInput.readUTF();
        this.acessoRowIdRoot = dataInput.readUTF();
        this.codigoProduto = dataInput.readUTF();
        this.datVendaOrig = dataInput.readUTF();
        this.horVendaOrig = dataInput.readUTF();
        this.numOrdemSiebelOrig = dataInput.readUTF();
        this.loginVendedorOrig = dataInput.readUTF();
        this.canalOrig = dataInput.readUTF();
        this.cnpjParceiroOrig = dataInput.readUTF();
        this.custCodeOrig = dataInput.readUTF();
        this.positionOrig = dataInput.readUTF();
        this.flgVendaSubmetida = dataInput.readUTF();
        this.flgVendaDuplicada = dataInput.readUTF();
        this.flgVendaBruta = dataInput.readUTF();
        this.flgVendaLiquida = dataInput.readUTF();
        this.flgCancDupl = dataInput.readUTF();
        this.flgCancLiquido = dataInput.readUTF();
        this.semanaVendaOrig = dataInput.readUTF();
        this.nomeParceiroVenda = dataInput.readUTF();
        this.nomeParceiroVendaOrig = dataInput.readUTF();
        this.rowIdDoItemDaOrdem = dataInput.readUTF();
        this.rowIdDoItemDaOrdemPai = dataInput.readUTF();
        this.categoriaItemOrdem = dataInput.readUTF();
        this.msan_olt_venda = dataInput.readUTF();
        this.dt_conclusao_wfm = dataInput.readUTF();
        this.dscStatusOrdemWfm = dataInput.readUTF();
        this.datStatusWfm = dataInput.readUTF();
        this.horaStatusWfm = dataInput.readUTF();
        this.idRecursoWfm = dataInput.readUTF();
        this.nomRecursoWfm = dataInput.readUTF();
        this.idRecursoPaiWfm = dataInput.readUTF();
        this.datPrimeiroAgend = dataInput.readUTF();
        this.horaPrimeiroAgendamento = dataInput.readUTF();
        this.datAgendAtual = dataInput.readUTF();
        this.horaAgendamentoAtual = dataInput.readUTF();
        this.dscStatusAtivacao = dataInput.readUTF();
        this.msanOltTrafego = dataInput.readUTF();
    }

    public void Step1Pt3Result (Step1Pt3Result result) {
        this.clear();
        this.tipo = TypeStep1Pt4.RELT;
        this.datRef = result.getDatRef();
        this.datCriacaoOrdem = result.getDatCriacaoOrdem();
        this.horCriacaoOrdem = result.getHorCriacaoOrdem();
        this.datVenda = result.getDatVenda();
        this.horaVenda = result.getHoraVenda();
        this.datStatusOrdem = result.getDatStatusOrdem();
        this.horStatusOrdem = result.getHorStatusOrdem();
        this.numOrdemSiebel = result.getNumOrdemSiebel();
        this.codContratoOltp = result.getCodContratoOltp();
        this.codContratoAtivacao = result.getCodContratoAtivacao();
        this.numeroAcesso = result.getNumeroAcesso();
        this.customerId = result.getCustomerId();
        this.tipoDocumento = result.getTipoDocumento();
        this.documento = result.getDocumento();
        this.tipoVenda = result.getTipoVenda();
        this.tipoProduto = result.getTipoProduto();
        this.planoAtivacaoOferta = result.getPlanoAtivacaoOferta();
        this.loginVendedor = result.getLoginVendedor();
        this.canal = result.getCanal();
        this.cnpjParceiro = result.getCnpjParceiro();
        this.custCode = result.getCustCode();
        this.position = result.getPosition();
        this.flgCancAntesVenda = result.getFlgCancAntesVenda();
        this.flgCancPosVenda = result.getFlgCancPosVenda();
        this.datCancVenda = result.getDatCancVenda();
        this.motivoCancelamento = result.getMotivoCancelamento();
        this.nomeCliente = result.getNomeCliente();
        this.telefone = result.getTelefone();
        this.email = result.getEmail();
        this.uf = result.getUf();
        this.tipoLogradouro = result.getTipoLogradouro();
        this.logradouro = result.getLogradouro();
        this.numero = result.getNumero();
        this.complemento = result.getComplemento();
        this.bairro = result.getBairro();
        this.cep = result.getCep();
        this.cidade = result.getCidade();
        this.statusOrdem = result.getStatusOrdem();
        this.tecnologia = result.getTecnologia();
        this.formaPagamento = result.getFormaPagamento();
        this.tipoConta = result.getTipoConta();
        this.codBanco = result.getCodBanco();
        this.codAgenciaBanco = result.getCodAgenciaBanco();
        this.codContaCorrente = result.getCodContaCorrente();
        this.codDebitoAutomatico = result.getCodDebitoAutomatico();
        this.diaVencimento = result.getDiaVencimento();
        this.semanaVenda = result.getSemanaVenda();
        this.score = result.getScore();
        this.scoreConsumido = result.getScoreConsumido();
        this.datFinalizacaoOrdem = result.getDatFinalizacaoOrdem();
        this.qtdContratos = result.getQtdContratos();
        this.numProtocolo = result.getNumProtocolo();
        this.flgOrdemAutomatica = result.getFlgOrdemAutomatica();
        this.dscTxRecorrente = result.getDscTxRecorrente();
        this.dscTxNaoRecorrente = result.getDscTxNaoRecorrente();
        this.dscStatusItem = result.getDscStatusItem();
        this.nomLoginResponsavel = result.getNomLoginResponsavel();
        this.flgPortabilidade = result.getFlgPortabilidade();
        this.dscOperadoraDoadora = result.getDscOperadoraDoadora();
        this.codDdd = result.getCodDdd();
        this.numTelefonePortado = result.getNumTelefonePortado();
        this.datJanelaPortabilidade = result.getDatJanelaPortabilidade();
        this.horJanela = result.getHorJanela();
        this.dscEnderecoFatura = result.getDscEnderecoFatura();
        this.dscAreaVoip = result.getDscAreaVoip();
        this.cpe = result.getCpe();
        this.ont = result.getOnt();
        this.detalheRecusaCrivo = result.getDetalheRecusaCrivo();
        this.itemRoot = result.getItemRoot();
        this.loginCancelamentoOrdem = result.getLoginCancelamentoOrdem();
        this.dominioRoot = result.getDominioRoot();
        this.codContaFinanceira = result.getCodContaFinanceira();
        this.nomPlanoAtual = result.getNomPlanoAtual();
        this.valPlanoAtualItem = result.getValPlanoAtualItem();
        this.nomDescontoAtualItem = result.getNomDescontoAtualItem();
        this.valDescontoAtualItem = result.getValDescontoAtualItem();
        this.nroOrdem = result.getNroOrdem();
        this.acessoRowId = result.getAcessoRowId();
        this.acessoRowIdRoot = result.getAcessoRowIdRoot();
        this.codigoProduto = result.getCodigoProduto();
        this.datVendaOrig = result.getDatVendaOrig();
        this.horVendaOrig = result.getHorVendaOrig();
        this.numOrdemSiebelOrig = result.getNumOrdemSiebelOrig();
        this.loginVendedorOrig = result.getLoginVendedorOrig();
        this.canalOrig = result.getCanalOrig();
        this.cnpjParceiroOrig = result.getCnpjParceiroOrig();
        this.custCodeOrig = result.getCustCodeOrig();
        this.positionOrig = result.getPositionOrig();
        this.flgVendaSubmetida = result.getFlgVendaSubmetida();
        this.flgVendaDuplicada = result.getFlgVendaDuplicada();
        this.flgVendaBruta = result.getFlgVendaBruta();
        this.flgVendaLiquida = result.getFlgVendaLiquida();
        this.flgCancDupl = result.getFlgCancDupl();
        this.flgCancLiquido = result.getFlgCancLiquido();
        this.semanaVendaOrig = result.getSemanaVendaOrig();
        this.nomeParceiroVenda = result.getNomeParceiroVenda();
        this.nomeParceiroVendaOrig = result.getNomeParceiroVendaOrig();
        this.rowIdDoItemDaOrdem = result.getRowIdDoItemDaOrdem();
        this.rowIdDoItemDaOrdemPai = result.getRowIdDoItemDaOrdemPai();
        this.categoriaItemOrdem = result.getCategoriaItemOrdem();
        this.msan_olt_venda = result.getMsan_olt_venda();
        this.dt_conclusao_wfm = result.getDt_conclusao_wfm();
        this.dscStatusOrdemWfm = result.getDscStatusOrdemWfm();
        this.datStatusWfm = result.getDatStatusWfm();
        this.horaStatusWfm = result.getHoraStatusWfm();
        this.idRecursoWfm = result.getIdRecursoWfm();
        this.nomRecursoWfm = result.getNomRecursoWfm();
        this.idRecursoPaiWfm = result.getIdRecursoPaiWfm();
        this.datPrimeiroAgend = result.getDatPrimeiroAgend();
        this.horaPrimeiroAgendamento = result.getHoraPrimeiroAgendamento();
        this.datAgendAtual = result.getDatAgendAtual();
        this.horaAgendamentoAtual = result.getHoraAgendamentoAtual();
        this.dscStatusAtivacao = result.getDscStatusAtivacao();
    }

    public void setFiber(CDRFiber fiber) {
        this.clear();
        this.tipo = TypeStep1Pt4.Fiber;
        this.msanOltTrafego = fiber.getNasportid();
    }

    public void clear(){
        this.tipo = null;
        this.datRef = StringUtils.EMPTY;
		this.datCriacaoOrdem = StringUtils.EMPTY;
		this.horCriacaoOrdem = StringUtils.EMPTY;
		this.datVenda = StringUtils.EMPTY;
		this.horaVenda = StringUtils.EMPTY;
		this.datStatusOrdem = StringUtils.EMPTY;
		this.horStatusOrdem = StringUtils.EMPTY;
		this.numOrdemSiebel = StringUtils.EMPTY;
		this.codContratoOltp = StringUtils.EMPTY;
		this.codContratoAtivacao = StringUtils.EMPTY;
		this.numeroAcesso = StringUtils.EMPTY;
		this.customerId = StringUtils.EMPTY;
		this.tipoDocumento = StringUtils.EMPTY;
		this.documento = StringUtils.EMPTY;
		this.tipoVenda = StringUtils.EMPTY;
		this.tipoProduto = StringUtils.EMPTY;
		this.planoAtivacaoOferta = StringUtils.EMPTY;
		this.loginVendedor = StringUtils.EMPTY;
		this.canal = StringUtils.EMPTY;
		this.cnpjParceiro = StringUtils.EMPTY;
		this.custCode = StringUtils.EMPTY;
		this.position = StringUtils.EMPTY;
		this.flgCancAntesVenda = StringUtils.EMPTY;
		this.flgCancPosVenda = StringUtils.EMPTY;
		this.datCancVenda = StringUtils.EMPTY;
		this.motivoCancelamento = StringUtils.EMPTY;
		this.nomeCliente = StringUtils.EMPTY;
		this.telefone = StringUtils.EMPTY;
		this.email = StringUtils.EMPTY;
		this.uf = StringUtils.EMPTY;
		this.tipoLogradouro = StringUtils.EMPTY;
		this.logradouro = StringUtils.EMPTY;
		this.numero = StringUtils.EMPTY;
		this.complemento = StringUtils.EMPTY;
		this.bairro = StringUtils.EMPTY;
		this.cep = StringUtils.EMPTY;
		this.cidade = StringUtils.EMPTY;
		this.statusOrdem = StringUtils.EMPTY;
		this.tecnologia = StringUtils.EMPTY;
		this.formaPagamento = StringUtils.EMPTY;
		this.tipoConta = StringUtils.EMPTY;
		this.codBanco = StringUtils.EMPTY;
		this.codAgenciaBanco = StringUtils.EMPTY;
		this.codContaCorrente = StringUtils.EMPTY;
		this.codDebitoAutomatico = StringUtils.EMPTY;
		this.diaVencimento = StringUtils.EMPTY;
		this.semanaVenda = StringUtils.EMPTY;
		this.score = StringUtils.EMPTY;
		this.scoreConsumido = StringUtils.EMPTY;
		this.datFinalizacaoOrdem = StringUtils.EMPTY;
		this.qtdContratos = StringUtils.EMPTY;
		this.numProtocolo = StringUtils.EMPTY;
		this.flgOrdemAutomatica = StringUtils.EMPTY;
		this.dscTxRecorrente = StringUtils.EMPTY;
		this.dscTxNaoRecorrente = StringUtils.EMPTY;
		this.dscStatusItem = StringUtils.EMPTY;
		this.nomLoginResponsavel = StringUtils.EMPTY;
		this.flgPortabilidade = StringUtils.EMPTY;
		this.dscOperadoraDoadora = StringUtils.EMPTY;
		this.codDdd = StringUtils.EMPTY;
		this.numTelefonePortado = StringUtils.EMPTY;
		this.datJanelaPortabilidade = StringUtils.EMPTY;
		this.horJanela = StringUtils.EMPTY;
		this.dscEnderecoFatura = StringUtils.EMPTY;
		this.dscAreaVoip = StringUtils.EMPTY;
		this.cpe = StringUtils.EMPTY;
		this.ont = StringUtils.EMPTY;
		this.detalheRecusaCrivo = StringUtils.EMPTY;
		this.itemRoot = StringUtils.EMPTY;
		this.loginCancelamentoOrdem = StringUtils.EMPTY;
		this.dominioRoot = StringUtils.EMPTY;
		this.codContaFinanceira = StringUtils.EMPTY;
		this.nomPlanoAtual = StringUtils.EMPTY;
		this.valPlanoAtualItem = StringUtils.EMPTY;
		this.nomDescontoAtualItem = StringUtils.EMPTY;
		this.valDescontoAtualItem = StringUtils.EMPTY;
		this.nroOrdem = StringUtils.EMPTY;
		this.acessoRowId = StringUtils.EMPTY;
		this.acessoRowIdRoot = StringUtils.EMPTY;
		this.codigoProduto = StringUtils.EMPTY;
		this.datVendaOrig = StringUtils.EMPTY;
		this.horVendaOrig = StringUtils.EMPTY;
		this.numOrdemSiebelOrig = StringUtils.EMPTY;
		this.loginVendedorOrig = StringUtils.EMPTY;
		this.canalOrig = StringUtils.EMPTY;
		this.cnpjParceiroOrig = StringUtils.EMPTY;
		this.custCodeOrig = StringUtils.EMPTY;
		this.positionOrig = StringUtils.EMPTY;
		this.flgVendaSubmetida = StringUtils.EMPTY;
		this.flgVendaDuplicada = StringUtils.EMPTY;
		this.flgVendaBruta = StringUtils.EMPTY;
		this.flgVendaLiquida = StringUtils.EMPTY;
		this.flgCancDupl = StringUtils.EMPTY;
		this.flgCancLiquido = StringUtils.EMPTY;
		this.semanaVendaOrig = StringUtils.EMPTY;
		this.nomeParceiroVenda = StringUtils.EMPTY;
		this.nomeParceiroVendaOrig = StringUtils.EMPTY;
		this.rowIdDoItemDaOrdem = StringUtils.EMPTY;
		this.rowIdDoItemDaOrdemPai = StringUtils.EMPTY;
		this.categoriaItemOrdem = StringUtils.EMPTY;
		this.msan_olt_venda = StringUtils.EMPTY;
		this.dt_conclusao_wfm = StringUtils.EMPTY;
		this.dscStatusOrdemWfm = StringUtils.EMPTY;
		this.datStatusWfm = StringUtils.EMPTY;
		this.horaStatusWfm = StringUtils.EMPTY;
		this.idRecursoWfm = StringUtils.EMPTY;
		this.nomRecursoWfm = StringUtils.EMPTY;
		this.idRecursoPaiWfm = StringUtils.EMPTY;
		this.datPrimeiroAgend = StringUtils.EMPTY;
		this.horaPrimeiroAgendamento = StringUtils.EMPTY;
		this.datAgendAtual = StringUtils.EMPTY;
		this.horaAgendamentoAtual = StringUtils.EMPTY;
		this.dscStatusAtivacao = StringUtils.EMPTY;
        this.msanOltTrafego = StringUtils.EMPTY;
    }

	public TypeStep1Pt4 getTipo() {
		return tipo;
	}

	public void setTipo(TypeStep1Pt4 tipo) {
		this.tipo = tipo;
	}

	public String getDatRef() {
		return datRef;
	}

	public void setDatRef(String datRef) {
		this.datRef = datRef;
	}

	public String getDatCriacaoOrdem() {
		return datCriacaoOrdem;
	}

	public void setDatCriacaoOrdem(String datCriacaoOrdem) {
		this.datCriacaoOrdem = datCriacaoOrdem;
	}

	public String getHorCriacaoOrdem() {
		return horCriacaoOrdem;
	}

	public void setHorCriacaoOrdem(String horCriacaoOrdem) {
		this.horCriacaoOrdem = horCriacaoOrdem;
	}

	public String getDatVenda() {
		return datVenda;
	}

	public void setDatVenda(String datVenda) {
		this.datVenda = datVenda;
	}

	public String getHoraVenda() {
		return horaVenda;
	}

	public void setHoraVenda(String horaVenda) {
		this.horaVenda = horaVenda;
	}

	public String getDatStatusOrdem() {
		return datStatusOrdem;
	}

	public void setDatStatusOrdem(String datStatusOrdem) {
		this.datStatusOrdem = datStatusOrdem;
	}

	public String getHorStatusOrdem() {
		return horStatusOrdem;
	}

	public void setHorStatusOrdem(String horStatusOrdem) {
		this.horStatusOrdem = horStatusOrdem;
	}

	public String getNumOrdemSiebel() {
		return numOrdemSiebel;
	}

	public void setNumOrdemSiebel(String numOrdemSiebel) {
		this.numOrdemSiebel = numOrdemSiebel;
	}

	public String getCodContratoOltp() {
		return codContratoOltp;
	}

	public void setCodContratoOltp(String codContratoOltp) {
		this.codContratoOltp = codContratoOltp;
	}

	public String getCodContratoAtivacao() {
		return codContratoAtivacao;
	}

	public void setCodContratoAtivacao(String codContratoAtivacao) {
		this.codContratoAtivacao = codContratoAtivacao;
	}

	public String getNumeroAcesso() {
		return numeroAcesso;
	}

	public void setNumeroAcesso(String numeroAcesso) {
		this.numeroAcesso = numeroAcesso;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public String getDocumento() {
		return documento;
	}

	public void setDocumento(String documento) {
		this.documento = documento;
	}

	public String getTipoVenda() {
		return tipoVenda;
	}

	public void setTipoVenda(String tipoVenda) {
		this.tipoVenda = tipoVenda;
	}

	public String getTipoProduto() {
		return tipoProduto;
	}

	public void setTipoProduto(String tipoProduto) {
		this.tipoProduto = tipoProduto;
	}

	public String getPlanoAtivacaoOferta() {
		return planoAtivacaoOferta;
	}

	public void setPlanoAtivacaoOferta(String planoAtivacaoOferta) {
		this.planoAtivacaoOferta = planoAtivacaoOferta;
	}

	public String getLoginVendedor() {
		return loginVendedor;
	}

	public void setLoginVendedor(String loginVendedor) {
		this.loginVendedor = loginVendedor;
	}

	public String getCanal() {
		return canal;
	}

	public void setCanal(String canal) {
		this.canal = canal;
	}

	public String getCnpjParceiro() {
		return cnpjParceiro;
	}

	public void setCnpjParceiro(String cnpjParceiro) {
		this.cnpjParceiro = cnpjParceiro;
	}

	public String getCustCode() {
		return custCode;
	}

	public void setCustCode(String custCode) {
		this.custCode = custCode;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getFlgCancAntesVenda() {
		return flgCancAntesVenda;
	}

	public void setFlgCancAntesVenda(String flgCancAntesVenda) {
		this.flgCancAntesVenda = flgCancAntesVenda;
	}

	public String getFlgCancPosVenda() {
		return flgCancPosVenda;
	}

	public void setFlgCancPosVenda(String flgCancPosVenda) {
		this.flgCancPosVenda = flgCancPosVenda;
	}

	public String getDatCancVenda() {
		return datCancVenda;
	}

	public void setDatCancVenda(String datCancVenda) {
		this.datCancVenda = datCancVenda;
	}

	public String getMotivoCancelamento() {
		return motivoCancelamento;
	}

	public void setMotivoCancelamento(String motivoCancelamento) {
		this.motivoCancelamento = motivoCancelamento;
	}

	public String getNomeCliente() {
		return nomeCliente;
	}

	public void setNomeCliente(String nomeCliente) {
		this.nomeCliente = nomeCliente;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	public String getTipoLogradouro() {
		return tipoLogradouro;
	}

	public void setTipoLogradouro(String tipoLogradouro) {
		this.tipoLogradouro = tipoLogradouro;
	}

	public String getLogradouro() {
		return logradouro;
	}

	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getComplemento() {
		return complemento;
	}

	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getStatusOrdem() {
		return statusOrdem;
	}

	public void setStatusOrdem(String statusOrdem) {
		this.statusOrdem = statusOrdem;
	}

	public String getTecnologia() {
		return tecnologia;
	}

	public void setTecnologia(String tecnologia) {
		this.tecnologia = tecnologia;
	}

	public String getFormaPagamento() {
		return formaPagamento;
	}

	public void setFormaPagamento(String formaPagamento) {
		this.formaPagamento = formaPagamento;
	}

	public String getTipoConta() {
		return tipoConta;
	}

	public void setTipoConta(String tipoConta) {
		this.tipoConta = tipoConta;
	}

	public String getCodBanco() {
		return codBanco;
	}

	public void setCodBanco(String codBanco) {
		this.codBanco = codBanco;
	}

	public String getCodAgenciaBanco() {
		return codAgenciaBanco;
	}

	public void setCodAgenciaBanco(String codAgenciaBanco) {
		this.codAgenciaBanco = codAgenciaBanco;
	}

	public String getCodContaCorrente() {
		return codContaCorrente;
	}

	public void setCodContaCorrente(String codContaCorrente) {
		this.codContaCorrente = codContaCorrente;
	}

	public String getCodDebitoAutomatico() {
		return codDebitoAutomatico;
	}

	public void setCodDebitoAutomatico(String codDebitoAutomatico) {
		this.codDebitoAutomatico = codDebitoAutomatico;
	}

	public String getDiaVencimento() {
		return diaVencimento;
	}

	public void setDiaVencimento(String diaVencimento) {
		this.diaVencimento = diaVencimento;
	}

	public String getSemanaVenda() {
		return semanaVenda;
	}

	public void setSemanaVenda(String semanaVenda) {
		this.semanaVenda = semanaVenda;
	}

	public String getScore() {
		return score;
	}

	public void setScore(String score) {
		this.score = score;
	}

	public String getScoreConsumido() {
		return scoreConsumido;
	}

	public void setScoreConsumido(String scoreConsumido) {
		this.scoreConsumido = scoreConsumido;
	}

	public String getDatFinalizacaoOrdem() {
		return datFinalizacaoOrdem;
	}

	public void setDatFinalizacaoOrdem(String datFinalizacaoOrdem) {
		this.datFinalizacaoOrdem = datFinalizacaoOrdem;
	}

	public String getQtdContratos() {
		return qtdContratos;
	}

	public void setQtdContratos(String qtdContratos) {
		this.qtdContratos = qtdContratos;
	}

	public String getNumProtocolo() {
		return numProtocolo;
	}

	public void setNumProtocolo(String numProtocolo) {
		this.numProtocolo = numProtocolo;
	}

	public String getFlgOrdemAutomatica() {
		return flgOrdemAutomatica;
	}

	public void setFlgOrdemAutomatica(String flgOrdemAutomatica) {
		this.flgOrdemAutomatica = flgOrdemAutomatica;
	}

	public String getDscTxRecorrente() {
		return dscTxRecorrente;
	}

	public void setDscTxRecorrente(String dscTxRecorrente) {
		this.dscTxRecorrente = dscTxRecorrente;
	}

	public String getDscTxNaoRecorrente() {
		return dscTxNaoRecorrente;
	}

	public void setDscTxNaoRecorrente(String dscTxNaoRecorrente) {
		this.dscTxNaoRecorrente = dscTxNaoRecorrente;
	}

	public String getDscStatusItem() {
		return dscStatusItem;
	}

	public void setDscStatusItem(String dscStatusItem) {
		this.dscStatusItem = dscStatusItem;
	}

	public String getNomLoginResponsavel() {
		return nomLoginResponsavel;
	}

	public void setNomLoginResponsavel(String nomLoginResponsavel) {
		this.nomLoginResponsavel = nomLoginResponsavel;
	}

	public String getFlgPortabilidade() {
		return flgPortabilidade;
	}

	public void setFlgPortabilidade(String flgPortabilidade) {
		this.flgPortabilidade = flgPortabilidade;
	}

	public String getDscOperadoraDoadora() {
		return dscOperadoraDoadora;
	}

	public void setDscOperadoraDoadora(String dscOperadoraDoadora) {
		this.dscOperadoraDoadora = dscOperadoraDoadora;
	}

	public String getCodDdd() {
		return codDdd;
	}

	public void setCodDdd(String codDdd) {
		this.codDdd = codDdd;
	}

	public String getNumTelefonePortado() {
		return numTelefonePortado;
	}

	public void setNumTelefonePortado(String numTelefonePortado) {
		this.numTelefonePortado = numTelefonePortado;
	}

	public String getDatJanelaPortabilidade() {
		return datJanelaPortabilidade;
	}

	public void setDatJanelaPortabilidade(String datJanelaPortabilidade) {
		this.datJanelaPortabilidade = datJanelaPortabilidade;
	}

	public String getHorJanela() {
		return horJanela;
	}

	public void setHorJanela(String horJanela) {
		this.horJanela = horJanela;
	}

	public String getDscEnderecoFatura() {
		return dscEnderecoFatura;
	}

	public void setDscEnderecoFatura(String dscEnderecoFatura) {
		this.dscEnderecoFatura = dscEnderecoFatura;
	}

	public String getDscAreaVoip() {
		return dscAreaVoip;
	}

	public void setDscAreaVoip(String dscAreaVoip) {
		this.dscAreaVoip = dscAreaVoip;
	}

	public String getCpe() {
		return cpe;
	}

	public void setCpe(String cpe) {
		this.cpe = cpe;
	}

	public String getOnt() {
		return ont;
	}

	public void setOnt(String ont) {
		this.ont = ont;
	}

	public String getDetalheRecusaCrivo() {
		return detalheRecusaCrivo;
	}

	public void setDetalheRecusaCrivo(String detalheRecusaCrivo) {
		this.detalheRecusaCrivo = detalheRecusaCrivo;
	}

	public String getItemRoot() {
		return itemRoot;
	}

	public void setItemRoot(String itemRoot) {
		this.itemRoot = itemRoot;
	}

	public String getLoginCancelamentoOrdem() {
		return loginCancelamentoOrdem;
	}

	public void setLoginCancelamentoOrdem(String loginCancelamentoOrdem) {
		this.loginCancelamentoOrdem = loginCancelamentoOrdem;
	}

	public String getDominioRoot() {
		return dominioRoot;
	}

	public void setDominioRoot(String dominioRoot) {
		this.dominioRoot = dominioRoot;
	}

	public String getCodContaFinanceira() {
		return codContaFinanceira;
	}

	public void setCodContaFinanceira(String codContaFinanceira) {
		this.codContaFinanceira = codContaFinanceira;
	}

	public String getNomPlanoAtual() {
		return nomPlanoAtual;
	}

	public void setNomPlanoAtual(String nomPlanoAtual) {
		this.nomPlanoAtual = nomPlanoAtual;
	}

	public String getValPlanoAtualItem() {
		return valPlanoAtualItem;
	}

	public void setValPlanoAtualItem(String valPlanoAtualItem) {
		this.valPlanoAtualItem = valPlanoAtualItem;
	}

	public String getNomDescontoAtualItem() {
		return nomDescontoAtualItem;
	}

	public void setNomDescontoAtualItem(String nomDescontoAtualItem) {
		this.nomDescontoAtualItem = nomDescontoAtualItem;
	}

	public String getValDescontoAtualItem() {
		return valDescontoAtualItem;
	}

	public void setValDescontoAtualItem(String valDescontoAtualItem) {
		this.valDescontoAtualItem = valDescontoAtualItem;
	}

	public String getNroOrdem() {
		return nroOrdem;
	}

	public void setNroOrdem(String nroOrdem) {
		this.nroOrdem = nroOrdem;
	}

	public String getAcessoRowId() {
		return acessoRowId;
	}

	public void setAcessoRowId(String acessoRowId) {
		this.acessoRowId = acessoRowId;
	}

	public String getAcessoRowIdRoot() {
		return acessoRowIdRoot;
	}

	public void setAcessoRowIdRoot(String acessoRowIdRoot) {
		this.acessoRowIdRoot = acessoRowIdRoot;
	}

	public String getCodigoProduto() {
		return codigoProduto;
	}

	public void setCodigoProduto(String codigoProduto) {
		this.codigoProduto = codigoProduto;
	}

	public String getDatVendaOrig() {
		return datVendaOrig;
	}

	public void setDatVendaOrig(String datVendaOrig) {
		this.datVendaOrig = datVendaOrig;
	}

	public String getHorVendaOrig() {
		return horVendaOrig;
	}

	public void setHorVendaOrig(String horVendaOrig) {
		this.horVendaOrig = horVendaOrig;
	}

	public String getNumOrdemSiebelOrig() {
		return numOrdemSiebelOrig;
	}

	public void setNumOrdemSiebelOrig(String numOrdemSiebelOrig) {
		this.numOrdemSiebelOrig = numOrdemSiebelOrig;
	}

	public String getLoginVendedorOrig() {
		return loginVendedorOrig;
	}

	public void setLoginVendedorOrig(String loginVendedorOrig) {
		this.loginVendedorOrig = loginVendedorOrig;
	}

	public String getCanalOrig() {
		return canalOrig;
	}

	public void setCanalOrig(String canalOrig) {
		this.canalOrig = canalOrig;
	}

	public String getCnpjParceiroOrig() {
		return cnpjParceiroOrig;
	}

	public void setCnpjParceiroOrig(String cnpjParceiroOrig) {
		this.cnpjParceiroOrig = cnpjParceiroOrig;
	}

	public String getCustCodeOrig() {
		return custCodeOrig;
	}

	public void setCustCodeOrig(String custCodeOrig) {
		this.custCodeOrig = custCodeOrig;
	}

	public String getPositionOrig() {
		return positionOrig;
	}

	public void setPositionOrig(String positionOrig) {
		this.positionOrig = positionOrig;
	}

	public String getFlgVendaSubmetida() {
		return flgVendaSubmetida;
	}

	public void setFlgVendaSubmetida(String flgVendaSubmetida) {
		this.flgVendaSubmetida = flgVendaSubmetida;
	}

	public String getFlgVendaDuplicada() {
		return flgVendaDuplicada;
	}

	public void setFlgVendaDuplicada(String flgVendaDuplicada) {
		this.flgVendaDuplicada = flgVendaDuplicada;
	}

	public String getFlgVendaBruta() {
		return flgVendaBruta;
	}

	public void setFlgVendaBruta(String flgVendaBruta) {
		this.flgVendaBruta = flgVendaBruta;
	}

	public String getFlgVendaLiquida() {
		return flgVendaLiquida;
	}

	public void setFlgVendaLiquida(String flgVendaLiquida) {
		this.flgVendaLiquida = flgVendaLiquida;
	}

	public String getFlgCancDupl() {
		return flgCancDupl;
	}

	public void setFlgCancDupl(String flgCancDupl) {
		this.flgCancDupl = flgCancDupl;
	}

	public String getFlgCancLiquido() {
		return flgCancLiquido;
	}

	public void setFlgCancLiquido(String flgCancLiquido) {
		this.flgCancLiquido = flgCancLiquido;
	}

	public String getSemanaVendaOrig() {
		return semanaVendaOrig;
	}

	public void setSemanaVendaOrig(String semanaVendaOrig) {
		this.semanaVendaOrig = semanaVendaOrig;
	}

	public String getNomeParceiroVenda() {
		return nomeParceiroVenda;
	}

	public void setNomeParceiroVenda(String nomeParceiroVenda) {
		this.nomeParceiroVenda = nomeParceiroVenda;
	}

	public String getNomeParceiroVendaOrig() {
		return nomeParceiroVendaOrig;
	}

	public void setNomeParceiroVendaOrig(String nomeParceiroVendaOrig) {
		this.nomeParceiroVendaOrig = nomeParceiroVendaOrig;
	}

	public String getRowIdDoItemDaOrdem() {
		return rowIdDoItemDaOrdem;
	}

	public void setRowIdDoItemDaOrdem(String rowIdDoItemDaOrdem) {
		this.rowIdDoItemDaOrdem = rowIdDoItemDaOrdem;
	}

	public String getRowIdDoItemDaOrdemPai() {
		return rowIdDoItemDaOrdemPai;
	}

	public void setRowIdDoItemDaOrdemPai(String rowIdDoItemDaOrdemPai) {
		this.rowIdDoItemDaOrdemPai = rowIdDoItemDaOrdemPai;
	}

	public String getCategoriaItemOrdem() {
		return categoriaItemOrdem;
	}

	public void setCategoriaItemOrdem(String categoriaItemOrdem) {
		this.categoriaItemOrdem = categoriaItemOrdem;
	}

	public String getMsan_olt_venda() {
		return msan_olt_venda;
	}

	public void setMsan_olt_venda(String msan_olt_venda) {
		this.msan_olt_venda = msan_olt_venda;
	}

	public String getDt_conclusao_wfm() {
		return dt_conclusao_wfm;
	}

	public void setDt_conclusao_wfm(String dt_conclusao_wfm) {
		this.dt_conclusao_wfm = dt_conclusao_wfm;
	}

	public String getDscStatusOrdemWfm() {
		return dscStatusOrdemWfm;
	}

	public void setDscStatusOrdemWfm(String dscStatusOrdemWfm) {
		this.dscStatusOrdemWfm = dscStatusOrdemWfm;
	}

	public String getDatStatusWfm() {
		return datStatusWfm;
	}

	public void setDatStatusWfm(String datStatusWfm) {
		this.datStatusWfm = datStatusWfm;
	}

	public String getHoraStatusWfm() {
		return horaStatusWfm;
	}

	public void setHoraStatusWfm(String horaStatusWfm) {
		this.horaStatusWfm = horaStatusWfm;
	}

	public String getIdRecursoWfm() {
		return idRecursoWfm;
	}

	public void setIdRecursoWfm(String idRecursoWfm) {
		this.idRecursoWfm = idRecursoWfm;
	}

	public String getNomRecursoWfm() {
		return nomRecursoWfm;
	}

	public void setNomRecursoWfm(String nomRecursoWfm) {
		this.nomRecursoWfm = nomRecursoWfm;
	}

	public String getIdRecursoPaiWfm() {
		return idRecursoPaiWfm;
	}

	public void setIdRecursoPaiWfm(String idRecursoPaiWfm) {
		this.idRecursoPaiWfm = idRecursoPaiWfm;
	}

	public String getDatPrimeiroAgend() {
		return datPrimeiroAgend;
	}

	public void setDatPrimeiroAgend(String datPrimeiroAgend) {
		this.datPrimeiroAgend = datPrimeiroAgend;
	}

	public String getHoraPrimeiroAgendamento() {
		return horaPrimeiroAgendamento;
	}

	public void setHoraPrimeiroAgendamento(String horaPrimeiroAgendamento) {
		this.horaPrimeiroAgendamento = horaPrimeiroAgendamento;
	}

	public String getDatAgendAtual() {
		return datAgendAtual;
	}

	public void setDatAgendAtual(String datAgendAtual) {
		this.datAgendAtual = datAgendAtual;
	}

	public String getHoraAgendamentoAtual() {
		return horaAgendamentoAtual;
	}

	public void setHoraAgendamentoAtual(String horaAgendamentoAtual) {
		this.horaAgendamentoAtual = horaAgendamentoAtual;
	}

	public String getDscStatusAtivacao() {
		return dscStatusAtivacao;
	}

	public void setDscStatusAtivacao(String dscStatusAtivacao) {
		this.dscStatusAtivacao = dscStatusAtivacao;
	}

	public String getMsanOltTrafego() {
		return msanOltTrafego;
	}

	public void setMsanOltTrafego(String msanOltTrafego) {
		this.msanOltTrafego = msanOltTrafego;
	}

    


}
