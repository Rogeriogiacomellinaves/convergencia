package br.com.tim.mapreduce.refactoring.model;

import org.apache.commons.lang3.StringUtils;

import br.com.tim.utils.CommonsConstants;

public class Gross {

    private String datReferencia;
    private String operadoraTim;
    private String regional;
    private String cidade;
    private String skyContrato;
    private String dddAcesso;
    private String acesso;
    private String codContratoBscs;
    private String codPdvBscs;
    private String codPdvSap;
    private String imei;
    private String iccid;
    private String cpfCnpj;
    private String tecnologia;
    private String nivelPlano;
    private String tipoFamiliaPlano;
    private String tipoPrePos;
    private String vozDados;
    private String pacoteMinuto;
    private String custcode;
    private String nomePdv;
    private String loginAtivacao;
    private String motivoGross;
    private String cnpjPdv;
    private String codChip;
    private String imsiInstalacao;
    private String dataInstalacao;
    private String siteCr;
    private String segmentoCr;
    private String timTorcedor;
    private String canalM4u;
    private String loginM4u;
    private String origemEis;
    private String operadoraSigla;
    private String dddPdv;
    private String ufPdv;
    private String cidadePdv;
    private String cepPdv;
    private String idCadtim;
    private String idParceiro;
    private String sapCliente;
    private String cnpjPdvCadtim;
    private String nickname;
    private String canalCadtim;
    private String canalEis;
    private String canalGe;
    private String grupoEconomico;
    private String idGrupoEconomico;
    private String segmentoRecarga;
    private String status;
    private String flagElegivelMeta;
    private String gerenteCanalMatricula;
    private String gerenteCanal;
    private String coordenadorMatricula;
    private String coordenador;
    private String keyAccountMatricula;
    private String keyAccount;
    private String responsavelPdvMatricula;
    private String responsavelPdv;
    private String responsavelPdvCargo;
    private String dataVgInicio;
    private String dataVgFim;
    private String movelPosPagoControleVoz;
    private String movelPosPagoVoz;
    private String movelPrePagoVoz;
    private String movelPosPagoDados;
    private String tipo;
    private String segmento;
    private String dataAtualizacaoCadtim;
    private String campoCadtim01;
    private String campoCadtim02;
    private String campoCadtim03;
    private String campoCadtim04;
    private String campoCadtim05;
    private String campoRegional01;
    private String campoRegional02;
    private String campoRegional03;
    private String campoCrc01;
    private String campoCrc02;
    private String campoCrc03;
    private String nomeArquivo;
    private String mesReferencia;
    private String tipoArquivoGross;

    public Gross() {

    	 this.datReferencia = CommonsConstants.EMPTY;
         this.operadoraTim = CommonsConstants.EMPTY;
         this.regional = CommonsConstants.EMPTY;
         this.cidade = CommonsConstants.EMPTY;
         this.skyContrato = CommonsConstants.EMPTY;
         this.dddAcesso = CommonsConstants.EMPTY;
         this.acesso = CommonsConstants.EMPTY;
         this.codContratoBscs = CommonsConstants.EMPTY;
         this.codPdvBscs = CommonsConstants.EMPTY;
         this.codPdvSap = CommonsConstants.EMPTY;
         this.imei = CommonsConstants.EMPTY;
         this.iccid = CommonsConstants.EMPTY;
         this.cpfCnpj = CommonsConstants.EMPTY;
         this.tecnologia = CommonsConstants.EMPTY;
         this.nivelPlano = CommonsConstants.EMPTY;
         this.tipoFamiliaPlano = CommonsConstants.EMPTY;
         this.tipoPrePos = CommonsConstants.EMPTY;
         this.vozDados = CommonsConstants.EMPTY;
         this.pacoteMinuto = CommonsConstants.EMPTY;
         this.custcode = CommonsConstants.EMPTY;
         this.nomePdv = CommonsConstants.EMPTY;
         this.loginAtivacao = CommonsConstants.EMPTY;
         this.motivoGross = CommonsConstants.EMPTY;
         this.cnpjPdv = CommonsConstants.EMPTY;
         this.codChip = CommonsConstants.EMPTY;
         this.imsiInstalacao = CommonsConstants.EMPTY;
         this.dataInstalacao = CommonsConstants.EMPTY;
         this.siteCr = CommonsConstants.EMPTY;
         this.segmentoCr = CommonsConstants.EMPTY;
         this.timTorcedor = CommonsConstants.EMPTY;
         this.canalM4u = CommonsConstants.EMPTY;
         this.loginM4u = CommonsConstants.EMPTY;
         this.origemEis = CommonsConstants.EMPTY;
         this.operadoraSigla = CommonsConstants.EMPTY;
         this.dddPdv = CommonsConstants.EMPTY;
         this.ufPdv = CommonsConstants.EMPTY;
         this.cidadePdv = CommonsConstants.EMPTY;
         this.cepPdv = CommonsConstants.EMPTY;
         this.idCadtim = CommonsConstants.EMPTY;
         this.idParceiro = CommonsConstants.EMPTY;
         this.sapCliente = CommonsConstants.EMPTY;
         this.cnpjPdvCadtim = CommonsConstants.EMPTY;
         this.nickname = CommonsConstants.EMPTY;
         this.canalCadtim = CommonsConstants.EMPTY;
         this.canalEis = CommonsConstants.EMPTY;
         this.canalGe = CommonsConstants.EMPTY;
         this.grupoEconomico = CommonsConstants.EMPTY;
         this.idGrupoEconomico = CommonsConstants.EMPTY;
         this.segmentoRecarga = CommonsConstants.EMPTY;
         this.status = CommonsConstants.EMPTY;
         this.flagElegivelMeta = CommonsConstants.EMPTY;
         this.gerenteCanalMatricula = CommonsConstants.EMPTY;
         this.gerenteCanal = CommonsConstants.EMPTY;
         this.coordenadorMatricula = CommonsConstants.EMPTY;
         this.coordenador = CommonsConstants.EMPTY;
         this.keyAccountMatricula = CommonsConstants.EMPTY;
         this.keyAccount = CommonsConstants.EMPTY;
         this.responsavelPdvMatricula = CommonsConstants.EMPTY;
         this.responsavelPdv = CommonsConstants.EMPTY;
         this.responsavelPdvCargo = CommonsConstants.EMPTY;
         this.dataVgInicio = CommonsConstants.EMPTY;
         this.dataVgFim = CommonsConstants.EMPTY;
         this.movelPosPagoControleVoz = CommonsConstants.EMPTY;
         this.movelPosPagoVoz = CommonsConstants.EMPTY;
         this.movelPrePagoVoz = CommonsConstants.EMPTY;
         this.movelPosPagoDados = CommonsConstants.EMPTY;
         this.tipo = CommonsConstants.EMPTY;
         this.segmento = CommonsConstants.EMPTY;
         this.dataAtualizacaoCadtim = CommonsConstants.EMPTY;
         this.campoCadtim01 = CommonsConstants.EMPTY;
         this.campoCadtim02 = CommonsConstants.EMPTY;
         this.campoCadtim03 = CommonsConstants.EMPTY;
         this.campoCadtim04 = CommonsConstants.EMPTY;
         this.campoCadtim05 = CommonsConstants.EMPTY;
         this.campoRegional01 = CommonsConstants.EMPTY;
         this.campoRegional02 = CommonsConstants.EMPTY;
         this.campoRegional03 = CommonsConstants.EMPTY;
         this.campoCrc01 = CommonsConstants.EMPTY;
         this.campoCrc02 = CommonsConstants.EMPTY;
         this.campoCrc03 = CommonsConstants.EMPTY;
         this.nomeArquivo = CommonsConstants.EMPTY;
         this.mesReferencia = CommonsConstants.EMPTY;
         this.tipoArquivoGross = CommonsConstants.EMPTY;

    }

    public void setGross(String datReferencia, String operadoraTim, String regional, String cidade, String skyContrato, String dddAcesso, String acesso,
                         String codContratoBscs, String codPdvBscs, String codPdvSap, String imei, String iccid, String cpfCnpj, String tecnologia,
                         String nivelPlano, String tipoFamiliaPlano, String tipoPrePos, String vozDados, String pacoteMinuto, String custcode, String nomePdv,
                         String loginAtivacao, String motivoGross, String cnpjPdv, String codChip, String imsiInstalacao, String dataInstalacao, String siteCr,
                         String segmentoCr, String timTorcedor, String canalM4u, String loginM4u, String origemEis, String operadoraSigla, String dddPdv,
                         String ufPdv, String cidadePdv, String cepPdv, String idCadtim, String idParceiro, String sapCliente, String cnpjPdvCadtim,
                         String nickname, String canalCadtim, String canalEis, String canalGe, String grupoEconomico, String idGrupoEconomico, String segmentoRecarga,
                         String status, String flagElegivelMeta, String gerenteCanalMatricula, String gerenteCanal, String coordenadorMatricula, String coordenador,
                         String keyAccountMatricula, String keyAccount, String responsavelPdvMatricula, String responsavelPdv, String responsavelPdvCargo,
                         String dataVgInicio, String dataVgFim, String movelPosPagoControleVoz, String movelPosPagoVoz, String movelPrePagoVoz, String movelPosPagoDados,
                         String tipo, String segmento, String dataAtualizacaoCadtim, String campoCadtim01, String campoCadtim02, String campoCadtim03,
                         String campoCadtim04, String campoCadtim05, String campoRegional01, String campoRegional02, String campoRegional03, String campoCrc01,
                         String campoCrc02, String campoCrc03, String nomeArquivo, String mesReferencia, String tipoArquivoGross ) {
        this.datReferencia = datReferencia;
        this.operadoraTim = operadoraTim;
        this.regional = regional;
        this.cidade = cidade;
        this.skyContrato = skyContrato;
        this.dddAcesso = dddAcesso;
        this.acesso = acesso;
        this.codContratoBscs = codContratoBscs;
        this.codPdvBscs = codPdvBscs;
        this.codPdvSap = codPdvSap;
        this.imei = imei;
        this.iccid = iccid;
        this.cpfCnpj = cpfCnpj;
        this.tecnologia = tecnologia;
        this.nivelPlano = nivelPlano;
        this.tipoFamiliaPlano = tipoFamiliaPlano;
        this.tipoPrePos = tipoPrePos;
        this.vozDados = vozDados;
        this.pacoteMinuto = pacoteMinuto;
        this.custcode = custcode;
        this.nomePdv = nomePdv;
        this.loginAtivacao = loginAtivacao;
        this.motivoGross = motivoGross;
        this.cnpjPdv = cnpjPdv;
        this.codChip = codChip;
        this.imsiInstalacao = imsiInstalacao;
        this.dataInstalacao = dataInstalacao;
        this.siteCr = siteCr;
        this.segmentoCr = segmentoCr;
        this.timTorcedor = timTorcedor;
        this.canalM4u = canalM4u;
        this.loginM4u = loginM4u;
        this.origemEis = origemEis;
        this.operadoraSigla = operadoraSigla;
        this.dddPdv = dddPdv;
        this.ufPdv = ufPdv;
        this.cidadePdv = cidadePdv;
        this.cepPdv = cepPdv;
        this.idCadtim = idCadtim;
        this.idParceiro = idParceiro;
        this.sapCliente = sapCliente;
        this.cnpjPdvCadtim = cnpjPdvCadtim;
        this.nickname = nickname;
        this.canalCadtim = canalCadtim;
        this.canalEis = canalEis;
        this.canalGe = canalGe;
        this.grupoEconomico = grupoEconomico;
        this.idGrupoEconomico = idGrupoEconomico;
        this.segmentoRecarga = segmentoRecarga;
        this.status = status;
        this.flagElegivelMeta = flagElegivelMeta;
        this.gerenteCanalMatricula = gerenteCanalMatricula;
        this.gerenteCanal = gerenteCanal;
        this.coordenadorMatricula = coordenadorMatricula;
        this.coordenador = coordenador;
        this.keyAccountMatricula = keyAccountMatricula;
        this.keyAccount = keyAccount;
        this.responsavelPdvMatricula = responsavelPdvMatricula;
        this.responsavelPdv = responsavelPdv;
        this.responsavelPdvCargo = responsavelPdvCargo;
        this.dataVgInicio = dataVgInicio;
        this.dataVgFim = dataVgFim;
        this.movelPosPagoControleVoz = movelPosPagoControleVoz;
        this.movelPosPagoVoz = movelPosPagoVoz;
        this.movelPrePagoVoz = movelPrePagoVoz;
        this.movelPosPagoDados = movelPosPagoDados;
        this.tipo = tipo;
        this.segmento = segmento;
        this.dataAtualizacaoCadtim = dataAtualizacaoCadtim;
        this.campoCadtim01 = campoCadtim01;
        this.campoCadtim02 = campoCadtim02;
        this.campoCadtim03 = campoCadtim03;
        this.campoCadtim04 = campoCadtim04;
        this.campoCadtim05 = campoCadtim05;
        this.campoRegional01 = campoRegional01;
        this.campoRegional02 = campoRegional02;
        this.campoRegional03 = campoRegional03;
        this.campoCrc01 = campoCrc01;
        this.campoCrc02 = campoCrc02;
        this.campoCrc03 = campoCrc03;
        this.nomeArquivo = nomeArquivo;
        this.mesReferencia = mesReferencia;
        this.tipoArquivoGross = tipoArquivoGross;
    }

    public boolean parse(String textString) {
        if (StringUtils.isNotBlank(textString)) {
            String[] cols = textString.split("\\|", -1);
            int i = 0;
            this.setGross(cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                          cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                          cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                          cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                          cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                          cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                          cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                          cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                          cols[i++], cols[i++], cols[i++]);
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        String delimiter = "|";

        sb.append(datReferencia).append(delimiter)
          .append(operadoraTim).append(delimiter)
          .append(regional).append(delimiter)
          .append(cidade).append(delimiter)
          .append(skyContrato).append(delimiter)
          .append(dddAcesso).append(delimiter)
          .append(acesso).append(delimiter)
          .append(codContratoBscs).append(delimiter)
          .append(codPdvBscs).append(delimiter)
          .append(codPdvSap).append(delimiter)
          .append(imei).append(delimiter)
          .append(iccid).append(delimiter)
          .append(cpfCnpj).append(delimiter)
          .append(tecnologia).append(delimiter)
          .append(nivelPlano).append(delimiter)
          .append(tipoFamiliaPlano).append(delimiter)
          .append(tipoPrePos).append(delimiter)
          .append(vozDados).append(delimiter)
          .append(pacoteMinuto).append(delimiter)
          .append(custcode).append(delimiter)
          .append(nomePdv).append(delimiter)
          .append(loginAtivacao).append(delimiter)
          .append(motivoGross).append(delimiter)
          .append(cnpjPdv).append(delimiter)
          .append(codChip).append(delimiter)
          .append(imsiInstalacao).append(delimiter)
          .append(dataInstalacao).append(delimiter)
          .append(siteCr).append(delimiter)
          .append(segmentoCr).append(delimiter)
          .append(timTorcedor).append(delimiter)
          .append(canalM4u).append(delimiter)
          .append(loginM4u).append(delimiter)
          .append(origemEis).append(delimiter)
          .append(operadoraSigla).append(delimiter)
          .append(dddPdv).append(delimiter)
          .append(ufPdv).append(delimiter)
          .append(cidadePdv).append(delimiter)
          .append(cepPdv).append(delimiter)
          .append(idCadtim).append(delimiter)
          .append(idParceiro).append(delimiter)
          .append(sapCliente).append(delimiter)
          .append(cnpjPdvCadtim).append(delimiter)
          .append(nickname).append(delimiter)
          .append(canalCadtim).append(delimiter)
          .append(canalEis).append(delimiter)
          .append(canalGe).append(delimiter)
          .append(grupoEconomico).append(delimiter)
          .append(idGrupoEconomico).append(delimiter)
          .append(segmentoRecarga).append(delimiter)
          .append(status).append(delimiter)
          .append(flagElegivelMeta).append(delimiter)
          .append(gerenteCanalMatricula).append(delimiter)
          .append(gerenteCanal).append(delimiter)
          .append(coordenadorMatricula).append(delimiter)
          .append(coordenador).append(delimiter)
          .append(keyAccountMatricula).append(delimiter)
          .append(keyAccount).append(delimiter)
          .append(responsavelPdvMatricula).append(delimiter)
          .append(responsavelPdv).append(delimiter)
          .append(responsavelPdvCargo).append(delimiter)
          .append(dataVgInicio).append(delimiter)
          .append(dataVgFim).append(delimiter)
          .append(movelPosPagoControleVoz).append(delimiter)
          .append(movelPosPagoVoz).append(delimiter)
          .append(movelPrePagoVoz).append(delimiter)
          .append(movelPosPagoDados).append(delimiter)
          .append(tipo).append(delimiter)
          .append(segmento).append(delimiter)
          .append(dataAtualizacaoCadtim).append(delimiter)
          .append(campoCadtim01).append(delimiter)
          .append(campoCadtim02).append(delimiter)
          .append(campoCadtim03).append(delimiter)
          .append(campoCadtim04).append(delimiter)
          .append(campoCadtim05).append(delimiter)
          .append(campoRegional01).append(delimiter)
          .append(campoRegional02).append(delimiter)
          .append(campoRegional03).append(delimiter)
          .append(campoCrc01).append(delimiter)
          .append(campoCrc02).append(delimiter)
          .append(campoCrc03).append(delimiter)
          .append(nomeArquivo).append(delimiter)
          .append(mesReferencia).append(delimiter)
          .append(tipoArquivoGross);

        return sb.toString();

    }

    public String getDatReferencia() {
        return datReferencia;
    }

    public void setDatReferencia(String datReferencia) {
        this.datReferencia = datReferencia;
    }

    public String getOperadoraTim() {
        return operadoraTim;
    }

    public void setOperadoraTim(String operadoraTim) {
        this.operadoraTim = operadoraTim;
    }

    public String getRegional() {
        return regional;
    }

    public void setRegional(String regional) {
        this.regional = regional;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getSkyContrato() {
        return skyContrato;
    }

    public void setSkyContrato(String skyContrato) {
        this.skyContrato = skyContrato;
    }

    public String getDddAcesso() {
        return dddAcesso;
    }

    public void setDddAcesso(String dddAcesso) {
        this.dddAcesso = dddAcesso;
    }

    public String getAcesso() {
        return acesso;
    }

    public void setAcesso(String acesso) {
        this.acesso = acesso;
    }

    public String getCodContratoBscs() {
        return codContratoBscs;
    }

    public void setCodContratoBscs(String codContratoBscs) {
        this.codContratoBscs = codContratoBscs;
    }

    public String getCodPdvBscs() {
        return codPdvBscs;
    }

    public void setCodPdvBscs(String codPdvBscs) {
        this.codPdvBscs = codPdvBscs;
    }

    public String getCodPdvSap() {
        return codPdvSap;
    }

    public void setCodPdvSap(String codPdvSap) {
        this.codPdvSap = codPdvSap;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public String getIccid() {
        return iccid;
    }

    public void setIccid(String iccid) {
        this.iccid = iccid;
    }

    public String getCpfCnpj() {
        return cpfCnpj;
    }

    public void setCpfCnpj(String cpfCnpj) {
        this.cpfCnpj = cpfCnpj;
    }

    public String getTecnologia() {
        return tecnologia;
    }

    public void setTecnologia(String tecnologia) {
        this.tecnologia = tecnologia;
    }

    public String getNivelPlano() {
        return nivelPlano;
    }

    public void setNivelPlano(String nivelPlano) {
        this.nivelPlano = nivelPlano;
    }

    public String getTipoFamiliaPlano() {
        return tipoFamiliaPlano;
    }

    public void setTipoFamiliaPlano(String tipoFamiliaPlano) {
        this.tipoFamiliaPlano = tipoFamiliaPlano;
    }

    public String getTipoPrePos() {
        return tipoPrePos;
    }

    public void setTipoPrePos(String tipoPrePos) {
        this.tipoPrePos = tipoPrePos;
    }

    public String getVozDados() {
        return vozDados;
    }

    public void setVozDados(String vozDados) {
        this.vozDados = vozDados;
    }

    public String getPacoteMinuto() {
        return pacoteMinuto;
    }

    public void setPacoteMinuto(String pacoteMinuto) {
        this.pacoteMinuto = pacoteMinuto;
    }

    public String getCustcode() {
        return custcode;
    }

    public void setCustcode(String custcode) {
        this.custcode = custcode;
    }

    public String getNomePdv() {
        return nomePdv;
    }

    public void setNomePdv(String nomePdv) {
        this.nomePdv = nomePdv;
    }

    public String getLoginAtivacao() {
        return loginAtivacao;
    }

    public void setLoginAtivacao(String loginAtivacao) {
        this.loginAtivacao = loginAtivacao;
    }

    public String getMotivoGross() {
        return motivoGross;
    }

    public void setMotivoGross(String motivoGross) {
        this.motivoGross = motivoGross;
    }

    public String getCnpjPdv() {
        return cnpjPdv;
    }

    public void setCnpjPdv(String cnpjPdv) {
        this.cnpjPdv = cnpjPdv;
    }

    public String getCodChip() {
        return codChip;
    }

    public void setCodChip(String codChip) {
        this.codChip = codChip;
    }

    public String getImsiInstalacao() {
        return imsiInstalacao;
    }

    public void setImsiInstalacao(String imsiInstalacao) {
        this.imsiInstalacao = imsiInstalacao;
    }

    public String getDataInstalacao() {
        return dataInstalacao;
    }

    public void setDataInstalacao(String dataInstalacao) {
        this.dataInstalacao = dataInstalacao;
    }

    public String getSiteCr() {
        return siteCr;
    }

    public void setSiteCr(String siteCr) {
        this.siteCr = siteCr;
    }

    public String getSegmentoCr() {
        return segmentoCr;
    }

    public void setSegmentoCr(String segmentoCr) {
        this.segmentoCr = segmentoCr;
    }

    public String getTimTorcedor() {
        return timTorcedor;
    }

    public void setTimTorcedor(String timTorcedor) {
        this.timTorcedor = timTorcedor;
    }

    public String getCanalM4u() {
        return canalM4u;
    }

    public void setCanalM4u(String canalM4u) {
        this.canalM4u = canalM4u;
    }

    public String getLoginM4u() {
        return loginM4u;
    }

    public void setLoginM4u(String loginM4u) {
        this.loginM4u = loginM4u;
    }

    public String getOrigemEis() {
        return origemEis;
    }

    public void setOrigemEis(String origemEis) {
        this.origemEis = origemEis;
    }

    public String getOperadoraSigla() {
        return operadoraSigla;
    }

    public void setOperadoraSigla(String operadoraSigla) {
        this.operadoraSigla = operadoraSigla;
    }

    public String getDddPdv() {
        return dddPdv;
    }

    public void setDddPdv(String dddPdv) {
        this.dddPdv = dddPdv;
    }

    public String getUfPdv() {
        return ufPdv;
    }

    public void setUfPdv(String ufPdv) {
        this.ufPdv = ufPdv;
    }

    public String getCidadePdv() {
        return cidadePdv;
    }

    public void setCidadePdv(String cidadePdv) {
        this.cidadePdv = cidadePdv;
    }

    public String getCepPdv() {
        return cepPdv;
    }

    public void setCepPdv(String cepPdv) {
        this.cepPdv = cepPdv;
    }

    public String getIdCadtim() {
        return idCadtim;
    }

    public void setIdCadtim(String idCadtim) {
        this.idCadtim = idCadtim;
    }

    public String getIdParceiro() {
        return idParceiro;
    }

    public void setIdParceiro(String idParceiro) {
        this.idParceiro = idParceiro;
    }

    public String getSapCliente() {
        return sapCliente;
    }

    public void setSapCliente(String sapCliente) {
        this.sapCliente = sapCliente;
    }

    public String getCnpjPdvCadtim() {
        return cnpjPdvCadtim;
    }

    public void setCnpjPdvCadtim(String cnpjPdvCadtim) {
        this.cnpjPdvCadtim = cnpjPdvCadtim;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getCanalCadtim() {
        return canalCadtim;
    }

    public void setCanalCadtim(String canalCadtim) {
        this.canalCadtim = canalCadtim;
    }

    public String getCanalEis() {
        return canalEis;
    }

    public void setCanalEis(String canalEis) {
        this.canalEis = canalEis;
    }

    public String getCanalGe() {
        return canalGe;
    }

    public void setCanalGe(String canalGe) {
        this.canalGe = canalGe;
    }

    public String getGrupoEconomico() {
        return grupoEconomico;
    }

    public void setGrupoEconomico(String grupoEconomico) {
        this.grupoEconomico = grupoEconomico;
    }

    public String getIdGrupoEconomico() {
        return idGrupoEconomico;
    }

    public void setIdGrupoEconomico(String idGrupoEconomico) {
        this.idGrupoEconomico = idGrupoEconomico;
    }

    public String getSegmentoRecarga() {
        return segmentoRecarga;
    }

    public void setSegmentoRecarga(String segmentoRecarga) {
        this.segmentoRecarga = segmentoRecarga;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getFlagElegivelMeta() {
        return flagElegivelMeta;
    }

    public void setFlagElegivelMeta(String flagElegivelMeta) {
        this.flagElegivelMeta = flagElegivelMeta;
    }

    public String getGerenteCanalMatricula() {
        return gerenteCanalMatricula;
    }

    public void setGerenteCanalMatricula(String gerenteCanalMatricula) {
        this.gerenteCanalMatricula = gerenteCanalMatricula;
    }

    public String getGerenteCanal() {
        return gerenteCanal;
    }

    public void setGerenteCanal(String gerenteCanal) {
        this.gerenteCanal = gerenteCanal;
    }

    public String getCoordenadorMatricula() {
        return coordenadorMatricula;
    }

    public void setCoordenadorMatricula(String coordenadorMatricula) {
        this.coordenadorMatricula = coordenadorMatricula;
    }

    public String getCoordenador() {
        return coordenador;
    }

    public void setCoordenador(String coordenador) {
        this.coordenador = coordenador;
    }

    public String getKeyAccountMatricula() {
        return keyAccountMatricula;
    }

    public void setKeyAccountMatricula(String keyAccountMatricula) {
        this.keyAccountMatricula = keyAccountMatricula;
    }

    public String getKeyAccount() {
        return keyAccount;
    }

    public void setKeyAccount(String keyAccount) {
        this.keyAccount = keyAccount;
    }

    public String getResponsavelPdvMatricula() {
        return responsavelPdvMatricula;
    }

    public void setResponsavelPdvMatricula(String responsavelPdvMatricula) {
        this.responsavelPdvMatricula = responsavelPdvMatricula;
    }

    public String getResponsavelPdv() {
        return responsavelPdv;
    }

    public void setResponsavelPdv(String responsavelPdv) {
        this.responsavelPdv = responsavelPdv;
    }

    public String getResponsavelPdvCargo() {
        return responsavelPdvCargo;
    }

    public void setResponsavelPdvCargo(String responsavelPdvCargo) {
        this.responsavelPdvCargo = responsavelPdvCargo;
    }

    public String getDataVgInicio() {
        return dataVgInicio;
    }

    public void setDataVgInicio(String dataVgInicio) {
        this.dataVgInicio = dataVgInicio;
    }

    public String getDataVgFim() {
        return dataVgFim;
    }

    public void setDataVgFim(String dataVgFim) {
        this.dataVgFim = dataVgFim;
    }

    public String getMovelPosPagoControleVoz() {
        return movelPosPagoControleVoz;
    }

    public void setMovelPosPagoControleVoz(String movelPosPagoControleVoz) {
        this.movelPosPagoControleVoz = movelPosPagoControleVoz;
    }

    public String getMovelPosPagoVoz() {
        return movelPosPagoVoz;
    }

    public void setMovelPosPagoVoz(String movelPosPagoVoz) {
        this.movelPosPagoVoz = movelPosPagoVoz;
    }

    public String getMovelPrePagoVoz() {
        return movelPrePagoVoz;
    }

    public void setMovelPrePagoVoz(String movelPrePagoVoz) {
        this.movelPrePagoVoz = movelPrePagoVoz;
    }

    public String getMovelPosPagoDados() {
        return movelPosPagoDados;
    }

    public void setMovelPosPagoDados(String movelPosPagoDados) {
        this.movelPosPagoDados = movelPosPagoDados;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getSegmento() {
        return segmento;
    }

    public void setSegmento(String segmento) {
        this.segmento = segmento;
    }

    public String getDataAtualizacaoCadtim() {
        return dataAtualizacaoCadtim;
    }

    public void setDataAtualizacaoCadtim(String dataAtualizacaoCadtim) {
        this.dataAtualizacaoCadtim = dataAtualizacaoCadtim;
    }

    public String getCampoCadtim01() {
        return campoCadtim01;
    }

    public void setCampoCadtim01(String campoCadtim01) {
        this.campoCadtim01 = campoCadtim01;
    }

    public String getCampoCadtim02() {
        return campoCadtim02;
    }

    public void setCampoCadtim02(String campoCadtim02) {
        this.campoCadtim02 = campoCadtim02;
    }

    public String getCampoCadtim03() {
        return campoCadtim03;
    }

    public void setCampoCadtim03(String campoCadtim03) {
        this.campoCadtim03 = campoCadtim03;
    }

    public String getCampoCadtim04() {
        return campoCadtim04;
    }

    public void setCampoCadtim04(String campoCadtim04) {
        this.campoCadtim04 = campoCadtim04;
    }

    public String getCampoCadtim05() {
        return campoCadtim05;
    }

    public void setCampoCadtim05(String campoCadtim05) {
        this.campoCadtim05 = campoCadtim05;
    }

    public String getCampoRegional01() {
        return campoRegional01;
    }

    public void setCampoRegional01(String campoRegional01) {
        this.campoRegional01 = campoRegional01;
    }

    public String getCampoRegional02() {
        return campoRegional02;
    }

    public void setCampoRegional02(String campoRegional02) {
        this.campoRegional02 = campoRegional02;
    }

    public String getCampoRegional03() {
        return campoRegional03;
    }

    public void setCampoRegional03(String campoRegional03) {
        this.campoRegional03 = campoRegional03;
    }

    public String getCampoCrc01() {
        return campoCrc01;
    }

    public void setCampoCrc01(String campoCrc01) {
        this.campoCrc01 = campoCrc01;
    }

    public String getCampoCrc02() {
        return campoCrc02;
    }

    public void setCampoCrc02(String campoCrc02) {
        this.campoCrc02 = campoCrc02;
    }

    public String getCampoCrc03() {
        return campoCrc03;
    }

    public void setCampoCrc03(String campoCrc03) {
        this.campoCrc03 = campoCrc03;
    }

    public String getNomeArquivo() {
        return nomeArquivo;
    }

    public void setNomeArquivo(String nomeArquivo) {
        this.nomeArquivo = nomeArquivo;
    }

    public String getMesReferencia() {
        return mesReferencia;
    }

    public void setMesReferencia(String mesReferencia) {
        this.mesReferencia = mesReferencia;
    }

    public String getTipoArquivoGross() {
        return tipoArquivoGross;
    }

    public void setTipoArquivoGross(String tipoArquivoGross) {
        this.tipoArquivoGross = tipoArquivoGross;
    }
}
