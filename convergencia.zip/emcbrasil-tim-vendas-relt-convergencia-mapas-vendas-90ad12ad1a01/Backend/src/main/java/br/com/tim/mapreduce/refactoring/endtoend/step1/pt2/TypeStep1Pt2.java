package br.com.tim.mapreduce.refactoring.endtoend.step1.pt2;

public enum TypeStep1Pt2 {
	
	ORDER, ITEM, DEFAULT

}
