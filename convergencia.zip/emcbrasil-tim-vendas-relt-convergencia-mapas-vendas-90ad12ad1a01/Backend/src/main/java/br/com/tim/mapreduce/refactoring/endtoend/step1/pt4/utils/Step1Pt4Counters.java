package br.com.tim.mapreduce.refactoring.endtoend.step1.pt4.utils;

public enum Step1Pt4Counters {
	
	STEP1PT3_MAPPER_WRITE, FIBER_MAPPER_WRITE, STEP1PT4_REDUCER_WRITE, BAT222_REDUCER_WRITE

}
