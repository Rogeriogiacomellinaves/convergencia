package br.com.tim.mapreduce.e2e.step10;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

import br.com.tim.mapreduce.e2e.step10.model.Step9PT2Result;

public class MapperStep9PT2Result extends org.apache.hadoop.mapreduce.Mapper<Writable,Text,E2EStep10Key,E2EStep10Value>{
	private E2EStep10Key outkey;
	private E2EStep10Value outValue;
	private Step9PT2Result input;
	
	@Override
	protected void map(Writable key, Text value, Context context) throws IOException, InterruptedException {
		input.parse(value.toString());
		outkey.setNumOrdemSiebel(input.getNumOrdemSiebel().trim());
		outkey.setDat_ref(input.getDatRef());
		outkey.setTipo(TypeStep10.RELT);
		outValue.setStep9PT2Result(input);
		context.write(outkey, outValue);
	}
	
	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		super.setup(context);
		this.outkey = new E2EStep10Key();
		this.outValue = new E2EStep10Value();
		this.input = new Step9PT2Result();
	}
	
	@Override
	protected void cleanup(Context context) throws IOException, InterruptedException {
		super.cleanup(context);
		this.clear();
	}
	
	private void clear(){
		this.outValue.clear();
	}
}
