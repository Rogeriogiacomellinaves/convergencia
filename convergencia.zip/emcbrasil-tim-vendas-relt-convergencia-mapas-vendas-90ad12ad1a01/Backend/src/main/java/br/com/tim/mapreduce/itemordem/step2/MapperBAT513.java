
package br.com.tim.mapreduce.itemordem.step2;

import br.com.tim.mapreduce.model.BAT513;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

import java.io.IOException;

public class MapperBAT513 extends org.apache.hadoop.mapreduce.Mapper<Writable,Text,IOStep2Key,IOStep2Value> {

	private IOStep2Key outkey;
	private IOStep2Value outValue;
	private BAT513 input;
	@Override
	protected void map(Writable key, Text value, Context context) throws IOException, InterruptedException {
		input.parse(value.toString());
		outkey.setKey(input);
		outValue.setBAT513(input);
		context.write(outkey,outValue);

	}

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		super.setup(context);
		this.outkey = new IOStep2Key();
		this.outValue = new IOStep2Value();
		this.input = new BAT513();
	}

	@Override
	protected void cleanup(Context context) throws IOException, InterruptedException {
		super.cleanup(context);
		this.clear();
	}

	private void clear(){
	   this.outValue.clear();
	}

}