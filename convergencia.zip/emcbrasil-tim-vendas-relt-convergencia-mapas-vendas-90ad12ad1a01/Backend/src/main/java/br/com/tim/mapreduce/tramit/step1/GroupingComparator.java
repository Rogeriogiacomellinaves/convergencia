package br.com.tim.mapreduce.tramit.step1;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

public class GroupingComparator extends WritableComparator {

    public GroupingComparator() {
        super(TramitStep1Key.class, true);
    }

    @SuppressWarnings({"rawtypes"})
    @Override
    public int compare(WritableComparable a, WritableComparable b) {
        TramitStep1Key keyA = (TramitStep1Key) a;
        TramitStep1Key keyB = (TramitStep1Key) b;

        return keyA.compareToGrouping(keyB);
    }

}
