package br.com.tim.mapreduce.tramit.step2;

import org.apache.commons.lang3.StringUtils;

public class TramitStep2OutValue {

    protected String ordemSiebel;
    protected String cpfCNPJ;
    protected String contrato;
    protected String datCriacaoOrdem;
    protected String horCriacaoOrdem;
    protected String login;
    protected String statusSiebel;
    protected String motivoCancelamento;
    protected String tipoOrdem;
    protected String subtipoOrdem;
    protected String parceiroVendaSiebel;
    protected String tipoErro;
    protected String erroNormalizado;
    protected String owner;
    protected String aging;
    protected String agingFaixa;
    protected String tecnologia;
    protected String cpe;
    protected String ont;
    protected String produto;
    protected String uf;
    protected String datRef;
    protected String statusWfmToa;
    protected String resourceWfmToa; 
    protected String dateWfmToa;
    protected String stepErro;
	protected String msan;


    public void setResultStep1(TramitStep2Value result) {
        this.ordemSiebel = result.getOrdemSiebel();
        this.cpfCNPJ = result.getCpfCNPJ();
        this.contrato = result.getContrato();
        this.datCriacaoOrdem = StringUtils.substring(result.getDatCriacaoOrdem(), 0, 10);
        this.horCriacaoOrdem = result.getDatCriacaoOrdem();
        this.login = result.getLogin();
        this.statusSiebel = result.getStatusSiebel();
        this.motivoCancelamento = result.getMotivoCancelamento();
        this.tipoOrdem = result.getTipoOrdem();
        this.subtipoOrdem = result.getSubtipoOrdem();
        this.parceiroVendaSiebel = result.getParceiroVendaSiebel();
        this.tipoErro = result.getTipoErro();
        this.aging = result.getAging();
        this.agingFaixa = result.getAgingFaixa();
        this.tecnologia = result.getTecnologia();
        this.cpe = result.getCpe();
        this.ont = result.getOnt();
        this.produto = result.getProduto();
        this.uf = result.getUf();
        this.statusWfmToa = result.getStatusWfmToa();
    	this.resourceWfmToa = result.getStatusWfmToa();
    	this.dateWfmToa = result.getDateWfmToa();
    	this.stepErro = result.getStepErro();
    	this.msan = result.getMsan();
    }
    
  

    public void setFallout(TramitStep2Value fallout) {
        this.erroNormalizado = fallout.getErroNormalizado();
        this.owner = fallout.getOwner();
    }

    public void clearResultStep1(){
        this.ordemSiebel = "";
        this.cpfCNPJ = "";
        this.contrato = "";
        this.datCriacaoOrdem = "";
        this.login = "";
        this.statusSiebel = "";
        this.motivoCancelamento = "";
        this.tipoOrdem = "";
        this.subtipoOrdem = "";
        this.parceiroVendaSiebel = "";
        this.tipoErro = "";
        this.aging = "";
        this.agingFaixa = "";
        this.tecnologia = "";
        this.cpe = "";
        this.ont = "";
        this.produto = "";
        this.uf = "";
        this.statusWfmToa = "";
    	this.resourceWfmToa = "";
    	this.dateWfmToa = "";
    	this.stepErro = "";
    	this.msan = "";
    }

    public void clear(){
        this.ordemSiebel = "";
        this.cpfCNPJ = "";
        this.contrato = "";
        this.datCriacaoOrdem = "";
        this.login = "";
        this.statusSiebel = "";
        this.motivoCancelamento = "";
        this.tipoOrdem = "";
        this.subtipoOrdem = "";
        this.parceiroVendaSiebel = "";
        this.tipoErro = "";
        this.erroNormalizado = "";
        this.owner = "";
        this.aging = "";
        this.agingFaixa = "";
        this.tecnologia = "";
        this.cpe = "";
        this.ont = "";
        this.produto = "";
        this.uf = "";
        this.datRef = "";
        this.statusWfmToa = "";
    	this.resourceWfmToa = "";
    	this.dateWfmToa = "";
    	this.stepErro = "";
    	this.msan = "";
    }

    public void setDatRef(String datRef) {
        this.datRef = datRef;
    }

    @Override
    public String toString(){
        return new StringBuilder()
                   .append(ordemSiebel).append("|")
                   .append(cpfCNPJ).append("|")
                   .append(contrato).append("|")
                   .append(datCriacaoOrdem).append("|")
                   .append(horCriacaoOrdem).append("|")
                   .append(login).append("|")
                   .append(statusSiebel).append("|")
                   .append(motivoCancelamento).append("|")
                   .append(statusWfmToa).append("|")
                   .append(tipoOrdem).append("|")
                   .append(subtipoOrdem).append("|")
                   .append(parceiroVendaSiebel).append("|")
                   .append(resourceWfmToa).append("|")
                   .append(dateWfmToa).append("|")
                   .append(tipoErro).append("|")
                   .append(stepErro).append("|")
                   .append(erroNormalizado).append("|")
                   .append(msan).append("|")
                   .append(owner).append("|")
                   .append(aging).append("|")
                   .append(agingFaixa).append("|")
                   .append(tecnologia).append("|")
                   .append(cpe).append("|")
                   .append(ont).append("|")
                   .append(produto).append("|")
                   .append(uf).append("|")
                   .append(datRef).toString();
    }

}
