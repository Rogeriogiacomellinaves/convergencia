package br.com.tim.mapreduce.refactoring.endtoend.step5.pt1;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;


public class GroupingComparator extends WritableComparator{
	
	public GroupingComparator() {
		super(Step5Key.class, true);
	}

	
    @SuppressWarnings({"rawtypes"})
    @Override
    public int compare(WritableComparable a, WritableComparable b) {
    	Step5Key keyA = (Step5Key) a;
    	Step5Key keyB = (Step5Key) b;

        return keyA.compareToGrouping(keyB);
    }

}
