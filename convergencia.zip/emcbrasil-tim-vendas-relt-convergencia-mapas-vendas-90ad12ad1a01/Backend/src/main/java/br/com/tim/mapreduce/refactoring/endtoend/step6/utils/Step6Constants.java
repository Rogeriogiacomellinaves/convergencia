package br.com.tim.mapreduce.refactoring.endtoend.step6.utils;

public class Step6Constants {
	
	
	public static final String STEP5_FACT_INPUT = "step4-fact-input";
	public static final String STEP6_OUTPUT = "output-path-step6";
	public static final String STEP6PT1 = "STEP6PT1";
	

}
