package br.com.tim.hive;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.log4j.Logger;
import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import br.com.tim.commons.Constants;
import br.com.tim.hive.HiveIngestionInitializationException;
import br.com.tim.hive.query.HiveQueryContext;
import sun.reflect.generics.reflectiveObjects.NotImplementedException;

@SuppressWarnings("restriction")
public class HiveContextHdpFinal extends HiveQueryContext {
	private static Logger _log = Logger.getLogger(HiveQueryContext.class);

    private FileSystem fs;
    private Configuration config;
    private String description, hiveQueryClassName, outputHandlerClassName;
    private int  returnCodeError, returnCodeLoad, returnCodeNoLoad;
    private Map<String, String> properties;
    private String[] args;
    @SuppressWarnings("unused")
	private String execTs;
    private String[] nameQuerys;
	private LocalDateTime dt;
	private LocalDateTime dtBAT513;
	private DateTimeFormatter dtf;

    
    private static final SimpleDateFormat sdfData = new SimpleDateFormat("yyyy-MM-dd");

    public HiveContextHdpFinal init(String[] args, Configuration config) throws HiveIngestionInitializationException {

		try {
			this.dtf = DateTimeFormat.forPattern("yyyy-MM-dd");
			this.args = args;
			this.config = config;
			this.fs = FileSystem.get(this.config);
			String execTs = DateTimeFormat.forPattern("yyyy-MM-dd-HH-mm-ss").print(new java.util.Date().getTime());
			this.config.set("timestamp", execTs);
			this.description = this.config.get("process-id");
			this.returnCodeError = this.config.getInt("return-code-error", 1);
			this.returnCodeLoad = this.config.getInt("return-code-load", 0);
			this.returnCodeNoLoad = this.config.getInt("return-code-no-load", 2);
			this.hiveQueryClassName = this.config.get("hive-query-class");
			this.outputHandlerClassName = this.config.get("output-handler-class");
			this.nameQuerys = this.config.getStrings("hive-name-querys");
			this.loadProperties();
			this.configuration();
			String timestamp = LocalDateTime.now().toString("yyyyMMddHHmmss");
			
			this.config.set("TIMESTAMP", timestamp);
			
			_log.info("Setando execution date para a query:");
			if (args.length == 0) {
				dt = LocalDateTime.now().minusDays(1);
				_log.info("Setando execution date para a query:" + dt.toString("yyyyMMdd"));
				this.config.set("PARAM_DATE_REF", dt.toString("yyyyMMdd"));				
			} else {
				if(!args[0].split("=")[0].toLowerCase().equals("reprocess-day")) {
					_log.error("Esperado parâmetro 'reprocess-day=yyyy-MM-dd' ano, mês e dia");
				}else {
					try {
						String data = args[0].split("=")[1];
						dtf.parseLocalDate(data);
						this.config.set("PARAM_DATE_REF", data.replace("-", ""));
					} catch (Exception e) {
						throw new HiveIngestionInitializationException("Erro para definir data de execução.");
					}
	
					_log.info("Data de execução: " + args[0]);
				}
			}
			
			
			Process process;
	    	String hadoopCommand = "hadoop fs -ls /apps/hive/warehouse/fact.db/dw_f_bat513_ctlg_prod_sblpos/";
	    	
	    	_log.info("Hadoop command: " + hadoopCommand);
			process = Runtime.getRuntime().exec(hadoopCommand);

			BufferedReader stdInput = new BufferedReader(new InputStreamReader(process.getInputStream()));
			String result;
			String lastLine = new String();
			
			while ((result = stdInput.readLine()) != null) {
				
				if (!result.contains("HIVE_DEFAULT_PARTITION")) {
					lastLine = result;
				}
				
			}

			try {
				String[] split = lastLine.split("=");
				String firstSplit = split[1];
				String[] lastSplit = firstSplit.split("/");

				_log.info("Got lastest day BAT513 " + lastSplit[0]);
				this.config.set("PARAM_DATE_REF_BAT513", lastSplit[0]);
				
			} catch (Exception e) {

				dtBAT513 = LocalDateTime.now().minusDays(1);
				_log.info("Setando execution date para a query BAT513:" + dtBAT513.toString("yyyyMMdd"));
				this.config.set("PARAM_DATE_REF_BAT513", dt.toString("yyyyMMdd"));

			}
			

			if (this.config.getBoolean(Constants.FLAG_ADD_JAR, false)) {
				addJarHdfs();
			}

		} catch (Exception e) {
			throw new HiveIngestionInitializationException(e);
		}

		super.init(config);

		return this;
    }
    
    protected void configuration() throws HiveIngestionInitializationException {

    }

    private void loadProperties() {
        this.properties = new HashMap<>();
        Iterator<Map.Entry<String, String>> iterator = this.config.iterator();
        String prefix = "hiveingestion.";

        while(iterator.hasNext()){
            Map.Entry<String, String> entry = iterator.next();
            String key = entry.getKey();

            if(!key.startsWith(prefix))
                continue;

            String keyWithoutPrefix = key.substring(prefix.length());
            
			this.properties.put(keyWithoutPrefix, entry.getValue());
        }
    }

    /**
     * This method is used to add jar in hdfs
     * @throws HiveIngestionInitializationException
     */
    protected synchronized void addJarHdfs() throws HiveIngestionInitializationException {

        _log.info("Executing method addJarHdfs.");
        try{

            String strPathJarLocal = System.getProperty(Constants.PATH_JAR_LOCAL);
            String strPathJarHdfs = this.getConfig().get(Constants.PATH_JAR_HDFS);
            String strPrefixPathJarHdfs = this.getConfig().get(Constants.PREFIX_JAR_HDFS_GLOB);

            if (StringUtils.isEmpty(strPathJarHdfs)){
                throw new Exception("Hdfs Path from jar not found. Is necessary add in xml Ex: Propertie (path-jar-hdfs) Value (/platinum/work/faturamento_ix/jar/)");
            }

            if (StringUtils.isEmpty(strPathJarLocal)){
                throw new Exception("Local path from jar not found. Is necessary add in -Dpath.jar Ex: /data/apps/aplication.jar");
            }

            if (StringUtils.isEmpty(strPrefixPathJarHdfs)){
                throw new Exception("Prefix jar not found. Is necessary add in xml Ex: Propertie (prefix-jar-hdfs-glob) Value (tim-fatu-inge-billing*) ");
            }

            Path origPathJar = new Path(strPathJarLocal);
            Path destPathJarHdfs = new Path(strPathJarHdfs);
            Path auxPathJarHdfsGrob = new Path(destPathJarHdfs,strPrefixPathJarHdfs);
            Path lastPathJar = null;

            _log.info("Checking path " + auxPathJarHdfsGrob);
            FileStatus[] files =  getFs().globStatus(auxPathJarHdfsGrob);

             for (FileStatus file: files) {
                 if (StringUtils.equalsIgnoreCase(origPathJar.getName(),file.getPath().getName())){
                     _log.info("This jar is already the most recent " + file.getPath());
                     lastPathJar = file.getPath();
                 }else {
                     _log.info("Removing jar from HDFS " + file.getPath());
                     getFs().delete(file.getPath(),true);
                 }
             }

             if (lastPathJar == null){
                 _log.info("Copying jar from " + origPathJar + " to " + destPathJarHdfs);
                 getFs().copyFromLocalFile(origPathJar,destPathJarHdfs);
             }

             lastPathJar = getJarHdfsGrob(auxPathJarHdfsGrob);
             this.getConfig().set(Constants.QUERY_ADD_JAR,"ADD JAR " + lastPathJar);

        }catch (Exception e){
            _log.error(e);
            throw new HiveIngestionInitializationException(e);
        }

    }

    /**
	 * 
	 * Method format date to pattern yyMMdd
	 * 
	 * @param LocalDate date
	 * @return String
	 */
	public static String formatDateyyMMdd(LocalDate date){

		String formattedDate;
		
		try {
			formattedDate = date.toString(sdfData.toPattern());
		} catch (Exception e) {
			formattedDate = StringUtils.EMPTY;
		}
		
		return formattedDate;
	}
    
    /**
	 *
	 * methodo parse a string with the format yyMMdd to turn it into LocalDate
	 * 
	 * @param date
	 * @return
	 */
	public static LocalDate parseDateyyyyMMdd(String date) {

		LocalDate data;

		try {
			data = new LocalDate(sdfData.parse(date));
		} catch (Exception e) {
			data = null;
		}

		return data;
	}

    private Path getJarHdfsGrob(Path dest) throws  Exception{
        FileStatus[] files =  getFs().globStatus(dest);
        for (FileStatus fileStatus: files) {
            return fileStatus.getPath();
        }
        throw new Exception("Path jar hdfs not found" + dest);
    }

    public String getDescription() {
        return description;
    }

    public int getReturnCodeError() {
        return returnCodeError;
    }

    public int getReturnCodeLoad() {
        return returnCodeLoad;
    }

    public int getReturnCodeNoLoad() {
        return returnCodeNoLoad;
    }

    public Map<String, String> getProperties() {
        return properties;
    }

    public String getOutputHandlerClassName() {return outputHandlerClassName;}

    public String getHiveQueryClassName() {
        return hiveQueryClassName;
    }

    @Override
    public Configuration getConfig() {
        return config;
    }

    @Override
    public FileSystem getFs() {
        return fs;
    }

    public String[] getNameQuerys() {
        return nameQuerys;
    }

    @Deprecated
    @Override
    public String getInsertStatement() {
        throw new NotImplementedException();
    }

    public String[] getArgs() {
		return args;
	}
}
