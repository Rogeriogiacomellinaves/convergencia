package br.com.tim.mapreduce.refactoring.model;

import org.apache.commons.lang3.StringUtils;

import br.com.tim.utils.CommonsConstants;

public class BAT223 {

    private String customerId;
    private String cpfCliente;
    private String tipoLogradouroInstalacao;
    private String logradouroInstalacao;
    private String numeroEnderecoInstalacao;
    private String complementoInstalacao;
    private String bairroInstalacao;
    private String cidadeInstalacao;
    private String ufInstalacao;
    private String cepInstalacao;
    private String caixaPostalInstalacao;
    private String rowidEnderecoInstalacao;
    private String codigoNacionalLocalidade;
    private String tipoAcesso;
    private String numeroContrato;
    private String dataHoraAtivacao;
    private String codigoComercialPlano;
    private String nomePlano;
    private String msisdn;
    private String statusContrato;
    private String dataHoraUltimoStatus;
    private String dataHoraUltimaAtualizacaoContrato;
    private String dataAgingCliente;
    private String codigoPdvAtivacao;
    private String codigoPdvUltimaModificacao;
    private String numeroSimcard;
    private String subtipoAcesso;
    private String motivoStatus;
    private String clientePermiteDivulgacaoListaTelefonica;
    private String loginResponsavelAtivacao;
    private String perfilLoginResponsavelAtivacao;
    private String perfilLoginModif;
    private String loginRespUltimaModif;
    private String flagContratoPertenceGrupoAcapulco;
    private String flagContratoAdministradorGrupoAcapulco;
    private String rowid;
    private String loteid;
    private String arquivo;
    private String arquivots;
    private String currentDate;
    private String idePromocao;
    private String dscSegmentoLinha;
    private String rowIdAcesso;
    private String dscPaisCliente;
    private String rowIdCliente;
    private String rowIdRootAcesso;
    private String rowIdPerfilFatura;

    public BAT223() {

        this.customerId = CommonsConstants.EMPTY;
        this.cpfCliente = CommonsConstants.EMPTY;
        this.tipoLogradouroInstalacao = CommonsConstants.EMPTY;
        this.logradouroInstalacao = CommonsConstants.EMPTY;
        this.numeroEnderecoInstalacao = CommonsConstants.EMPTY;
        this.complementoInstalacao = CommonsConstants.EMPTY;
        this.bairroInstalacao = CommonsConstants.EMPTY;
        this.cidadeInstalacao = CommonsConstants.EMPTY;
        this.ufInstalacao = CommonsConstants.EMPTY;
        this.cepInstalacao = CommonsConstants.EMPTY;
        this.caixaPostalInstalacao = CommonsConstants.EMPTY;
        this.rowidEnderecoInstalacao = CommonsConstants.EMPTY;
        this.codigoNacionalLocalidade = CommonsConstants.EMPTY;
        this.tipoAcesso = CommonsConstants.EMPTY;
        this.numeroContrato = CommonsConstants.EMPTY;
        this.dataHoraAtivacao = CommonsConstants.EMPTY;
        this.codigoComercialPlano = CommonsConstants.EMPTY;
        this.nomePlano = CommonsConstants.EMPTY;
        this.msisdn = CommonsConstants.EMPTY;
        this.statusContrato = CommonsConstants.EMPTY;
        this.dataHoraUltimoStatus = CommonsConstants.EMPTY;
        this.dataHoraUltimaAtualizacaoContrato = CommonsConstants.EMPTY;
        this.dataAgingCliente = CommonsConstants.EMPTY;
        this.codigoPdvAtivacao = CommonsConstants.EMPTY;
        this.codigoPdvUltimaModificacao = CommonsConstants.EMPTY;
        this.numeroSimcard = CommonsConstants.EMPTY;
        this.subtipoAcesso = CommonsConstants.EMPTY;
        this.motivoStatus = CommonsConstants.EMPTY;
        this.clientePermiteDivulgacaoListaTelefonica = CommonsConstants.EMPTY;
        this.loginResponsavelAtivacao = CommonsConstants.EMPTY;
        this.perfilLoginResponsavelAtivacao = CommonsConstants.EMPTY;
        this.perfilLoginModif = CommonsConstants.EMPTY;
        this.loginRespUltimaModif = CommonsConstants.EMPTY;
        this.flagContratoPertenceGrupoAcapulco = CommonsConstants.EMPTY;
        this.flagContratoAdministradorGrupoAcapulco = CommonsConstants.EMPTY;
        this.rowid = CommonsConstants.EMPTY;
        this.loteid = CommonsConstants.EMPTY;
        this.arquivo = CommonsConstants.EMPTY;
        this.arquivots = CommonsConstants.EMPTY;
        this.currentDate = CommonsConstants.EMPTY;
        this.idePromocao = CommonsConstants.EMPTY;
        this.dscSegmentoLinha = CommonsConstants.EMPTY;
        this.rowIdAcesso = CommonsConstants.EMPTY;
        this.dscPaisCliente = CommonsConstants.EMPTY;
        this.rowIdCliente = CommonsConstants.EMPTY;
        this.rowIdRootAcesso = CommonsConstants.EMPTY;
        this.rowIdPerfilFatura = CommonsConstants.EMPTY;

    }

    public void setBAT223(String customerId, String cpfCliente, String tipoLogradouroInstalacao, String logradouroInstalacao, String numeroEnderecoInstalacao, String complementoInstalacao,
                          String bairroInstalacao, String cidadeInstalacao, String ufInstalacao, String cepInstalacao, String caixaPostalInstalacao, String rowidEnderecoInstalacao,
                          String codigoNacionalLocalidade, String tipoAcesso, String numeroContrato, String dataHoraAtivacao, String codigoComercialPlano, String nomePlano, String msisdn,
                          String statusContrato, String dataHoraUltimoStatus, String dataHoraUltimaAtualizacaoContrato, String dataAgingCliente, String codigoPdvAtivacao,
                          String codigoPdvUltimaModificacao, String numeroSimcard, String subtipoAcesso, String motivoStatus, String clientePermiteDivulgacaoListaTelefonica,
                          String loginResponsavelAtivacao, String perfilLoginResponsavelAtivacao, String perfilLoginModif, String loginRespUltimaModif, String flagContratoPertenceGrupoAcapulco,
                          String flagContratoAdministradorGrupoAcapulco, String rowid, String loteid, String arquivo, String arquivots, String currentDate, String idePromocao,
                          String dscSegmentoLinha, String rowIdAcesso, String dscPaisCliente, String rowIdCliente, String rowIdRootAcesso, String rowIdPerfilFatura) {
        this.customerId = customerId;
        this.cpfCliente = cpfCliente;
        this.tipoLogradouroInstalacao = tipoLogradouroInstalacao;
        this.logradouroInstalacao = logradouroInstalacao;
        this.numeroEnderecoInstalacao = numeroEnderecoInstalacao;
        this.complementoInstalacao = complementoInstalacao;
        this.bairroInstalacao = bairroInstalacao;
        this.cidadeInstalacao = cidadeInstalacao;
        this.ufInstalacao = ufInstalacao;
        this.cepInstalacao = cepInstalacao;
        this.caixaPostalInstalacao = caixaPostalInstalacao;
        this.rowidEnderecoInstalacao = rowidEnderecoInstalacao;
        this.codigoNacionalLocalidade = codigoNacionalLocalidade;
        this.tipoAcesso = tipoAcesso;
        this.numeroContrato = numeroContrato;
        this.dataHoraAtivacao = dataHoraAtivacao;
        this.codigoComercialPlano = codigoComercialPlano;
        this.nomePlano = nomePlano;
        this.msisdn = msisdn;
        this.statusContrato = statusContrato;
        this.dataHoraUltimoStatus = dataHoraUltimoStatus;
        this.dataHoraUltimaAtualizacaoContrato = dataHoraUltimaAtualizacaoContrato;
        this.dataAgingCliente = dataAgingCliente;
        this.codigoPdvAtivacao = codigoPdvAtivacao;
        this.codigoPdvUltimaModificacao = codigoPdvUltimaModificacao;
        this.numeroSimcard = numeroSimcard;
        this.subtipoAcesso = subtipoAcesso;
        this.motivoStatus = motivoStatus;
        this.clientePermiteDivulgacaoListaTelefonica = clientePermiteDivulgacaoListaTelefonica;
        this.loginResponsavelAtivacao = loginResponsavelAtivacao;
        this.perfilLoginResponsavelAtivacao = perfilLoginResponsavelAtivacao;
        this.perfilLoginModif = perfilLoginModif;
        this.loginRespUltimaModif = loginRespUltimaModif;
        this.flagContratoPertenceGrupoAcapulco = flagContratoPertenceGrupoAcapulco;
        this.flagContratoAdministradorGrupoAcapulco = flagContratoAdministradorGrupoAcapulco;
        this.rowid = rowid;
        this.loteid = loteid;
        this.arquivo = arquivo;
        this.arquivots = arquivots;
        this.currentDate = currentDate;
        this.idePromocao = idePromocao;
        this.dscSegmentoLinha = dscSegmentoLinha;
        this.rowIdAcesso = rowIdAcesso;
        this.dscPaisCliente = dscPaisCliente;
        this.rowIdCliente = rowIdCliente;
        this.rowIdRootAcesso = rowIdRootAcesso;
        this.rowIdPerfilFatura = rowIdPerfilFatura;
    }

    public boolean parse(String textString) {
        if (StringUtils.isNotBlank(textString)) {
            String[] cols = textString.split("\\|", -1);
            int i = 0;
            this.setBAT223(cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                           cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                           cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                           cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                           cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++]);
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        String delimiter = "|";

        sb.append(customerId).append(delimiter)
          .append(cpfCliente).append(delimiter)
          .append(tipoLogradouroInstalacao).append(delimiter)
          .append(logradouroInstalacao).append(delimiter)
          .append(numeroEnderecoInstalacao).append(delimiter)
          .append(complementoInstalacao).append(delimiter)
          .append(bairroInstalacao).append(delimiter)
          .append(cidadeInstalacao).append(delimiter)
          .append(ufInstalacao).append(delimiter)
          .append(cepInstalacao).append(delimiter)
          .append(caixaPostalInstalacao).append(delimiter)
          .append(rowidEnderecoInstalacao).append(delimiter)
          .append(codigoNacionalLocalidade).append(delimiter)
          .append(tipoAcesso).append(delimiter)
          .append(numeroContrato).append(delimiter)
          .append(dataHoraAtivacao).append(delimiter)
          .append(codigoComercialPlano).append(delimiter)
          .append(nomePlano).append(delimiter)
          .append(msisdn).append(delimiter)
          .append(statusContrato).append(delimiter)
          .append(dataHoraUltimoStatus).append(delimiter)
          .append(dataHoraUltimaAtualizacaoContrato).append(delimiter)
          .append(dataAgingCliente).append(delimiter)
          .append(codigoPdvAtivacao).append(delimiter)
          .append(codigoPdvUltimaModificacao).append(delimiter)
          .append(numeroSimcard).append(delimiter)
          .append(subtipoAcesso).append(delimiter)
          .append(motivoStatus).append(delimiter)
          .append(clientePermiteDivulgacaoListaTelefonica).append(delimiter)
          .append(loginResponsavelAtivacao).append(delimiter)
          .append(perfilLoginResponsavelAtivacao).append(delimiter)
          .append(perfilLoginModif).append(delimiter)
          .append(loginRespUltimaModif).append(delimiter)
          .append(flagContratoPertenceGrupoAcapulco).append(delimiter)
          .append(flagContratoAdministradorGrupoAcapulco).append(delimiter)
          .append(rowid).append(delimiter)
          .append(loteid).append(delimiter)
          .append(arquivo).append(delimiter)
          .append(arquivots).append(delimiter)
          .append(currentDate).append(delimiter)
          .append(idePromocao).append(delimiter)
          .append(dscSegmentoLinha).append(delimiter)
          .append(rowIdAcesso).append(delimiter)
          .append(dscPaisCliente).append(delimiter)
          .append(rowIdCliente).append(delimiter)
          .append(rowIdRootAcesso).append(delimiter)
          .append(rowIdPerfilFatura);

        return sb.toString();

    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getCpfCliente() {
        return cpfCliente;
    }

    public void setCpfCliente(String cpfCliente) {
        this.cpfCliente = cpfCliente;
    }

    public String getTipoLogradouroInstalacao() {
        return tipoLogradouroInstalacao;
    }

    public void setTipoLogradouroInstalacao(String tipoLogradouroInstalacao) {
        this.tipoLogradouroInstalacao = tipoLogradouroInstalacao;
    }

    public String getLogradouroInstalacao() {
        return logradouroInstalacao;
    }

    public void setLogradouroInstalacao(String logradouroInstalacao) {
        this.logradouroInstalacao = logradouroInstalacao;
    }

    public String getNumeroEnderecoInstalacao() {
        return numeroEnderecoInstalacao;
    }

    public void setNumeroEnderecoInstalacao(String numeroEnderecoInstalacao) {
        this.numeroEnderecoInstalacao = numeroEnderecoInstalacao;
    }

    public String getComplementoInstalacao() {
        return complementoInstalacao;
    }

    public void setComplementoInstalacao(String complementoInstalacao) {
        this.complementoInstalacao = complementoInstalacao;
    }

    public String getBairroInstalacao() {
        return bairroInstalacao;
    }

    public void setBairroInstalacao(String bairroInstalacao) {
        this.bairroInstalacao = bairroInstalacao;
    }

    public String getCidadeInstalacao() {
        return cidadeInstalacao;
    }

    public void setCidadeInstalacao(String cidadeInstalacao) {
        this.cidadeInstalacao = cidadeInstalacao;
    }

    public String getUfInstalacao() {
        return ufInstalacao;
    }

    public void setUfInstalacao(String ufInstalacao) {
        this.ufInstalacao = ufInstalacao;
    }

    public String getCepInstalacao() {
        return cepInstalacao;
    }

    public void setCepInstalacao(String cepInstalacao) {
        this.cepInstalacao = cepInstalacao;
    }

    public String getCaixaPostalInstalacao() {
        return caixaPostalInstalacao;
    }

    public void setCaixaPostalInstalacao(String caixaPostalInstalacao) {
        this.caixaPostalInstalacao = caixaPostalInstalacao;
    }

    public String getRowidEnderecoInstalacao() {
        return rowidEnderecoInstalacao;
    }

    public void setRowidEnderecoInstalacao(String rowidEnderecoInstalacao) {
        this.rowidEnderecoInstalacao = rowidEnderecoInstalacao;
    }

    public String getCodigoNacionalLocalidade() {
        return codigoNacionalLocalidade;
    }

    public void setCodigoNacionalLocalidade(String codigoNacionalLocalidade) {
        this.codigoNacionalLocalidade = codigoNacionalLocalidade;
    }

    public String getTipoAcesso() {
        return tipoAcesso;
    }

    public void setTipoAcesso(String tipoAcesso) {
        this.tipoAcesso = tipoAcesso;
    }

    public String getNumeroContrato() {
        return numeroContrato;
    }

    public void setNumeroContrato(String numeroContrato) {
        this.numeroContrato = numeroContrato;
    }

    public String getDataHoraAtivacao() {
        return dataHoraAtivacao;
    }

    public void setDataHoraAtivacao(String dataHoraAtivacao) {
        this.dataHoraAtivacao = dataHoraAtivacao;
    }

    public String getCodigoComercialPlano() {
        return codigoComercialPlano;
    }

    public void setCodigoComercialPlano(String codigoComercialPlano) {
        this.codigoComercialPlano = codigoComercialPlano;
    }

    public String getNomePlano() {
        return nomePlano;
    }

    public void setNomePlano(String nomePlano) {
        this.nomePlano = nomePlano;
    }

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    public String getStatusContrato() {
        return statusContrato;
    }

    public void setStatusContrato(String statusContrato) {
        this.statusContrato = statusContrato;
    }

    public String getDataHoraUltimoStatus() {
        return dataHoraUltimoStatus;
    }

    public void setDataHoraUltimoStatus(String dataHoraUltimoStatus) {
        this.dataHoraUltimoStatus = dataHoraUltimoStatus;
    }

    public String getDataHoraUltimaAtualizacaoContrato() {
        return dataHoraUltimaAtualizacaoContrato;
    }

    public void setDataHoraUltimaAtualizacaoContrato(String dataHoraUltimaAtualizacaoContrato) {
        this.dataHoraUltimaAtualizacaoContrato = dataHoraUltimaAtualizacaoContrato;
    }

    public String getDataAgingCliente() {
        return dataAgingCliente;
    }

    public void setDataAgingCliente(String dataAgingCliente) {
        this.dataAgingCliente = dataAgingCliente;
    }

    public String getCodigoPdvAtivacao() {
        return codigoPdvAtivacao;
    }

    public void setCodigoPdvAtivacao(String codigoPdvAtivacao) {
        this.codigoPdvAtivacao = codigoPdvAtivacao;
    }

    public String getCodigoPdvUltimaModificacao() {
        return codigoPdvUltimaModificacao;
    }

    public void setCodigoPdvUltimaModificacao(String codigoPdvUltimaModificacao) {
        this.codigoPdvUltimaModificacao = codigoPdvUltimaModificacao;
    }

    public String getNumeroSimcard() {
        return numeroSimcard;
    }

    public void setNumeroSimcard(String numeroSimcard) {
        this.numeroSimcard = numeroSimcard;
    }

    public String getSubtipoAcesso() {
        return subtipoAcesso;
    }

    public void setSubtipoAcesso(String subtipoAcesso) {
        this.subtipoAcesso = subtipoAcesso;
    }

    public String getMotivoStatus() {
        return motivoStatus;
    }

    public void setMotivoStatus(String motivoStatus) {
        this.motivoStatus = motivoStatus;
    }

    public String getClientePermiteDivulgacaoListaTelefonica() {
        return clientePermiteDivulgacaoListaTelefonica;
    }

    public void setClientePermiteDivulgacaoListaTelefonica(String clientePermiteDivulgacaoListaTelefonica) {
        this.clientePermiteDivulgacaoListaTelefonica = clientePermiteDivulgacaoListaTelefonica;
    }

    public String getLoginResponsavelAtivacao() {
        return loginResponsavelAtivacao;
    }

    public void setLoginResponsavelAtivacao(String loginResponsavelAtivacao) {
        this.loginResponsavelAtivacao = loginResponsavelAtivacao;
    }

    public String getPerfilLoginResponsavelAtivacao() {
        return perfilLoginResponsavelAtivacao;
    }

    public void setPerfilLoginResponsavelAtivacao(String perfilLoginResponsavelAtivacao) {
        this.perfilLoginResponsavelAtivacao = perfilLoginResponsavelAtivacao;
    }

    public String getPerfilLoginModif() {
        return perfilLoginModif;
    }

    public void setPerfilLoginModif(String perfilLoginModif) {
        this.perfilLoginModif = perfilLoginModif;
    }

    public String getLoginRespUltimaModif() {
        return loginRespUltimaModif;
    }

    public void setLoginRespUltimaModif(String loginRespUltimaModif) {
        this.loginRespUltimaModif = loginRespUltimaModif;
    }

    public String getFlagContratoPertenceGrupoAcapulco() {
        return flagContratoPertenceGrupoAcapulco;
    }

    public void setFlagContratoPertenceGrupoAcapulco(String flagContratoPertenceGrupoAcapulco) {
        this.flagContratoPertenceGrupoAcapulco = flagContratoPertenceGrupoAcapulco;
    }

    public String getFlagContratoAdministradorGrupoAcapulco() {
        return flagContratoAdministradorGrupoAcapulco;
    }

    public void setFlagContratoAdministradorGrupoAcapulco(String flagContratoAdministradorGrupoAcapulco) {
        this.flagContratoAdministradorGrupoAcapulco = flagContratoAdministradorGrupoAcapulco;
    }

    public String getRowid() {
        return rowid;
    }

    public void setRowid(String rowid) {
        this.rowid = rowid;
    }

    public String getLoteid() {
        return loteid;
    }

    public void setLoteid(String loteid) {
        this.loteid = loteid;
    }

    public String getArquivo() {
        return arquivo;
    }

    public void setArquivo(String arquivo) {
        this.arquivo = arquivo;
    }

    public String getArquivots() {
        return arquivots;
    }

    public void setArquivots(String arquivots) {
        this.arquivots = arquivots;
    }

    public String getCurrentDate() {
        return currentDate;
    }

    public void setCurrentDate(String currentDate) {
        this.currentDate = currentDate;
    }

    public String getIdePromocao() {
        return idePromocao;
    }

    public void setIdePromocao(String idePromocao) {
        this.idePromocao = idePromocao;
    }

    public String getDscSegmentoLinha() {
        return dscSegmentoLinha;
    }

    public void setDscSegmentoLinha(String dscSegmentoLinha) {
        this.dscSegmentoLinha = dscSegmentoLinha;
    }

    public String getRowIdAcesso() {
        return rowIdAcesso;
    }

    public void setRowIdAcesso(String rowIdAcesso) {
        this.rowIdAcesso = rowIdAcesso;
    }

    public String getDscPaisCliente() {
        return dscPaisCliente;
    }

    public void setDscPaisCliente(String dscPaisCliente) {
        this.dscPaisCliente = dscPaisCliente;
    }

    public String getRowIdCliente() {
        return rowIdCliente;
    }

    public void setRowIdCliente(String rowIdCliente) {
        this.rowIdCliente = rowIdCliente;
    }

    public String getRowIdRootAcesso() {
        return rowIdRootAcesso;
    }

    public void setRowIdRootAcesso(String rowIdRootAcesso) {
        this.rowIdRootAcesso = rowIdRootAcesso;
    }

    public String getRowIdPerfilFatura() {
        return rowIdPerfilFatura;
    }

    public void setRowIdPerfilFatura(String rowIdPerfilFatura) {
        this.rowIdPerfilFatura = rowIdPerfilFatura;
    }
}
