
package br.com.tim.mapreduce.refactoring.endtoend.step4.pt4;

import br.com.tim.mapreduce.refactoring.endtoend.step4.utils.Step4PT4Counters;
import br.com.tim.mapreduce.refactoring.model.CDRFiber;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

import java.io.IOException;

public class MapperFiber extends org.apache.hadoop.mapreduce.Mapper<Writable,Text,E2EStep4Pt4Key,E2EStep4Pt4Value> {

	private E2EStep4Pt4Key outkey;
	private E2EStep4Pt4Value outValue;
	private CDRFiber input;
	@Override
	protected void map(Writable key, Text value, Context context) throws IOException, InterruptedException {
		input.parse(value.toString());
		outkey.setNumAcesso(input.getChargeableuseridentity());
		outkey.setTipo(TypeStep4Pt4.Fiber);
		outValue.setFiber(input);
		context.write(outkey, outValue);
		context.getCounter(Step4PT4Counters.FIBER_MAPPER_WRITE).increment(1l);
	}

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		super.setup(context);
		this.outkey = new E2EStep4Pt4Key();
		this.outValue = new E2EStep4Pt4Value();
		this.input = new CDRFiber();
	}

	@Override
	protected void cleanup(Context context) throws IOException, InterruptedException {
		super.cleanup(context);
		this.clear();
	}

	private void clear(){
	   this.outValue.clear();
	}

}