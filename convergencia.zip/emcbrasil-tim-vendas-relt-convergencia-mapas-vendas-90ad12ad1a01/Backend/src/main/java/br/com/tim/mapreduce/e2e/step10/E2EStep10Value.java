
package br.com.tim.mapreduce.e2e.step10;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Writable;

import br.com.tim.mapreduce.e2e.step10.model.Step9PT2Result;
import br.com.tim.mapreduce.model.Wfmtoa;

public class E2EStep10Value implements Writable {
	
	protected TypeStep10 tipo;
	protected String datRef;
	protected String datCriacaoOrdem;
	protected String horCriacaoOrdem;
	protected String datVenda;
	protected String horaVenda;
	protected String datVendaOrig;
	protected String horVendaOrig;
	protected String datStatusOrdem;
	protected String horStatusOrdem;
	protected String numOrdemSiebel;
	protected String numOrdemSiebelOrig;
	protected String codContratoOltp;
	protected String codContratoAtivacao;
	protected String codContratoAtual;
	protected String numeroAcesso;
	protected String customerId;
	protected String tipoDocumento;
	protected String documento;
	protected String tipoVenda;
	protected String tipoProduto;
	protected String velocidadeDownload;
	protected String velocidadeUpload;
	protected String planoAtivacaoOferta;
	protected String loginVendedor;
	protected String loginVendedorOrig;
	protected String nomeVendedor;
	protected String nomeVendedorOrig;
	protected String canal;
	protected String canalOrig;
	protected String cnpjParceiro;
	protected String cnpjParceiroOrig;
	protected String custCode;
	protected String custCodeOrig;
	protected String position;
	protected String positionOrig;
	protected String parceiro;
	protected String parceiroOrig;
	protected String flgCancAntesVenda;
	protected String flgVendaSubmetida;
	protected String flgVendaDuplicada;
	protected String flgVendaBruta;
	protected String flgVendaLiquida;
	protected String flgGross;
	protected String flgChurn;
	protected String flgCancPosVenda;
	protected String flgCancDupl;
	protected String flgCancLiquido;
	protected String datGross;
	protected String datChurn;
	protected String motivoChurn;
	protected String tipoChurn;
	protected String datCancVenda;
	protected String motivoCancelamento;
	protected String nomeCliente;
	protected String telefone;
	protected String email;
	protected String uf;
	protected String tipoLogradouro;
	protected String logradouro;
	protected String numero;
	protected String complemento;
	protected String bairro;
	protected String cep;
	protected String cidade;
	protected String msanOltTrafego;
	protected String statusOrdem;
	protected String tecnologia;
	protected String formaPagamento;
	protected String tipoConta;
	protected String codBanco;
	protected String codAgenciaBanco;
	protected String codContaCorrente;
	protected String codDebitoAutomatico;
	protected String diaVencimento;
	protected String semanaVenda;
	protected String semanaVendaOrig;
	protected String score;
	protected String scoreConsumido;
	protected String datFinalizacaoOrdem;
	protected String qtdContratos;
	protected String codContaFinanceira;
	protected String numProtocolo;
	protected String flgOrdemAutomatica;
	protected String dscTxRecorrente;
	protected String dscTxNaoRecorrente;
	protected String dscStatusItem;
	protected String nomLoginResponsavel;
	protected String nomPlanoAtual;
	protected String valPlanoAtualItem;
	protected String nomDescontoAtualItem;
	protected String valDescontoAtualItem;
	protected String flgPortabilidade;
	protected String dscOperadoraDoadora;
	protected String codDdd;
	protected String numTelefonePortado;
	protected String datJanelaPortabilidade;
	protected String horJanela;
	protected String dscEnderecoFatura;
	protected String dscAreaVoip;
	protected String cpe;
	protected String ont;
	protected String codConvergente;
	protected String detalheRecusaCrivo;
	protected String itemRoot;
	protected String loginCancelamentoOrdem;
	protected String nomeUsuarioCancelouOrdem;
	protected String custcodeCliente;
	protected String dominioRoot;
	protected String datRefRelt;
	protected String msan_olt_venda;
	protected String dt_conclusao_wfm;
	protected String dscStatusOrdemWfm;
	protected String datStatusWfm;
	protected String horaStatusWfm;
	protected String idRecursoWfm;
	protected String nomRecursoWfm;
	protected String idRecursoPaiWfm;
	protected String datPrimeiroAgend;
	protected String horaPrimeiroAgendamento;
	protected String datAgendAtual;
	protected String horaAgendamentoAtual;
	protected String dscStatusAtivacao;
	
	

	@Override
	public void readFields(DataInput dataInput) throws IOException {
		this.tipo = TypeStep10.values()[dataInput.readInt()];
		this.datRef = dataInput.readUTF();
		this.datCriacaoOrdem = dataInput.readUTF();
		this.horCriacaoOrdem = dataInput.readUTF();
		this.datVenda = dataInput.readUTF();
		this.horaVenda = dataInput.readUTF();
		this.datVendaOrig = dataInput.readUTF();
		this.horVendaOrig = dataInput.readUTF();
		this.datStatusOrdem = dataInput.readUTF();
		this.horStatusOrdem = dataInput.readUTF();
		this.numOrdemSiebel = dataInput.readUTF();
		this.numOrdemSiebelOrig = dataInput.readUTF();
		this.codContratoOltp = dataInput.readUTF();
		this.codContratoAtivacao = dataInput.readUTF();
		this.codContratoAtual = dataInput.readUTF();
		this.numeroAcesso = dataInput.readUTF();
		this.customerId = dataInput.readUTF();
		this.tipoDocumento = dataInput.readUTF();
		this.documento = dataInput.readUTF();
		this.tipoVenda = dataInput.readUTF();
		this.tipoProduto = dataInput.readUTF();
		this.velocidadeDownload = dataInput.readUTF();
		this.velocidadeUpload = dataInput.readUTF();
		this.planoAtivacaoOferta = dataInput.readUTF();
		this.loginVendedor = dataInput.readUTF();
		this.loginVendedorOrig = dataInput.readUTF();
		this.nomeVendedor = dataInput.readUTF();
		this.nomeVendedorOrig = dataInput.readUTF();
		this.canal = dataInput.readUTF();
		this.canalOrig = dataInput.readUTF();
		this.cnpjParceiro = dataInput.readUTF();
		this.cnpjParceiroOrig = dataInput.readUTF();
		this.custCode = dataInput.readUTF();
		this.custCodeOrig = dataInput.readUTF();
		this.position = dataInput.readUTF();
		this.positionOrig = dataInput.readUTF();
		this.parceiro = dataInput.readUTF();
		this.parceiroOrig = dataInput.readUTF();
		this.flgCancAntesVenda = dataInput.readUTF();
		this.flgVendaSubmetida = dataInput.readUTF();
		this.flgVendaDuplicada = dataInput.readUTF();
		this.flgVendaBruta = dataInput.readUTF();
		this.flgVendaLiquida = dataInput.readUTF();
		this.flgGross = dataInput.readUTF();
		this.flgChurn = dataInput.readUTF();
		this.flgCancPosVenda = dataInput.readUTF();
		this.flgCancDupl = dataInput.readUTF();
		this.flgCancLiquido = dataInput.readUTF();
		this.datGross = dataInput.readUTF();
		this.datChurn = dataInput.readUTF();
		this.motivoChurn = dataInput.readUTF();
		this.tipoChurn = dataInput.readUTF();
		this.datCancVenda = dataInput.readUTF();
		this.motivoCancelamento = dataInput.readUTF();
		this.nomeCliente = dataInput.readUTF();
		this.telefone = dataInput.readUTF();
		this.email = dataInput.readUTF();
		this.uf = dataInput.readUTF();
		this.tipoLogradouro = dataInput.readUTF();
		this.logradouro = dataInput.readUTF();
		this.numero = dataInput.readUTF();
		this.complemento = dataInput.readUTF();
		this.bairro = dataInput.readUTF();
		this.cep = dataInput.readUTF();
		this.cidade = dataInput.readUTF();
		this.msanOltTrafego = dataInput.readUTF();
		this.statusOrdem = dataInput.readUTF();
		this.tecnologia = dataInput.readUTF();
		this.formaPagamento = dataInput.readUTF();
		this.tipoConta = dataInput.readUTF();
		this.codBanco = dataInput.readUTF();
		this.codAgenciaBanco = dataInput.readUTF();
		this.codContaCorrente = dataInput.readUTF();
		this.codDebitoAutomatico = dataInput.readUTF();
		this.diaVencimento = dataInput.readUTF();
		this.semanaVenda = dataInput.readUTF();
		this.semanaVendaOrig = dataInput.readUTF();
		this.score = dataInput.readUTF();
		this.scoreConsumido = dataInput.readUTF();
		this.datFinalizacaoOrdem = dataInput.readUTF();
		this.qtdContratos = dataInput.readUTF();
		this.codContaFinanceira = dataInput.readUTF();
		this.numProtocolo = dataInput.readUTF();
		this.flgOrdemAutomatica = dataInput.readUTF();
		this.dscTxRecorrente = dataInput.readUTF();
		this.dscTxNaoRecorrente = dataInput.readUTF();
		this.dscStatusItem = dataInput.readUTF();
		this.nomLoginResponsavel = dataInput.readUTF();
		this.nomPlanoAtual = dataInput.readUTF();
		this.valPlanoAtualItem = dataInput.readUTF();
		this.nomDescontoAtualItem = dataInput.readUTF();
		this.valDescontoAtualItem = dataInput.readUTF();
		this.flgPortabilidade = dataInput.readUTF();
		this.dscOperadoraDoadora = dataInput.readUTF();
		this.codDdd = dataInput.readUTF();
		this.numTelefonePortado = dataInput.readUTF();
		this.datJanelaPortabilidade = dataInput.readUTF();
		this.horJanela = dataInput.readUTF();
		this.dscEnderecoFatura = dataInput.readUTF();
		this.dscAreaVoip = dataInput.readUTF();
		this.cpe = dataInput.readUTF();
		this.ont = dataInput.readUTF();
		this.codConvergente = dataInput.readUTF();
		this.detalheRecusaCrivo = dataInput.readUTF();
		this.itemRoot = dataInput.readUTF();
		this.loginCancelamentoOrdem = dataInput.readUTF();
		this.nomeUsuarioCancelouOrdem = dataInput.readUTF();
		this.custcodeCliente = dataInput.readUTF();
		this.dominioRoot = dataInput.readUTF();
		this.datRefRelt = dataInput.readUTF();
		this.msan_olt_venda = dataInput.readUTF();
		this.dt_conclusao_wfm = dataInput.readUTF();
		this.dscStatusOrdemWfm = dataInput.readUTF();
		this.datStatusWfm = dataInput.readUTF();
		this.horaStatusWfm = dataInput.readUTF();
		this.idRecursoWfm = dataInput.readUTF();
		this.nomRecursoWfm = dataInput.readUTF();
		this.idRecursoPaiWfm = dataInput.readUTF();
		this.datPrimeiroAgend = dataInput.readUTF();
		this.horaPrimeiroAgendamento = dataInput.readUTF();
		this.datAgendAtual = dataInput.readUTF();
		this.horaAgendamentoAtual = dataInput.readUTF();
		this.dscStatusAtivacao = dataInput.readUTF();	
		
	}

	@Override
	public void write(DataOutput dataOutput) throws IOException {
		dataOutput.writeInt(tipo.ordinal());
		dataOutput.writeUTF(datRef);
		dataOutput.writeUTF(datCriacaoOrdem);
		dataOutput.writeUTF(horCriacaoOrdem);
		dataOutput.writeUTF(datVenda);
		dataOutput.writeUTF(horaVenda);
		dataOutput.writeUTF(datVendaOrig);
		dataOutput.writeUTF(horVendaOrig);
		dataOutput.writeUTF(datStatusOrdem);
		dataOutput.writeUTF(horStatusOrdem);
		dataOutput.writeUTF(numOrdemSiebel);
		dataOutput.writeUTF(numOrdemSiebelOrig);
		dataOutput.writeUTF(codContratoOltp);
		dataOutput.writeUTF(codContratoAtivacao);
		dataOutput.writeUTF(codContratoAtual);
		dataOutput.writeUTF(numeroAcesso);
		dataOutput.writeUTF(customerId);
		dataOutput.writeUTF(tipoDocumento);
		dataOutput.writeUTF(documento);
		dataOutput.writeUTF(tipoVenda);
		dataOutput.writeUTF(tipoProduto);
		dataOutput.writeUTF(velocidadeDownload);
		dataOutput.writeUTF(velocidadeUpload);
		dataOutput.writeUTF(planoAtivacaoOferta);
		dataOutput.writeUTF(loginVendedor);
		dataOutput.writeUTF(loginVendedorOrig);
		dataOutput.writeUTF(nomeVendedor);
		dataOutput.writeUTF(nomeVendedorOrig);
		dataOutput.writeUTF(canal);
		dataOutput.writeUTF(canalOrig);
		dataOutput.writeUTF(cnpjParceiro);
		dataOutput.writeUTF(cnpjParceiroOrig);
		dataOutput.writeUTF(custCode);
		dataOutput.writeUTF(custCodeOrig);
		dataOutput.writeUTF(position);
		dataOutput.writeUTF(positionOrig);
		dataOutput.writeUTF(parceiro);
		dataOutput.writeUTF(parceiroOrig);
		dataOutput.writeUTF(flgCancAntesVenda);
		dataOutput.writeUTF(flgVendaSubmetida);
		dataOutput.writeUTF(flgVendaDuplicada);
		dataOutput.writeUTF(flgVendaBruta);
		dataOutput.writeUTF(flgVendaLiquida);
		dataOutput.writeUTF(flgGross);
		dataOutput.writeUTF(flgChurn);
		dataOutput.writeUTF(flgCancPosVenda);
		dataOutput.writeUTF(flgCancDupl);
		dataOutput.writeUTF(flgCancLiquido);
		dataOutput.writeUTF(datGross);
		dataOutput.writeUTF(datChurn);
		dataOutput.writeUTF(motivoChurn);
		dataOutput.writeUTF(tipoChurn);
		dataOutput.writeUTF(datCancVenda);
		dataOutput.writeUTF(motivoCancelamento);
		dataOutput.writeUTF(nomeCliente);
		dataOutput.writeUTF(telefone);
		dataOutput.writeUTF(email);
		dataOutput.writeUTF(uf);
		dataOutput.writeUTF(tipoLogradouro);
		dataOutput.writeUTF(logradouro);
		dataOutput.writeUTF(numero);
		dataOutput.writeUTF(complemento);
		dataOutput.writeUTF(bairro);
		dataOutput.writeUTF(cep);
		dataOutput.writeUTF(cidade);
		dataOutput.writeUTF(msanOltTrafego);
		dataOutput.writeUTF(statusOrdem);
		dataOutput.writeUTF(tecnologia);
		dataOutput.writeUTF(formaPagamento);
		dataOutput.writeUTF(tipoConta);
		dataOutput.writeUTF(codBanco);
		dataOutput.writeUTF(codAgenciaBanco);
		dataOutput.writeUTF(codContaCorrente);
		dataOutput.writeUTF(codDebitoAutomatico);
		dataOutput.writeUTF(diaVencimento);
		dataOutput.writeUTF(semanaVenda);
		dataOutput.writeUTF(semanaVendaOrig);
		dataOutput.writeUTF(score);
		dataOutput.writeUTF(scoreConsumido);
		dataOutput.writeUTF(datFinalizacaoOrdem);
		dataOutput.writeUTF(qtdContratos);
		dataOutput.writeUTF(codContaFinanceira);
		dataOutput.writeUTF(numProtocolo);
		dataOutput.writeUTF(flgOrdemAutomatica);
		dataOutput.writeUTF(dscTxRecorrente);
		dataOutput.writeUTF(dscTxNaoRecorrente);
		dataOutput.writeUTF(dscStatusItem);
		dataOutput.writeUTF(nomLoginResponsavel);
		dataOutput.writeUTF(nomPlanoAtual);
		dataOutput.writeUTF(valPlanoAtualItem);
		dataOutput.writeUTF(nomDescontoAtualItem);
		dataOutput.writeUTF(valDescontoAtualItem);
		dataOutput.writeUTF(flgPortabilidade);
		dataOutput.writeUTF(dscOperadoraDoadora);
		dataOutput.writeUTF(codDdd);
		dataOutput.writeUTF(numTelefonePortado);
		dataOutput.writeUTF(datJanelaPortabilidade);
		dataOutput.writeUTF(horJanela);
		dataOutput.writeUTF(dscEnderecoFatura);
		dataOutput.writeUTF(dscAreaVoip);
		dataOutput.writeUTF(cpe);
		dataOutput.writeUTF(ont);
		dataOutput.writeUTF(codConvergente);
		dataOutput.writeUTF(detalheRecusaCrivo);
		dataOutput.writeUTF(itemRoot);
		dataOutput.writeUTF(loginCancelamentoOrdem);
		dataOutput.writeUTF(nomeUsuarioCancelouOrdem);
		dataOutput.writeUTF(custcodeCliente);
		dataOutput.writeUTF(dominioRoot);
		dataOutput.writeUTF(datRefRelt);
		dataOutput.writeUTF(msan_olt_venda);
		dataOutput.writeUTF(dt_conclusao_wfm);
		dataOutput.writeUTF(dscStatusOrdemWfm);
		dataOutput.writeUTF(datStatusWfm);
		dataOutput.writeUTF(horaStatusWfm);
		dataOutput.writeUTF(idRecursoWfm);
		dataOutput.writeUTF(nomRecursoWfm);
		dataOutput.writeUTF(idRecursoPaiWfm);
		dataOutput.writeUTF(datPrimeiroAgend);
		dataOutput.writeUTF(horaPrimeiroAgendamento);
		dataOutput.writeUTF(datAgendAtual);
		dataOutput.writeUTF(horaAgendamentoAtual);
		dataOutput.writeUTF(dscStatusAtivacao);
		
	}
	
	public void setStep9PT2Result(Step9PT2Result result) {
		this.clear();
		this.tipo = TypeStep10.RELT;
		
		this.datRef = result.getDatRef();
		this.datCriacaoOrdem = result.getDatCriacaoOrdem();
		this.horCriacaoOrdem = result.getHorCriacaoOrdem();
		this.datVenda = result.getDatVenda();
		this.horaVenda = result.getHoraVenda();
		this.datVendaOrig = result.getDatVendaOrig();
		this.horVendaOrig = result.getHorVendaOrig();
		this.datStatusOrdem = result.getDatStatusOrdem();
		this.horStatusOrdem = result.getHorStatusOrdem();
		this.numOrdemSiebel = result.getNumOrdemSiebel();
		this.numOrdemSiebelOrig = result.getNumOrdemSiebelOrig();
		this.codContratoOltp = result.getCodContratoOltp();
		this.codContratoAtivacao = result.getCodContratoAtivacao();
		this.codContratoAtual = result.getCodContratoAtual();
		this.numeroAcesso = result.getNumeroAcesso();
		this.customerId = result.getCustomerId();
		this.tipoDocumento = result.getTipoDocumento();
		this.documento = result.getDocumento();
		this.tipoVenda = result.getTipoVenda();
		this.tipoProduto = result.getTipoProduto();
		this.velocidadeDownload = result.getVelocidadeDownload();
		this.velocidadeUpload = result.getVelocidadeUpload();
		this.planoAtivacaoOferta = result.getPlanoAtivacaoOferta();
		this.loginVendedor = result.getLoginVendedor();
		this.loginVendedorOrig = result.getLoginVendedorOrig();
		this.nomeVendedor = result.getNomeVendedor();
		this.nomeVendedorOrig = result.getNomeVendedorOrig();
		this.canal = result.getCanal();
		this.canalOrig = result.getCanalOrig();
		this.cnpjParceiro = result.getCnpjParceiro();
		this.cnpjParceiroOrig = result.getCnpjParceiroOrig();
		this.custCode = result.getCustCode();
		this.custCodeOrig = result.getCustCodeOrig();
		this.position = result.getPosition();
		this.positionOrig = result.getPositionOrig();
		this.parceiro = result.getParceiro();
		this.parceiroOrig = result.getParceiroOrig();
		this.flgCancAntesVenda = result.getFlgCancAntesVenda();
		this.flgVendaSubmetida = result.getFlgVendaSubmetida();
		this.flgVendaDuplicada = result.getFlgVendaDuplicada();
		this.flgVendaBruta = result.getFlgVendaBruta();
		this.flgVendaLiquida = result.getFlgVendaLiquida();
		this.flgGross = result.getFlgGross();
		this.flgChurn = result.getFlgChurn();
		this.flgCancPosVenda = result.getFlgCancPosVenda();
		this.flgCancDupl = result.getFlgCancDupl();
		this.flgCancLiquido = result.getFlgCancLiquido();
		this.datGross = result.getDatGross();
		this.datChurn = result.getDatChurn();
		this.motivoChurn = result.getMotivoChurn();
		this.tipoChurn = result.getTipoChurn();
		this.datCancVenda = result.getDatCancVenda();
		this.motivoCancelamento = result.getMotivoCancelamento();
		this.nomeCliente = result.getNomeCliente();
		this.telefone = result.getTelefone();
		this.email = result.getEmail();
		this.uf = result.getUf();
		this.tipoLogradouro = result.getTipoLogradouro();
		this.logradouro = result.getLogradouro();
		this.numero = result.getNumero();
		this.complemento = result.getComplemento();
		this.bairro = result.getBairro();
		this.cep = result.getCep();
		this.cidade = result.getCidade();
		this.msanOltTrafego = result.getMsanOltTrafego();
		this.statusOrdem = result.getStatusOrdem();
		this.tecnologia = result.getTecnologia();
		this.formaPagamento = result.getFormaPagamento();
		this.tipoConta = result.getTipoConta();
		this.codBanco = result.getCodBanco();
		this.codAgenciaBanco = result.getCodAgenciaBanco();
		this.codContaCorrente = result.getCodContaCorrente();
		this.codDebitoAutomatico = result.getCodDebitoAutomatico();
		this.diaVencimento = result.getDiaVencimento();
		this.semanaVenda = result.getSemanaVenda();
		this.semanaVendaOrig = result.getSemanaVendaOrig();
		this.score = result.getScore();
		this.scoreConsumido = result.getScoreConsumido();
		this.datFinalizacaoOrdem = result.getDatFinalizacaoOrdem();
		this.qtdContratos = result.getQtdContratos();
		this.codContaFinanceira = result.getCodContaFinanceira();
		this.numProtocolo = result.getNumProtocolo();
		this.flgOrdemAutomatica = result.getFlgOrdemAutomatica();
		this.dscTxRecorrente = result.getDscTxRecorrente();
		this.dscTxNaoRecorrente = result.getDscTxNaoRecorrente();
		this.dscStatusItem = result.getDscStatusItem();
		this.nomLoginResponsavel = result.getNomLoginResponsavel();
		this.nomPlanoAtual = result.getNomPlanoAtual();
		this.valPlanoAtualItem = result.getValPlanoAtualItem();
		this.nomDescontoAtualItem = result.getNomDescontoAtualItem();
		this.valDescontoAtualItem = result.getValDescontoAtualItem();
		this.flgPortabilidade = result.getFlgPortabilidade();
		this.dscOperadoraDoadora = result.getDscOperadoraDoadora();
		this.codDdd = result.getCodDdd();
		this.numTelefonePortado = result.getNumTelefonePortado();
		this.datJanelaPortabilidade = result.getDatJanelaPortabilidade();
		this.horJanela = result.getHorJanela();
		this.dscEnderecoFatura = result.getDscEnderecoFatura();
		this.dscAreaVoip = result.getDscAreaVoip();
		this.cpe = result.getCpe();
		this.ont = result.getOnt();
		this.codConvergente = result.getCodConvergente();
		this.detalheRecusaCrivo = result.getDetalheRecusaCrivo();
		this.itemRoot = result.getItemRoot();
		this.loginCancelamentoOrdem = result.getLoginCancelamentoOrdem();
		this.nomeUsuarioCancelouOrdem = result.getNomeUsuarioCancelouOrdem();
		this.custcodeCliente = result.getCustcodeCliente();
		this.dominioRoot = result.getDominioRoot();
		this.datRefRelt = result.getDatRefRelt();

		
	}
	
	
	
	public void setWfmtoa(Wfmtoa wfm) {
		this.clear();
		this.tipo = TypeStep10.WFMTOA;
		this.msan_olt_venda = wfm.getXaPrimaryNetworkMsan();
		this.dt_conclusao_wfm = wfm.getQueueDate().trim() +" " + wfm.getEndTime().trim();
		this.dscStatusOrdemWfm = wfm.getAstatus();
	
		if(wfm.getAstatus().trim().equals("pending")) {
			this.datStatusWfm = wfm.getAtimeOfBooking().trim().substring(0, 10);
			this.horaStatusWfm = wfm.getAtimeOfBooking().trim().substring(11, 19); 
		}else if(wfm.getAstatus().trim().equals("suspended") ||
				wfm.getAstatus().trim().equals("notdone") ||
				wfm.getAstatus().trim().equals("completed")) {
			this.datStatusWfm = wfm.getQueueDate().trim() + " " + wfm.getEndTime().trim();
			this.horaStatusWfm = wfm.getEndTime();
		}else if(wfm.getAstatus().trim().equals("cancelled")) {
			this.datStatusWfm = "";
			this.horaStatusWfm = "";
		}
		
		this.idRecursoWfm = wfm.getExternalId();
		this.nomRecursoWfm = wfm.getPname();
		this.idRecursoPaiWfm = wfm.getParent();

		if (wfm.getaTimeOfBooking().trim().length() >=9) {
			this.datPrimeiroAgend = wfm.getaTimeOfBooking().trim().substring(0, 10);
		}
		
		if (wfm.getaTimeOfBooking().trim().length() >=20) {
			this.horaPrimeiroAgendamento = wfm.getaTimeOfBooking().trim().substring(11, 19);
		}
		
		if(wfm.getQueueDate().trim().length() >= 9) {
			this.datAgendAtual = wfm.getQueueDate().trim().substring(0, 10);
		}
		
		if(wfm.getEta().trim().length() >= 19) {
			this.horaAgendamentoAtual = wfm.getEta().trim().substring(11, 19); 
		}
		
		if(wfm.getaTimeOfBooking().trim().length() >= 9) {
			this.datPrimeiroAgend = wfm.getaTimeOfBooking().trim().substring(0, 10);
		}
				
		if (wfm.getaTimeOfBooking().trim().length() >=20) {
			this.horaPrimeiroAgendamento = wfm.getaTimeOfBooking().trim().substring(11, 19);
		}
		
		this.dscStatusAtivacao = wfm.getXaCompletionCode();
		
	}
	
	
	public void clear(){
        this.tipo = null;
        
        this.datRef = "";
        this.datCriacaoOrdem = "";
        this.horCriacaoOrdem = "";
        this.datVenda = "";
        this.horaVenda = "";
        this.datVendaOrig = "";
        this.horVendaOrig = "";
        this.datStatusOrdem = "";
        this.horStatusOrdem = "";
        this.numOrdemSiebel = "";
        this.numOrdemSiebelOrig = "";
        this.codContratoOltp = "";
        this.codContratoAtivacao = "";
        this.codContratoAtual = "";
        this.numeroAcesso = "";
        this.customerId = "";
        this.tipoDocumento = "";
        this.documento = "";
        this.tipoVenda = "";
        this.tipoProduto = "";
        this.velocidadeDownload = "";
        this.velocidadeUpload = "";
        this.planoAtivacaoOferta = "";
        this.loginVendedor = "";
        this.loginVendedorOrig = "";
        this.nomeVendedor = "";
        this.nomeVendedorOrig = "";
        this.canal = "";
        this.canalOrig = "";
        this.cnpjParceiro = "";
        this.cnpjParceiroOrig = "";
        this.custCode = "";
        this.custCodeOrig = "";
        this.position = "";
        this.positionOrig = "";
        this.parceiro = "";
        this.parceiroOrig = "";
        this.flgCancAntesVenda = "";
        this.flgVendaSubmetida = "";
        this.flgVendaDuplicada = "";
        this.flgVendaBruta = "";
        this.flgVendaLiquida = "";
        this.flgGross = "";
        this.flgChurn = "";
        this.flgCancPosVenda = "";
        this.flgCancDupl = "";
        this.flgCancLiquido = "";
        this.datGross = "";
        this.datChurn = "";
        this.motivoChurn = "";
        this.tipoChurn = "";
        this.datCancVenda = "";
        this.motivoCancelamento = "";
        this.nomeCliente = "";
        this.telefone = "";
        this.email = "";
        this.uf = "";
        this.tipoLogradouro = "";
        this.logradouro = "";
        this.numero = "";
        this.complemento = "";
        this.bairro = "";
        this.cep = "";
        this.cidade = "";
        this.msanOltTrafego = "";
        this.statusOrdem = "";
        this.tecnologia = "";
        this.formaPagamento = "";
        this.tipoConta = "";
        this.codBanco = "";
        this.codAgenciaBanco = "";
        this.codContaCorrente = "";
        this.codDebitoAutomatico = "";
        this.diaVencimento = "";
        this.semanaVenda = "";
        this.semanaVendaOrig = "";
        this.score = "";
        this.scoreConsumido = "";
        this.datFinalizacaoOrdem = "";
        this.qtdContratos = "";
        this.codContaFinanceira = "";
        this.numProtocolo = "";
        this.flgOrdemAutomatica = "";
        this.dscTxRecorrente = "";
        this.dscTxNaoRecorrente = "";
        this.dscStatusItem = "";
        this.nomLoginResponsavel = "";
        this.nomPlanoAtual = "";
        this.valPlanoAtualItem = "";
        this.nomDescontoAtualItem = "";
        this.valDescontoAtualItem = "";
        this.flgPortabilidade = "";
        this.dscOperadoraDoadora = "";
        this.codDdd = "";
        this.numTelefonePortado = "";
        this.datJanelaPortabilidade = "";
        this.horJanela = "";
        this.dscEnderecoFatura = "";
        this.dscAreaVoip = "";
        this.cpe = "";
        this.ont = "";
        this.codConvergente = "";
        this.detalheRecusaCrivo = "";
        this.itemRoot = "";
        this.loginCancelamentoOrdem = "";
        this.nomeUsuarioCancelouOrdem = "";
        this.custcodeCliente = "";
        this.dominioRoot = "";
        this.datRefRelt = "";
        this.msan_olt_venda = "";
        this.dt_conclusao_wfm = "";
        this.dscStatusOrdemWfm = "";
        this.datStatusWfm = "";
        this.horaStatusWfm = "";
        this.idRecursoWfm = "";
        this.nomRecursoWfm = "";
        this.idRecursoPaiWfm = "";
        this.datPrimeiroAgend = "";
        this.horaPrimeiroAgendamento = "";
        this.datAgendAtual = "";
        this.horaAgendamentoAtual = "";
        this.dscStatusAtivacao = "";        
	}

	
	public TypeStep10 getTipo() {
		return tipo;
	}

	public void setTipo(TypeStep10 tipo) {
		this.tipo = tipo;
	}

	public String getDatRef() {
		return datRef;
	}

	public void setDatRef(String datRef) {
		this.datRef = datRef;
	}

	public String getDatCriacaoOrdem() {
		return datCriacaoOrdem;
	}

	public void setDatCriacaoOrdem(String datCriacaoOrdem) {
		this.datCriacaoOrdem = datCriacaoOrdem;
	}

	public String getHorCriacaoOrdem() {
		return horCriacaoOrdem;
	}

	public void setHorCriacaoOrdem(String horCriacaoOrdem) {
		this.horCriacaoOrdem = horCriacaoOrdem;
	}

	public String getDatVenda() {
		return datVenda;
	}

	public void setDatVenda(String datVenda) {
		this.datVenda = datVenda;
	}

	public String getHoraVenda() {
		return horaVenda;
	}

	public void setHoraVenda(String horaVenda) {
		this.horaVenda = horaVenda;
	}

	public String getDatVendaOrig() {
		return datVendaOrig;
	}

	public void setDatVendaOrig(String datVendaOrig) {
		this.datVendaOrig = datVendaOrig;
	}

	public String getHorVendaOrig() {
		return horVendaOrig;
	}

	public void setHorVendaOrig(String horVendaOrig) {
		this.horVendaOrig = horVendaOrig;
	}

	public String getDatStatusOrdem() {
		return datStatusOrdem;
	}

	public void setDatStatusOrdem(String datStatusOrdem) {
		this.datStatusOrdem = datStatusOrdem;
	}

	public String getHorStatusOrdem() {
		return horStatusOrdem;
	}

	public void setHorStatusOrdem(String horStatusOrdem) {
		this.horStatusOrdem = horStatusOrdem;
	}

	public String getNumOrdemSiebelOrig() {
		return numOrdemSiebelOrig;
	}

	public void setNumOrdemSiebelOrig(String numOrdemSiebelOrig) {
		this.numOrdemSiebelOrig = numOrdemSiebelOrig;
	}

	public String getCodContratoOltp() {
		return codContratoOltp;
	}

	public void setCodContratoOltp(String codContratoOltp) {
		this.codContratoOltp = codContratoOltp;
	}

	public String getCodContratoAtivacao() {
		return codContratoAtivacao;
	}

	public void setCodContratoAtivacao(String codContratoAtivacao) {
		this.codContratoAtivacao = codContratoAtivacao;
	}

	public String getCodContratoAtual() {
		return codContratoAtual;
	}

	public void setCodContratoAtual(String codContratoAtual) {
		this.codContratoAtual = codContratoAtual;
	}

	public String getNumeroAcesso() {
		return numeroAcesso;
	}

	public void setNumeroAcesso(String numeroAcesso) {
		this.numeroAcesso = numeroAcesso;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public String getDocumento() {
		return documento;
	}

	public void setDocumento(String documento) {
		this.documento = documento;
	}

	public String getTipoVenda() {
		return tipoVenda;
	}

	public void setTipoVenda(String tipoVenda) {
		this.tipoVenda = tipoVenda;
	}

	public String getTipoProduto() {
		return tipoProduto;
	}

	public void setTipoProduto(String tipoProduto) {
		this.tipoProduto = tipoProduto;
	}

	public String getVelocidadeDownload() {
		return velocidadeDownload;
	}

	public void setVelocidadeDownload(String velocidadeDownload) {
		this.velocidadeDownload = velocidadeDownload;
	}

	public String getVelocidadeUpload() {
		return velocidadeUpload;
	}

	public void setVelocidadeUpload(String velocidadeUpload) {
		this.velocidadeUpload = velocidadeUpload;
	}

	public String getPlanoAtivacaoOferta() {
		return planoAtivacaoOferta;
	}

	public void setPlanoAtivacaoOferta(String planoAtivacaoOferta) {
		this.planoAtivacaoOferta = planoAtivacaoOferta;
	}

	public String getLoginVendedor() {
		return loginVendedor;
	}

	public void setLoginVendedor(String loginVendedor) {
		this.loginVendedor = loginVendedor;
	}

	public String getLoginVendedorOrig() {
		return loginVendedorOrig;
	}

	public void setLoginVendedorOrig(String loginVendedorOrig) {
		this.loginVendedorOrig = loginVendedorOrig;
	}

	public String getNomeVendedor() {
		return nomeVendedor;
	}

	public void setNomeVendedor(String nomeVendedor) {
		this.nomeVendedor = nomeVendedor;
	}

	public String getNomeVendedorOrig() {
		return nomeVendedorOrig;
	}

	public void setNomeVendedorOrig(String nomeVendedorOrig) {
		this.nomeVendedorOrig = nomeVendedorOrig;
	}

	public String getCanal() {
		return canal;
	}

	public void setCanal(String canal) {
		this.canal = canal;
	}

	public String getCanalOrig() {
		return canalOrig;
	}

	public void setCanalOrig(String canalOrig) {
		this.canalOrig = canalOrig;
	}

	public String getCnpjParceiro() {
		return cnpjParceiro;
	}

	public void setCnpjParceiro(String cnpjParceiro) {
		this.cnpjParceiro = cnpjParceiro;
	}

	public String getCnpjParceiroOrig() {
		return cnpjParceiroOrig;
	}

	public void setCnpjParceiroOrig(String cnpjParceiroOrig) {
		this.cnpjParceiroOrig = cnpjParceiroOrig;
	}

	public String getCustCode() {
		return custCode;
	}

	public void setCustCode(String custCode) {
		this.custCode = custCode;
	}

	public String getCustCodeOrig() {
		return custCodeOrig;
	}

	public void setCustCodeOrig(String custCodeOrig) {
		this.custCodeOrig = custCodeOrig;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getPositionOrig() {
		return positionOrig;
	}

	public void setPositionOrig(String positionOrig) {
		this.positionOrig = positionOrig;
	}

	public String getParceiro() {
		return parceiro;
	}

	public void setParceiro(String parceiro) {
		this.parceiro = parceiro;
	}

	public String getParceiroOrig() {
		return parceiroOrig;
	}

	public void setParceiroOrig(String parceiroOrig) {
		this.parceiroOrig = parceiroOrig;
	}

	public String getFlgCancAntesVenda() {
		return flgCancAntesVenda;
	}

	public void setFlgCancAntesVenda(String flgCancAntesVenda) {
		this.flgCancAntesVenda = flgCancAntesVenda;
	}

	public String getFlgVendaSubmetida() {
		return flgVendaSubmetida;
	}

	public void setFlgVendaSubmetida(String flgVendaSubmetida) {
		this.flgVendaSubmetida = flgVendaSubmetida;
	}

	public String getFlgVendaDuplicada() {
		return flgVendaDuplicada;
	}

	public void setFlgVendaDuplicada(String flgVendaDuplicada) {
		this.flgVendaDuplicada = flgVendaDuplicada;
	}

	public String getFlgVendaBruta() {
		return flgVendaBruta;
	}

	public void setFlgVendaBruta(String flgVendaBruta) {
		this.flgVendaBruta = flgVendaBruta;
	}

	public String getFlgVendaLiquida() {
		return flgVendaLiquida;
	}

	public void setFlgVendaLiquida(String flgVendaLiquida) {
		this.flgVendaLiquida = flgVendaLiquida;
	}

	public String getFlgGross() {
		return flgGross;
	}

	public void setFlgGross(String flgGross) {
		this.flgGross = flgGross;
	}

	public String getFlgChurn() {
		return flgChurn;
	}

	public void setFlgChurn(String flgChurn) {
		this.flgChurn = flgChurn;
	}

	public String getFlgCancPosVenda() {
		return flgCancPosVenda;
	}

	public void setFlgCancPosVenda(String flgCancPosVenda) {
		this.flgCancPosVenda = flgCancPosVenda;
	}

	public String getFlgCancDupl() {
		return flgCancDupl;
	}

	public void setFlgCancDupl(String flgCancDupl) {
		this.flgCancDupl = flgCancDupl;
	}

	public String getFlgCancLiquido() {
		return flgCancLiquido;
	}

	public void setFlgCancLiquido(String flgCancLiquido) {
		this.flgCancLiquido = flgCancLiquido;
	}

	public String getDatGross() {
		return datGross;
	}

	public void setDatGross(String datGross) {
		this.datGross = datGross;
	}

	public String getDatChurn() {
		return datChurn;
	}

	public void setDatChurn(String datChurn) {
		this.datChurn = datChurn;
	}

	public String getMotivoChurn() {
		return motivoChurn;
	}

	public void setMotivoChurn(String motivoChurn) {
		this.motivoChurn = motivoChurn;
	}

	public String getTipoChurn() {
		return tipoChurn;
	}

	public void setTipoChurn(String tipoChurn) {
		this.tipoChurn = tipoChurn;
	}

	public String getDatCancVenda() {
		return datCancVenda;
	}

	public void setDatCancVenda(String datCancVenda) {
		this.datCancVenda = datCancVenda;
	}

	public String getMotivoCancelamento() {
		return motivoCancelamento;
	}

	public void setMotivoCancelamento(String motivoCancelamento) {
		this.motivoCancelamento = motivoCancelamento;
	}

	public String getNomeCliente() {
		return nomeCliente;
	}

	public void setNomeCliente(String nomeCliente) {
		this.nomeCliente = nomeCliente;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	public String getTipoLogradouro() {
		return tipoLogradouro;
	}

	public void setTipoLogradouro(String tipoLogradouro) {
		this.tipoLogradouro = tipoLogradouro;
	}

	public String getLogradouro() {
		return logradouro;
	}

	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getComplemento() {
		return complemento;
	}

	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getMsanOltTrafego() {
		return msanOltTrafego;
	}

	public void setMsanOltTrafego(String msanOltTrafego) {
		this.msanOltTrafego = msanOltTrafego;
	}

	public String getStatusOrdem() {
		return statusOrdem;
	}

	public void setStatusOrdem(String statusOrdem) {
		this.statusOrdem = statusOrdem;
	}

	public String getTecnologia() {
		return tecnologia;
	}

	public void setTecnologia(String tecnologia) {
		this.tecnologia = tecnologia;
	}

	public String getFormaPagamento() {
		return formaPagamento;
	}

	public void setFormaPagamento(String formaPagamento) {
		this.formaPagamento = formaPagamento;
	}

	public String getTipoConta() {
		return tipoConta;
	}

	public void setTipoConta(String tipoConta) {
		this.tipoConta = tipoConta;
	}

	public String getCodBanco() {
		return codBanco;
	}

	public void setCodBanco(String codBanco) {
		this.codBanco = codBanco;
	}

	public String getCodAgenciaBanco() {
		return codAgenciaBanco;
	}

	public void setCodAgenciaBanco(String codAgenciaBanco) {
		this.codAgenciaBanco = codAgenciaBanco;
	}

	public String getCodContaCorrente() {
		return codContaCorrente;
	}

	public void setCodContaCorrente(String codContaCorrente) {
		this.codContaCorrente = codContaCorrente;
	}

	public String getCodDebitoAutomatico() {
		return codDebitoAutomatico;
	}

	public void setCodDebitoAutomatico(String codDebitoAutomatico) {
		this.codDebitoAutomatico = codDebitoAutomatico;
	}

	public String getDiaVencimento() {
		return diaVencimento;
	}

	public void setDiaVencimento(String diaVencimento) {
		this.diaVencimento = diaVencimento;
	}

	public String getSemanaVenda() {
		return semanaVenda;
	}

	public void setSemanaVenda(String semanaVenda) {
		this.semanaVenda = semanaVenda;
	}

	public String getSemanaVendaOrig() {
		return semanaVendaOrig;
	}

	public void setSemanaVendaOrig(String semanaVendaOrig) {
		this.semanaVendaOrig = semanaVendaOrig;
	}

	public String getScore() {
		return score;
	}

	public void setScore(String score) {
		this.score = score;
	}

	public String getScoreConsumido() {
		return scoreConsumido;
	}

	public void setScoreConsumido(String scoreConsumido) {
		this.scoreConsumido = scoreConsumido;
	}

	public String getDatFinalizacaoOrdem() {
		return datFinalizacaoOrdem;
	}

	public void setDatFinalizacaoOrdem(String datFinalizacaoOrdem) {
		this.datFinalizacaoOrdem = datFinalizacaoOrdem;
	}

	public String getQtdContratos() {
		return qtdContratos;
	}

	public void setQtdContratos(String qtdContratos) {
		this.qtdContratos = qtdContratos;
	}

	public String getCodContaFinanceira() {
		return codContaFinanceira;
	}

	public void setCodContaFinanceira(String codContaFinanceira) {
		this.codContaFinanceira = codContaFinanceira;
	}

	public String getNumProtocolo() {
		return numProtocolo;
	}

	public void setNumProtocolo(String numProtocolo) {
		this.numProtocolo = numProtocolo;
	}

	public String getFlgOrdemAutomatica() {
		return flgOrdemAutomatica;
	}

	public void setFlgOrdemAutomatica(String flgOrdemAutomatica) {
		this.flgOrdemAutomatica = flgOrdemAutomatica;
	}

	public String getDscTxRecorrente() {
		return dscTxRecorrente;
	}

	public void setDscTxRecorrente(String dscTxRecorrente) {
		this.dscTxRecorrente = dscTxRecorrente;
	}

	public String getDscTxNaoRecorrente() {
		return dscTxNaoRecorrente;
	}

	public void setDscTxNaoRecorrente(String dscTxNaoRecorrente) {
		this.dscTxNaoRecorrente = dscTxNaoRecorrente;
	}

	public String getDscStatusItem() {
		return dscStatusItem;
	}

	public void setDscStatusItem(String dscStatusItem) {
		this.dscStatusItem = dscStatusItem;
	}

	public String getNomLoginResponsavel() {
		return nomLoginResponsavel;
	}

	public void setNomLoginResponsavel(String nomLoginResponsavel) {
		this.nomLoginResponsavel = nomLoginResponsavel;
	}

	public String getNomPlanoAtual() {
		return nomPlanoAtual;
	}

	public void setNomPlanoAtual(String nomPlanoAtual) {
		this.nomPlanoAtual = nomPlanoAtual;
	}

	public String getValPlanoAtualItem() {
		return valPlanoAtualItem;
	}

	public void setValPlanoAtualItem(String valPlanoAtualItem) {
		this.valPlanoAtualItem = valPlanoAtualItem;
	}

	public String getNomDescontoAtualItem() {
		return nomDescontoAtualItem;
	}

	public void setNomDescontoAtualItem(String nomDescontoAtualItem) {
		this.nomDescontoAtualItem = nomDescontoAtualItem;
	}

	public String getValDescontoAtualItem() {
		return valDescontoAtualItem;
	}

	public void setValDescontoAtualItem(String valDescontoAtualItem) {
		this.valDescontoAtualItem = valDescontoAtualItem;
	}

	public String getFlgPortabilidade() {
		return flgPortabilidade;
	}

	public void setFlgPortabilidade(String flgPortabilidade) {
		this.flgPortabilidade = flgPortabilidade;
	}

	public String getDscOperadoraDoadora() {
		return dscOperadoraDoadora;
	}

	public void setDscOperadoraDoadora(String dscOperadoraDoadora) {
		this.dscOperadoraDoadora = dscOperadoraDoadora;
	}

	public String getCodDdd() {
		return codDdd;
	}

	public void setCodDdd(String codDdd) {
		this.codDdd = codDdd;
	}

	public String getNumTelefonePortado() {
		return numTelefonePortado;
	}

	public void setNumTelefonePortado(String numTelefonePortado) {
		this.numTelefonePortado = numTelefonePortado;
	}

	public String getDatJanelaPortabilidade() {
		return datJanelaPortabilidade;
	}

	public void setDatJanelaPortabilidade(String datJanelaPortabilidade) {
		this.datJanelaPortabilidade = datJanelaPortabilidade;
	}

	public String getHorJanela() {
		return horJanela;
	}

	public void setHorJanela(String horJanela) {
		this.horJanela = horJanela;
	}

	public String getDscEnderecoFatura() {
		return dscEnderecoFatura;
	}

	public void setDscEnderecoFatura(String dscEnderecoFatura) {
		this.dscEnderecoFatura = dscEnderecoFatura;
	}

	public String getDscAreaVoip() {
		return dscAreaVoip;
	}

	public void setDscAreaVoip(String dscAreaVoip) {
		this.dscAreaVoip = dscAreaVoip;
	}

	public String getCpe() {
		return cpe;
	}

	public void setCpe(String cpe) {
		this.cpe = cpe;
	}

	public String getOnt() {
		return ont;
	}

	public void setOnt(String ont) {
		this.ont = ont;
	}

	public String getCodConvergente() {
		return codConvergente;
	}

	public void setCodConvergente(String codConvergente) {
		this.codConvergente = codConvergente;
	}

	public String getDetalheRecusaCrivo() {
		return detalheRecusaCrivo;
	}

	public void setDetalheRecusaCrivo(String detalheRecusaCrivo) {
		this.detalheRecusaCrivo = detalheRecusaCrivo;
	}

	public String getItemRoot() {
		return itemRoot;
	}

	public void setItemRoot(String itemRoot) {
		this.itemRoot = itemRoot;
	}

	public String getLoginCancelamentoOrdem() {
		return loginCancelamentoOrdem;
	}

	public void setLoginCancelamentoOrdem(String loginCancelamentoOrdem) {
		this.loginCancelamentoOrdem = loginCancelamentoOrdem;
	}

	public String getNomeUsuarioCancelouOrdem() {
		return nomeUsuarioCancelouOrdem;
	}

	public void setNomeUsuarioCancelouOrdem(String nomeUsuarioCancelouOrdem) {
		this.nomeUsuarioCancelouOrdem = nomeUsuarioCancelouOrdem;
	}

	public String getCustcodeCliente() {
		return custcodeCliente;
	}

	public void setCustcodeCliente(String custcodeCliente) {
		this.custcodeCliente = custcodeCliente;
	}

	public String getDominioRoot() {
		return dominioRoot;
	}

	public void setDominioRoot(String dominioRoot) {
		this.dominioRoot = dominioRoot;
	}

	public String getDatRefRelt() {
		return datRefRelt;
	}

	public void setDatRefRelt(String datRefRelt) {
		this.datRefRelt = datRefRelt;
	}

	public String getMsan_olt_venda() {
		return msan_olt_venda;
	}

	public void setMsan_olt_venda(String msan_olt_venda) {
		this.msan_olt_venda = msan_olt_venda;
	}

	public String getDt_conclusao_wfm() {
		return dt_conclusao_wfm;
	}

	public void setDt_conclusao_wfm(String dt_conclusao_wfm) {
		this.dt_conclusao_wfm = dt_conclusao_wfm;
	}

	public String getDscStatusOrdemWfm() {
		return dscStatusOrdemWfm;
	}

	public void setDscStatusOrdemWfm(String dscStatusOrdemWfm) {
		this.dscStatusOrdemWfm = dscStatusOrdemWfm;
	}

	public String getDatStatusWfm() {
		return datStatusWfm;
	}

	public void setDatStatusWfm(String datStatusWfm) {
		this.datStatusWfm = datStatusWfm;
	}

	public String getHoraStatusWfm() {
		return horaStatusWfm;
	}

	public void setHoraStatusWfm(String horaStatusWfm) {
		this.horaStatusWfm = horaStatusWfm;
	}

	public String getIdRecursoWfm() {
		return idRecursoWfm;
	}

	public void setIdRecursoWfm(String idRecursoWfm) {
		this.idRecursoWfm = idRecursoWfm;
	}

	public String getNomRecursoWfm() {
		return nomRecursoWfm;
	}

	public void setNomRecursoWfm(String nomRecursoWfm) {
		this.nomRecursoWfm = nomRecursoWfm;
	}

	public String getIdRecursoPaiWfm() {
		return idRecursoPaiWfm;
	}

	public void setIdRecursoPaiWfm(String idRecursoPaiWfm) {
		this.idRecursoPaiWfm = idRecursoPaiWfm;
	}

	public String getDatPrimeiroAgend() {
		return datPrimeiroAgend;
	}

	public void setDatPrimeiroAgend(String datPrimeiroAgend) {
		this.datPrimeiroAgend = datPrimeiroAgend;
	}

	public String getHoraPrimeiroAgendamento() {
		return horaPrimeiroAgendamento;
	}

	public void setHoraPrimeiroAgendamento(String horaPrimeiroAgendamento) {
		this.horaPrimeiroAgendamento = horaPrimeiroAgendamento;
	}

	public String getDatAgendAtual() {
		return datAgendAtual;
	}

	public void setDatAgendAtual(String datAgendAtual) {
		this.datAgendAtual = datAgendAtual;
	}

	public String getHoraAgendamentoAtual() {
		return horaAgendamentoAtual;
	}

	public void setHoraAgendamentoAtual(String horaAgendamentoAtual) {
		this.horaAgendamentoAtual = horaAgendamentoAtual;
	}

	public String getDscStatusAtivacao() {
		return dscStatusAtivacao;
	}

	public void setDscStatusAtivacao(String dscStatusAtivacao) {
		this.dscStatusAtivacao = dscStatusAtivacao;
	}
	public String getNumOrdemSiebel() {
		return numOrdemSiebel;
	}

	public void setNumOrdemSiebel(String numOrdemSiebel) {
		this.numOrdemSiebel = numOrdemSiebel;
	}
	
}
