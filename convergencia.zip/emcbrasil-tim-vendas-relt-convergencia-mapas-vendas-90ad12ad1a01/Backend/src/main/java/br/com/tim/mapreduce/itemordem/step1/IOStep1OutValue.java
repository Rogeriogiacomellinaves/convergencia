package br.com.tim.mapreduce.itemordem.step1;

public class IOStep1OutValue {

    private String nroOrdem;
    private String nomBairro;
    private String cep;
    private String nomCidade;
    private String numCNPJParcVenda;
    private String dscComplemento;
    private String datDesconexao;
    private String datVenda;
    private String dscLogradouro;
    private String numLogradouro;
    private String nomPlanoAtual;
    private String nomPlanoNovo;
    private String numTelefone;
    private String dscTipoLogradouro;
    private String nomProduto;
    private String dscTipoMotivo;
    private String sglUFInstalacao;
    private String datRef;
    private String dscAcaoItemOrdem;
    private String dscStatusItem;
    private String email;
    private String dscTipoOrdem;
    private String dscFormaPgto;
    private String codCtaFinanceira;
    private String codContratoOltp;
    private String numProtocolo;
    private String datCriacaoOrdem;
    private String datStatusOrdem;
    private String datSuspensao;
    private String datReativacao;
    private String codServiceId;
    private String nomContato;
    private String dscMotivoStatusItem;
    private String nomLoginResponsavel;
    private String nomLoginVendedor;
    private String dscCanalVenda;
    private String valPlanoAtual;
    private String nomDescontoAtual;
    private String valDescontoAtual;
    private String valPlanoNovo;
    private String nomDescontoNovo;
    private String valDescontoNovo;
    private String flgPortabilidade;
    private String codDdd;
    private String numTelefonePortado;
    private String datJanelaPortabilidade;
    private String dscEstorno;
    private String numBilheteEstornado;
    private String dscMotivoEstorno;
    private String dscStatusOrdemWfm;
    private String datHoraStatusWfm;
    private String diaVencimento;
    private String dscTipoConta;
    private String dscEnderecoFatura;
    private String dscAreaVoip;
    private String codBanco;
    private String codAgenciaBco;
    private String codContaCorrente;
    private String datAltFormaPgto;
    private String codDebitoAutomatico;
    private String codItemOrdem;
    private String nomParceiroVenda;
    private String idItemOrdPai;
    private String idItemOrdem;
    private String dscCategoriaItem;
    private String tecnologia;
    private String cpe;
    private String ont;
    private String numTelefone2;
    private String numtelefone3;
    private String dominioRoot;
    private String codProduto;

    public void setNroOrdem(String nroOrdem) {
        this.nroOrdem = nroOrdem;
    }

    public void clear(){
        this.nroOrdem = "";
        this.nomBairro = "";
        this.cep = "";
        this.nomCidade = "";
        this.numCNPJParcVenda = "";
        this.dscComplemento = "";
        this.datDesconexao = "";
        this.datVenda = "";
        this.dscLogradouro = "";
        this.numLogradouro = "";
        this.nomPlanoAtual = "";
        this.nomPlanoNovo = "";
        this.numTelefone = "";
        this.dscTipoLogradouro = "";
        this.nomProduto = "";
        this.dscTipoMotivo = "";
        this.sglUFInstalacao = "";
        this.datRef = "";
        this.dscAcaoItemOrdem = "";
        this.dscStatusItem = "";
        this.email = "";
        this.dscTipoOrdem = "";
        this.dscFormaPgto = "";
        this.codCtaFinanceira = "";
        this.codContratoOltp = "";
        this.numProtocolo = "";
        this.datCriacaoOrdem = "";
        this.datStatusOrdem = "";
        this.datSuspensao = "";
        this.datReativacao = "";
        this.codServiceId = "";
        this.nomContato = "";
        this.dscMotivoStatusItem = "";
        this.nomLoginResponsavel = "";
        this.nomLoginVendedor = "";
        this.dscCanalVenda = "";
        this.valPlanoAtual = "";
        this.nomDescontoAtual = "";
        this.valDescontoAtual = "";
        this.valPlanoNovo = "";
        this.nomDescontoNovo = "";
        this.valDescontoNovo = "";
        this.flgPortabilidade = "";
        this.codDdd = "";
        this.numTelefonePortado = "";
        this.datJanelaPortabilidade = "";
        this.dscEstorno = "";
        this.numBilheteEstornado = "";
        this.dscMotivoEstorno = "";
        this.dscStatusOrdemWfm = "";
        this.datHoraStatusWfm = "";
        this.diaVencimento = "";
        this.dscTipoConta = "";
        this.dscEnderecoFatura = "";
        this.dscAreaVoip = "";
        this.codBanco = "";
        this.codAgenciaBco = "";
        this.codContaCorrente = "";
        this.datAltFormaPgto = "";
        this.codDebitoAutomatico = "";
        this.codItemOrdem = "";
        this.nomParceiroVenda = "";
        this.idItemOrdPai = "";
        this.idItemOrdem = "";
        this.dscCategoriaItem = "";
        this.tecnologia = "";
        this.cpe = "";
        this.ont = "";
        this.numTelefone2 = "";
        this.numtelefone3 = "";
        this.dominioRoot = "";
        this.codProduto = "";
    }

    public void setItem(IOStep1Value item) {
        this.nomBairro = item.getNomBairro();
        this.cep = item.getCep();
        this.nomCidade = item.getNomCidade();
        this.dscComplemento = item.getDscComplemento();
        this.datDesconexao = item.getDatDesconexao();
        this.dscLogradouro = item.getDscLogradouro();
        this.numLogradouro = item.getNumLogradouro();
        this.nomPlanoAtual = item.getNomPlanoAtual();
        this.nomPlanoNovo = item.getNomPlanoNovo();
        this.numTelefone = item.getNumTelefone();
        this.dscTipoLogradouro = item.getDscTipoLogradouro();
        this.nomProduto = item.getNomProduto();
        this.dscTipoMotivo = item.getDscTipoMotivo();
        this.sglUFInstalacao = item.getSglUFInstalacao();
        this.dscAcaoItemOrdem = item.getDscAcaoItemOrdem();
        this.dscStatusItem = item.getDscStatusItem();
        this.email = item.getEmail();
        this.dscFormaPgto = item.getDscFormaPgto();
        this.codCtaFinanceira = item.getCodCtaFinanceira();
        this.codContratoOltp = item.getCodContratoOltp();
        this.numProtocolo = item.getNumProtocolo();
        this.datSuspensao = item.getDatSuspensao();
        this.datReativacao = item.getDatReativacao();
        this.codServiceId = item.getCodServiceId();
        this.dscMotivoStatusItem = item.getDscMotivoStatusItem();
        this.valPlanoAtual = item.getValPlanoAtual();
        this.nomDescontoAtual = item.getNomDescontoAtual();
        this.valDescontoAtual = item.getValDescontoAtual();
        this.valPlanoNovo = item.getValPlanoNovo();
        this.nomDescontoNovo = item.getNomDescontoNovo();
        this.valDescontoNovo = item.getValDescontoNovo();
        this.flgPortabilidade = item.getFlgPortabilidade();
        this.codDdd = item.getCodDdd();
        this.numTelefonePortado = item.getNumTelefonePortado();
        this.datJanelaPortabilidade = item.getDatJanelaPortabilidade();
        this.dscEstorno = item.getDscEstorno();
        this.numBilheteEstornado = item.getNumBilheteEstornado();
        this.dscMotivoEstorno = item.getDscMotivoEstorno();
        this.diaVencimento = item.getDiaVencimento();
        this.dscTipoConta = item.getDscTipoConta();
        this.dscEnderecoFatura = item.getDscEnderecoFatura();
        this.dscAreaVoip = item.getDscAreaVoip();
        this.codBanco = item.getCodBanco();
        this.codAgenciaBco = item.getCodAgenciaBco();
        this.codContaCorrente = item.getCodContaCorrente();
        this.datAltFormaPgto = item.getDatAltFormaPgto();
        this.codDebitoAutomatico = item.getCodDebitoAutomatico();
        this.codItemOrdem = item.getCodItemOrdem();
        this.idItemOrdPai = item.getIdItemOrdPai();
        this.idItemOrdem = item.getIdItemOrdem();
        this.dscCategoriaItem = item.getDscCategoriaItem();
        this.tecnologia = item.getTecnologia();
        this.cpe = item.getCpe();
        this.ont = item.getOnt();
        this.dominioRoot = item.getDominioRoot();
        this.codProduto = item.getCodProduto();
    }

    public void setOrdem(IOStep1Value ordem) {
        this.numCNPJParcVenda = ordem.getNumCNPJParcVenda();
        this.datVenda = ordem.getDatVenda();
        this.datRef = ordem.getDatRef();
        this.dscTipoOrdem = ordem.getDscTipoOrdem();
        this.datCriacaoOrdem = ordem.getDatCriacaoOrdem();
        this.datStatusOrdem = ordem.getDatStatusOrdem();
        this.nomContato = ordem.getNomContato();
        this.nomLoginResponsavel = ordem.getNomLoginResponsavel();
        this.nomLoginVendedor = ordem.getNomLoginVendedor();
        this.dscCanalVenda = ordem.getDscCanalVenda();
        this.nomParceiroVenda = ordem.getNomParceiroVenda();
        this.numTelefone2 = ordem.getNumTelefone2();
        this.numtelefone3 = ordem.getNumTelefone3();
    }

    public void setWfm(IOStep1Value wfm) {
    	this.dscStatusOrdemWfm = wfm.getDscStatusOrdemWfm();
    	this.datHoraStatusWfm = wfm.getDatHoraStatusWfm();
    }
    
    public void clearItem(){
        this.nomBairro = "";
        this.cep = "";
        this.nomCidade = "";
        this.dscComplemento = "";
        this.datDesconexao = "";
        this.dscLogradouro = "";
        this.numLogradouro = "";
        this.nomPlanoAtual = "";
        this.nomPlanoNovo = "";
        this.numTelefone = "";
        this.dscTipoLogradouro = "";
        this.nomProduto = "";
        this.dscTipoMotivo = "";
        this.sglUFInstalacao = "";
        this.dscAcaoItemOrdem = "";
        this.dscStatusItem = "";
        this.email = "";
        this.dscFormaPgto = "";
        this.codCtaFinanceira = "";
        this.codContratoOltp = "";
        this.numProtocolo = "";
        this.datSuspensao = "";
        this.datReativacao = "";
        this.codServiceId = "";
        this.dscMotivoStatusItem = "";
        this.valPlanoAtual = "";
        this.nomDescontoAtual = "";
        this.valDescontoAtual = "";
        this.valPlanoNovo = "";
        this.nomDescontoNovo = "";
        this.valDescontoNovo = "";
        this.flgPortabilidade = "";
        this.codDdd = "";
        this.numTelefonePortado = "";
        this.datJanelaPortabilidade = "";
        this.dscEstorno = "";
        this.numBilheteEstornado = "";
        this.dscMotivoEstorno = "";
        this.diaVencimento = "";
        this.dscTipoConta = "";
        this.dscEnderecoFatura = "";
        this.dscAreaVoip = "";
        this.codBanco = "";
        this.codAgenciaBco = "";
        this.codContaCorrente = "";
        this.datAltFormaPgto = "";
        this.codDebitoAutomatico = "";
        this.codItemOrdem = "";
        this.idItemOrdPai = "";
        this.idItemOrdem = "";
        this.dscCategoriaItem = "";
        this.tecnologia = "";
        this.cpe = "";
        this.ont = "";
        this.dominioRoot = "";
        this.codProduto = "";
    }


    @Override
    public String toString() {
        return new StringBuilder()
                .append(nroOrdem).append("|")
                .append(nomBairro).append("|")
                .append(cep).append("|")
                .append(nomCidade).append("|")
                .append(numCNPJParcVenda).append("|")
                .append(dscComplemento).append("|")
                .append(datDesconexao).append("|")
                .append(datVenda).append("|")
                .append(dscLogradouro).append("|")
                .append(numLogradouro).append("|")
                .append(nomPlanoAtual).append("|")
                .append(nomPlanoNovo).append("|")
                .append(numTelefone).append("|")
                .append(dscTipoLogradouro).append("|")
                .append(nomProduto).append("|")
                .append(dscTipoMotivo).append("|")
                .append(sglUFInstalacao).append("|")
                .append(datRef).append("|")
                .append(dscAcaoItemOrdem).append("|")
                .append(dscStatusItem).append("|")
                .append(email).append("|")
                .append(dscTipoOrdem).append("|")
                .append(dscFormaPgto).append("|")
                .append(codCtaFinanceira).append("|")
                .append(codContratoOltp).append("|")
                .append(numProtocolo).append("|")
                .append(datCriacaoOrdem).append("|")
                .append(datStatusOrdem).append("|")
                .append(datSuspensao).append("|")
                .append(datReativacao).append("|")
                .append(codServiceId).append("|")
                .append(nomContato).append("|")
                .append(dscMotivoStatusItem).append("|")
                .append(nomLoginResponsavel).append("|")
                .append(nomLoginVendedor).append("|")
                .append(dscCanalVenda).append("|")
                .append(valPlanoAtual).append("|")
                .append(nomDescontoAtual).append("|")
                .append(valDescontoAtual).append("|")
                .append(valPlanoNovo).append("|")
                .append(nomDescontoNovo).append("|")
                .append(valDescontoNovo).append("|")
                .append(flgPortabilidade).append("|")
                .append(codDdd).append("|")
                .append(numTelefonePortado).append("|")
                .append(datJanelaPortabilidade).append("|")
                .append(dscEstorno).append("|")
                .append(numBilheteEstornado).append("|")
                .append(dscMotivoEstorno).append("|")
                .append(dscStatusOrdemWfm).append("|")
                .append(datHoraStatusWfm).append("|")
                .append(diaVencimento).append("|")
                .append(dscTipoConta).append("|")
                .append(dscEnderecoFatura).append("|")
                .append(dscAreaVoip).append("|")
                .append(codBanco).append("|")
                .append(codAgenciaBco).append("|")
                .append(codContaCorrente).append("|")
                .append(datAltFormaPgto).append("|")
                .append(codDebitoAutomatico).append("|")
                .append(codItemOrdem).append("|")
                .append(nomParceiroVenda).append("|")
                .append(idItemOrdPai).append("|")
                .append(idItemOrdem).append("|")
                .append(dscCategoriaItem).append("|")
                .append(tecnologia).append("|")
                .append(cpe).append("|")
                .append(ont).append("|")
                .append(numTelefone2).append("|")
                .append(numtelefone3).append("|")
                .append(dominioRoot).append("|")
                .append(codProduto)
                .toString();
    }
}
