package br.com.tim.mapreduce.e2e.step9.model;

import org.apache.commons.lang3.StringUtils;

public class Step8Result {

    private String datRef;
    private String codContratoOltp;
    private String codContratoAtivacao;
    private String numeroAcesso;
    private String customerId;
    private String tipoProduto;
    private String planoAtivacaoOferta;
    private String motivoChurn;
    private String tipoChurn;
    private String email;
    private String uf;
    private String tipoLogradouro;
    private String logradouro;
    private String numero;
    private String complemento;
    private String bairro;
    private String cep;
    private String cidade;
    private String tecnologia;
    private String formaPagamento;
    private String tipoConta;
    private String codBanco;
    private String codAgenciaBanco;
    private String codContaCorrente;
    private String codDebitoAutomatico;
    private String diaVencimento;
    private String codContaFinanceira;
    private String numProtocolo;
    private String flgOrdemAutomatica;
    private String dscTxRecorrente;
    private String dscTxNaoRecorrente;
    private String dscStatusItem;
    private String nomPlanoAtual;
    private String valPlanoAtualItem;
    private String nomDescontoAtualItem;
    private String valDescontoAtualItem;
    private String flgPortabilidade;
    private String dscOperadoraDoadora;
    private String codDdd;
    private String numTelefonePortado;
    private String datJanelaPortabilidade;
    private String horJanela;
    private String dscEnderecoFatura;
    private String dscAreaVoip;
    private String cpe;
    private String ont;
    private String itemRoot;
    private String dominioRoot;
    private String nroOrdem;
    private String acessoRowId;
    private String acessoRowIdRoot;
    private String codigoProduto;
    private String datCriacaoOrdem;
    private String horCriacaoOrdem;
    private String datVenda;
    private String horaVenda;
    private String datVendaOrig;
    private String horVendaOrig;
    private String datStatusOrdem;
    private String horStatusOrdem;
    private String numOrdemSiebel;
    private String numOrdemSiebelOrig;
    private String tipoDocumento;
    private String documento;
    private String tipoVenda;
    private String loginVendedor;
    private String loginVendedorOrig;
    private String canal;
    private String canalOrig;
    private String cnpjParceiro;
    private String cnpjParceiroOrig;
    private String custCode;
    private String custCodeOrig;
    private String position;
    private String positionOrig;
    private String flgCancAntesVenda;
    private String flgVendaSubmetida;
    private String flgVendaDuplicada;
    private String flgVendaBruta;
    private String flgVendaLiquida;
    private String flgCancPosVenda;
    private String flgCancDupl;
    private String flgCancLiquido;
    private String datCancVenda;
    private String motivoCancelamento;
    private String nomeCliente;
    private String telefone;
    private String statusOrdem;
    private String semanaVenda;
    private String semanaVendaOrig;
    private String score;
    private String scoreConsumido;
    private String datFinalizacaoOrdem;
    private String qtdContratos;
    private String nomLoginResponsavel;
    private String detalheRecusaCrivo;
    private String loginCancelamentoOrdem;
    private String nomeParceiroVenda;
    private String nomeParceiroVendaOrig;
    private String velocidadeDownload;
    private String velocidadeUpload;
    private String custcodeCliente;
    private String msanOltTrafego;
    private String codContratoAtual;
    private String codConvergente;
    private String nomeVendedor;
    private String nomeVendedorOrig;
    private String nomeUsuarioCancelouOrdem;
    private String flgGross;
    private String flgChurn;
    private String datGross;
    private String datChurn;

    public Step8Result(){}

    public void setStep1Result(String datRef, String codContratoOltp, String codContratoAtivacao, String numeroAcesso, String customerId, String tipoProduto,
                               String planoAtivacaoOferta, String motivoChurn, String tipoChurn, String email, String uf, String tipoLogradouro, String logradouro,
                               String numero, String complemento, String bairro, String cep, String cidade, String tecnologia, String formaPagamento, String tipoConta,
                               String codBanco, String codAgenciaBanco, String codContaCorrente, String codDebitoAutomatico, String diaVencimento, String codContaFinanceira,
                               String numProtocolo, String flgOrdemAutomatica, String dscTxRecorrente, String dscTxNaoRecorrente, String dscStatusItem, String nomPlanoAtual,
                               String valPlanoAtualItem, String nomDescontoAtualItem, String valDescontoAtualItem, String flgPortabilidade, String dscOperadoraDoadora,
                               String codDdd, String numTelefonePortado, String datJanelaPortabilidade, String horJanela, String dscEnderecoFatura, String dscAreaVoip,
                               String cpe, String ont, String itemRoot, String dominioRoot, String nroOrdem, String acessoRowId, String acessoRowIdRoot, String codigoProduto, String datCriacaoOrdem,
                               String horCriacaoOrdem, String datVenda, String horaVenda, String datVendaOrig, String horVendaOrig, String datStatusOrdem, String horStatusOrdem,
                               String numOrdemSiebel, String numOrdemSiebelOrig, String tipoDocumento, String documento, String tipoVenda, String loginVendedor,
                               String loginVendedorOrig, String canal, String canalOrig, String cnpjParceiro, String cnpjParceiroOrig, String custCode, String custCodeOrig,
                               String position, String positionOrig, String flgCancAntesVenda, String flgVendaSubmetida, String flgVendaDuplicada, String flgVendaBruta, String flgVendaLiquida,
                               String flgCancPosVenda, String flgCancDupl,String flgCancLiquido, String datCancVenda, String motivoCancelamento, String nomeCliente, String telefone, String statusOrdem,
                               String semanaVenda, String semanaVendaOrig, String score, String scoreConsumido, String datFinalizacaoOrdem, String qtdContratos,
                               String nomLoginResponsavel, String detalheRecusaCrivo, String loginCancelamentoOrdem, String nomeParceiroVenda, String nomeParceiroVendaOrig, String velocidadeDownload, String velocidadeUpload,
                               String custcodeCliente, String msanOltTrafego, String codContratoAtual, String codConvergente, String nomeVendedor, String nomeVendedorOrig, String nomeUsuarioCancelouOrdem,
                               String flgGross, String flgChurn, String datGross, String datChurn) {

        this.datRef = datRef;
        this.codContratoOltp = codContratoOltp;
        this.codContratoAtivacao = codContratoAtivacao;
        this.numeroAcesso = numeroAcesso;
        this.customerId = customerId;
        this.tipoProduto = tipoProduto;
        this.planoAtivacaoOferta = planoAtivacaoOferta;
        this.motivoChurn = motivoChurn;
        this.tipoChurn = tipoChurn;
        this.email = email;
        this.uf = uf;
        this.tipoLogradouro = tipoLogradouro;
        this.logradouro = logradouro;
        this.numero = numero;
        this.complemento = complemento;
        this.bairro = bairro;
        this.cep = cep;
        this.cidade = cidade;
        this.tecnologia = tecnologia;
        this.formaPagamento = formaPagamento;
        this.tipoConta = tipoConta;
        this.codBanco = codBanco;
        this.codAgenciaBanco = codAgenciaBanco;
        this.codContaCorrente = codContaCorrente;
        this.codDebitoAutomatico = codDebitoAutomatico;
        this.diaVencimento = diaVencimento;
        this.codContaFinanceira = codContaFinanceira;
        this.numProtocolo = numProtocolo;
        this.flgOrdemAutomatica = flgOrdemAutomatica;
        this.dscTxRecorrente = dscTxRecorrente;
        this.dscTxNaoRecorrente = dscTxNaoRecorrente;
        this.dscStatusItem = dscStatusItem;
        this.nomPlanoAtual = nomPlanoAtual;
        this.valPlanoAtualItem = valPlanoAtualItem;
        this.nomDescontoAtualItem = nomDescontoAtualItem;
        this.valDescontoAtualItem = valDescontoAtualItem;
        this.flgPortabilidade = flgPortabilidade;
        this.dscOperadoraDoadora = dscOperadoraDoadora;
        this.codDdd = codDdd;
        this.numTelefonePortado = numTelefonePortado;
        this.datJanelaPortabilidade = datJanelaPortabilidade;
        this.horJanela = horJanela;
        this.dscEnderecoFatura = dscEnderecoFatura;
        this.dscAreaVoip = dscAreaVoip;
        this.cpe = cpe;
        this.ont = ont;
        this.itemRoot = itemRoot;
        this.dominioRoot = dominioRoot;
        this.nroOrdem = nroOrdem;
        this.acessoRowId = acessoRowId;
        this.acessoRowIdRoot = acessoRowIdRoot;
        this.codigoProduto = codigoProduto;
        this.datCriacaoOrdem = datCriacaoOrdem;
        this.horCriacaoOrdem = horCriacaoOrdem;
        this.datVenda = datVenda;
        this.horaVenda = horaVenda;
        this.datVendaOrig = datVendaOrig;
        this.horVendaOrig = horVendaOrig;
        this.datStatusOrdem = datStatusOrdem;
        this.horStatusOrdem = horStatusOrdem;
        this.numOrdemSiebel = numOrdemSiebel;
        this.numOrdemSiebelOrig = numOrdemSiebelOrig;
        this.tipoDocumento = tipoDocumento;
        this.documento = documento;
        this.tipoVenda = tipoVenda;
        this.loginVendedor = loginVendedor;
        this.loginVendedorOrig = loginVendedorOrig;
        this.canal = canal;
        this.canalOrig = canalOrig;
        this.cnpjParceiro = cnpjParceiro;
        this.cnpjParceiroOrig = cnpjParceiroOrig;
        this.custCode = custCode;
        this.custCodeOrig = custCodeOrig;
        this.position = position;
        this.positionOrig = positionOrig;
        this.flgCancAntesVenda = flgCancAntesVenda;
        this.flgVendaSubmetida = flgVendaSubmetida;
        this.flgVendaDuplicada = flgVendaDuplicada;
        this.flgVendaBruta = flgVendaBruta;
        this.flgVendaLiquida = flgVendaLiquida;
        this.flgCancPosVenda = flgCancPosVenda;
        this.flgCancDupl = flgCancDupl;
        this.flgCancLiquido = flgCancLiquido;
        this.datCancVenda = datCancVenda;
        this.motivoCancelamento = motivoCancelamento;
        this.nomeCliente = nomeCliente;
        this.telefone = telefone;
        this.statusOrdem = statusOrdem;
        this.semanaVenda = semanaVenda;
        this.semanaVendaOrig = semanaVendaOrig;
        this.score = score;
        this.scoreConsumido = scoreConsumido;
        this.datFinalizacaoOrdem = datFinalizacaoOrdem;
        this.qtdContratos = qtdContratos;
        this.nomLoginResponsavel = nomLoginResponsavel;
        this.detalheRecusaCrivo = detalheRecusaCrivo;
        this.loginCancelamentoOrdem = loginCancelamentoOrdem;
        this.nomeParceiroVenda = nomeParceiroVenda;
        this.nomeParceiroVendaOrig = nomeParceiroVendaOrig;
        this.velocidadeDownload = velocidadeDownload;
        this.velocidadeUpload = velocidadeUpload;
        this.custcodeCliente = custcodeCliente;
        this.msanOltTrafego = msanOltTrafego;
        this.codContratoAtual = codContratoAtual;
        this.codConvergente = codConvergente;
        this.nomeVendedor = nomeVendedor;
        this.nomeVendedorOrig = nomeVendedorOrig;
        this.nomeUsuarioCancelouOrdem = nomeUsuarioCancelouOrdem;
        this.flgGross = flgGross;
        this.flgChurn = flgChurn;
        this.datGross = datGross;
        this.datChurn = datChurn;
    }

    public boolean parse(String textString) {
        if (StringUtils.isNotBlank(textString)) {
            String[] cols = textString.split("\\|", -1);
            int i = 0;
            this.setStep1Result(cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                                cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                                cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                                cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                                cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                                cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                                cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                                cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                                cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                                cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                                cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                                cols[i++], cols[i++]);
            return true;
        }
        return false;
    }

    public String getNomeParceiroVendaOrig() {
        return nomeParceiroVendaOrig;
    }

    public String getFlgGross() {
        return flgGross;
    }

    public String getFlgChurn() {
        return flgChurn;
    }

    public String getDatGross() {
        return datGross;
    }

    public String getDatChurn() {
        return datChurn;
    }

    public String getNomeUsuarioCancelouOrdem() {
        return nomeUsuarioCancelouOrdem;
    }

    public String getNomeVendedorOrig() {
        return nomeVendedorOrig;
    }

    public String getNomeVendedor() {
        return nomeVendedor;
    }

    public String getCodConvergente() {
        return codConvergente;
    }

    public String getCodContratoAtual() {
        return codContratoAtual;
    }

    public String getMsanOltTrafego() {
        return msanOltTrafego;
    }

    public String getCustcodeCliente() {
        return custcodeCliente;
    }

    public String getVelocidadeDownload() {
        return velocidadeDownload;
    }

    public String getVelocidadeUpload() {
        return velocidadeUpload;
    }

    public String getAcessoRowIdRoot() {
        return acessoRowIdRoot;
    }

    public String getDatRef() {
        return datRef;
    }

    public String getCodContratoOltp() {
        return codContratoOltp;
    }

    public String getCodContratoAtivacao() {
        return codContratoAtivacao;
    }

    public String getNumeroAcesso() {
        return numeroAcesso;
    }

    public String getCustomerId() {
        return customerId;
    }

    public String getTipoProduto() {
        return tipoProduto;
    }

    public String getPlanoAtivacaoOferta() {
        return planoAtivacaoOferta;
    }

    public String getMotivoChurn() {
        return motivoChurn;
    }

    public String getTipoChurn() {
        return tipoChurn;
    }

    public String getEmail() {
        return email;
    }

    public String getUf() {
        return uf;
    }

    public String getTipoLogradouro() {
        return tipoLogradouro;
    }

    public String getLogradouro() {
        return logradouro;
    }

    public String getNumero() {
        return numero;
    }

    public String getComplemento() {
        return complemento;
    }

    public String getBairro() {
        return bairro;
    }

    public String getCep() {
        return cep;
    }

    public String getCidade() {
        return cidade;
    }

    public String getTecnologia() {
        return tecnologia;
    }

    public String getFormaPagamento() {
        return formaPagamento;
    }

    public String getTipoConta() {
        return tipoConta;
    }

    public String getCodBanco() {
        return codBanco;
    }

    public String getCodAgenciaBanco() {
        return codAgenciaBanco;
    }

    public String getCodContaCorrente() {
        return codContaCorrente;
    }

    public String getCodDebitoAutomatico() {
        return codDebitoAutomatico;
    }

    public String getDiaVencimento() {
        return diaVencimento;
    }

    public String getCodContaFinanceira() {
        return codContaFinanceira;
    }

    public String getNumProtocolo() {
        return numProtocolo;
    }

    public String getFlgOrdemAutomatica() {
        return flgOrdemAutomatica;
    }

    public String getDscTxRecorrente() {
        return dscTxRecorrente;
    }

    public String getDscTxNaoRecorrente() {
        return dscTxNaoRecorrente;
    }

    public String getDscStatusItem() {
        return dscStatusItem;
    }

    public String getNomPlanoAtual() {
        return nomPlanoAtual;
    }

    public String getValPlanoAtualItem() {
        return valPlanoAtualItem;
    }

    public String getNomDescontoAtualItem() {
        return nomDescontoAtualItem;
    }

    public String getValDescontoAtualItem() {
        return valDescontoAtualItem;
    }

    public String getFlgPortabilidade() {
        return flgPortabilidade;
    }

    public String getDscOperadoraDoadora() {
        return dscOperadoraDoadora;
    }

    public String getCodDdd() {
        return codDdd;
    }

    public String getNumTelefonePortado() {
        return numTelefonePortado;
    }

    public String getDatJanelaPortabilidade() {
        return datJanelaPortabilidade;
    }

    public String getHorJanela() {
        return horJanela;
    }

    public String getDscEnderecoFatura() {
        return dscEnderecoFatura;
    }

    public String getDscAreaVoip() {
        return dscAreaVoip;
    }

    public String getCpe() {
        return cpe;
    }

    public String getOnt() {
        return ont;
    }

    public String getItemRoot() {
        return itemRoot;
    }

    public String getDominioRoot() {
        return dominioRoot;
    }

    public String getNroOrdem() {
        return nroOrdem;
    }

    public String getAcessoRowId() {
        return acessoRowId;
    }

    public String getCodigoProduto() {
        return codigoProduto;
    }

    public String getDatCriacaoOrdem() {
        return datCriacaoOrdem;
    }

    public String getHorCriacaoOrdem() {
        return horCriacaoOrdem;
    }

    public String getDatVenda() {
        return datVenda;
    }

    public String getHoraVenda() {
        return horaVenda;
    }

    public String getDatVendaOrig() {
        return datVendaOrig;
    }

    public String getHorVendaOrig() {
        return horVendaOrig;
    }

    public String getDatStatusOrdem() {
        return datStatusOrdem;
    }

    public String getHorStatusOrdem() {
        return horStatusOrdem;
    }

    public String getNumOrdemSiebel() {
        return numOrdemSiebel;
    }

    public String getNumOrdemSiebelOrig() {
        return numOrdemSiebelOrig;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public String getDocumento() {
        return documento;
    }

    public String getTipoVenda() {
        return tipoVenda;
    }

    public String getLoginVendedor() {
        return loginVendedor;
    }

    public String getLoginVendedorOrig() {
        return loginVendedorOrig;
    }

    public String getCanal() {
        return canal;
    }

    public String getCanalOrig() {
        return canalOrig;
    }

    public String getCnpjParceiro() {
        return cnpjParceiro;
    }

    public String getCnpjParceiroOrig() {
        return cnpjParceiroOrig;
    }

    public String getCustCode() {
        return custCode;
    }

    public String getCustCodeOrig() {
        return custCodeOrig;
    }

    public String getPosition() {
        return position;
    }

    public String getPositionOrig() {
        return positionOrig;
    }

    public String getFlgCancAntesVenda() {
        return flgCancAntesVenda;
    }

    public String getFlgVendaDuplicada() {
        return flgVendaDuplicada;
    }

    public String getFlgVendaBruta() {
        return flgVendaBruta;
    }

    public String getFlgVendaLiquida() {
        return flgVendaLiquida;
    }

    public String getFlgCancPosVenda() {
        return flgCancPosVenda;
    }

    public String getDatCancVenda() {
        return datCancVenda;
    }

    public String getMotivoCancelamento() {
        return motivoCancelamento;
    }

    public String getNomeCliente() {
        return nomeCliente;
    }

    public String getTelefone() {
        return telefone;
    }

    public String getStatusOrdem() {
        return statusOrdem;
    }

    public String getSemanaVenda() {
        return semanaVenda;
    }

    public String getSemanaVendaOrig() {
        return semanaVendaOrig;
    }

    public String getScore() {
        return score;
    }

    public String getScoreConsumido() {
        return scoreConsumido;
    }

    public String getDatFinalizacaoOrdem() {
        return datFinalizacaoOrdem;
    }

    public String getQtdContratos() {
        return qtdContratos;
    }

    public String getNomLoginResponsavel() {
        return nomLoginResponsavel;
    }

    public String getDetalheRecusaCrivo() {
        return detalheRecusaCrivo;
    }

    public String getLoginCancelamentoOrdem() {
        return loginCancelamentoOrdem;
    }

    public String getNomeParceiroVenda() {
        return nomeParceiroVenda;
    }

    public String getFlgVendaSubmetida() {
        return flgVendaSubmetida;
    }

    public String getFlgCancDupl() {
        return flgCancDupl;
    }

    public String getFlgCancLiquido() {
        return flgCancLiquido;
    }
}
