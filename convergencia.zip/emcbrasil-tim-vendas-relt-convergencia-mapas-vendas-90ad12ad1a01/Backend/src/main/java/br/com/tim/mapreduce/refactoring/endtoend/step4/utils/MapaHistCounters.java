package br.com.tim.mapreduce.refactoring.endtoend.step4.utils;

public enum MapaHistCounters {
	MAPA_HIST_MAPPER_WRITE, MAPA_HIST_MAPPER_DISCART, MAPA_HIST_REDUCER_WRITE, MAPA_HIST_REDUCER_DISCART

}
