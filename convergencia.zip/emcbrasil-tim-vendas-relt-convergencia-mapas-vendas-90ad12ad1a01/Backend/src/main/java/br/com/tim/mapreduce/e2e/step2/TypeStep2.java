package br.com.tim.mapreduce.e2e.step2;

public enum TypeStep2 {

    ORDEM, RELT
}
