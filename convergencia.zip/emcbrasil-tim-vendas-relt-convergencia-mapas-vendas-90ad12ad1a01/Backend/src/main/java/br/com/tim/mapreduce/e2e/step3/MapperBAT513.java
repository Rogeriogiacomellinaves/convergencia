
package br.com.tim.mapreduce.e2e.step3;

import br.com.tim.mapreduce.model.BAT513;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

import java.io.IOException;

public class MapperBAT513 extends org.apache.hadoop.mapreduce.Mapper<Writable,Text,E2EStep3Key,E2EStep3Value> {

	private E2EStep3Key outkey;
	private E2EStep3Value outValue;
	private BAT513 input;
	@Override
	protected void map(Writable key, Text value, Context context) throws IOException, InterruptedException {
		input.parse(value.toString());
		outkey.setIdSiebel(input.getIdSiebel());
		outkey.setTipo(TypeStep3.BAT513);
		outValue.setBAT513(input);
		context.write(outkey, outValue);
	}

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		super.setup(context);
		this.outkey = new E2EStep3Key();
		this.outValue = new E2EStep3Value();
		this.input = new BAT513();
	}

	@Override
	protected void cleanup(Context context) throws IOException, InterruptedException {
		super.cleanup(context);
		this.clear();
	}

	private void clear(){
	   this.outValue.clear();
	}

}