package br.com.tim.mapreduce.refactoring.endtoend.step5.pt1;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Objects;

import com.google.common.collect.ComparisonChain;

import br.com.tim.mapreduce.refactoring.endtoend.GroupComparable;

public class Step5Key implements GroupComparable<Step5Key>{
	
	private String numOrderSiebelOrig;
	private String datRef;
	private TypeStep5 tipo;
	
	@Override
	public void write(DataOutput out) throws IOException {
		
		out.writeInt(tipo.ordinal());
		out.writeUTF(this.numOrderSiebelOrig);
		out.writeUTF(this.datRef);
		
	}
	@Override
	public void readFields(DataInput in) throws IOException {
		// TODO Auto-generated method stub
		this.tipo  = TypeStep5.values()[in.readInt()];
		this.numOrderSiebelOrig = in.readUTF();
		this.datRef = in.readUTF();
	}
	
	
	public String getnumOrderSiebelOrig() {
		return numOrderSiebelOrig;
	}
	public void setnumOrderSiebelOrig(String numOrderSiebelOrig) {
		this.numOrderSiebelOrig = numOrderSiebelOrig;
	}
	public String getDatRef() {
		return datRef;
	}
	public void setDatRef(String datRef) {
		this.datRef = datRef;
	}
	public TypeStep5 getTipo() {
		return tipo;
	}
	public void setTipo(TypeStep5 tipo) {
		this.tipo = tipo;
	}
	
	@Override
	public int compareTo(Step5Key o) {
		return ComparisonChain.start().compare(this.numOrderSiebelOrig, o.numOrderSiebelOrig).compare(this.tipo, o.tipo).compare(this.datRef, o.datRef)
				.result();
	}
	@Override
	public int compareToGrouping(Step5Key o) {
		return ComparisonChain.start().compare(this.numOrderSiebelOrig, o.numOrderSiebelOrig).result();
	}
	
	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		Step5Key key = (Step5Key) o;
		return Objects.equals(numOrderSiebelOrig, key.numOrderSiebelOrig);
	}


	public int hashCodeJoin() {

		return Objects.hash(numOrderSiebelOrig);
	}

	@Override
	public int hashCode() {

		return Objects.hash(numOrderSiebelOrig);
	}
	
}
