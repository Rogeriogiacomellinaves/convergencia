
package br.com.tim.mapreduce.e2e.step8;

import br.com.tim.mapreduce.e2e.step8.model.Step7Result;
import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

import java.io.IOException;

public class MapperStep7Result extends org.apache.hadoop.mapreduce.Mapper<Writable,Text,E2EStep8Key,E2EStep8Value> {

	private E2EStep8Key outkey;
	private E2EStep8Value outValue;
	private Step7Result input;
	@Override
	protected void map(Writable key, Text value, Context context) throws IOException, InterruptedException {
		input.parse(value.toString());
		if(StringUtils.isEmpty(input.getNumeroAcesso()))
			outkey.setNumAcesso(input.getCodContratoAtivacao());
		else
			outkey.setNumAcesso(input.getNumeroAcesso());
		outkey.setCodContrato(input.getCodContratoOltp());
		outkey.setTipo(TypeStep8.RELT);
		outValue.setStep7Result(input);
		context.write(outkey, outValue);
	}

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		super.setup(context);
		this.outkey = new E2EStep8Key();
		this.outValue = new E2EStep8Value();
		this.input = new Step7Result();
	}

	@Override
	protected void cleanup(Context context) throws IOException, InterruptedException {
		super.cleanup(context);
		this.clear();
	}

	private void clear(){
	   this.outValue.clear();
	}

}