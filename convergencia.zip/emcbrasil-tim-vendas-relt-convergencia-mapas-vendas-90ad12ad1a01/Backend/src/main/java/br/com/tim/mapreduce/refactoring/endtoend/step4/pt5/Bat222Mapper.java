package br.com.tim.mapreduce.refactoring.endtoend.step4.pt5;

import java.io.IOException;

import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.Mapper;


import br.com.tim.mapreduce.refactoring.endtoend.step4.model.Bat222Model;
import br.com.tim.mapreduce.refactoring.endtoend.step4.utils.Step4PT5Counters;

public class Bat222Mapper<T extends Writable> extends Mapper<T, Text, Step4Pt5Key, E2EStep4Pt5Value> {

    private E2EStep4Pt5Value outValue;
    private Bat222Model model;
    private static final String NACIONALIDADE_BRASIL = "BRASIL";
    private Step4Pt5Key outkey;
    @Override
    protected void setup(Mapper<T, Text, Step4Pt5Key, E2EStep4Pt5Value>.Context context) throws IOException, InterruptedException {
        this.outValue = new E2EStep4Pt5Value();
        this.model = new Bat222Model();
        this.outkey = new Step4Pt5Key();
    }

    @Override
    protected void map(T key, Text value, Mapper<T, Text, Step4Pt5Key, E2EStep4Pt5Value>.Context context)
            throws IOException, InterruptedException {

        if (StringUtils.isBlank(value.toString()))
            return;

        model.parseFromText(value.toString());

        if (!StringUtils.isBlank(model.getSocialsecno()) && model.getNacionalidade().toUpperCase().equals(NACIONALIDADE_BRASIL)) {
           
        	outValue.clear();
            outValue.setBat222(model);
            
            outkey.setNroOrdem(model.getSocialsecno());
            outkey.setTipo(TypeStep4Pt5.BAT222);

            context.write(outkey, this.outValue);
            context.getCounter(Step4PT5Counters.BAT_222_MAPPER).increment(1l);

        }else {
        	
        	context.getCounter(Step4PT5Counters.SOCIALSECNO_IS_BLANCK).increment(1);
            return;
        	
        }



    }

}