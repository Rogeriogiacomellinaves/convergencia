package br.com.tim.mapreduce.refactoring.endtoend.step4.utils;

public enum Step4PT5Counters {

	WRITE_RECORDS, BAT_222_MAPPER, SOCIALSECNO_IS_BLANCK
	
}
