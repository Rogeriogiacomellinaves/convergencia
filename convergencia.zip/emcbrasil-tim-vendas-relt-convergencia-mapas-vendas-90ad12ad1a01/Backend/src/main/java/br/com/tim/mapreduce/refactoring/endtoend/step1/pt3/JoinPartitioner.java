package br.com.tim.mapreduce.refactoring.endtoend.step1.pt3;

import org.apache.hadoop.mapreduce.Partitioner;

public class JoinPartitioner extends Partitioner<E2EStep1pt3Key, E2EStep1pt3Value> {

	@Override
	public int getPartition(E2EStep1pt3Key taggedKey, E2EStep1pt3Value value, int numPartitions) {
		return Math.abs(taggedKey.hashCodeJoin() % numPartitions);
	}

}
