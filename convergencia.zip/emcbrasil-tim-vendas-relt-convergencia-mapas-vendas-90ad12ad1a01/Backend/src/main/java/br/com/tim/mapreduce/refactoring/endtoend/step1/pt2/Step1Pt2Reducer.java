package br.com.tim.mapreduce.refactoring.endtoend.step1.pt2;

import java.io.IOException;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.log4j.Logger;
import org.apache.parquet.Strings;

import br.com.tim.mapreduce.refactoring.endtoend.utils.Step1Pt2Counters;


public class Step1Pt2Reducer extends Reducer<Step1Pt2Key, Step1Pt2Value, NullWritable, Text> {
	
    protected static final Logger LOG = Logger.getLogger(Step1Pt2Reducer.class);    
    private Step1Pt2OutValue outValue;
    private boolean firstOrdem;
    private static String CANCELADO = "Cancelado";
    
    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        super.setup(context);
        outValue = new Step1Pt2OutValue();
    }
    
    
    @Override
    protected void reduce(Step1Pt2Key key, Iterable<Step1Pt2Value> values, Context context) throws InterruptedException {
    	
        firstOrdem = true;
        outValue.clear();
        
        try {
        	
        	for (Step1Pt2Value value : values) {
        		switch (value.getTipo()) {
        		case ORDER:
        			 if(firstOrdem){
                         outValue.setFirstOrdem(value);
                         firstOrdem = false;
                     }
                     else
                         outValue.setOrdem(value);
        			break;
        		case ITEM:
        			outValue.clearRelt();
        			outValue.setRelt(value);
        			if (validRecord(outValue)) {
            			context.write(NullWritable.get(), new Text(outValue.toString()));
            			context.getCounter(Step1Pt2Counters.STEP2_REDUCER_WIRTE).increment(1l);
        			}else {
            			context.getCounter(Step1Pt2Counters.STEP2_CANCELADO_DAT_NULL).increment(1l);
        			}

        			break;
        		default:
        			break;
        		}
        	}
        	
        	
        }catch (Exception e) {
            LOG.error(" ############ ERROR EXECUTION REDUCER ############ ");
            LOG.error(e.getMessage());
            throw new InterruptedException(e.getMessage());
        }
    	
    }
    
    @Override
    protected void cleanup(Context context) throws IOException, InterruptedException {
        super.cleanup(context);

    }
    
	public boolean validRecord(Step1Pt2OutValue out) {

		if (Strings.isNullOrEmpty(out.getDatVenda()) && out.getStatusOrdem().equals(CANCELADO)) {
			return false;
		} else {
			return true;

		}
	}
    	
}
