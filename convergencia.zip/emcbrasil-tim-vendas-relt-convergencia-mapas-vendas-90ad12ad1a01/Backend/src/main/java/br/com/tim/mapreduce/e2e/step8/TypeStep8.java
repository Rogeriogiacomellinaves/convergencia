package br.com.tim.mapreduce.e2e.step8;

public enum TypeStep8 {

    GROSS, CHURN, RELT
}
