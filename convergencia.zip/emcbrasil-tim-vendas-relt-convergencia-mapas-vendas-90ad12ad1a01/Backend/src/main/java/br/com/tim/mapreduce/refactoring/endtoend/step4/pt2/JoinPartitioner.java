package br.com.tim.mapreduce.refactoring.endtoend.step4.pt2;

import org.apache.hadoop.mapreduce.Partitioner;

public class JoinPartitioner extends Partitioner<Step4Pt2Key, Step4Pt2Value>{

	@Override
	public int getPartition(Step4Pt2Key taggedKey, Step4Pt2Value value, int numPartitions) {
        
		return Math.abs(taggedKey.hashCodeJoin() % numPartitions);

	}

}
