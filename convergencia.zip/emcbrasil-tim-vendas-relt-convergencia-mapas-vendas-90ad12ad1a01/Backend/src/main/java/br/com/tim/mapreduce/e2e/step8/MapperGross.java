
package br.com.tim.mapreduce.e2e.step8;

import br.com.tim.mapreduce.model.Gross;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

import java.io.IOException;

public class MapperGross extends org.apache.hadoop.mapreduce.Mapper<Writable,Text,E2EStep8Key,E2EStep8Value> {

	private E2EStep8Key outkey;
	private E2EStep8Value outValue;
	private Gross input;
	@Override
	protected void map(Writable key, Text value, Context context) throws IOException, InterruptedException {
		input.parse(value.toString());
		outkey.setNumAcesso(input.getAcesso());
		outkey.setCodContrato(input.getCodContratoBscs());
		outkey.setTipo(TypeStep8.GROSS);
		outValue.setGross(input);
		context.write(outkey, outValue);
	}

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		super.setup(context);
		this.outkey = new E2EStep8Key();
		this.outValue = new E2EStep8Value();
		this.input = new Gross();
	}

	@Override
	protected void cleanup(Context context) throws IOException, InterruptedException {
		super.cleanup(context);
		this.clear();
	}

	private void clear(){
	   this.outValue.clear();
	}

}