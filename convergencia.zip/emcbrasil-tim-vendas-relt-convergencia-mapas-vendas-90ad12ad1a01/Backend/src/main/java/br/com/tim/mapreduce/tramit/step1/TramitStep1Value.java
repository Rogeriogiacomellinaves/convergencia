package br.com.tim.mapreduce.tramit.step1;

import br.com.tim.mapreduce.model.BAT509Item;
import br.com.tim.mapreduce.model.BAT509Order;
import br.com.tim.mapreduce.model.Wfmtoa;

import org.apache.hadoop.io.Writable;
import org.joda.time.Days;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;


public class TramitStep1Value implements Writable {

    protected TypeStep1 tipo;
    protected String ordemSiebel;
    protected String cpfCNPJ;
    protected String contrato;
    protected String datCriacaoOrdem;
    protected String login;
    protected String statusSiebel;
    protected String motivoCancelamento;
    protected String tipoOrdem;
    protected String subtipoOrdem;
    protected String parceiroVendaSiebel;
    protected String aging;
    protected String agingFaixa;
    protected String tecnologia;
    protected String cpe;
    protected String ont;
    protected String produto;
    protected String uf;
    protected String nomLoginResponsavel;
    protected String acaoItemOrdem;
	protected String statusWfmToa;
    protected String resourceWfmToa; 
    protected String dateWfmToa;
	protected String msan;

    DateTimeFormatter dtf = DateTimeFormat.forPattern("MM/dd/yyyy HH:mm:ss");

    @Override
    public void write(DataOutput dataOutput) throws IOException {
        dataOutput.writeInt(tipo.ordinal());
        dataOutput.writeUTF(ordemSiebel);
        dataOutput.writeUTF(cpfCNPJ);
        dataOutput.writeUTF(contrato);
        dataOutput.writeUTF(datCriacaoOrdem);
        dataOutput.writeUTF(login);
        dataOutput.writeUTF(statusSiebel);
        dataOutput.writeUTF(motivoCancelamento);
        dataOutput.writeUTF(tipoOrdem);
        dataOutput.writeUTF(subtipoOrdem);
        dataOutput.writeUTF(parceiroVendaSiebel);
        dataOutput.writeUTF(aging);
        dataOutput.writeUTF(agingFaixa);
        dataOutput.writeUTF(tecnologia);
        dataOutput.writeUTF(cpe);
        dataOutput.writeUTF(ont);
        dataOutput.writeUTF(produto);
        dataOutput.writeUTF(uf);
        dataOutput.writeUTF(nomLoginResponsavel);
        dataOutput.writeUTF(acaoItemOrdem);
        dataOutput.writeUTF(statusWfmToa);
        dataOutput.writeUTF(resourceWfmToa);
        dataOutput.writeUTF(dateWfmToa);
        dataOutput.writeUTF(msan);
    }

    @Override
    public void readFields(DataInput dataInput) throws IOException {
        this.tipo = TypeStep1.values()[dataInput.readInt()];
        this.ordemSiebel = dataInput.readUTF();
        this.cpfCNPJ = dataInput.readUTF();
        this.contrato = dataInput.readUTF();
        this.datCriacaoOrdem = dataInput.readUTF();
        this.login = dataInput.readUTF();
        this.statusSiebel = dataInput.readUTF();
        this.motivoCancelamento = dataInput.readUTF();
        this.tipoOrdem = dataInput.readUTF();
        this.subtipoOrdem = dataInput.readUTF();
        this.parceiroVendaSiebel = dataInput.readUTF();
        this.aging = dataInput.readUTF();
        this.agingFaixa = dataInput.readUTF();
        this.tecnologia = dataInput.readUTF();
        this.cpe = dataInput.readUTF();
        this.ont = dataInput.readUTF();
        this.produto = dataInput.readUTF();
        this.uf = dataInput.readUTF();
        this.nomLoginResponsavel = dataInput.readUTF();
        this.acaoItemOrdem = dataInput.readUTF();
        this.statusWfmToa = dataInput.readUTF();
        this.resourceWfmToa = dataInput.readUTF();
        this.dateWfmToa = dataInput.readUTF();
        this.msan = dataInput.readUTF();
    }

    public void setItem(BAT509Item item) {
        this.clear();
        this.tipo = TypeStep1.ITEM;
        this.contrato = item.getNumeroAcesso();
        this.tecnologia = item.getDscTecnologia();
        this.cpe = item.getCpe();
        this.ont = item.getOnt();
        this.produto = item.getNomeProduto();
        this.uf = item.getUfInstalacao();
        this.acaoItemOrdem = item.getAcaoItemOrdem();
    }

    public void setOrdem(BAT509Order ordem) {
        this.clear();
        this.tipo = TypeStep1.ORDEM;
        this.ordemSiebel = ordem.getNumeroOrdem();
        this.cpfCNPJ = ordem.getNumeroCliente();
        this.datCriacaoOrdem = ordem.getDataCriacaoOrdem();
        this.login = ordem.getLoginVendedor();
        this.statusSiebel = ordem.getStatusOrdem();
        this.motivoCancelamento = ordem.getMotivoCancelamentoOrdem();
        this.tipoOrdem = ordem.getTipoOrdem();
        this.subtipoOrdem = ordem.getSubTipoOrdem();
        this.parceiroVendaSiebel = ordem.getNomeParceiroVenda();
        if(ordem.getDatafinalizacaoOrdem() == null || ordem.getDatafinalizacaoOrdem().equals(""))
            this.aging = String.valueOf(Days.daysBetween(dtf.parseLocalDate(ordem.getDataCriacaoOrdem()), LocalDate.now()).getDays());
        else
            this.aging = String.valueOf(Days.daysBetween(dtf.parseLocalDate(ordem.getDataCriacaoOrdem()), dtf.parseLocalDate(ordem.getDatafinalizacaoOrdem())).getDays());
        if(Integer.valueOf(this.aging) < 4)
            this.agingFaixa = "0-3";
        else if(Integer.valueOf(this.aging) < 6)
            this.agingFaixa = "4-5";
        else if(Integer.valueOf(this.aging) < 11)
            this.agingFaixa = "6-10";
        else if(Integer.valueOf(this.aging) < 16)
            this.agingFaixa = "11-15";
        else
            this.agingFaixa = ">15";

        this.nomLoginResponsavel = ordem.getLoginResponsavel();
    }
    
    public void setWfmtoa(Wfmtoa input) {

    	this.clear();
    	this.tipo = TypeStep1.WFMTOA;
		this.statusWfmToa = input.getAstatus();
		this.resourceWfmToa = input.getPname();
		this.dateWfmToa = input.getAtimeOfBooking();
		this.msan = input.getXaPrimaryNetworkMsan();
	}

    public void clear(){
        this.tipo = null;
        this.ordemSiebel = "";
        this.cpfCNPJ = "";
        this.contrato = "";
        this.datCriacaoOrdem = "";
        this.login = "";
        this.statusSiebel = "";
        this.motivoCancelamento = "";
        this.tipoOrdem = "";
        this.subtipoOrdem = "";
        this.parceiroVendaSiebel = "";
        this.aging = "";
        this.agingFaixa = "";
        this.tecnologia = "";
        this.cpe = "";
        this.ont = "";
        this.produto = "";
        this.uf = "";
        this.nomLoginResponsavel = "";
        this.acaoItemOrdem = "";
        this.statusWfmToa = "";
		this.resourceWfmToa = "";
		this.dateWfmToa = "";
		this.statusWfmToa = "";
		this.resourceWfmToa = "";
		this.dateWfmToa = "";
		this.msan = "";
	}
    
    public String getNomLoginResponsavel() {
        return nomLoginResponsavel;
    }

    public void setNomLoginResponsavel(String nomLoginResponsavel) {
        this.nomLoginResponsavel = nomLoginResponsavel;
    }

    public String getAcaoItemOrdem() {
        return acaoItemOrdem;
    }

    public void setAcaoItemOrdem(String acaoItemOrdem) {
        this.acaoItemOrdem = acaoItemOrdem;
    }

    public TypeStep1 getTipo() {
        return tipo;
    }

    public void setTipo(TypeStep1 tipo) {
        this.tipo = tipo;
    }

    public String getOrdemSiebel() {
        return ordemSiebel;
    }

    public void setOrdemSiebel(String ordemSiebel) {
        this.ordemSiebel = ordemSiebel;
    }

    public String getCpfCNPJ() {
        return cpfCNPJ;
    }

    public void setCpfCNPJ(String cpfCNPJ) {
        this.cpfCNPJ = cpfCNPJ;
    }

    public String getContrato() {
        return contrato;
    }

    public void setContrato(String contrato) {
        this.contrato = contrato;
    }

    public String getDatCriacaoOrdem() {
        return datCriacaoOrdem;
    }

    public void setDatCriacaoOrdem(String datCriacaoOrdem) {
        this.datCriacaoOrdem = datCriacaoOrdem;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getStatusSiebel() {
        return statusSiebel;
    }

    public void setStatusSiebel(String statusSiebel) {
        this.statusSiebel = statusSiebel;
    }

    public String getMotivoCancelamento() {
        return motivoCancelamento;
    }

    public void setMotivoCancelamento(String motivoCancelamento) {
        this.motivoCancelamento = motivoCancelamento;
    }

    public String getTipoOrdem() {
        return tipoOrdem;
    }

    public void setTipoOrdem(String tipoOrdem) {
        this.tipoOrdem = tipoOrdem;
    }

    public String getSubtipoOrdem() {
        return subtipoOrdem;
    }

    public void setSubtipoOrdem(String subtipoOrdem) {
        this.subtipoOrdem = subtipoOrdem;
    }

    public String getParceiroVendaSiebel() {
        return parceiroVendaSiebel;
    }

    public void setParceiroVendaSiebel(String parceiroVendaSiebel) {
        this.parceiroVendaSiebel = parceiroVendaSiebel;
    }

    public String getAging() {
        return aging;
    }

    public void setAging(String aging) {
        this.aging = aging;
    }

    public String getAgingFaixa() {
        return agingFaixa;
    }

    public void setAgingFaixa(String agingFaixa) {
        this.agingFaixa = agingFaixa;
    }

    public String getTecnologia() {
        return tecnologia;
    }

    public void setTecnologia(String tecnologia) {
        this.tecnologia = tecnologia;
    }

    public String getCpe() {
        return cpe;
    }

    public void setCpe(String cpe) {
        this.cpe = cpe;
    }

    public String getOnt() {
        return ont;
    }

    public void setOnt(String ont) {
        this.ont = ont;
    }

    public String getProduto() {
        return produto;
    }

    public void setProduto(String produto) {
        this.produto = produto;
    }

    public String getUf() {
        return uf;
    }

    public void setUf(String uf) {
        this.uf = uf;
    }
    
    public String getStatusWfmToa() {
		return statusWfmToa;
	}

	public void setStatusWfmToa(String statusWfmToa) {
		this.statusWfmToa = statusWfmToa;
	}

	public String getResourceWfmToa() {
		return resourceWfmToa;
	}

	public void setResourceWfmToa(String resourceWfmToa) {
		this.resourceWfmToa = resourceWfmToa;
	}

	public String getDateWfmToa() {
		return dateWfmToa;
	}

	public void setDateWfmToa(String dateWfmToa) {
		this.dateWfmToa = dateWfmToa;
	}

	public String getMsan() {
		return msan;
	}

	public void setMsan(String msan) {
		this.msan = msan;
	}
}
