package br.com.tim.mapreduce.e2e.step7.pt2;


import br.com.tim.mapreduce.e2e.step7.pt1.E2EStep7PT1Value;

public class E2EStep7PT2OutValue {

    private String datRef;
    private String codContratoOltp;
    private String codContratoAtivacao;
    private String numeroAcesso;
    private String customerId;
    private String tipoProduto;
    private String planoAtivacaoOferta;
    private String motivoChurn;
    private String tipoChurn;
    private String email;
    private String uf;
    private String tipoLogradouro;
    private String logradouro;
    private String numero;
    private String complemento;
    private String bairro;
    private String cep;
    private String cidade;
    private String tecnologia;
    private String formaPagamento;
    private String tipoConta;
    private String codBanco;
    private String codAgenciaBanco;
    private String codContaCorrente;
    private String codDebitoAutomatico;
    private String diaVencimento;
    private String codContaFinanceira;
    private String numProtocolo;
    private String flgOrdemAutomatica;
    private String dscTxRecorrente;
    private String dscTxNaoRecorrente;
    private String dscStatusItem;
    private String nomPlanoAtual;
    private String valPlanoAtualItem;
    private String nomDescontoAtualItem;
    private String valDescontoAtualItem;
    private String flgPortabilidade;
    private String dscOperadoraDoadora;
    private String codDdd;
    private String numTelefonePortado;
    private String datJanelaPortabilidade;
    private String horJanela;
    private String dscEnderecoFatura;
    private String dscAreaVoip;
    private String cpe;
    private String ont;
    private String itemRoot;
    private String dominioRoot;
    private String nroOrdem;
    private String acessoRowId;
    private String acessoRowIdRoot;
    private String codigoProduto;
    private String datCriacaoOrdem;
    private String horCriacaoOrdem;
    private String datVenda;
    private String horaVenda;
    private String datVendaOrig;
    private String horVendaOrig;
    private String datStatusOrdem;
    private String horStatusOrdem;
    private String numOrdemSiebel;
    private String numOrdemSiebelOrig;
    private String tipoDocumento;
    private String documento;
    private String tipoVenda;
    private String loginVendedor;
    private String loginVendedorOrig;
    private String canal;
    private String canalOrig;
    private String cnpjParceiro;
    private String cnpjParceiroOrig;
    private String custCode;
    private String custCodeOrig;
    private String position;
    private String positionOrig;
    private String flgCancAntesVenda;
    private String flgVendaSubmetida;
    private String flgVendaDuplicada;
    private String flgVendaBruta;
    private String flgVendaLiquida;
    private String flgCancPosVenda;
    private String flgCancDupl;
    private String flgCancLiquido;
    private String datCancVenda;
    private String motivoCancelamento;
    private String nomeCliente;
    private String telefone;
    private String statusOrdem;
    private String semanaVenda;
    private String semanaVendaOrig;
    private String score;
    private String scoreConsumido;
    private String datFinalizacaoOrdem;
    private String qtdContratos;
    private String nomLoginResponsavel;
    private String detalheRecusaCrivo;
    private String loginCancelamentoOrdem;
    private String nomeParceiroVenda;
    private String nomeParceiroVendaOrig;
    private String velocidadeDownload;
    private String velocidadeUpload;
    private String custcodeCliente;
    private String msanOltTrafego;
    private String codContratoAtual;
    private String codConvergente;
    private String nomeVendedor;

    private String nomeVendedorOrig;

    public void clear(){
        this.datRef = "";
        this.codContratoOltp = "";
        this.codContratoAtivacao = "";
        this.numeroAcesso = "";
        this.customerId = "";
        this.tipoProduto = "";
        this.planoAtivacaoOferta = "";
        this.motivoChurn = "";
        this.tipoChurn = "";
        this.email = "";
        this.uf = "";
        this.tipoLogradouro = "";
        this.logradouro = "";
        this.numero = "";
        this.complemento = "";
        this.bairro = "";
        this.cep = "";
        this.cidade = "";
        this.tecnologia = "";
        this.formaPagamento = "";
        this.tipoConta = "";
        this.codBanco = "";
        this.codAgenciaBanco = "";
        this.codContaCorrente = "";
        this.codDebitoAutomatico = "";
        this.diaVencimento = "";
        this.codContaFinanceira = "";
        this.numProtocolo = "";
        this.flgOrdemAutomatica = "";
        this.dscTxRecorrente = "";
        this.dscTxNaoRecorrente = "";
        this.dscStatusItem = "";
        this.nomPlanoAtual = "";
        this.valPlanoAtualItem = "";
        this.nomDescontoAtualItem = "";
        this.valDescontoAtualItem = "";
        this.flgPortabilidade = "";
        this.dscOperadoraDoadora = "";
        this.codDdd = "";
        this.numTelefonePortado = "";
        this.datJanelaPortabilidade = "";
        this.horJanela = "";
        this.dscEnderecoFatura = "";
        this.dscAreaVoip = "";
        this.cpe = "";
        this.ont = "";
        this.itemRoot = "";
        this.dominioRoot = "";
        this.nroOrdem = "";
        this.acessoRowId = "";
        this.acessoRowIdRoot = "";
        this.codigoProduto = "";
        this.datCriacaoOrdem = "";
        this.horCriacaoOrdem = "";
        this.datVenda = "";
        this.horaVenda = "";
        this.datVendaOrig = "";
        this.horVendaOrig = "";
        this.datStatusOrdem = "";
        this.horStatusOrdem = "";
        this.numOrdemSiebel = "";
        this.numOrdemSiebelOrig = "";
        this.tipoDocumento = "";
        this.documento = "";
        this.tipoVenda = "";
        this.loginVendedor = "";
        this.loginVendedorOrig = "";
        this.canal = "";
        this.canalOrig = "";
        this.cnpjParceiro = "";
        this.cnpjParceiroOrig = "";
        this.custCode = "";
        this.custCodeOrig = "";
        this.position = "";
        this.positionOrig = "";
        this.flgCancAntesVenda = "";
        this.flgVendaSubmetida = "";
        this.flgVendaDuplicada = "";
        this.flgVendaBruta = "";
        this.flgVendaLiquida = "";
        this.flgCancPosVenda = "";
        this.flgCancDupl = "";
        this.flgCancLiquido = "";
        this.datCancVenda = "";
        this.motivoCancelamento = "";
        this.nomeCliente = "";
        this.telefone = "";
        this.statusOrdem = "";
        this.semanaVenda = "";
        this.semanaVendaOrig = "";
        this.score = "";
        this.scoreConsumido = "";
        this.datFinalizacaoOrdem = "";
        this.qtdContratos = "";
        this.nomLoginResponsavel = "";
        this.detalheRecusaCrivo = "";
        this.loginCancelamentoOrdem = "";
        this.nomeParceiroVenda = "";
        this.nomeParceiroVendaOrig = "";
        this.velocidadeDownload = "";
        this.velocidadeUpload = "";
        this.custcodeCliente = "";
        this.msanOltTrafego = "";
        this.codContratoAtual = "";
        this.codConvergente = "";
        this.nomeVendedor = "";
        this.nomeVendedorOrig = "";
    }

    public void clearRelt(){
        this.datRef = "";
        this.codContratoOltp = "";
        this.codContratoAtivacao = "";
        this.numeroAcesso = "";
        this.customerId = "";
        this.tipoProduto = "";
        this.planoAtivacaoOferta = "";
        this.motivoChurn = "";
        this.tipoChurn = "";
        this.email = "";
        this.uf = "";
        this.tipoLogradouro = "";
        this.logradouro = "";
        this.numero = "";
        this.complemento = "";
        this.bairro = "";
        this.cep = "";
        this.cidade = "";
        this.tecnologia = "";
        this.formaPagamento = "";
        this.tipoConta = "";
        this.codBanco = "";
        this.codAgenciaBanco = "";
        this.codContaCorrente = "";
        this.codDebitoAutomatico = "";
        this.diaVencimento = "";
        this.codContaFinanceira = "";
        this.numProtocolo = "";
        this.flgOrdemAutomatica = "";
        this.dscTxRecorrente = "";
        this.dscTxNaoRecorrente = "";
        this.dscStatusItem = "";
        this.nomPlanoAtual = "";
        this.valPlanoAtualItem = "";
        this.nomDescontoAtualItem = "";
        this.valDescontoAtualItem = "";
        this.flgPortabilidade = "";
        this.dscOperadoraDoadora = "";
        this.codDdd = "";
        this.numTelefonePortado = "";
        this.datJanelaPortabilidade = "";
        this.horJanela = "";
        this.dscEnderecoFatura = "";
        this.dscAreaVoip = "";
        this.cpe = "";
        this.ont = "";
        this.itemRoot = "";
        this.dominioRoot = "";
        this.nroOrdem = "";
        this.acessoRowId = "";
        this.acessoRowIdRoot = "";
        this.codigoProduto = "";
        this.datCriacaoOrdem = "";
        this.horCriacaoOrdem = "";
        this.datVenda = "";
        this.horaVenda = "";
        this.datVendaOrig = "";
        this.horVendaOrig = "";
        this.datStatusOrdem = "";
        this.horStatusOrdem = "";
        this.numOrdemSiebel = "";
        this.numOrdemSiebelOrig = "";
        this.tipoDocumento = "";
        this.documento = "";
        this.tipoVenda = "";
        this.loginVendedor = "";
        this.loginVendedorOrig = "";
        this.canal = "";
        this.canalOrig = "";
        this.cnpjParceiro = "";
        this.cnpjParceiroOrig = "";
        this.custCode = "";
        this.custCodeOrig = "";
        this.position = "";
        this.positionOrig = "";
        this.flgCancAntesVenda = "";
        this.flgVendaSubmetida = "";
        this.flgVendaDuplicada = "";
        this.flgVendaBruta = "";
        this.flgVendaLiquida = "";
        this.flgCancPosVenda = "";
        this.flgCancDupl = "";
        this.flgCancLiquido = "";
        this.datCancVenda = "";
        this.motivoCancelamento = "";
        this.nomeCliente = "";
        this.telefone = "";
        this.statusOrdem = "";
        this.semanaVenda = "";
        this.semanaVendaOrig = "";
        this.score = "";
        this.scoreConsumido = "";
        this.datFinalizacaoOrdem = "";
        this.qtdContratos = "";
        this.nomLoginResponsavel = "";
        this.detalheRecusaCrivo = "";
        this.loginCancelamentoOrdem = "";
        this.nomeParceiroVenda = "";
        this.nomeParceiroVendaOrig = "";
        this.velocidadeDownload = "";
        this.velocidadeUpload = "";
        this.custcodeCliente = "";
        this.msanOltTrafego = "";
        this.codContratoAtual = "";
        this.codConvergente = "";
        this.nomeVendedor = "";
    }

    public void setRelt(E2EStep7PT2Value relt) {
        this.datRef = relt.getDatRef();
        this.codContratoOltp = relt.getCodContratoOltp();
        this.codContratoAtivacao = relt.getCodContratoAtivacao();
        this.numeroAcesso = relt.getNumeroAcesso();
        this.customerId = relt.getCustomerId();
        this.tipoProduto = relt.getTipoProduto();
        this.planoAtivacaoOferta = relt.getPlanoAtivacaoOferta();
        this.motivoChurn = relt.getMotivoChurn();
        this.tipoChurn = relt.getTipoChurn();
        this.email = relt.getEmail();
        this.uf = relt.getUf();
        this.tipoLogradouro = relt.getTipoLogradouro();
        this.logradouro = relt.getLogradouro();
        this.numero = relt.getNumero();
        this.complemento = relt.getComplemento();
        this.bairro = relt.getBairro();
        this.cep = relt.getCep();
        this.cidade = relt.getCidade();
        this.tecnologia = relt.getTecnologia();
        this.formaPagamento = relt.getFormaPagamento();
        this.tipoConta = relt.getTipoConta();
        this.codBanco = relt.getCodBanco();
        this.codAgenciaBanco = relt.getCodAgenciaBanco();
        this.codContaCorrente = relt.getCodContaCorrente();
        this.codDebitoAutomatico = relt.getCodDebitoAutomatico();
        this.diaVencimento = relt.getDiaVencimento();
        this.codContaFinanceira = relt.getCodContaFinanceira();
        this.numProtocolo = relt.getNumProtocolo();
        this.flgOrdemAutomatica = relt.getFlgOrdemAutomatica();
        this.dscTxRecorrente = relt.getDscTxRecorrente();
        this.dscTxNaoRecorrente = relt.getDscTxNaoRecorrente();
        this.dscStatusItem = relt.getDscStatusItem();
        this.nomPlanoAtual = relt.getNomPlanoAtual();
        this.valPlanoAtualItem = relt.getValPlanoAtualItem();
        this.nomDescontoAtualItem = relt.getNomDescontoAtualItem();
        this.valDescontoAtualItem = relt.getValDescontoAtualItem();
        this.flgPortabilidade = relt.getFlgPortabilidade();
        this.dscOperadoraDoadora = relt.getDscOperadoraDoadora();
        this.codDdd = relt.getCodDdd();
        this.numTelefonePortado = relt.getNumTelefonePortado();
        this.datJanelaPortabilidade = relt.getDatJanelaPortabilidade();
        this.horJanela = relt.getHorJanela();
        this.dscEnderecoFatura = relt.getDscEnderecoFatura();
        this.dscAreaVoip = relt.getDscAreaVoip();
        this.cpe = relt.getCpe();
        this.ont = relt.getOnt();
        this.itemRoot = relt.getItemRoot();
        this.dominioRoot = relt.getDominioRoot();
        this.nroOrdem = relt.getNroOrdem();
        this.acessoRowId = relt.getAcessoRowId();
        this.acessoRowIdRoot = relt.getAcessoRowIdRoot();
        this.codigoProduto = relt.getCodigoProduto();
        this.datCriacaoOrdem = relt.getDatCriacaoOrdem();
        this.horCriacaoOrdem = relt.getHorCriacaoOrdem();
        this.datVenda = relt.getDatVenda();
        this.horaVenda = relt.getHoraVenda();
        this.datVendaOrig = relt.getDatVendaOrig();
        this.horVendaOrig = relt.getHorVendaOrig();
        this.datStatusOrdem = relt.getDatStatusOrdem();
        this.horStatusOrdem = relt.getHorStatusOrdem();
        this.numOrdemSiebel = relt.getNumOrdemSiebel();
        this.numOrdemSiebelOrig = relt.getNumOrdemSiebelOrig();
        this.tipoDocumento = relt.getTipoDocumento();
        this.documento = relt.getDocumento();
        this.tipoVenda = relt.getTipoVenda();
        this.loginVendedor = relt.getLoginVendedor();
        this.loginVendedorOrig = relt.getLoginVendedorOrig();
        this.canal = relt.getCanal();
        this.canalOrig = relt.getCanalOrig();
        this.cnpjParceiro = relt.getCnpjParceiro();
        this.cnpjParceiroOrig = relt.getCnpjParceiroOrig();
        this.custCode = relt.getCustCode();
        this.custCodeOrig = relt.getCustCodeOrig();
        this.position = relt.getPosition();
        this.positionOrig = relt.getPositionOrig();
        this.flgCancAntesVenda = relt.getFlgCancAntesVenda();
        this.flgVendaSubmetida = relt.getFlgVendaSubmetida();
        this.flgVendaDuplicada = relt.getFlgVendaDuplicada();
        this.flgVendaBruta = relt.getFlgVendaBruta();
        this.flgVendaLiquida = relt.getFlgVendaLiquida();
        this.flgCancPosVenda = relt.getFlgCancPosVenda();
        this.flgCancDupl = relt.getFlgCancDupl();
        this.flgCancLiquido = relt.getFlgCancLiquido();
        this.datCancVenda = relt.getDatCancVenda();
        this.motivoCancelamento = relt.getMotivoCancelamento();
        this.nomeCliente = relt.getNomeCliente();
        this.telefone = relt.getTelefone();
        this.statusOrdem = relt.getStatusOrdem();
        this.semanaVenda = relt.getSemanaVenda();
        this.semanaVendaOrig = relt.getSemanaVendaOrig();
        this.score = relt.getScore();
        this.scoreConsumido = relt.getScoreConsumido();
        this.datFinalizacaoOrdem = relt.getDatFinalizacaoOrdem();
        this.qtdContratos = relt.getQtdContratos();
        this.nomLoginResponsavel = relt.getNomLoginResponsavel();
        this.detalheRecusaCrivo = relt.getDetalheRecusaCrivo();
        this.loginCancelamentoOrdem = relt.getLoginCancelamentoOrdem();
        this.nomeParceiroVenda = relt.getNomeParceiroVenda();
        this.nomeParceiroVendaOrig = relt.getNomeParceiroVendaOrig();
        this.velocidadeDownload = relt.getVelocidadeDownload();
        this.velocidadeUpload = relt.getVelocidadeUpload();
        this.custcodeCliente = relt.getCustcodeCliente();
        this.msanOltTrafego = relt.getMsanOltTrafego();
        this.codContratoAtual = relt.getCodContratoAtual();
        this.codConvergente = relt.getCodConvergente();
        this.nomeVendedor = relt.getNomeVendedor();
    }

    public void setBat510(E2EStep7PT2Value bat) {
        this.nomeVendedorOrig = bat.getNomeVendedorOrig();
    }

    @Override
    public String toString() {
        return new StringBuilder()
                .append(datRef).append("|")
                .append(codContratoOltp).append("|")
                .append(codContratoAtivacao).append("|")
                .append(numeroAcesso).append("|")
                .append(customerId).append("|")
                .append(tipoProduto).append("|")
                .append(planoAtivacaoOferta).append("|")
                .append(motivoChurn).append("|")
                .append(tipoChurn).append("|")
                .append(email).append("|")
                .append(uf).append("|")
                .append(tipoLogradouro).append("|")
                .append(logradouro).append("|")
                .append(numero).append("|")
                .append(complemento).append("|")
                .append(bairro).append("|")
                .append(cep).append("|")
                .append(cidade).append("|")
                .append(tecnologia).append("|")
                .append(formaPagamento).append("|")
                .append(tipoConta).append("|")
                .append(codBanco).append("|")
                .append(codAgenciaBanco).append("|")
                .append(codContaCorrente).append("|")
                .append(codDebitoAutomatico).append("|")
                .append(diaVencimento).append("|")
                .append(codContaFinanceira).append("|")
                .append(numProtocolo).append("|")
                .append(flgOrdemAutomatica).append("|")
                .append(dscTxRecorrente).append("|")
                .append(dscTxNaoRecorrente).append("|")
                .append(dscStatusItem).append("|")
                .append(nomPlanoAtual).append("|")
                .append(valPlanoAtualItem).append("|")
                .append(nomDescontoAtualItem).append("|")
                .append(valDescontoAtualItem).append("|")
                .append(flgPortabilidade).append("|")
                .append(dscOperadoraDoadora).append("|")
                .append(codDdd).append("|")
                .append(numTelefonePortado).append("|")
                .append(datJanelaPortabilidade).append("|")
                .append(horJanela).append("|")
                .append(dscEnderecoFatura).append("|")
                .append(dscAreaVoip).append("|")
                .append(cpe).append("|")
                .append(ont).append("|")
                .append(itemRoot).append("|")
                .append(dominioRoot).append("|")
                .append(nroOrdem).append("|")
                .append(acessoRowId).append("|")
                .append(acessoRowIdRoot).append("|")
                .append(codigoProduto).append("|")
                .append(datCriacaoOrdem).append("|")
                .append(horCriacaoOrdem).append("|")
                .append(datVenda).append("|")
                .append(horaVenda).append("|")
                .append(datVendaOrig).append("|")
                .append(horVendaOrig).append("|")
                .append(datStatusOrdem).append("|")
                .append(horStatusOrdem).append("|")
                .append(numOrdemSiebel).append("|")
                .append(numOrdemSiebelOrig).append("|")
                .append(tipoDocumento).append("|")
                .append(documento).append("|")
                .append(tipoVenda).append("|")
                .append(loginVendedor).append("|")
                .append(loginVendedorOrig).append("|")
                .append(canal).append("|")
                .append(canalOrig).append("|")
                .append(cnpjParceiro).append("|")
                .append(cnpjParceiroOrig).append("|")
                .append(custCode).append("|")
                .append(custCodeOrig).append("|")
                .append(position).append("|")
                .append(positionOrig).append("|")
                .append(flgCancAntesVenda).append("|")
                .append(flgVendaSubmetida).append("|")
                .append(flgVendaDuplicada).append("|")
                .append(flgVendaBruta).append("|")
                .append(flgVendaLiquida).append("|")
                .append(flgCancPosVenda).append("|")
                .append(flgCancDupl).append("|")
                .append(flgCancLiquido).append("|")
                .append(datCancVenda).append("|")
                .append(motivoCancelamento).append("|")
                .append(nomeCliente).append("|")
                .append(telefone).append("|")
                .append(statusOrdem).append("|")
                .append(semanaVenda).append("|")
                .append(semanaVendaOrig).append("|")
                .append(score).append("|")
                .append(scoreConsumido).append("|")
                .append(datFinalizacaoOrdem).append("|")
                .append(qtdContratos).append("|")
                .append(nomLoginResponsavel).append("|")
                .append(detalheRecusaCrivo).append("|")
                .append(loginCancelamentoOrdem).append("|")
                .append(nomeParceiroVenda).append("|")
                .append(nomeParceiroVendaOrig).append("|")
                .append(velocidadeDownload).append("|")
                .append(velocidadeUpload).append("|")
                .append(custcodeCliente).append("|")
                .append(msanOltTrafego).append("|")
                .append(codContratoAtual).append("|")
                .append(codConvergente).append("|")
                .append(nomeVendedor).append("|")
                .append(nomeVendedorOrig).toString();
    }
}
