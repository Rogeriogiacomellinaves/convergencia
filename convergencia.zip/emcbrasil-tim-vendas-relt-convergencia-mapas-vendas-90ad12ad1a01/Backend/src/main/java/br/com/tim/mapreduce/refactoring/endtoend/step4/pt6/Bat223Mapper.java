package br.com.tim.mapreduce.refactoring.endtoend.step4.pt6;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.Mapper;

import br.com.tim.mapreduce.refactoring.endtoend.step4.model.Bat223Model;
import br.com.tim.mapreduce.refactoring.endtoend.step4.utils.Step4PT6Counters223;

public class Bat223Mapper<T extends Writable> extends Mapper<T, Text, Step4Pt6Key, E2EStep4Pt6Value> {

    private E2EStep4Pt6Value outValue;
    private Bat223Model model;
    private Step4Pt6Key outkey;

    @Override
    protected void setup(Mapper<T, Text, Step4Pt6Key, E2EStep4Pt6Value>.Context context) throws IOException, InterruptedException {
        this.outValue = new E2EStep4Pt6Value();
        this.model = new Bat223Model();
        this.outkey = new Step4Pt6Key();
    }

    @Override
    protected void map(T key, Text value, Mapper<T, Text, Step4Pt6Key, E2EStep4Pt6Value>.Context context)
            throws IOException, InterruptedException {



        model.parseFromText(value.toString());
        
        outkey.setCodContrato(model.getNumero_contrato());
        outkey.setTipo(TypeStep4Pt6.BAT223);

        this.outValue.setBat223(model);

        context.write(outkey, this.outValue);
        context.getCounter(Step4PT6Counters223.BAT_223_MAPPER).increment(1l);

    }

}