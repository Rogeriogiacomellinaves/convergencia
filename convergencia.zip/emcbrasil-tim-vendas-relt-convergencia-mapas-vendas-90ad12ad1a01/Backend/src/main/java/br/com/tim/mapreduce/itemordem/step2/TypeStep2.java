package br.com.tim.mapreduce.itemordem.step2;

public enum TypeStep2 {

    BAT513, RESULTSTEP1
}
