package br.com.tim.mapreduce.e2e.step8;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.log4j.Logger;

import java.io.IOException;

public class E2EStep8Reducer extends org.apache.hadoop.mapreduce.Reducer<E2EStep8Key,E2EStep8Value,NullWritable,Text> {

    protected static final Logger LOG = Logger.getLogger(E2EStep8Reducer.class);
    private E2EStep8OutValue outValue;

    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        super.setup(context);
        outValue = new E2EStep8OutValue();
    }

    @Override
    protected void reduce(E2EStep8Key key, Iterable<E2EStep8Value> values, Context context) throws InterruptedException {

        outValue.clear();

        try {
            for (E2EStep8Value value : values) {
                if (value.getTipo().equals(TypeStep8.RELT)){
                    outValue.clearRelt();
                    outValue.setRelt(value);
                    context.getCounter("REDUCER", "RELT").increment(1);
                    context.write(NullWritable.get(), new Text(outValue.toString()));
                }else if (value.getTipo().equals(TypeStep8.GROSS)){
                    outValue.setGross(value);
                    context.getCounter("REDUCER", "GROSS").increment(1);
                }else if (value.getTipo().equals(TypeStep8.CHURN)){
                    outValue.setChurn(value);
                    context.getCounter("REDUCER", "CHURN").increment(1);
                }
            }

        } catch (Exception e) {
            LOG.error(" ############ ERROR EXECUTION REDUCER ############ ");
            LOG.error(e.getMessage());
            throw new InterruptedException(e.getMessage());
        }
    }



    @Override
    protected void cleanup(Context context) throws IOException, InterruptedException {
        super.cleanup(context);

    }
}


