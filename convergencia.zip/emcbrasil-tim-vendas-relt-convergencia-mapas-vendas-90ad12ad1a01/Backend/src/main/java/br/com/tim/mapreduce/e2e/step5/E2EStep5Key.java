package br.com.tim.mapreduce.e2e.step5;

import br.com.tim.mapreduce.e2e.GroupComparable;
import com.google.common.collect.ComparisonChain;
import org.apache.hadoop.io.WritableComparable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Objects;

public class E2EStep5Key implements GroupComparable<E2EStep5Key> {

	private String numAcesso;
	private TypeStep5 tipo;

	@Override
	public void write(DataOutput output) throws IOException {
		output.writeInt(tipo.ordinal());
		output.writeUTF(this.numAcesso);
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		this.tipo = TypeStep5.values()[in.readInt()];
		this.numAcesso = in.readUTF();
	}

	public String getNumAcesso() {
		return numAcesso;
	}

	public void setTipo(TypeStep5 tipo) {
		this.tipo = tipo;
	}

	public void setNumAcesso(String numAcesso) {
		this.numAcesso = numAcesso;
	}

	@Override
	public int compareTo(E2EStep5Key o) {
		return ComparisonChain.start().compare(this.numAcesso, o.numAcesso).compare(this.tipo, o.tipo)
				.result();
	}

	@Override
	public int compareToGrouping(E2EStep5Key o) {
		return ComparisonChain.start().compare(this.numAcesso, o.numAcesso).result();
	}

	public int hashCodeJoin() {

		return Objects.hash(numAcesso);
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		E2EStep5Key key = (E2EStep5Key) o;
		return Objects.equals(numAcesso, key.numAcesso);
	}


	@Override
	public int hashCode() {

		return Objects.hash(numAcesso);
	}
}