package br.com.tim.mapreduce.refactoring.endtoend.step4.pt6;

import java.io.IOException;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.log4j.Logger;

import br.com.tim.mapreduce.refactoring.endtoend.step4.utils.Step4PT6Counters223;

public class E2EStep4Pt6Reducer extends org.apache.hadoop.mapreduce.Reducer<Step4Pt6Key,E2EStep4Pt6Value,NullWritable,Text> {

    protected static final Logger LOG = Logger.getLogger(E2EStep4Pt6Reducer.class);
    private E2EStep4Pt6OutValue outValue;


    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        super.setup(context);
        outValue = new E2EStep4Pt6OutValue();
    }

    @Override
    protected void reduce(Step4Pt6Key key, Iterable<E2EStep4Pt6Value> values, Context context) throws InterruptedException {

        outValue.clear();

        try {
            for (E2EStep4Pt6Value value : values) {
                if (value.getTipo().equals(TypeStep4Pt6.RELT)){
                    outValue.clearRelt();
                    outValue.setRelt(value);
                    context.write(NullWritable.get(), new Text(outValue.toString()));
                    context.getCounter(Step4PT6Counters223.REDUCER_WRITE).increment(1l);
                }else if (value.getTipo().equals(TypeStep4Pt6.BAT223)){
                	context.getCounter(Step4PT6Counters223.BAT_223_REDUCER).increment(1l);
                    outValue.set223(value);
                }
            }

        } catch (Exception e) {
            LOG.error(" ############ ERROR EXECUTION REDUCER ############ ");
            LOG.error(e.getMessage());
            throw new InterruptedException(e.getMessage());
        }
    }



    @Override
    protected void cleanup(Context context) throws IOException, InterruptedException {
        super.cleanup(context);

    }
}


