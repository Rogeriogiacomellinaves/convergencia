package br.com.tim.mapreduce.refactoring.model;

import org.apache.commons.lang3.StringUtils;

import br.com.tim.utils.CommonsConstants;

public class CDRFiber {

        private String dateFiber;
        private String time;
        private String origem;
        private String rasclient;
        private String recordtype;
        private String fullname;
        private String authtype;
        private String username;
        private String nasipaddress;
        private String nasport;
        private String servicetype;
        private String framedprotocol;
        private String framedipaddress;
        private String framedipnetmask;
        private String framedrouting;
        private String sessiontimeout;
        private String idletimeout;
        private String terminationaction;
        private String nasidentifier;
        private String acctstatustype;
        private String acctdelaytime;
        private String acctinputoctets;
        private String acctoutputoctets;
        private String acctsessionid;
        private String acctauthentic;
        private String acctsessiontime;
        private String acctinputpackets;
        private String acctoutputpackets;
        private String acctterminationcause;
        private String nasporttype;
        private String acctinputgigawords;
        private String acctoutputgigawords;
        private String nasportid;
        private String adslagentcircuitid;
        private String adslagentremoteid;
        private String framedroute;
        private String classe;
        private String nasipv6address;
        private String framedinterfaceid;
        private String framedipv6prefix;
        private String framedipv6route;
        private String framedipv6pool;
        private String delegatedipv6prefix;
        private String unisphereingresspolicyname;
        private String unisphereegresspolicyname;
        private String unisphereservicebundle;
        private String chargeableuseridentity;
        private String unisphereservicesession;
        private String unispherelocalinterface;
        private String unisphereinterfacedesc;
        private String jnpripv6ingresspolicyname;
        private String jnpripv6egresspolicyname;
        private String jnprcosparametertype;
        private String unisphereqossetname;
        private String jnprcosschedulerpmttype;
        private String unisphereipv6acctinputoctets;
        private String unisphereipv6acctoutputoctets;
        private String unisphereipv6acctinputpackets;
        private String unisphereipv6acctoutputpackets;
        private String unisphereipv6acctinputgigawords;
        private String unisphereipv6acctoutputgigawords;
        private String jnpripv6delegatedpoolname;
        private String callingstationid;
        private String parentifhandle;
        private String ifhandle;
        private String clientmacaddress;
        private String circuitidtag;
        private String remoteid;
        private String echostring1;
        private String echostring2;
        private String echostring3;
        private String echostring4;
        private String vrfid;
        private String accountinglist;
        private String pppoesessionid;
        private String connectprogress;
        private String acctinputoctetsipv4;
        private String accinputgigawordsipv4;
        private String acctinputpacketsipv4;
        private String acctoutputoctetsipv4;
        private String acctoutputgigawordsipv4;
        private String acctoutputpacketsipv4;
        private String acctinputoctetsipv6;
        private String acctinputgigawordsipv6;
        private String acctinputpacketsipv6;
        private String acctoutputoctetsipv6;
        private String acctoutputgigawordsipv6;
        private String acctoutputpacketsipv6;
        private String rowid;
        private String loteid;
        private String arquivo;
        private String arquivots;
        private String currentdate;
        private String acctinteriminterval;
        private String hwqosprofilename;
        private String hwdownqosprofilename;
        private String hwusermac;
        private String hwvpninstance;
        private String hwacctipv6inputoctets;
        private String hwacctipv6outputoctets;
        private String hwacctipv6inputpackets;
        private String hwacctipv6outputpackets;
        private String hwacctipv6inputgigawords;
        private String hwacctipv6outputgigawords;
        private String huaweiuserclass;
        private String huaweidomainname;
        private String hwconnectid;

    public CDRFiber() {

    	 this.dateFiber = CommonsConstants.EMPTY;
         this.time = CommonsConstants.EMPTY;
         this.origem = CommonsConstants.EMPTY;
         this.rasclient = CommonsConstants.EMPTY;
         this.recordtype = CommonsConstants.EMPTY;
         this.fullname = CommonsConstants.EMPTY;
         this.authtype = CommonsConstants.EMPTY;
         this.username = CommonsConstants.EMPTY;
         this.nasipaddress = CommonsConstants.EMPTY;
         this.nasport = CommonsConstants.EMPTY;
         this.servicetype = CommonsConstants.EMPTY;
         this.framedprotocol = CommonsConstants.EMPTY;
         this.framedipaddress = CommonsConstants.EMPTY;
         this.framedipnetmask = CommonsConstants.EMPTY;
         this.framedrouting = CommonsConstants.EMPTY;
         this.sessiontimeout = CommonsConstants.EMPTY;
         this.idletimeout = CommonsConstants.EMPTY;
         this.terminationaction = CommonsConstants.EMPTY;
         this.nasidentifier = CommonsConstants.EMPTY;
         this.acctstatustype = CommonsConstants.EMPTY;
         this.acctdelaytime = CommonsConstants.EMPTY;
         this.acctinputoctets = CommonsConstants.EMPTY;
         this.acctoutputoctets = CommonsConstants.EMPTY;
         this.acctsessionid = CommonsConstants.EMPTY;
         this.acctauthentic = CommonsConstants.EMPTY;
         this.acctsessiontime = CommonsConstants.EMPTY;
         this.acctinputpackets = CommonsConstants.EMPTY;
         this.acctoutputpackets = CommonsConstants.EMPTY;
         this.acctterminationcause = CommonsConstants.EMPTY;
         this.nasporttype = CommonsConstants.EMPTY;
         this.acctinputgigawords = CommonsConstants.EMPTY;
         this.acctoutputgigawords = CommonsConstants.EMPTY;
         this.nasportid = CommonsConstants.EMPTY;
         this.adslagentcircuitid = CommonsConstants.EMPTY;
         this.adslagentremoteid = CommonsConstants.EMPTY;
         this.framedroute = CommonsConstants.EMPTY;
         this.classe = CommonsConstants.EMPTY;
         this.nasipv6address = CommonsConstants.EMPTY;
         this.framedinterfaceid = CommonsConstants.EMPTY;
         this.framedipv6prefix = CommonsConstants.EMPTY;
         this.framedipv6route = CommonsConstants.EMPTY;
         this.framedipv6pool = CommonsConstants.EMPTY;
         this.delegatedipv6prefix = CommonsConstants.EMPTY;
         this.unisphereingresspolicyname = CommonsConstants.EMPTY;
         this.unisphereegresspolicyname = CommonsConstants.EMPTY;
         this.unisphereservicebundle = CommonsConstants.EMPTY;
         this.chargeableuseridentity = CommonsConstants.EMPTY;
         this.unisphereservicesession = CommonsConstants.EMPTY;
         this.unispherelocalinterface = CommonsConstants.EMPTY;
         this.unisphereinterfacedesc = CommonsConstants.EMPTY;
         this.jnpripv6ingresspolicyname = CommonsConstants.EMPTY;
         this.jnpripv6egresspolicyname = CommonsConstants.EMPTY;
         this.jnprcosparametertype = CommonsConstants.EMPTY;
         this.unisphereqossetname = CommonsConstants.EMPTY;
         this.jnprcosschedulerpmttype = CommonsConstants.EMPTY;
         this.unisphereipv6acctinputoctets = CommonsConstants.EMPTY;
         this.unisphereipv6acctoutputoctets = CommonsConstants.EMPTY;
         this.unisphereipv6acctinputpackets = CommonsConstants.EMPTY;
         this.unisphereipv6acctoutputpackets = CommonsConstants.EMPTY;
         this.unisphereipv6acctinputgigawords = CommonsConstants.EMPTY;
         this.unisphereipv6acctoutputgigawords = CommonsConstants.EMPTY;
         this.jnpripv6delegatedpoolname = CommonsConstants.EMPTY;
         this.callingstationid = CommonsConstants.EMPTY;
         this.parentifhandle = CommonsConstants.EMPTY;
         this.ifhandle = CommonsConstants.EMPTY;
         this.clientmacaddress = CommonsConstants.EMPTY;
         this.circuitidtag = CommonsConstants.EMPTY;
         this.remoteid = CommonsConstants.EMPTY;
         this.echostring1 = CommonsConstants.EMPTY;
         this.echostring2 = CommonsConstants.EMPTY;
         this.echostring3 = CommonsConstants.EMPTY;
         this.echostring4 = CommonsConstants.EMPTY;
         this.vrfid = CommonsConstants.EMPTY;
         this.accountinglist = CommonsConstants.EMPTY;
         this.pppoesessionid = CommonsConstants.EMPTY;
         this.connectprogress = CommonsConstants.EMPTY;
         this.acctinputoctetsipv4 = CommonsConstants.EMPTY;
         this.accinputgigawordsipv4 = CommonsConstants.EMPTY;
         this.acctinputpacketsipv4 = CommonsConstants.EMPTY;
         this.acctoutputoctetsipv4 = CommonsConstants.EMPTY;
         this.acctoutputgigawordsipv4 = CommonsConstants.EMPTY;
         this.acctoutputpacketsipv4 = CommonsConstants.EMPTY;
         this.acctinputoctetsipv6 = CommonsConstants.EMPTY;
         this.acctinputgigawordsipv6 = CommonsConstants.EMPTY;
         this.acctinputpacketsipv6 = CommonsConstants.EMPTY;
         this.acctoutputoctetsipv6 = CommonsConstants.EMPTY;
         this.acctoutputgigawordsipv6 = CommonsConstants.EMPTY;
         this.acctoutputpacketsipv6 = CommonsConstants.EMPTY;
         this.rowid = CommonsConstants.EMPTY;
         this.loteid = CommonsConstants.EMPTY;
         this.arquivo = CommonsConstants.EMPTY;
         this.arquivots = CommonsConstants.EMPTY;
         this.currentdate = CommonsConstants.EMPTY;
         this.acctinteriminterval = CommonsConstants.EMPTY;
         this.hwqosprofilename = CommonsConstants.EMPTY;
         this.hwdownqosprofilename = CommonsConstants.EMPTY;
         this.hwusermac = CommonsConstants.EMPTY;
         this.hwvpninstance = CommonsConstants.EMPTY;
         this.hwacctipv6inputoctets = CommonsConstants.EMPTY;
         this.hwacctipv6outputoctets = CommonsConstants.EMPTY;
         this.hwacctipv6inputpackets = CommonsConstants.EMPTY;
         this.hwacctipv6outputpackets = CommonsConstants.EMPTY;
         this.hwacctipv6inputgigawords = CommonsConstants.EMPTY;
         this.hwacctipv6outputgigawords = CommonsConstants.EMPTY;
         this.huaweiuserclass = CommonsConstants.EMPTY;
         this.huaweidomainname = CommonsConstants.EMPTY;
         this.hwconnectid = CommonsConstants.EMPTY;

    }

    public void setCDRFiber(String dateFiber, String time, String origem, String rasclient, String recordtype, String fullname, String authtype, String username,
                            String nasipaddress, String nasport, String servicetype, String framedprotocol, String framedipaddress, String framedipnetmask,
                            String framedrouting, String sessiontimeout, String idletimeout, String terminationaction, String nasidentifier, String acctstatustype,
                            String acctdelaytime, String acctinputoctets, String acctoutputoctets, String acctsessionid, String acctauthentic, String acctsessiontime,
                            String acctinputpackets, String acctoutputpackets, String acctterminationcause, String nasporttype, String acctinputgigawords,
                            String acctoutputgigawords, String nasportid, String adslagentcircuitid, String adslagentremoteid, String framedroute, String classe,
                            String nasipv6address, String framedinterfaceid, String framedipv6prefix, String framedipv6route, String framedipv6pool, String delegatedipv6prefix,
                            String unisphereingresspolicyname, String unisphereegresspolicyname, String unisphereservicebundle, String chargeableuseridentity,
                            String unisphereservicesession, String unispherelocalinterface, String unisphereinterfacedesc, String jnpripv6ingresspolicyname,
                            String jnpripv6egresspolicyname, String jnprcosparametertype, String unisphereqossetname, String jnprcosschedulerpmttype, String unisphereipv6acctinputoctets,
                            String unisphereipv6acctoutputoctets, String unisphereipv6acctinputpackets, String unisphereipv6acctoutputpackets, String unisphereipv6acctinputgigawords,
                            String unisphereipv6acctoutputgigawords, String jnpripv6delegatedpoolname, String callingstationid, String parentifhandle, String ifhandle,
                            String clientmacaddress,String circuitidtag, String remoteid, String echostring1, String echostring2, String echostring3, String echostring4,
                            String vrfid,String accountinglist, String pppoesessionid, String connectprogress, String acctinputoctetsipv4, String accinputgigawordsipv4,
                            String acctinputpacketsipv4, String acctoutputoctetsipv4, String acctoutputgigawordsipv4, String acctoutputpacketsipv4, String acctinputoctetsipv6,
                            String acctinputgigawordsipv6, String acctinputpacketsipv6, String acctoutputoctetsipv6, String acctoutputgigawordsipv6, String acctoutputpacketsipv6,
                            String rowid, String loteid, String arquivo, String arquivots, String currentdate, String acctinteriminterval, String hwqosprofilename,
                            String hwdownqosprofilename, String hwusermac, String hwvpninstance, String hwacctipv6inputoctets, String hwacctipv6outputoctets,
                            String hwacctipv6inputpackets, String hwacctipv6outputpackets, String hwacctipv6inputgigawords, String hwacctipv6outputgigawords, String huaweiuserclass,
                            String huaweidomainname, String hwconnectid) {
        this.dateFiber = dateFiber;
        this.time = time;
        this.origem = origem;
        this.rasclient = rasclient;
        this.recordtype = recordtype;
        this.fullname = fullname;
        this.authtype = authtype;
        this.username = username;
        this.nasipaddress = nasipaddress;
        this.nasport = nasport;
        this.servicetype = servicetype;
        this.framedprotocol = framedprotocol;
        this.framedipaddress = framedipaddress;
        this.framedipnetmask = framedipnetmask;
        this.framedrouting = framedrouting;
        this.sessiontimeout = sessiontimeout;
        this.idletimeout = idletimeout;
        this.terminationaction = terminationaction;
        this.nasidentifier = nasidentifier;
        this.acctstatustype = acctstatustype;
        this.acctdelaytime = acctdelaytime;
        this.acctinputoctets = acctinputoctets;
        this.acctoutputoctets = acctoutputoctets;
        this.acctsessionid = acctsessionid;
        this.acctauthentic = acctauthentic;
        this.acctsessiontime = acctsessiontime;
        this.acctinputpackets = acctinputpackets;
        this.acctoutputpackets = acctoutputpackets;
        this.acctterminationcause = acctterminationcause;
        this.nasporttype = nasporttype;
        this.acctinputgigawords = acctinputgigawords;
        this.acctoutputgigawords = acctoutputgigawords;
        this.nasportid = nasportid;
        this.adslagentcircuitid = adslagentcircuitid;
        this.adslagentremoteid = adslagentremoteid;
        this.framedroute = framedroute;
        this.classe = classe;
        this.nasipv6address = nasipv6address;
        this.framedinterfaceid = framedinterfaceid;
        this.framedipv6prefix = framedipv6prefix;
        this.framedipv6route = framedipv6route;
        this.framedipv6pool = framedipv6pool;
        this.delegatedipv6prefix = delegatedipv6prefix;
        this.unisphereingresspolicyname = unisphereingresspolicyname;
        this.unisphereegresspolicyname = unisphereegresspolicyname;
        this.unisphereservicebundle = unisphereservicebundle;
        this.chargeableuseridentity = chargeableuseridentity;
        this.unisphereservicesession = unisphereservicesession;
        this.unispherelocalinterface = unispherelocalinterface;
        this.unisphereinterfacedesc = unisphereinterfacedesc;
        this.jnpripv6ingresspolicyname = jnpripv6ingresspolicyname;
        this.jnpripv6egresspolicyname = jnpripv6egresspolicyname;
        this.jnprcosparametertype = jnprcosparametertype;
        this.unisphereqossetname = unisphereqossetname;
        this.jnprcosschedulerpmttype = jnprcosschedulerpmttype;
        this.unisphereipv6acctinputoctets = unisphereipv6acctinputoctets;
        this.unisphereipv6acctoutputoctets = unisphereipv6acctoutputoctets;
        this.unisphereipv6acctinputpackets = unisphereipv6acctinputpackets;
        this.unisphereipv6acctoutputpackets = unisphereipv6acctoutputpackets;
        this.unisphereipv6acctinputgigawords = unisphereipv6acctinputgigawords;
        this.unisphereipv6acctoutputgigawords = unisphereipv6acctoutputgigawords;
        this.jnpripv6delegatedpoolname = jnpripv6delegatedpoolname;
        this.callingstationid = callingstationid;
        this.parentifhandle = parentifhandle;
        this.ifhandle = ifhandle;
        this.clientmacaddress = clientmacaddress;
        this.circuitidtag = circuitidtag;
        this.remoteid = remoteid;
        this.echostring1 = echostring1;
        this.echostring2 = echostring2;
        this.echostring3 = echostring3;
        this.echostring4 = echostring4;
        this.vrfid = vrfid;
        this.accountinglist = accountinglist;
        this.pppoesessionid = pppoesessionid;
        this.connectprogress = connectprogress;
        this.acctinputoctetsipv4 = acctinputoctetsipv4;
        this.accinputgigawordsipv4 = accinputgigawordsipv4;
        this.acctinputpacketsipv4 = acctinputpacketsipv4;
        this.acctoutputoctetsipv4 = acctoutputoctetsipv4;
        this.acctoutputgigawordsipv4 = acctoutputgigawordsipv4;
        this.acctoutputpacketsipv4 = acctoutputpacketsipv4;
        this.acctinputoctetsipv6 = acctinputoctetsipv6;
        this.acctinputgigawordsipv6 = acctinputgigawordsipv6;
        this.acctinputpacketsipv6 = acctinputpacketsipv6;
        this.acctoutputoctetsipv6 = acctoutputoctetsipv6;
        this.acctoutputgigawordsipv6 = acctoutputgigawordsipv6;
        this.acctoutputpacketsipv6 = acctoutputpacketsipv6;
        this.rowid = rowid;
        this.loteid = loteid;
        this.arquivo = arquivo;
        this.arquivots = arquivots;
        this.currentdate = currentdate;
        this.acctinteriminterval = acctinteriminterval;
        this.hwqosprofilename = hwqosprofilename;
        this.hwdownqosprofilename = hwdownqosprofilename;
        this.hwusermac = hwusermac;
        this.hwvpninstance = hwvpninstance;
        this.hwacctipv6inputoctets = hwacctipv6inputoctets;
        this.hwacctipv6outputoctets = hwacctipv6outputoctets;
        this.hwacctipv6inputpackets = hwacctipv6inputpackets;
        this.hwacctipv6outputpackets = hwacctipv6outputpackets;
        this.hwacctipv6inputgigawords = hwacctipv6inputgigawords;
        this.hwacctipv6outputgigawords = hwacctipv6outputgigawords;
        this.huaweiuserclass = huaweiuserclass;
        this.huaweidomainname = huaweidomainname;
        this.hwconnectid = hwconnectid;
    }

    public boolean parse(String textString) {
        if (StringUtils.isNotBlank(textString)) {
            String[] cols = textString.split("\\|", -1);
            int i = 0;
            this.setCDRFiber(cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                             cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                             cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                             cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                             cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                             cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                             cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                             cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                             cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                             cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                             cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++]);
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        String delimiter = "|";

        sb.append(dateFiber).append(delimiter)
          .append(time).append(delimiter)
          .append(origem).append(delimiter)
          .append(rasclient).append(delimiter)
          .append(recordtype).append(delimiter)
          .append(fullname).append(delimiter)
          .append(authtype).append(delimiter)
          .append(username).append(delimiter)
          .append(nasipaddress).append(delimiter)
          .append(nasport).append(delimiter)
          .append(servicetype).append(delimiter)
          .append(framedprotocol).append(delimiter)
          .append(framedipaddress).append(delimiter)
          .append(framedipnetmask).append(delimiter)
          .append(framedrouting).append(delimiter)
          .append(sessiontimeout).append(delimiter)
          .append(idletimeout).append(delimiter)
          .append(terminationaction).append(delimiter)
          .append(nasidentifier).append(delimiter)
          .append(acctstatustype).append(delimiter)
          .append(acctdelaytime).append(delimiter)
          .append(acctinputoctets).append(delimiter)
          .append(acctoutputoctets).append(delimiter)
          .append(acctsessionid).append(delimiter)
          .append(acctauthentic).append(delimiter)
          .append(acctsessiontime).append(delimiter)
          .append(acctinputpackets).append(delimiter)
          .append(acctoutputpackets).append(delimiter)
          .append(acctterminationcause).append(delimiter)
          .append(nasporttype).append(delimiter)
          .append(acctinputgigawords).append(delimiter)
          .append(acctoutputgigawords).append(delimiter)
          .append(nasportid).append(delimiter)
          .append(adslagentcircuitid).append(delimiter)
          .append(adslagentremoteid).append(delimiter)
          .append(framedroute).append(delimiter)
          .append(classe).append(delimiter)
          .append(nasipv6address).append(delimiter)
          .append(framedinterfaceid).append(delimiter)
          .append(framedipv6prefix).append(delimiter)
          .append(framedipv6route).append(delimiter)
          .append(framedipv6pool).append(delimiter)
          .append(delegatedipv6prefix).append(delimiter)
          .append(unisphereingresspolicyname).append(delimiter)
          .append(unisphereegresspolicyname).append(delimiter)
          .append(unisphereservicebundle).append(delimiter)
          .append(chargeableuseridentity).append(delimiter)
          .append(unisphereservicesession).append(delimiter)
          .append(unispherelocalinterface).append(delimiter)
          .append(unisphereinterfacedesc).append(delimiter)
          .append(jnpripv6ingresspolicyname).append(delimiter)
          .append(jnpripv6egresspolicyname).append(delimiter)
          .append(jnprcosparametertype).append(delimiter)
          .append(unisphereqossetname).append(delimiter)
          .append(jnprcosschedulerpmttype).append(delimiter)
          .append(unisphereipv6acctinputoctets).append(delimiter)
          .append(unisphereipv6acctoutputoctets).append(delimiter)
          .append(unisphereipv6acctinputpackets).append(delimiter)
          .append(unisphereipv6acctoutputpackets).append(delimiter)
          .append(unisphereipv6acctinputgigawords).append(delimiter)
          .append(unisphereipv6acctoutputgigawords).append(delimiter)
          .append(jnpripv6delegatedpoolname).append(delimiter)
          .append(callingstationid).append(delimiter)
          .append(parentifhandle).append(delimiter)
          .append(ifhandle).append(delimiter)
          .append(clientmacaddress).append(delimiter)
          .append(circuitidtag).append(delimiter)
          .append(remoteid).append(delimiter)
          .append(echostring1).append(delimiter)
          .append(echostring2).append(delimiter)
          .append(echostring3).append(delimiter)
          .append(echostring4).append(delimiter)
          .append(vrfid).append(delimiter)
          .append(accountinglist).append(delimiter)
          .append(pppoesessionid).append(delimiter)
          .append(connectprogress).append(delimiter)
          .append(acctinputoctetsipv4).append(delimiter)
          .append(accinputgigawordsipv4).append(delimiter)
          .append(acctinputpacketsipv4).append(delimiter)
          .append(acctoutputoctetsipv4).append(delimiter)
          .append(acctoutputgigawordsipv4).append(delimiter)
          .append(acctoutputpacketsipv4).append(delimiter)
          .append(acctinputoctetsipv6).append(delimiter)
          .append(acctinputgigawordsipv6).append(delimiter)
          .append(acctinputpacketsipv6).append(delimiter)
          .append(acctoutputoctetsipv6).append(delimiter)
          .append(acctoutputgigawordsipv6).append(delimiter)
          .append(acctoutputpacketsipv6).append(delimiter)
          .append(rowid).append(delimiter)
          .append(loteid).append(delimiter)
          .append(arquivo).append(delimiter)
          .append(arquivots).append(delimiter)
          .append(currentdate).append(delimiter)
          .append(acctinteriminterval).append(delimiter)
          .append(hwqosprofilename).append(delimiter)
          .append(hwdownqosprofilename).append(delimiter)
          .append(hwusermac).append(delimiter)
          .append(hwvpninstance).append(delimiter)
          .append(hwacctipv6inputoctets).append(delimiter)
          .append(hwacctipv6outputoctets).append(delimiter)
          .append(hwacctipv6inputpackets).append(delimiter)
          .append(hwacctipv6outputpackets).append(delimiter)
          .append(hwacctipv6inputgigawords).append(delimiter)
          .append(hwacctipv6outputgigawords).append(delimiter)
          .append(huaweiuserclass).append(delimiter)
          .append(huaweidomainname).append(delimiter)
          .append(hwconnectid);

        return sb.toString();

    }

    public String getDateFiber() {
        return dateFiber;
    }

    public void setDateFiber(String dateFiber) {
        this.dateFiber = dateFiber;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getOrigem() {
        return origem;
    }

    public void setOrigem(String origem) {
        this.origem = origem;
    }

    public String getRasclient() {
        return rasclient;
    }

    public void setRasclient(String rasclient) {
        this.rasclient = rasclient;
    }

    public String getRecordtype() {
        return recordtype;
    }

    public void setRecordtype(String recordtype) {
        this.recordtype = recordtype;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getAuthtype() {
        return authtype;
    }

    public void setAuthtype(String authtype) {
        this.authtype = authtype;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getNasipaddress() {
        return nasipaddress;
    }

    public void setNasipaddress(String nasipaddress) {
        this.nasipaddress = nasipaddress;
    }

    public String getNasport() {
        return nasport;
    }

    public void setNasport(String nasport) {
        this.nasport = nasport;
    }

    public String getServicetype() {
        return servicetype;
    }

    public void setServicetype(String servicetype) {
        this.servicetype = servicetype;
    }

    public String getFramedprotocol() {
        return framedprotocol;
    }

    public void setFramedprotocol(String framedprotocol) {
        this.framedprotocol = framedprotocol;
    }

    public String getFramedipaddress() {
        return framedipaddress;
    }

    public void setFramedipaddress(String framedipaddress) {
        this.framedipaddress = framedipaddress;
    }

    public String getFramedipnetmask() {
        return framedipnetmask;
    }

    public void setFramedipnetmask(String framedipnetmask) {
        this.framedipnetmask = framedipnetmask;
    }

    public String getFramedrouting() {
        return framedrouting;
    }

    public void setFramedrouting(String framedrouting) {
        this.framedrouting = framedrouting;
    }

    public String getSessiontimeout() {
        return sessiontimeout;
    }

    public void setSessiontimeout(String sessiontimeout) {
        this.sessiontimeout = sessiontimeout;
    }

    public String getIdletimeout() {
        return idletimeout;
    }

    public void setIdletimeout(String idletimeout) {
        this.idletimeout = idletimeout;
    }

    public String getTerminationaction() {
        return terminationaction;
    }

    public void setTerminationaction(String terminationaction) {
        this.terminationaction = terminationaction;
    }

    public String getNasidentifier() {
        return nasidentifier;
    }

    public void setNasidentifier(String nasidentifier) {
        this.nasidentifier = nasidentifier;
    }

    public String getAcctstatustype() {
        return acctstatustype;
    }

    public void setAcctstatustype(String acctstatustype) {
        this.acctstatustype = acctstatustype;
    }

    public String getAcctdelaytime() {
        return acctdelaytime;
    }

    public void setAcctdelaytime(String acctdelaytime) {
        this.acctdelaytime = acctdelaytime;
    }

    public String getAcctinputoctets() {
        return acctinputoctets;
    }

    public void setAcctinputoctets(String acctinputoctets) {
        this.acctinputoctets = acctinputoctets;
    }

    public String getAcctoutputoctets() {
        return acctoutputoctets;
    }

    public void setAcctoutputoctets(String acctoutputoctets) {
        this.acctoutputoctets = acctoutputoctets;
    }

    public String getAcctsessionid() {
        return acctsessionid;
    }

    public void setAcctsessionid(String acctsessionid) {
        this.acctsessionid = acctsessionid;
    }

    public String getAcctauthentic() {
        return acctauthentic;
    }

    public void setAcctauthentic(String acctauthentic) {
        this.acctauthentic = acctauthentic;
    }

    public String getAcctsessiontime() {
        return acctsessiontime;
    }

    public void setAcctsessiontime(String acctsessiontime) {
        this.acctsessiontime = acctsessiontime;
    }

    public String getAcctinputpackets() {
        return acctinputpackets;
    }

    public void setAcctinputpackets(String acctinputpackets) {
        this.acctinputpackets = acctinputpackets;
    }

    public String getAcctoutputpackets() {
        return acctoutputpackets;
    }

    public void setAcctoutputpackets(String acctoutputpackets) {
        this.acctoutputpackets = acctoutputpackets;
    }

    public String getAcctterminationcause() {
        return acctterminationcause;
    }

    public void setAcctterminationcause(String acctterminationcause) {
        this.acctterminationcause = acctterminationcause;
    }

    public String getNasporttype() {
        return nasporttype;
    }

    public void setNasporttype(String nasporttype) {
        this.nasporttype = nasporttype;
    }

    public String getAcctinputgigawords() {
        return acctinputgigawords;
    }

    public void setAcctinputgigawords(String acctinputgigawords) {
        this.acctinputgigawords = acctinputgigawords;
    }

    public String getAcctoutputgigawords() {
        return acctoutputgigawords;
    }

    public void setAcctoutputgigawords(String acctoutputgigawords) {
        this.acctoutputgigawords = acctoutputgigawords;
    }

    public String getNasportid() {
        return nasportid;
    }

    public void setNasportid(String nasportid) {
        this.nasportid = nasportid;
    }

    public String getAdslagentcircuitid() {
        return adslagentcircuitid;
    }

    public void setAdslagentcircuitid(String adslagentcircuitid) {
        this.adslagentcircuitid = adslagentcircuitid;
    }

    public String getAdslagentremoteid() {
        return adslagentremoteid;
    }

    public void setAdslagentremoteid(String adslagentremoteid) {
        this.adslagentremoteid = adslagentremoteid;
    }

    public String getFramedroute() {
        return framedroute;
    }

    public void setFramedroute(String framedroute) {
        this.framedroute = framedroute;
    }

    public String getClasse() {
        return classe;
    }

    public void setClasse(String classe) {
        this.classe = classe;
    }

    public String getNasipv6address() {
        return nasipv6address;
    }

    public void setNasipv6address(String nasipv6address) {
        this.nasipv6address = nasipv6address;
    }

    public String getFramedinterfaceid() {
        return framedinterfaceid;
    }

    public void setFramedinterfaceid(String framedinterfaceid) {
        this.framedinterfaceid = framedinterfaceid;
    }

    public String getFramedipv6prefix() {
        return framedipv6prefix;
    }

    public void setFramedipv6prefix(String framedipv6prefix) {
        this.framedipv6prefix = framedipv6prefix;
    }

    public String getFramedipv6route() {
        return framedipv6route;
    }

    public void setFramedipv6route(String framedipv6route) {
        this.framedipv6route = framedipv6route;
    }

    public String getFramedipv6pool() {
        return framedipv6pool;
    }

    public void setFramedipv6pool(String framedipv6pool) {
        this.framedipv6pool = framedipv6pool;
    }

    public String getDelegatedipv6prefix() {
        return delegatedipv6prefix;
    }

    public void setDelegatedipv6prefix(String delegatedipv6prefix) {
        this.delegatedipv6prefix = delegatedipv6prefix;
    }

    public String getUnisphereingresspolicyname() {
        return unisphereingresspolicyname;
    }

    public void setUnisphereingresspolicyname(String unisphereingresspolicyname) {
        this.unisphereingresspolicyname = unisphereingresspolicyname;
    }

    public String getUnisphereegresspolicyname() {
        return unisphereegresspolicyname;
    }

    public void setUnisphereegresspolicyname(String unisphereegresspolicyname) {
        this.unisphereegresspolicyname = unisphereegresspolicyname;
    }

    public String getUnisphereservicebundle() {
        return unisphereservicebundle;
    }

    public void setUnisphereservicebundle(String unisphereservicebundle) {
        this.unisphereservicebundle = unisphereservicebundle;
    }

    public String getChargeableuseridentity() {
        return chargeableuseridentity;
    }

    public void setChargeableuseridentity(String chargeableuseridentity) {
        this.chargeableuseridentity = chargeableuseridentity;
    }

    public String getUnisphereservicesession() {
        return unisphereservicesession;
    }

    public void setUnisphereservicesession(String unisphereservicesession) {
        this.unisphereservicesession = unisphereservicesession;
    }

    public String getUnispherelocalinterface() {
        return unispherelocalinterface;
    }

    public void setUnispherelocalinterface(String unispherelocalinterface) {
        this.unispherelocalinterface = unispherelocalinterface;
    }

    public String getUnisphereinterfacedesc() {
        return unisphereinterfacedesc;
    }

    public void setUnisphereinterfacedesc(String unisphereinterfacedesc) {
        this.unisphereinterfacedesc = unisphereinterfacedesc;
    }

    public String getJnpripv6ingresspolicyname() {
        return jnpripv6ingresspolicyname;
    }

    public void setJnpripv6ingresspolicyname(String jnpripv6ingresspolicyname) {
        this.jnpripv6ingresspolicyname = jnpripv6ingresspolicyname;
    }

    public String getJnpripv6egresspolicyname() {
        return jnpripv6egresspolicyname;
    }

    public void setJnpripv6egresspolicyname(String jnpripv6egresspolicyname) {
        this.jnpripv6egresspolicyname = jnpripv6egresspolicyname;
    }

    public String getJnprcosparametertype() {
        return jnprcosparametertype;
    }

    public void setJnprcosparametertype(String jnprcosparametertype) {
        this.jnprcosparametertype = jnprcosparametertype;
    }

    public String getUnisphereqossetname() {
        return unisphereqossetname;
    }

    public void setUnisphereqossetname(String unisphereqossetname) {
        this.unisphereqossetname = unisphereqossetname;
    }

    public String getJnprcosschedulerpmttype() {
        return jnprcosschedulerpmttype;
    }

    public void setJnprcosschedulerpmttype(String jnprcosschedulerpmttype) {
        this.jnprcosschedulerpmttype = jnprcosschedulerpmttype;
    }

    public String getUnisphereipv6acctinputoctets() {
        return unisphereipv6acctinputoctets;
    }

    public void setUnisphereipv6acctinputoctets(String unisphereipv6acctinputoctets) {
        this.unisphereipv6acctinputoctets = unisphereipv6acctinputoctets;
    }

    public String getUnisphereipv6acctoutputoctets() {
        return unisphereipv6acctoutputoctets;
    }

    public void setUnisphereipv6acctoutputoctets(String unisphereipv6acctoutputoctets) {
        this.unisphereipv6acctoutputoctets = unisphereipv6acctoutputoctets;
    }

    public String getUnisphereipv6acctinputpackets() {
        return unisphereipv6acctinputpackets;
    }

    public void setUnisphereipv6acctinputpackets(String unisphereipv6acctinputpackets) {
        this.unisphereipv6acctinputpackets = unisphereipv6acctinputpackets;
    }

    public String getUnisphereipv6acctoutputpackets() {
        return unisphereipv6acctoutputpackets;
    }

    public void setUnisphereipv6acctoutputpackets(String unisphereipv6acctoutputpackets) {
        this.unisphereipv6acctoutputpackets = unisphereipv6acctoutputpackets;
    }

    public String getUnisphereipv6acctinputgigawords() {
        return unisphereipv6acctinputgigawords;
    }

    public void setUnisphereipv6acctinputgigawords(String unisphereipv6acctinputgigawords) {
        this.unisphereipv6acctinputgigawords = unisphereipv6acctinputgigawords;
    }

    public String getUnisphereipv6acctoutputgigawords() {
        return unisphereipv6acctoutputgigawords;
    }

    public void setUnisphereipv6acctoutputgigawords(String unisphereipv6acctoutputgigawords) {
        this.unisphereipv6acctoutputgigawords = unisphereipv6acctoutputgigawords;
    }

    public String getJnpripv6delegatedpoolname() {
        return jnpripv6delegatedpoolname;
    }

    public void setJnpripv6delegatedpoolname(String jnpripv6delegatedpoolname) {
        this.jnpripv6delegatedpoolname = jnpripv6delegatedpoolname;
    }

    public String getCallingstationid() {
        return callingstationid;
    }

    public void setCallingstationid(String callingstationid) {
        this.callingstationid = callingstationid;
    }

    public String getParentifhandle() {
        return parentifhandle;
    }

    public void setParentifhandle(String parentifhandle) {
        this.parentifhandle = parentifhandle;
    }

    public String getIfhandle() {
        return ifhandle;
    }

    public void setIfhandle(String ifhandle) {
        this.ifhandle = ifhandle;
    }

    public String getClientmacaddress() {
        return clientmacaddress;
    }

    public void setClientmacaddress(String clientmacaddress) {
        this.clientmacaddress = clientmacaddress;
    }

    public String getCircuitidtag() {
        return circuitidtag;
    }

    public void setCircuitidtag(String circuitidtag) {
        this.circuitidtag = circuitidtag;
    }

    public String getRemoteid() {
        return remoteid;
    }

    public void setRemoteid(String remoteid) {
        this.remoteid = remoteid;
    }

    public String getEchostring1() {
        return echostring1;
    }

    public void setEchostring1(String echostring1) {
        this.echostring1 = echostring1;
    }

    public String getEchostring2() {
        return echostring2;
    }

    public void setEchostring2(String echostring2) {
        this.echostring2 = echostring2;
    }

    public String getEchostring3() {
        return echostring3;
    }

    public void setEchostring3(String echostring3) {
        this.echostring3 = echostring3;
    }

    public String getEchostring4() {
        return echostring4;
    }

    public void setEchostring4(String echostring4) {
        this.echostring4 = echostring4;
    }

    public String getVrfid() {
        return vrfid;
    }

    public void setVrfid(String vrfid) {
        this.vrfid = vrfid;
    }

    public String getAccountinglist() {
        return accountinglist;
    }

    public void setAccountinglist(String accountinglist) {
        this.accountinglist = accountinglist;
    }

    public String getPppoesessionid() {
        return pppoesessionid;
    }

    public void setPppoesessionid(String pppoesessionid) {
        this.pppoesessionid = pppoesessionid;
    }

    public String getConnectprogress() {
        return connectprogress;
    }

    public void setConnectprogress(String connectprogress) {
        this.connectprogress = connectprogress;
    }

    public String getAcctinputoctetsipv4() {
        return acctinputoctetsipv4;
    }

    public void setAcctinputoctetsipv4(String acctinputoctetsipv4) {
        this.acctinputoctetsipv4 = acctinputoctetsipv4;
    }

    public String getAccinputgigawordsipv4() {
        return accinputgigawordsipv4;
    }

    public void setAccinputgigawordsipv4(String accinputgigawordsipv4) {
        this.accinputgigawordsipv4 = accinputgigawordsipv4;
    }

    public String getAcctinputpacketsipv4() {
        return acctinputpacketsipv4;
    }

    public void setAcctinputpacketsipv4(String acctinputpacketsipv4) {
        this.acctinputpacketsipv4 = acctinputpacketsipv4;
    }

    public String getAcctoutputoctetsipv4() {
        return acctoutputoctetsipv4;
    }

    public void setAcctoutputoctetsipv4(String acctoutputoctetsipv4) {
        this.acctoutputoctetsipv4 = acctoutputoctetsipv4;
    }

    public String getAcctoutputgigawordsipv4() {
        return acctoutputgigawordsipv4;
    }

    public void setAcctoutputgigawordsipv4(String acctoutputgigawordsipv4) {
        this.acctoutputgigawordsipv4 = acctoutputgigawordsipv4;
    }

    public String getAcctoutputpacketsipv4() {
        return acctoutputpacketsipv4;
    }

    public void setAcctoutputpacketsipv4(String acctoutputpacketsipv4) {
        this.acctoutputpacketsipv4 = acctoutputpacketsipv4;
    }

    public String getAcctinputoctetsipv6() {
        return acctinputoctetsipv6;
    }

    public void setAcctinputoctetsipv6(String acctinputoctetsipv6) {
        this.acctinputoctetsipv6 = acctinputoctetsipv6;
    }

    public String getAcctinputgigawordsipv6() {
        return acctinputgigawordsipv6;
    }

    public void setAcctinputgigawordsipv6(String acctinputgigawordsipv6) {
        this.acctinputgigawordsipv6 = acctinputgigawordsipv6;
    }

    public String getAcctinputpacketsipv6() {
        return acctinputpacketsipv6;
    }

    public void setAcctinputpacketsipv6(String acctinputpacketsipv6) {
        this.acctinputpacketsipv6 = acctinputpacketsipv6;
    }

    public String getAcctoutputoctetsipv6() {
        return acctoutputoctetsipv6;
    }

    public void setAcctoutputoctetsipv6(String acctoutputoctetsipv6) {
        this.acctoutputoctetsipv6 = acctoutputoctetsipv6;
    }

    public String getAcctoutputgigawordsipv6() {
        return acctoutputgigawordsipv6;
    }

    public void setAcctoutputgigawordsipv6(String acctoutputgigawordsipv6) {
        this.acctoutputgigawordsipv6 = acctoutputgigawordsipv6;
    }

    public String getAcctoutputpacketsipv6() {
        return acctoutputpacketsipv6;
    }

    public void setAcctoutputpacketsipv6(String acctoutputpacketsipv6) {
        this.acctoutputpacketsipv6 = acctoutputpacketsipv6;
    }

    public String getRowid() {
        return rowid;
    }

    public void setRowid(String rowid) {
        this.rowid = rowid;
    }

    public String getLoteid() {
        return loteid;
    }

    public void setLoteid(String loteid) {
        this.loteid = loteid;
    }

    public String getArquivo() {
        return arquivo;
    }

    public void setArquivo(String arquivo) {
        this.arquivo = arquivo;
    }

    public String getArquivots() {
        return arquivots;
    }

    public void setArquivots(String arquivots) {
        this.arquivots = arquivots;
    }

    public String getCurrentdate() {
        return currentdate;
    }

    public void setCurrentdate(String currentdate) {
        this.currentdate = currentdate;
    }

    public String getAcctinteriminterval() {
        return acctinteriminterval;
    }

    public void setAcctinteriminterval(String acctinteriminterval) {
        this.acctinteriminterval = acctinteriminterval;
    }

    public String getHwqosprofilename() {
        return hwqosprofilename;
    }

    public void setHwqosprofilename(String hwqosprofilename) {
        this.hwqosprofilename = hwqosprofilename;
    }

    public String getHwdownqosprofilename() {
        return hwdownqosprofilename;
    }

    public void setHwdownqosprofilename(String hwdownqosprofilename) {
        this.hwdownqosprofilename = hwdownqosprofilename;
    }

    public String getHwusermac() {
        return hwusermac;
    }

    public void setHwusermac(String hwusermac) {
        this.hwusermac = hwusermac;
    }

    public String getHwvpninstance() {
        return hwvpninstance;
    }

    public void setHwvpninstance(String hwvpninstance) {
        this.hwvpninstance = hwvpninstance;
    }

    public String getHwacctipv6inputoctets() {
        return hwacctipv6inputoctets;
    }

    public void setHwacctipv6inputoctets(String hwacctipv6inputoctets) {
        this.hwacctipv6inputoctets = hwacctipv6inputoctets;
    }

    public String getHwacctipv6outputoctets() {
        return hwacctipv6outputoctets;
    }

    public void setHwacctipv6outputoctets(String hwacctipv6outputoctets) {
        this.hwacctipv6outputoctets = hwacctipv6outputoctets;
    }

    public String getHwacctipv6inputpackets() {
        return hwacctipv6inputpackets;
    }

    public void setHwacctipv6inputpackets(String hwacctipv6inputpackets) {
        this.hwacctipv6inputpackets = hwacctipv6inputpackets;
    }

    public String getHwacctipv6outputpackets() {
        return hwacctipv6outputpackets;
    }

    public void setHwacctipv6outputpackets(String hwacctipv6outputpackets) {
        this.hwacctipv6outputpackets = hwacctipv6outputpackets;
    }

    public String getHwacctipv6inputgigawords() {
        return hwacctipv6inputgigawords;
    }

    public void setHwacctipv6inputgigawords(String hwacctipv6inputgigawords) {
        this.hwacctipv6inputgigawords = hwacctipv6inputgigawords;
    }

    public String getHwacctipv6outputgigawords() {
        return hwacctipv6outputgigawords;
    }

    public void setHwacctipv6outputgigawords(String hwacctipv6outputgigawords) {
        this.hwacctipv6outputgigawords = hwacctipv6outputgigawords;
    }

    public String getHuaweiuserclass() {
        return huaweiuserclass;
    }

    public void setHuaweiuserclass(String huaweiuserclass) {
        this.huaweiuserclass = huaweiuserclass;
    }

    public String getHuaweidomainname() {
        return huaweidomainname;
    }

    public void setHuaweidomainname(String huaweidomainname) {
        this.huaweidomainname = huaweidomainname;
    }

    public String getHwconnectid() {
        return hwconnectid;
    }

    public void setHwconnectid(String hwconnectid) {
        this.hwconnectid = hwconnectid;
    }
}
