package br.com.tim.mapreduce.model;

import org.apache.commons.lang3.StringUtils;

public class BAT510 {

    private String loginVendedor;
    private String nomVendedor;
    private String custcodePdv;
    private String cnpjPdv;
    private String nomPdv;
    private String canalVenda;
    private String datCadastroVendedor;
    private String datExpiracaoVendedor;
    private String datInicioPdv;
    private String datFimPdv;
    private String flgCadastroVigente;
    private String rowid;
    private String loteid;
    private String arquivo;
    private String arquivots;
    private String currentDate;

    public BAT510() {

        this.loginVendedor = null;
        this.nomVendedor = null;
        this.custcodePdv = null;
        this.cnpjPdv = null;
        this.nomPdv = null;
        this.canalVenda = null;
        this.datCadastroVendedor = null;
        this.datExpiracaoVendedor = null;
        this.datInicioPdv = null;
        this.datFimPdv = null;
        this.flgCadastroVigente = null;
        this.rowid = null;
        this.loteid = null;
        this.arquivo = null;
        this.arquivots = null;
        this.currentDate = null;

    }

    public void setBAT510(String loginVendedor, String nomVendedor, String custcodePdv, String cnpjPdv, String nomPdv, String canalVenda, String datCadastroVendedor,
                          String datExpiracaoVendedor, String datInicioPdv, String datFimPdv, String flgCadastroVigente, String rowid, String loteid, String arquivo,
                          String arquivots, String currentDate) {
        this.loginVendedor = loginVendedor;
        this.nomVendedor = nomVendedor;
        this.custcodePdv = custcodePdv;
        this.cnpjPdv = cnpjPdv;
        this.nomPdv = nomPdv;
        this.canalVenda = canalVenda;
        this.datCadastroVendedor = datCadastroVendedor;
        this.datExpiracaoVendedor = datExpiracaoVendedor;
        this.datInicioPdv = datInicioPdv;
        this.datFimPdv = datFimPdv;
        this.flgCadastroVigente = flgCadastroVigente;
        this.rowid = rowid;
        this.loteid = loteid;
        this.arquivo = arquivo;
        this.arquivots = arquivots;
        this.currentDate = currentDate;
    }

    public boolean parse(String textString) {
        if (StringUtils.isNotBlank(textString)) {
            String[] cols = textString.split("\\|", -1);
            int i = 0;
            this.setBAT510(cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                           cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++]);
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        String delimiter = "|";

        sb.append(loginVendedor).append(delimiter)
          .append(nomVendedor).append(delimiter)
          .append(custcodePdv).append(delimiter)
          .append(cnpjPdv).append(delimiter)
          .append(nomPdv).append(delimiter)
          .append(canalVenda).append(delimiter)
          .append(datCadastroVendedor).append(delimiter)
          .append(datExpiracaoVendedor).append(delimiter)
          .append(datInicioPdv).append(delimiter)
          .append(datFimPdv).append(delimiter)
          .append(flgCadastroVigente).append(delimiter)
          .append(rowid).append(delimiter)
          .append(loteid).append(delimiter)
          .append(arquivo).append(delimiter)
          .append(arquivots).append(delimiter)
          .append(currentDate);

        return sb.toString();

    }

    public String getLoginVendedor() {
        return loginVendedor;
    }

    public void setLoginVendedor(String loginVendedor) {
        this.loginVendedor = loginVendedor;
    }

    public String getNomVendedor() {
        return nomVendedor;
    }

    public void setNomVendedor(String nomVendedor) {
        this.nomVendedor = nomVendedor;
    }

    public String getCustcodePdv() {
        return custcodePdv;
    }

    public void setCustcodePdv(String custcodePdv) {
        this.custcodePdv = custcodePdv;
    }

    public String getCnpjPdv() {
        return cnpjPdv;
    }

    public void setCnpjPdv(String cnpjPdv) {
        this.cnpjPdv = cnpjPdv;
    }

    public String getNomPdv() {
        return nomPdv;
    }

    public void setNomPdv(String nomPdv) {
        this.nomPdv = nomPdv;
    }

    public String getCanalVenda() {
        return canalVenda;
    }

    public void setCanalVenda(String canalVenda) {
        this.canalVenda = canalVenda;
    }

    public String getDatCadastroVendedor() {
        return datCadastroVendedor;
    }

    public void setDatCadastroVendedor(String datCadastroVendedor) {
        this.datCadastroVendedor = datCadastroVendedor;
    }

    public String getDatExpiracaoVendedor() {
        return datExpiracaoVendedor;
    }

    public void setDatExpiracaoVendedor(String datExpiracaoVendedor) {
        this.datExpiracaoVendedor = datExpiracaoVendedor;
    }

    public String getDatInicioPdv() {
        return datInicioPdv;
    }

    public void setDatInicioPdv(String datInicioPdv) {
        this.datInicioPdv = datInicioPdv;
    }

    public String getDatFimPdv() {
        return datFimPdv;
    }

    public void setDatFimPdv(String datFimPdv) {
        this.datFimPdv = datFimPdv;
    }

    public String getFlgCadastroVigente() {
        return flgCadastroVigente;
    }

    public void setFlgCadastroVigente(String flgCadastroVigente) {
        this.flgCadastroVigente = flgCadastroVigente;
    }

    public String getRowid() {
        return rowid;
    }

    public void setRowid(String rowid) {
        this.rowid = rowid;
    }

    public String getLoteid() {
        return loteid;
    }

    public void setLoteid(String loteid) {
        this.loteid = loteid;
    }

    public String getArquivo() {
        return arquivo;
    }

    public void setArquivo(String arquivo) {
        this.arquivo = arquivo;
    }

    public String getArquivots() {
        return arquivots;
    }

    public void setArquivots(String arquivots) {
        this.arquivots = arquivots;
    }

    public String getCurrentDate() {
        return currentDate;
    }

    public void setCurrentDate(String currentDate) {
        this.currentDate = currentDate;
    }
}
