package br.com.tim.mapreduce.e2e.step9.pt2;

import br.com.tim.mapreduce.e2e.step9.TypeStep9;
import br.com.tim.mapreduce.e2e.step9.model.Step8Result;
import br.com.tim.mapreduce.e2e.step9.model.Step9PT1Result;
import br.com.tim.mapreduce.model.BAT226;
import org.apache.hadoop.io.Writable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public class E2EStep9PT2Value implements Writable {

    protected TypeStep9 tipo;

    protected String datRef;
    protected String codContratoOltp;
    protected String codContratoAtivacao;
    protected String numeroAcesso;
    protected String customerId;
    protected String tipoProduto;
    protected String planoAtivacaoOferta;
    protected String motivoChurn;
    protected String tipoChurn;
    protected String email;
    protected String uf;
    protected String tipoLogradouro;
    protected String logradouro;
    protected String numero;
    protected String complemento;
    protected String bairro;
    protected String cep;
    protected String cidade;
    protected String tecnologia;
    protected String formaPagamento;
    protected String tipoConta;
    protected String codBanco;
    protected String codAgenciaBanco;
    protected String codContaCorrente;
    protected String codDebitoAutomatico;
    protected String diaVencimento;
    protected String codContaFinanceira;
    protected String numProtocolo;
    protected String flgOrdemAutomatica;
    protected String dscTxRecorrente;
    protected String dscTxNaoRecorrente;
    protected String dscStatusItem;
    protected String nomPlanoAtual;
    protected String valPlanoAtualItem;
    protected String nomDescontoAtualItem;
    protected String valDescontoAtualItem;
    protected String flgPortabilidade;
    protected String dscOperadoraDoadora;
    protected String codDdd;
    protected String numTelefonePortado;
    protected String datJanelaPortabilidade;
    protected String horJanela;
    protected String dscEnderecoFatura;
    protected String dscAreaVoip;
    protected String cpe;
    protected String ont;
    protected String itemRoot;
    protected String dominioRoot;
    protected String nroOrdem;
    protected String acessoRowId;
    protected String acessoRowIdRoot;
    protected String codigoProduto;
    protected String datCriacaoOrdem;
    protected String horCriacaoOrdem;
    protected String datVenda;
    protected String horaVenda;
    protected String datVendaOrig;
    protected String horVendaOrig;
    protected String datStatusOrdem;
    protected String horStatusOrdem;
    protected String numOrdemSiebel;
    protected String numOrdemSiebelOrig;
    protected String tipoDocumento;
    protected String documento;
    protected String tipoVenda;
    protected String loginVendedor;
    protected String loginVendedorOrig;
    protected String canal;
    protected String canalOrig;
    protected String cnpjParceiro;
    protected String cnpjParceiroOrig;
    protected String custCode;
    protected String custCodeOrig;
    protected String position;
    protected String positionOrig;
    protected String flgCancAntesVenda;
    protected String flgVendaSubmetida;
    protected String flgVendaDuplicada;
    protected String flgVendaBruta;
    protected String flgVendaLiquida;
    protected String flgCancPosVenda;
    protected String flgCancDupl;
    protected String flgCancLiquido;
    protected String datCancVenda;
    protected String motivoCancelamento;
    protected String nomeCliente;
    protected String telefone;
    protected String statusOrdem;
    protected String semanaVenda;
    protected String semanaVendaOrig;
    protected String score;
    protected String scoreConsumido;
    protected String datFinalizacaoOrdem;
    protected String qtdContratos;
    protected String nomLoginResponsavel;
    protected String detalheRecusaCrivo;
    protected String loginCancelamentoOrdem;
    protected String nomeParceiroVenda;
    protected String nomeParceiroVendaOrig;
    protected String velocidadeDownload;
    protected String velocidadeUpload;
    protected String custcodeCliente;
    protected String msanOltTrafego;
    protected String codContratoAtual;
    protected String codConvergente;
    protected String nomeVendedor;
    protected String nomeVendedorOrig;
    protected String nomeUsuarioCancelouOrdem;
    protected String datChurn;
    protected String datGross;
    protected String flgGross;
    protected String flgChurn;
    protected String parceiro;

    protected String parceiroOrig;

    @Override
    public void write(DataOutput dataOutput) throws IOException {
        dataOutput.writeInt(tipo.ordinal());
        dataOutput.writeUTF(datRef);
        dataOutput.writeUTF(codContratoOltp);
        dataOutput.writeUTF(codContratoAtivacao);
        dataOutput.writeUTF(numeroAcesso);
        dataOutput.writeUTF(customerId);
        dataOutput.writeUTF(tipoProduto);
        dataOutput.writeUTF(planoAtivacaoOferta);
        dataOutput.writeUTF(motivoChurn);
        dataOutput.writeUTF(tipoChurn);
        dataOutput.writeUTF(email);
        dataOutput.writeUTF(uf);
        dataOutput.writeUTF(tipoLogradouro);
        dataOutput.writeUTF(logradouro);
        dataOutput.writeUTF(numero);
        dataOutput.writeUTF(complemento);
        dataOutput.writeUTF(bairro);
        dataOutput.writeUTF(cep);
        dataOutput.writeUTF(cidade);
        dataOutput.writeUTF(tecnologia);
        dataOutput.writeUTF(formaPagamento);
        dataOutput.writeUTF(tipoConta);
        dataOutput.writeUTF(codBanco);
        dataOutput.writeUTF(codAgenciaBanco);
        dataOutput.writeUTF(codContaCorrente);
        dataOutput.writeUTF(codDebitoAutomatico);
        dataOutput.writeUTF(diaVencimento);
        dataOutput.writeUTF(codContaFinanceira);
        dataOutput.writeUTF(numProtocolo);
        dataOutput.writeUTF(flgOrdemAutomatica);
        dataOutput.writeUTF(dscTxRecorrente);
        dataOutput.writeUTF(dscTxNaoRecorrente);
        dataOutput.writeUTF(dscStatusItem);
        dataOutput.writeUTF(nomPlanoAtual);
        dataOutput.writeUTF(valPlanoAtualItem);
        dataOutput.writeUTF(nomDescontoAtualItem);
        dataOutput.writeUTF(valDescontoAtualItem);
        dataOutput.writeUTF(flgPortabilidade);
        dataOutput.writeUTF(dscOperadoraDoadora);
        dataOutput.writeUTF(codDdd);
        dataOutput.writeUTF(numTelefonePortado);
        dataOutput.writeUTF(datJanelaPortabilidade);
        dataOutput.writeUTF(horJanela);
        dataOutput.writeUTF(dscEnderecoFatura);
        dataOutput.writeUTF(dscAreaVoip);
        dataOutput.writeUTF(cpe);
        dataOutput.writeUTF(ont);
        dataOutput.writeUTF(itemRoot);
        dataOutput.writeUTF(dominioRoot);
        dataOutput.writeUTF(nroOrdem);
        dataOutput.writeUTF(acessoRowId);
        dataOutput.writeUTF(acessoRowIdRoot);
        dataOutput.writeUTF(codigoProduto);
        dataOutput.writeUTF(datCriacaoOrdem);
        dataOutput.writeUTF(horCriacaoOrdem);
        dataOutput.writeUTF(datVenda);
        dataOutput.writeUTF(horaVenda);
        dataOutput.writeUTF(datVendaOrig);
        dataOutput.writeUTF(horVendaOrig);
        dataOutput.writeUTF(datStatusOrdem);
        dataOutput.writeUTF(horStatusOrdem);
        dataOutput.writeUTF(numOrdemSiebel);
        dataOutput.writeUTF(numOrdemSiebelOrig);
        dataOutput.writeUTF(tipoDocumento);
        dataOutput.writeUTF(documento);
        dataOutput.writeUTF(tipoVenda);
        dataOutput.writeUTF(loginVendedor);
        dataOutput.writeUTF(loginVendedorOrig);
        dataOutput.writeUTF(canal);
        dataOutput.writeUTF(canalOrig);
        dataOutput.writeUTF(cnpjParceiro);
        dataOutput.writeUTF(cnpjParceiroOrig);
        dataOutput.writeUTF(custCode);
        dataOutput.writeUTF(custCodeOrig);
        dataOutput.writeUTF(position);
        dataOutput.writeUTF(positionOrig);
        dataOutput.writeUTF(flgCancAntesVenda);
        dataOutput.writeUTF(flgVendaSubmetida);
        dataOutput.writeUTF(flgVendaDuplicada);
        dataOutput.writeUTF(flgVendaBruta);
        dataOutput.writeUTF(flgVendaLiquida);
        dataOutput.writeUTF(flgCancPosVenda);
        dataOutput.writeUTF(flgCancDupl);
        dataOutput.writeUTF(flgCancLiquido);
        dataOutput.writeUTF(datCancVenda);
        dataOutput.writeUTF(motivoCancelamento);
        dataOutput.writeUTF(nomeCliente);
        dataOutput.writeUTF(telefone);
        dataOutput.writeUTF(statusOrdem);
        dataOutput.writeUTF(semanaVenda);
        dataOutput.writeUTF(semanaVendaOrig);
        dataOutput.writeUTF(score);
        dataOutput.writeUTF(scoreConsumido);
        dataOutput.writeUTF(datFinalizacaoOrdem);
        dataOutput.writeUTF(qtdContratos);
        dataOutput.writeUTF(nomLoginResponsavel);
        dataOutput.writeUTF(detalheRecusaCrivo);
        dataOutput.writeUTF(loginCancelamentoOrdem);
        dataOutput.writeUTF(nomeParceiroVenda);
        dataOutput.writeUTF(nomeParceiroVendaOrig);
        dataOutput.writeUTF(velocidadeDownload);
        dataOutput.writeUTF(velocidadeUpload);
        dataOutput.writeUTF(custcodeCliente);
        dataOutput.writeUTF(msanOltTrafego);
        dataOutput.writeUTF(codContratoAtual);
        dataOutput.writeUTF(codConvergente);
        dataOutput.writeUTF(nomeVendedor);
        dataOutput.writeUTF(nomeVendedorOrig);
        dataOutput.writeUTF(nomeUsuarioCancelouOrdem);
        dataOutput.writeUTF(datChurn);
        dataOutput.writeUTF(datGross);
        dataOutput.writeUTF(flgGross);
        dataOutput.writeUTF(flgChurn);
        dataOutput.writeUTF(parceiro);
        dataOutput.writeUTF(parceiroOrig);
    }

    @Override
    public void readFields(DataInput dataInput) throws IOException {
        this.tipo = TypeStep9.values()[dataInput.readInt()];
        this.datRef = dataInput.readUTF();
        this.codContratoOltp = dataInput.readUTF();
        this.codContratoAtivacao = dataInput.readUTF();
        this.numeroAcesso = dataInput.readUTF();
        this.customerId = dataInput.readUTF();
        this.tipoProduto = dataInput.readUTF();
        this.planoAtivacaoOferta = dataInput.readUTF();
        this.motivoChurn = dataInput.readUTF();
        this.tipoChurn = dataInput.readUTF();
        this.email = dataInput.readUTF();
        this.uf = dataInput.readUTF();
        this.tipoLogradouro = dataInput.readUTF();
        this.logradouro = dataInput.readUTF();
        this.numero = dataInput.readUTF();
        this.complemento = dataInput.readUTF();
        this.bairro = dataInput.readUTF();
        this.cep = dataInput.readUTF();
        this.cidade = dataInput.readUTF();
        this.tecnologia = dataInput.readUTF();
        this.formaPagamento = dataInput.readUTF();
        this.tipoConta = dataInput.readUTF();
        this.codBanco = dataInput.readUTF();
        this.codAgenciaBanco = dataInput.readUTF();
        this.codContaCorrente = dataInput.readUTF();
        this.codDebitoAutomatico = dataInput.readUTF();
        this.diaVencimento = dataInput.readUTF();
        this.codContaFinanceira = dataInput.readUTF();
        this.numProtocolo = dataInput.readUTF();
        this.flgOrdemAutomatica = dataInput.readUTF();
        this.dscTxRecorrente = dataInput.readUTF();
        this.dscTxNaoRecorrente = dataInput.readUTF();
        this.dscStatusItem = dataInput.readUTF();
        this.nomPlanoAtual = dataInput.readUTF();
        this.valPlanoAtualItem = dataInput.readUTF();
        this.nomDescontoAtualItem = dataInput.readUTF();
        this.valDescontoAtualItem = dataInput.readUTF();
        this.flgPortabilidade = dataInput.readUTF();
        this.dscOperadoraDoadora = dataInput.readUTF();
        this.codDdd = dataInput.readUTF();
        this.numTelefonePortado = dataInput.readUTF();
        this.datJanelaPortabilidade = dataInput.readUTF();
        this.horJanela = dataInput.readUTF();
        this.dscEnderecoFatura = dataInput.readUTF();
        this.dscAreaVoip = dataInput.readUTF();
        this.cpe = dataInput.readUTF();
        this.ont = dataInput.readUTF();
        this.itemRoot = dataInput.readUTF();
        this.dominioRoot = dataInput.readUTF();
        this.nroOrdem = dataInput.readUTF();
        this.acessoRowId = dataInput.readUTF();
        this.acessoRowIdRoot = dataInput.readUTF();
        this.codigoProduto = dataInput.readUTF();
        this.datCriacaoOrdem = dataInput.readUTF();
        this.horCriacaoOrdem = dataInput.readUTF();
        this.datVenda = dataInput.readUTF();
        this.horaVenda = dataInput.readUTF();
        this.datVendaOrig = dataInput.readUTF();
        this.horVendaOrig = dataInput.readUTF();
        this.datStatusOrdem = dataInput.readUTF();
        this.horStatusOrdem = dataInput.readUTF();
        this.numOrdemSiebel = dataInput.readUTF();
        this.numOrdemSiebelOrig = dataInput.readUTF();
        this.tipoDocumento = dataInput.readUTF();
        this.documento = dataInput.readUTF();
        this.tipoVenda = dataInput.readUTF();
        this.loginVendedor = dataInput.readUTF();
        this.loginVendedorOrig = dataInput.readUTF();
        this.canal = dataInput.readUTF();
        this.canalOrig = dataInput.readUTF();
        this.cnpjParceiro = dataInput.readUTF();
        this.cnpjParceiroOrig = dataInput.readUTF();
        this.custCode = dataInput.readUTF();
        this.custCodeOrig = dataInput.readUTF();
        this.position = dataInput.readUTF();
        this.positionOrig = dataInput.readUTF();
        this.flgCancAntesVenda = dataInput.readUTF();
        this.flgVendaSubmetida = dataInput.readUTF();
        this.flgVendaDuplicada = dataInput.readUTF();
        this.flgVendaBruta = dataInput.readUTF();
        this.flgVendaLiquida = dataInput.readUTF();
        this.flgCancPosVenda = dataInput.readUTF();
        this.flgCancDupl = dataInput.readUTF();
        this.flgCancLiquido = dataInput.readUTF();
        this.datCancVenda = dataInput.readUTF();
        this.motivoCancelamento = dataInput.readUTF();
        this.nomeCliente = dataInput.readUTF();
        this.telefone = dataInput.readUTF();
        this.statusOrdem = dataInput.readUTF();
        this.semanaVenda = dataInput.readUTF();
        this.semanaVendaOrig = dataInput.readUTF();
        this.score = dataInput.readUTF();
        this.scoreConsumido = dataInput.readUTF();
        this.datFinalizacaoOrdem = dataInput.readUTF();
        this.qtdContratos = dataInput.readUTF();
        this.nomLoginResponsavel = dataInput.readUTF();
        this.detalheRecusaCrivo = dataInput.readUTF();
        this.loginCancelamentoOrdem = dataInput.readUTF();
        this.nomeParceiroVenda = dataInput.readUTF();
        this.nomeParceiroVendaOrig = dataInput.readUTF();
        this.velocidadeDownload = dataInput.readUTF();
        this.velocidadeUpload = dataInput.readUTF();
        this.custcodeCliente = dataInput.readUTF();
        this.msanOltTrafego = dataInput.readUTF();
        this.codContratoAtual = dataInput.readUTF();
        this.codConvergente = dataInput.readUTF();
        this.nomeVendedor = dataInput.readUTF();
        this.nomeVendedorOrig = dataInput.readUTF();
        this.nomeUsuarioCancelouOrdem = dataInput.readUTF();
        this.datChurn = dataInput.readUTF();
        this.datGross = dataInput.readUTF();
        this.flgGross = dataInput.readUTF();
        this.flgChurn = dataInput.readUTF();
        this.parceiro = dataInput.readUTF();
        this.parceiroOrig = dataInput.readUTF();
    }

    public void setStep9PT1Result(Step9PT1Result result) {
        this.clear();
        this.tipo = TypeStep9.RELT;
        this.datRef = result.getDatRef();
        this.codContratoOltp = result.getCodContratoOltp();
        this.codContratoAtivacao = result.getCodContratoAtivacao();
        this.numeroAcesso = result.getNumeroAcesso();
        this.customerId = result.getCustomerId();
        this.tipoProduto = result.getTipoProduto();
        this.planoAtivacaoOferta = result.getPlanoAtivacaoOferta();
        this.motivoChurn = result.getMotivoChurn();
        this.tipoChurn = result.getTipoChurn();
        this.email = result.getEmail();
        this.uf = result.getUf();
        this.tipoLogradouro = result.getTipoLogradouro();
        this.logradouro = result.getLogradouro();
        this.numero = result.getNumero();
        this.complemento = result.getComplemento();
        this.bairro = result.getBairro();
        this.cep = result.getCep();
        this.cidade = result.getCidade();
        this.tecnologia = result.getTecnologia();
        this.formaPagamento = result.getFormaPagamento();
        this.tipoConta = result.getTipoConta();
        this.codBanco = result.getCodBanco();
        this.codAgenciaBanco = result.getCodAgenciaBanco();
        this.codContaCorrente = result.getCodContaCorrente();
        this.codDebitoAutomatico = result.getCodDebitoAutomatico();
        this.diaVencimento = result.getDiaVencimento();
        this.codContaFinanceira = result.getCodContaFinanceira();
        this.numProtocolo = result.getNumProtocolo();
        this.flgOrdemAutomatica = result.getFlgOrdemAutomatica();
        this.dscTxRecorrente = result.getDscTxRecorrente();
        this.dscTxNaoRecorrente = result.getDscTxNaoRecorrente();
        this.dscStatusItem = result.getDscStatusItem();
        this.nomPlanoAtual = result.getNomPlanoAtual();
        this.valPlanoAtualItem = result.getValPlanoAtualItem();
        this.nomDescontoAtualItem = result.getNomDescontoAtualItem();
        this.valDescontoAtualItem = result.getValDescontoAtualItem();
        this.flgPortabilidade = result.getFlgPortabilidade();
        this.dscOperadoraDoadora = result.getDscOperadoraDoadora();
        this.codDdd = result.getCodDdd();
        this.numTelefonePortado = result.getNumTelefonePortado();
        this.datJanelaPortabilidade = result.getDatJanelaPortabilidade();
        this.horJanela = result.getHorJanela();
        this.dscEnderecoFatura = result.getDscEnderecoFatura();
        this.dscAreaVoip = result.getDscAreaVoip();
        this.cpe = result.getCpe();
        this.ont = result.getOnt();
        this.itemRoot = result.getItemRoot();
        this.dominioRoot = result.getDominioRoot();
        this.nroOrdem = result.getNroOrdem();
        this.acessoRowId = result.getAcessoRowId();
        this.acessoRowIdRoot = result.getAcessoRowIdRoot();
        this.codigoProduto = result.getCodigoProduto();
        this.datCriacaoOrdem = result.getDatCriacaoOrdem();
        this.horCriacaoOrdem = result.getHorCriacaoOrdem();
        this.datVenda = result.getDatVenda();
        this.horaVenda = result.getHoraVenda();
        this.datVendaOrig = result.getDatVendaOrig();
        this.horVendaOrig = result.getHorVendaOrig();
        this.datStatusOrdem = result.getDatStatusOrdem();
        this.horStatusOrdem = result.getHorStatusOrdem();
        this.numOrdemSiebel = result.getNumOrdemSiebel();
        this.numOrdemSiebelOrig = result.getNumOrdemSiebelOrig();
        this.tipoDocumento = result.getTipoDocumento();
        this.documento = result.getDocumento();
        this.tipoVenda = result.getTipoVenda();
        this.loginVendedor = result.getLoginVendedor();
        this.loginVendedorOrig = result.getLoginVendedorOrig();
        this.canal = result.getCanal();
        this.canalOrig = result.getCanalOrig();
        this.cnpjParceiro = result.getCnpjParceiro();
        this.cnpjParceiroOrig = result.getCnpjParceiroOrig();
        this.custCode = result.getCustCode();
        this.custCodeOrig = result.getCustCodeOrig();
        this.position = result.getPosition();
        this.positionOrig = result.getPositionOrig();
        this.flgCancAntesVenda = result.getFlgCancAntesVenda();
        this.flgVendaSubmetida = result.getFlgVendaSubmetida();
        this.flgVendaDuplicada = result.getFlgVendaDuplicada();
        this.flgVendaBruta = result.getFlgVendaBruta();
        this.flgVendaLiquida = result.getFlgVendaLiquida();
        this.flgCancPosVenda = result.getFlgCancPosVenda();
        this.flgCancDupl = result.getFlgCancDupl();
        this.flgCancLiquido = result.getFlgCancLiquido();
        this.datCancVenda = result.getDatCancVenda();
        this.motivoCancelamento = result.getMotivoCancelamento();
        this.nomeCliente = result.getNomeCliente();
        this.telefone = result.getTelefone();
        this.statusOrdem = result.getStatusOrdem();
        this.semanaVenda = result.getSemanaVenda();
        this.semanaVendaOrig = result.getSemanaVendaOrig();
        this.score = result.getScore();
        this.scoreConsumido = result.getScoreConsumido();
        this.datFinalizacaoOrdem = result.getDatFinalizacaoOrdem();
        this.qtdContratos = result.getQtdContratos();
        this.nomLoginResponsavel = result.getNomLoginResponsavel();
        this.detalheRecusaCrivo = result.getDetalheRecusaCrivo();
        this.loginCancelamentoOrdem = result.getLoginCancelamentoOrdem();
        this.nomeParceiroVenda = result.getNomeParceiroVenda();
        this.nomeParceiroVendaOrig = result.getNomeParceiroVendaOrig();
        this.velocidadeDownload = result.getVelocidadeDownload();
        this.velocidadeUpload = result.getVelocidadeUpload();
        this.custcodeCliente = result.getCustcodeCliente();
        this.msanOltTrafego = result.getMsanOltTrafego();
        this.codContratoAtual = result.getCodContratoAtual();
        this.codConvergente = result.getCodConvergente();
        this.nomeVendedor = result.getNomeVendedor();
        this.nomeVendedorOrig = result.getNomeVendedorOrig();
        this.nomeUsuarioCancelouOrdem = result.getNomeUsuarioCancelouOrdem();
        this.datChurn = result.getDatChurn();
        this.datGross = result.getDatGross();
        this.flgGross = result.getFlgGross();
        this.flgChurn = result.getFlgChurn();
        this.parceiro = result.getParceiro();
    }

    public void setBat226(BAT226 bat) {
        this.clear();
        this.tipo = TypeStep9.BAT226;
        this.parceiroOrig = bat.getPositionPai();
    }

    public void clear(){
        this.tipo = null;
        this.datRef = "";
        this.codContratoOltp = "";
        this.codContratoAtivacao = "";
        this.numeroAcesso = "";
        this.customerId = "";
        this.tipoProduto = "";
        this.planoAtivacaoOferta = "";
        this.motivoChurn = "";
        this.tipoChurn = "";
        this.email = "";
        this.uf = "";
        this.tipoLogradouro = "";
        this.logradouro = "";
        this.numero = "";
        this.complemento = "";
        this.bairro = "";
        this.cep = "";
        this.cidade = "";
        this.tecnologia = "";
        this.formaPagamento = "";
        this.tipoConta = "";
        this.codBanco = "";
        this.codAgenciaBanco = "";
        this.codContaCorrente = "";
        this.codDebitoAutomatico = "";
        this.diaVencimento = "";
        this.codContaFinanceira = "";
        this.numProtocolo = "";
        this.flgOrdemAutomatica = "";
        this.dscTxRecorrente = "";
        this.dscTxNaoRecorrente = "";
        this.dscStatusItem = "";
        this.nomPlanoAtual = "";
        this.valPlanoAtualItem = "";
        this.nomDescontoAtualItem = "";
        this.valDescontoAtualItem = "";
        this.flgPortabilidade = "";
        this.dscOperadoraDoadora = "";
        this.codDdd = "";
        this.numTelefonePortado = "";
        this.datJanelaPortabilidade = "";
        this.horJanela = "";
        this.dscEnderecoFatura = "";
        this.dscAreaVoip = "";
        this.cpe = "";
        this.ont = "";
        this.itemRoot = "";
        this.dominioRoot = "";
        this.nroOrdem = "";
        this.acessoRowId = "";
        this.acessoRowIdRoot = "";
        this.codigoProduto = "";
        this.datCriacaoOrdem = "";
        this.horCriacaoOrdem = "";
        this.datVenda = "";
        this.horaVenda = "";
        this.datVendaOrig = "";
        this.horVendaOrig = "";
        this.datStatusOrdem = "";
        this.horStatusOrdem = "";
        this.numOrdemSiebel = "";
        this.numOrdemSiebelOrig = "";
        this.tipoDocumento = "";
        this.documento = "";
        this.tipoVenda = "";
        this.loginVendedor = "";
        this.loginVendedorOrig = "";
        this.canal = "";
        this.canalOrig = "";
        this.cnpjParceiro = "";
        this.cnpjParceiroOrig = "";
        this.custCode = "";
        this.custCodeOrig = "";
        this.position = "";
        this.positionOrig = "";
        this.flgCancAntesVenda = "";
        this.flgVendaSubmetida = "";
        this.flgVendaDuplicada = "";
        this.flgVendaBruta = "";
        this.flgVendaLiquida = "";
        this.flgCancPosVenda = "";
        this.flgCancDupl = "";
        this.flgCancLiquido = "";
        this.datCancVenda = "";
        this.motivoCancelamento = "";
        this.nomeCliente = "";
        this.telefone = "";
        this.statusOrdem = "";
        this.semanaVenda = "";
        this.semanaVendaOrig = "";
        this.score = "";
        this.scoreConsumido = "";
        this.datFinalizacaoOrdem = "";
        this.qtdContratos = "";
        this.nomLoginResponsavel = "";
        this.detalheRecusaCrivo = "";
        this.loginCancelamentoOrdem = "";
        this.nomeParceiroVenda = "";
        this.nomeParceiroVendaOrig = "";
        this.velocidadeDownload = "";
        this.velocidadeUpload = "";
        this.custcodeCliente = "";
        this.msanOltTrafego = "";
        this.codContratoAtual = "";
        this.codConvergente = "";
        this.nomeVendedor = "";
        this.nomeVendedorOrig = "";
        this.nomeUsuarioCancelouOrdem = "";
        this.datChurn = "";
        this.datGross = "";
        this.flgGross = "";
        this.flgChurn = "";
        this.parceiro = "";
        this.parceiroOrig = "";
    }

    public String getParceiroOrig() {
        return parceiroOrig;
    }

    public String getFlgGross() {
        return flgGross;
    }

    public String getFlgChurn() {
        return flgChurn;
    }

    public String getParceiro() {
        return parceiro;
    }

    public String getDatChurn() {
        return datChurn;
    }

    public String getDatGross() {
        return datGross;
    }

    public String getNomeParceiroVendaOrig() {
        return nomeParceiroVendaOrig;
    }

    public String getNomeUsuarioCancelouOrdem() {
        return nomeUsuarioCancelouOrdem;
    }

    public String getNomeVendedorOrig() {
        return nomeVendedorOrig;
    }

    public String getNomeVendedor() {
        return nomeVendedor;
    }

    public String getCodContratoAtual() {
        return codContratoAtual;
    }

    public String getMsanOltTrafego() {
        return msanOltTrafego;
    }

    public String getCustcodeCliente() {
        return custcodeCliente;
    }

    public String getAcessoRowIdRoot() {
        return acessoRowIdRoot;
    }

    public TypeStep9 getTipo() {
        return tipo;
    }

    public String getFlgVendaSubmetida() {
        return flgVendaSubmetida;
    }

    public String getFlgCancDupl() {
        return flgCancDupl;
    }

    public String getFlgCancLiquido() {
        return flgCancLiquido;
    }

    public String getDatRef() {
        return datRef;
    }

    public String getCodContratoOltp() {
        return codContratoOltp;
    }

    public String getCodContratoAtivacao() {
        return codContratoAtivacao;
    }

    public String getNumeroAcesso() {
        return numeroAcesso;
    }

    public String getCustomerId() {
        return customerId;
    }

    public String getTipoProduto() {
        return tipoProduto;
    }

    public String getPlanoAtivacaoOferta() {
        return planoAtivacaoOferta;
    }

    public String getMotivoChurn() {
        return motivoChurn;
    }

    public String getTipoChurn() {
        return tipoChurn;
    }

    public String getEmail() {
        return email;
    }

    public String getUf() {
        return uf;
    }

    public String getTipoLogradouro() {
        return tipoLogradouro;
    }

    public String getLogradouro() {
        return logradouro;
    }

    public String getNumero() {
        return numero;
    }

    public String getComplemento() {
        return complemento;
    }

    public String getBairro() {
        return bairro;
    }

    public String getCep() {
        return cep;
    }

    public String getCidade() {
        return cidade;
    }

    public String getTecnologia() {
        return tecnologia;
    }

    public String getFormaPagamento() {
        return formaPagamento;
    }

    public String getTipoConta() {
        return tipoConta;
    }

    public String getCodBanco() {
        return codBanco;
    }

    public String getCodAgenciaBanco() {
        return codAgenciaBanco;
    }

    public String getCodContaCorrente() {
        return codContaCorrente;
    }

    public String getCodDebitoAutomatico() {
        return codDebitoAutomatico;
    }

    public String getDiaVencimento() {
        return diaVencimento;
    }

    public String getCodContaFinanceira() {
        return codContaFinanceira;
    }

    public String getNumProtocolo() {
        return numProtocolo;
    }

    public String getFlgOrdemAutomatica() {
        return flgOrdemAutomatica;
    }

    public String getDscTxRecorrente() {
        return dscTxRecorrente;
    }

    public String getDscTxNaoRecorrente() {
        return dscTxNaoRecorrente;
    }

    public String getDscStatusItem() {
        return dscStatusItem;
    }

    public String getNomPlanoAtual() {
        return nomPlanoAtual;
    }

    public String getValPlanoAtualItem() {
        return valPlanoAtualItem;
    }

    public String getNomDescontoAtualItem() {
        return nomDescontoAtualItem;
    }

    public String getValDescontoAtualItem() {
        return valDescontoAtualItem;
    }

    public String getFlgPortabilidade() {
        return flgPortabilidade;
    }

    public String getDscOperadoraDoadora() {
        return dscOperadoraDoadora;
    }

    public String getCodDdd() {
        return codDdd;
    }

    public String getNumTelefonePortado() {
        return numTelefonePortado;
    }

    public String getDatJanelaPortabilidade() {
        return datJanelaPortabilidade;
    }

    public String getHorJanela() {
        return horJanela;
    }

    public String getDscEnderecoFatura() {
        return dscEnderecoFatura;
    }

    public String getDscAreaVoip() {
        return dscAreaVoip;
    }

    public String getCpe() {
        return cpe;
    }

    public String getOnt() {
        return ont;
    }

    public String getItemRoot() {
        return itemRoot;
    }

    public String getDominioRoot() {
        return dominioRoot;
    }

    public String getNroOrdem() {
        return nroOrdem;
    }

    public String getAcessoRowId() {
        return acessoRowId;
    }

    public String getCodigoProduto() {
        return codigoProduto;
    }

    public String getDatCriacaoOrdem() {
        return datCriacaoOrdem;
    }

    public String getHorCriacaoOrdem() {
        return horCriacaoOrdem;
    }

    public String getDatVenda() {
        return datVenda;
    }

    public String getHoraVenda() {
        return horaVenda;
    }

    public String getDatVendaOrig() {
        return datVendaOrig;
    }

    public String getHorVendaOrig() {
        return horVendaOrig;
    }

    public String getDatStatusOrdem() {
        return datStatusOrdem;
    }

    public String getHorStatusOrdem() {
        return horStatusOrdem;
    }

    public String getNumOrdemSiebel() {
        return numOrdemSiebel;
    }

    public String getNumOrdemSiebelOrig() {
        return numOrdemSiebelOrig;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public String getDocumento() {
        return documento;
    }

    public String getTipoVenda() {
        return tipoVenda;
    }

    public String getLoginVendedor() {
        return loginVendedor;
    }

    public String getLoginVendedorOrig() {
        return loginVendedorOrig;
    }

    public String getCanal() {
        return canal;
    }

    public String getCanalOrig() {
        return canalOrig;
    }

    public String getCnpjParceiro() {
        return cnpjParceiro;
    }

    public String getCnpjParceiroOrig() {
        return cnpjParceiroOrig;
    }

    public String getCustCode() {
        return custCode;
    }

    public String getCustCodeOrig() {
        return custCodeOrig;
    }

    public String getPosition() {
        return position;
    }

    public String getPositionOrig() {
        return positionOrig;
    }

    public String getFlgCancAntesVenda() {
        return flgCancAntesVenda;
    }

    public String getFlgVendaDuplicada() {
        return flgVendaDuplicada;
    }

    public String getFlgVendaBruta() {
        return flgVendaBruta;
    }

    public String getFlgVendaLiquida() {
        return flgVendaLiquida;
    }

    public String getFlgCancPosVenda() {
        return flgCancPosVenda;
    }

    public String getDatCancVenda() {
        return datCancVenda;
    }

    public String getMotivoCancelamento() {
        return motivoCancelamento;
    }

    public String getNomeCliente() {
        return nomeCliente;
    }

    public String getTelefone() {
        return telefone;
    }

    public String getStatusOrdem() {
        return statusOrdem;
    }

    public String getSemanaVenda() {
        return semanaVenda;
    }

    public String getSemanaVendaOrig() {
        return semanaVendaOrig;
    }

    public String getScore() {
        return score;
    }

    public String getScoreConsumido() {
        return scoreConsumido;
    }

    public String getDatFinalizacaoOrdem() {
        return datFinalizacaoOrdem;
    }

    public String getQtdContratos() {
        return qtdContratos;
    }

    public String getNomLoginResponsavel() {
        return nomLoginResponsavel;
    }

    public String getDetalheRecusaCrivo() {
        return detalheRecusaCrivo;
    }

    public String getLoginCancelamentoOrdem() {
        return loginCancelamentoOrdem;
    }

    public String getNomeParceiroVenda() {
        return nomeParceiroVenda;
    }

    public String getVelocidadeDownload() {
        return velocidadeDownload;
    }

    public String getVelocidadeUpload() {
        return velocidadeUpload;
    }

    public String getCodConvergente() {
        return codConvergente;
    }
}
