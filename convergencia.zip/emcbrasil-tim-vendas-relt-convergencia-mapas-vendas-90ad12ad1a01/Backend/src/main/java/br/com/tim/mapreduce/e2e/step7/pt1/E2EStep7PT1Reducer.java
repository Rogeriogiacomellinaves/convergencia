package br.com.tim.mapreduce.e2e.step7.pt1;

import br.com.tim.mapreduce.e2e.step7.E2EStep7Key;
import br.com.tim.mapreduce.e2e.step7.TypeStep7;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.log4j.Logger;

import java.io.IOException;

public class E2EStep7PT1Reducer extends org.apache.hadoop.mapreduce.Reducer<E2EStep7Key,E2EStep7PT1Value,NullWritable,Text> {

    protected static final Logger LOG = Logger.getLogger(E2EStep7PT1Reducer.class);
    private E2EStep7PT1OutValue outValue;


    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        super.setup(context);
        outValue = new E2EStep7PT1OutValue();
    }

    @Override
    protected void reduce(E2EStep7Key key, Iterable<E2EStep7PT1Value> values, Context context) throws InterruptedException {

        outValue.clear();

        try {
            for (E2EStep7PT1Value value : values) {
                if (value.getTipo().equals(TypeStep7.RELT)){
                    outValue.clearRelt();
                    outValue.setRelt(value);
                    context.write(NullWritable.get(), new Text(outValue.toString()));
                }else if (value.getTipo().equals(TypeStep7.BAT510)){
                    outValue.setBat510(value);
                }
            }

        } catch (Exception e) {
            LOG.error(" ############ ERROR EXECUTION REDUCER ############ ");
            LOG.error(e.getMessage());
            throw new InterruptedException(e.getMessage());
        }
    }



    @Override
    protected void cleanup(Context context) throws IOException, InterruptedException {
        super.cleanup(context);

    }
}


