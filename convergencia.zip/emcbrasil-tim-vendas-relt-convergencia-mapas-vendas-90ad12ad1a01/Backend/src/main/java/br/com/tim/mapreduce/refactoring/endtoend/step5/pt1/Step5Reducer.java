package br.com.tim.mapreduce.refactoring.endtoend.step5.pt1;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.log4j.Logger;
import org.apache.parquet.Strings;

import br.com.tim.mapreduce.refactoring.endtoend.step5.model.Step4;
import br.com.tim.mapreduce.refactoring.endtoend.step5.utils.Step5Counters;
import br.com.tim.utils.CommonsConstants;

public class Step5Reducer extends Reducer<Step5Key, Step5Value, NullWritable, Text> {

	protected static final Logger LOG = Logger.getLogger(Step5Reducer.class);
	private final static String DELIMITER = CommonsConstants.FILE_FIELD_SEPARATOR;
	private static final String CONCLUIDA = "Concluído";
	private static final String PENDENTE_DE_PORTABILIDADE = "Pendente de Portabilidade";
	private static final String PENDENTE_PORTABILIDADE = "Pendente Portabilidade";
	private static final String APROCISIONAMENTO = "Em Aprovisionamento";
	private boolean possuiFlafLiq;
	private NullWritable outKey;
	private Step5OutputValue outValue;
	private Step4 step4Corrente;
	private Step4 step4;
	public List<Step5OutputValue> lstStep5OutputValueNotEmpty;
	
	
	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		super.setup(context);

		outKey = NullWritable.get();
		outValue = new Step5OutputValue();
		step4Corrente = new Step4();
		step4 = new Step4();
		lstStep5OutputValueNotEmpty = new ArrayList<>();
		
		clean();
	}

	@Override
	protected void reduce(Step5Key key, Iterable<Step5Value> values, Context context)
			throws InterruptedException, IOException {

		this.clean();
		
		

		for (Step5Value v : values) {

			switch (v.getType()) {
			case ORDEM:
				context.getCounter(Step5Counters.STEP2_REDUCER_READ).increment(1l);
				step4 = (Step4) v.getValue();
				break;
			default:
				break;
			}
			
			

			if (Strings.isNullOrEmpty(step4.getNumOrdemSiebelOrig()) || step4.getNumOrdemSiebelOrig().equals("\\N")) {

				context.getCounter(Step5Counters.STEP2_REDUCER_READ_EMPTY).increment(1l);
				outValue.update(step4);
				outValue.setFlgCancDupl("0");
				outValue.setFlgCancLiquido("0");
				outValue.setFlgVendaLiquida("0");
				prepareResponse(outValue, context);
				context.getCounter(Step5Counters.STEP2_REDUCER_WRITE_EMPTY).increment(1l);

			} else {

				context.getCounter(Step5Counters.STEP2_REDUCER_READ_NOT_EMPTY).increment(1l);
				step4Corrente.update(step4);
				outValue.updateNotNull(step4);
				lstStep5OutputValueNotEmpty.add(outValue);
				outValue = new Step5OutputValue();
				outValue.clean();
				//prepareResponse(outValue, context);
				context.getCounter(Step5Counters.STEP2_REDUCER_WRITE_NOT_EMPTY).increment(1l);
			}

			
		}
		
		



		/*
		 * Organizando os valores em uma lista e tambem colocando em um map para
		 * ordernar os valores por data de cancelamento
		 */


		//addMap(lstStep2);
		
		//list = ReducerRules.sortMapByKeyStep3(mapStep2);
		
		//lstStep3OutputValueNotEmpty
		
		
		
		Collections.sort(lstStep5OutputValueNotEmpty, new Comparator<Step5OutputValue>() {
			@Override
			public int compare(Step5OutputValue o1, Step5OutputValue o2) {
				return (o1.getDat_cancel_venda().compareTo(o2.getDat_cancel_venda()));
			}
			
		});
		
		for(int i = 0; i <= lstStep5OutputValueNotEmpty.size() - 1; i++) {
			context.getCounter(Step5Counters.STEP2_REDUCER_LIST_NOT_NULL).increment(1l);
		}
		
		
		if (lstStep5OutputValueNotEmpty.size() > 0) {

			//STEP5 
			
			if (possuiStatus(lstStep5OutputValueNotEmpty)) {
				/*
				 * Verificação se alguma do grupo original possui esteja como Concluído ou
				 * Pendente de Portabilidade ou Pendente Portabilidade ou Em Aprovisionamento
				 */

				for (int i = 0; i <= lstStep5OutputValueNotEmpty.size() - 1; i++) {

					if (lstStep5OutputValueNotEmpty.get(i).getFlgCancPosVenda().equals("1")) {

						lstStep5OutputValueNotEmpty.get(i).setFlgCancDupl("1");
					} else {
						lstStep5OutputValueNotEmpty.get(i).setFlgCancDupl("0");
					}

				}
			} else if (possuiMesmoNumeroSiebelCorrente(lstStep5OutputValueNotEmpty, step4Corrente.getNumOrdemSiebel())) {
				/*
				 * Aqui fazemos uma verificação se todos os numeros de ordem são semalhantes,
				 * pois se tiver somente o mesmo numero de siebel na lista deve -se ter uma
				 * outra tratativa
				 */

				for (int i = 0; i < lstStep5OutputValueNotEmpty.size(); i++) {

					lstStep5OutputValueNotEmpty.get(i).setFlgCancDupl("0");

				}

			} else {

					/*
					 * Se posssuir o primeiro item da lista ordenada por data de cancelamento, o
					 * item zero é a ordem de cancelamento mais atual
					 */

					
						lstStep5OutputValueNotEmpty.get(lstStep5OutputValueNotEmpty.size() - 1).setFlgCancDupl("0");
					
					
					
					

					for (int i = 0; i <= lstStep5OutputValueNotEmpty.size() - 1; i++) {

						/*
						 * Aqui verifica-se se no grupo existe mais algum numero de ordem siebel igual
						 * ao da ordem corrente, se tiver o valor deve ser o mesmo da ordem corrente,
						 * senão deve ser "1"
						 */
						if (lstStep5OutputValueNotEmpty.get(i).getNumOrdemSiebel().equals(lstStep5OutputValueNotEmpty.get(lstStep5OutputValueNotEmpty.size() - 1).getNumOrdemSiebel())) {

							lstStep5OutputValueNotEmpty.get(i).setFlgCancDupl(lstStep5OutputValueNotEmpty.get(lstStep5OutputValueNotEmpty.size() - 1).getFlgCancDupl());

						} else {

								if (lstStep5OutputValueNotEmpty.get(i).getFlgCancPosVenda().equals("1")) {
									lstStep5OutputValueNotEmpty.get(i).setFlgCancDupl("1");
								}else {
									lstStep5OutputValueNotEmpty.get(i).setFlgCancDupl("0");
								}
						}

					}

				
			}

		} 
		// metodo step 6

		if (lstStep5OutputValueNotEmpty.size() > 0) {

			for (int i = 0; i < lstStep5OutputValueNotEmpty.size(); i++) {

				if (lstStep5OutputValueNotEmpty.get(i).getFlgCancPosVenda().equals("1")
						&& lstStep5OutputValueNotEmpty.get(i).getFlgCancDupl().equals("0")) {

					lstStep5OutputValueNotEmpty.get(i).setFlgCancLiquido("1");
				} else {
					lstStep5OutputValueNotEmpty.get(i).setFlgCancLiquido("0");
				}

			}

		}

				// metodo step 7

				possuiFlafLiq = possuiFlCancelLiq(lstStep5OutputValueNotEmpty);
		
		if (lstStep5OutputValueNotEmpty.size() > 0) {
			for (int i = 0; i <= lstStep5OutputValueNotEmpty.size() - 1; i++) {

				if (lstStep5OutputValueNotEmpty.get(i).getFlgVendaBruta().equals("0")) {

					lstStep5OutputValueNotEmpty.get(i).setFlgVendaLiquida("0");

				} else {
					if (possuiFlafLiq) {
						lstStep5OutputValueNotEmpty.get(i).setFlgVendaLiquida("0");
					}else {
						lstStep5OutputValueNotEmpty.get(i).setFlgVendaLiquida("1");
					}
						
				}

			}
		}
				

				// escrita no reducer
				for (Step5OutputValue v : lstStep5OutputValueNotEmpty) {

					prepareResponse(v, context);
					context.getCounter(Step5Counters.STEP2_REDUCER_WRITE_NOT_EMPTY).increment(1l);

				}

			}
		
	

	@Override
	protected void cleanup(Context context) throws IOException, InterruptedException {
		super.cleanup(context);

	}

	public void clean() {

		outValue.clean();
		lstStep5OutputValueNotEmpty.clear();
		step4Corrente.clean();
		step4.clean();
		possuiFlafLiq = false;
		

	}

	private void prepareResponse(Step5OutputValue value, Context context) throws IOException, InterruptedException {

		StringBuffer sb = new StringBuffer();
		sb.setLength(0);
		sb.append(value.getDatref()).append(DELIMITER);
		sb.append(value.getDatCriacaoOrdem()).append(DELIMITER);
		sb.append(value.getHoraCriacaoDaOrdem()).append(DELIMITER);
		sb.append(value.getDatVenda()).append(DELIMITER);
		sb.append(value.getHoraDaVenda()).append(DELIMITER);
		sb.append(value.getDatStatusOrdem()).append(DELIMITER);
		sb.append(value.getHrStatusOrdem()).append(DELIMITER);
		sb.append(value.getNumOrdemSiebel()).append(DELIMITER);
		sb.append(value.getNumOrdemSiebelOrig()).append(DELIMITER);
		sb.append(value.getCodContratoOltp()).append(DELIMITER);
		sb.append(value.getCodContratoAtivacao()).append(DELIMITER);
		sb.append(value.getNumeroAcesso()).append(DELIMITER);
		sb.append(value.getCustomerId()).append(DELIMITER);
		sb.append(value.getTipoDocumento()).append(DELIMITER);
		sb.append(value.getDocumento()).append(DELIMITER);
		sb.append(value.getTipoVenda()).append(DELIMITER);
		sb.append(value.getTipoProduto()).append(DELIMITER);
		sb.append(value.getVelocidadeDownload()).append(DELIMITER);
		sb.append(value.getVelocidadeUpload()).append(DELIMITER);
		sb.append(value.getPlanoAtivacaoOferta()).append(DELIMITER);
		sb.append(value.getLoginVendedor()).append(DELIMITER);
		sb.append(value.getCanal()).append(DELIMITER);
		sb.append(value.getCnpjParceiro()).append(DELIMITER);
		sb.append(value.getCustcode()).append(DELIMITER);
		sb.append(value.getPosition()).append(DELIMITER);
		sb.append(value.getFlgCancAntesVenda()).append(DELIMITER);
		sb.append(value.getFlgCancPosVenda()).append(DELIMITER);
		sb.append(value.getDtCancVenda()).append(DELIMITER);
		sb.append(value.getMotivoCancelamento()).append(DELIMITER);
		sb.append(value.getNomeCliente()).append(DELIMITER);
		sb.append(value.getTelefone()).append(DELIMITER);
		sb.append(value.getEmailFatura()).append(DELIMITER);
		sb.append(value.getUf()).append(DELIMITER);
		sb.append(value.getTipoLogradouro()).append(DELIMITER);
		sb.append(value.getLogradouro()).append(DELIMITER);
		sb.append(value.getNumero()).append(DELIMITER);
		sb.append(value.getComplemento()).append(DELIMITER);
		sb.append(value.getBairro()).append(DELIMITER);
		sb.append(value.getCep()).append(DELIMITER);
		sb.append(value.getCidade()).append(DELIMITER);
		sb.append(value.getStatusOrdem()).append(DELIMITER);
		sb.append(value.getTecnologia()).append(DELIMITER);
		sb.append(value.getFormaPagamento()).append(DELIMITER);
		sb.append(value.getTipoConta()).append(DELIMITER);
		sb.append(value.getCodBanco()).append(DELIMITER);
		sb.append(value.getCodAgengiaBco()).append(DELIMITER);
		sb.append(value.getCodContaCorrente()).append(DELIMITER);
		sb.append(value.getCodDebitoAutomatico()).append(DELIMITER);
		sb.append(value.getDiaVencimento()).append(DELIMITER);
		sb.append(value.getSemanaVenda()).append(DELIMITER);
		sb.append(value.getScore()).append(DELIMITER);
		sb.append(value.getScoreConsumido()).append(DELIMITER);
		sb.append(value.getDtFinalizacaoOrdem()).append(DELIMITER);
		sb.append(value.getQdeContratos()).append(DELIMITER);
		sb.append(value.getNumProtocolo()).append(DELIMITER);
		sb.append(value.getFlgOrdemAutomatica()).append(DELIMITER);
		sb.append(value.getDscTxRecorrente()).append(DELIMITER);
		sb.append(value.getDscTxNaoRecorrente()).append(DELIMITER);
		sb.append(value.getDscStatusItem()).append(DELIMITER);
		sb.append(value.getNomLoginResponsavel()).append(DELIMITER);
		sb.append(value.getFlgPortabilidade()).append(DELIMITER);
		sb.append(value.getDscOperadoraDoadora()).append(DELIMITER);
		sb.append(value.getCodDdd()).append(DELIMITER);
		sb.append(value.getNumTelefonePortado()).append(DELIMITER);
		sb.append(value.getDatJanelaPortabilidade()).append(DELIMITER);
		sb.append(value.getHoraDaJanela()).append(DELIMITER);
		sb.append(value.getDscEnderecoFatura()).append(DELIMITER);
		sb.append(value.getDscAreaVoip()).append(DELIMITER);
		sb.append(value.getCpe()).append(DELIMITER);
		sb.append(value.getOnt()).append(DELIMITER);
		sb.append(value.getCodigoConvergente()).append(DELIMITER);
		sb.append(value.getDetalheRecusaCrivo()).append(DELIMITER);
		sb.append(value.getItemRoot()).append(DELIMITER);
		sb.append(value.getLoginCancelamentoOrdem()).append(DELIMITER);
		sb.append(value.getCustcodeCliente()).append(DELIMITER);
		sb.append(value.getDominioRoot()).append(DELIMITER);
		sb.append(value.getCodContFinanceira()).append(DELIMITER);
		sb.append(value.getValPlanoAtualItem()).append(DELIMITER);
		sb.append(value.getNomDescontoAtualItem()).append(DELIMITER);
		sb.append(value.getValDescontoAtualItem()).append(DELIMITER);
		sb.append(value.getNroOrdem()).append(DELIMITER);
		sb.append(value.getAcessoRowId()).append(DELIMITER);
		sb.append(value.getAcessoRowIdRoot()).append(DELIMITER);
		sb.append(value.getCodigoProduto()).append(DELIMITER);
		sb.append(value.getFlgVendaSubmetida()).append(DELIMITER);
		sb.append(value.getFlgVendaDuplicada()).append(DELIMITER);
		sb.append(value.getFlgVendaBruta()).append(DELIMITER);
		sb.append(value.getFlgVendaLiquida()).append(DELIMITER);
		sb.append(value.getFlgCancDupl()).append(DELIMITER);
		sb.append(value.getFlgCancLiquido()).append(DELIMITER);
		sb.append(value.getNomeParceiroVenda()).append(DELIMITER);
		sb.append(value.getNomeParceiroVendaOrig()).append(DELIMITER);
		sb.append(value.getRowIdItemOrdem()).append(DELIMITER);
		sb.append(value.getRowIdItemOrdemPai()).append(DELIMITER);
		sb.append(value.getCategoriaItemOrder()).append(DELIMITER);
		sb.append(value.getMsanOltVenda()).append(DELIMITER);
		sb.append(value.getDtConclusaoWfm()).append(DELIMITER);
		sb.append(value.getDscStatusOrdemWfm()).append(DELIMITER);
		sb.append(value.getDatStatusWfm()).append(DELIMITER);
		sb.append(value.getHoraStatusWfm()).append(DELIMITER);
		sb.append(value.getIdRecursoWfm()).append(DELIMITER);
		sb.append(value.getNomRecursoWfm()).append(DELIMITER);
		sb.append(value.getIdRecursoPaiWfm()).append(DELIMITER);
		sb.append(value.getDatPrimeiroAgend()).append(DELIMITER);
		sb.append(value.getHoraPrimeiroAgendamento()).append(DELIMITER);
		sb.append(value.getDatAgendAtual()).append(DELIMITER);
		sb.append(value.getHoraAgendamentoAtual()).append(DELIMITER);
		sb.append(value.getDscStatusAtivacao()).append(DELIMITER);
		sb.append(value.getMsanOltTrafego()).append(DELIMITER);
		sb.append(value.getDatVendaOrig()).append(DELIMITER);
		sb.append(value.getHoraVendaOrig()).append(DELIMITER);
		sb.append(value.getLoginVendedorOrig()).append(DELIMITER);
		sb.append(value.getCanalOrig()).append(DELIMITER);
		sb.append(value.getCnpjParceiroOrig()).append(DELIMITER);
		sb.append(value.getCustcodeOrig()).append(DELIMITER);
		sb.append(value.getPositionOrig()).append(DELIMITER);
		sb.append(value.getSemanaVendaOrig()).append(DELIMITER);
		sb.append(value.getCodContratoAtual()).append(DELIMITER);
		sb.append(value.getNomPlanoAtual()).append(DELIMITER);
		sb.append(value.getNomeVendedorOrig()).append(DELIMITER);
		sb.append(value.getFlVendaDuplicada()).append(DELIMITER);
		sb.append(value.getFlGross()).append(DELIMITER);
		sb.append(value.getDtGross()).append(DELIMITER);
		sb.append(value.getFlChurn()).append(DELIMITER);
		sb.append(value.getDtChurn()).append(DELIMITER);
		sb.append(value.getMotivoChurn()).append(DELIMITER);
		sb.append(value.getCodOrdemChurn()).append(DELIMITER);
		sb.append(value.getTipoChurn()).append(DELIMITER);
		sb.append(value.getDtCriacaoOrdemChurn()).append(DELIMITER);
		sb.append(value.getDtConclusaoOrdemChurn()).append(DELIMITER);
		sb.append(value.getNomeVendedor()).append(DELIMITER);
		sb.append(value.getNomeUsuarioCancOrdem()).append(DELIMITER);
		sb.append(value.getEmailCliente());
		
		context.write(outKey, new Text(sb.toString()));
		context.getCounter(Step5Counters.STEP2_REDUCER_WRITE).increment(1l);

	}


	/*
	public void addMap(List<Step4> lst) {
		
		
		for (Step4 value : lst) {
			
			outValue.update(value, false);
			LocalDate dateValue = LocalDate.parse(value.getDtCancVenda(),DATE_FORMATTER_YYYY_MM);
			mapStep2.put(dateValue, outValue);
			
		}
		
	}
	*/
	
	public boolean possuiFlagPosVenda(List<Step5OutputValue> lst) {

		for (Step5OutputValue v : lst) {

			if (v.getFlgCancPosVenda().equals("0")) {
				return false;
			}

		}

		return true;

	}

	
	public boolean possuiStatus(List<Step5OutputValue> lst) {

		for (Step5OutputValue v : lst) {

			if (v.getStatusOrdem().equals(CONCLUIDA) || v.getStatusOrdem().equals(PENDENTE_PORTABILIDADE)
					|| v.getStatusOrdem().equals(APROCISIONAMENTO)
					|| v.getStatusOrdem().equals(PENDENTE_DE_PORTABILIDADE)) {

				return true;

			}

		}

		return false;

	}
	
	
	public boolean possuiMesmoNumeroSiebelCorrente(List<Step5OutputValue> lst, String numSiebelCorrente) {
		
		
		for(Step5OutputValue v : lst) {
			
			if (!v.getNumOrdemSiebel().equals(numSiebelCorrente)){
				
				return false;
				
			}
			
		}
		
		return true;
	}
	
	
	public boolean possuiFlCancelLiq (List<Step5OutputValue> lst) {
		
		for (Step5OutputValue v : lst) {

			if (v.getFlgCancLiquido().equals("1")) {
				return true;
			}

		}

		return false;

		
	}
}
