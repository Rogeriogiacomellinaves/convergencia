package br.com.tim.mapreduce.refactoring.endtoend.step4.pt6;

import org.apache.hadoop.mapreduce.Partitioner;

public class JoinPartitioner extends Partitioner<Step4Pt6Key, E2EStep4Pt6Value>{

	@Override
	public int getPartition(Step4Pt6Key taggedKey, E2EStep4Pt6Value value, int numPartitions) {
        
		return Math.abs(taggedKey.hashCodeJoin() % numPartitions);

	}

}
