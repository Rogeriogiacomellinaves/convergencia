
package br.com.tim.mapreduce.refactoring.endtoend.step4.pt6;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

import br.com.tim.mapreduce.refactoring.endtoend.step4.model.Step4;
import br.com.tim.mapreduce.refactoring.endtoend.step4.utils.Step4PT6Counters223;

public class MapperStep4Pt5Result extends org.apache.hadoop.mapreduce.Mapper<Writable, Text, Step4Pt6Key, E2EStep4Pt6Value> {

	private E2EStep4Pt6Value outValue;
	private Step4 input;
	private Step4Pt6Key outkey;

	@Override
	protected void map(Writable key, Text value, Context context) throws IOException, InterruptedException {

		input.parseFromText(value);
		outValue.Step1Pt5Result(input);
		outkey.setCodContrato(outValue.getCodContratoOltp());
		outkey.setTipo(TypeStep4Pt6.RELT);
		context.write(outkey, outValue);
		context.getCounter(Step4PT6Counters223.STEP4PT5_MAPPER).increment(1l);
	}

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		super.setup(context);
		this.outValue = new E2EStep4Pt6Value();
		this.input = new Step4();
		this.outkey = new Step4Pt6Key();
	}

	@Override
	protected void cleanup(Context context) throws IOException, InterruptedException {
		super.cleanup(context);
		this.clear();
		
	}

	private void clear() {
		this.outValue.clear();
		
	}

}