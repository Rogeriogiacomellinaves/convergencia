package br.com.tim.mapreduce.refactoring.endtoend.step4.pt1;

import org.apache.hadoop.mapreduce.Partitioner;

public class JoinPartitioner extends Partitioner<Step4Key, Step4Value>{

	@Override
	public int getPartition(Step4Key taggedKey, Step4Value value, int numPartitions) {
		return Math.abs(taggedKey.hashCodeJoin() % numPartitions);

	}
	
}
