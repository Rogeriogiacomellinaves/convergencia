package br.com.tim.mapreduce.refactoring.endtoend.step1.pt1;

import org.apache.hadoop.mapreduce.Partitioner;

public class JoinPartitioner extends Partitioner<E2EStep1Pt1Key, E2EStep1Pt1Value> {

    @Override
    public int getPartition(E2EStep1Pt1Key taggedKey, E2EStep1Pt1Value value, int numPartitions) {
        return Math.abs(taggedKey.hashCodeJoin() % numPartitions);
    }
}