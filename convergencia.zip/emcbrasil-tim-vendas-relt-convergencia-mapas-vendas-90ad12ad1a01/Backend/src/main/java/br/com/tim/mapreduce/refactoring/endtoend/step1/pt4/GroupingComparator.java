package br.com.tim.mapreduce.refactoring.endtoend.step1.pt4;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

public class GroupingComparator extends WritableComparator {

    public GroupingComparator() {
        super(E2EStep1Pt4Key.class, true);
    }

    @SuppressWarnings({"rawtypes"})
    @Override
    public int compare(WritableComparable a, WritableComparable b) {
        E2EStep1Pt4Key keyA = (E2EStep1Pt4Key) a;
        E2EStep1Pt4Key keyB = (E2EStep1Pt4Key) b;

        return keyA.compareToGrouping(keyB);
    }

}
