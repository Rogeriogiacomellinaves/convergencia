package br.com.tim.mapreduce.refactoring.endtoend.step4.pt4;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

public class GroupingComparator extends WritableComparator {

    public GroupingComparator() {
        super(E2EStep4Pt4Key.class, true);
    }

    @SuppressWarnings({"rawtypes"})
    @Override
    public int compare(WritableComparable a, WritableComparable b) {
        E2EStep4Pt4Key keyA = (E2EStep4Pt4Key) a;
        E2EStep4Pt4Key keyB = (E2EStep4Pt4Key) b;

        return keyA.compareToGrouping(keyB);
    }

}
