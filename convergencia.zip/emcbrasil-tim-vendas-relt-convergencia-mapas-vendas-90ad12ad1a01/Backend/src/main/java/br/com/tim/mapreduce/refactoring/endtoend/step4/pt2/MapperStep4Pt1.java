package br.com.tim.mapreduce.refactoring.endtoend.step4.pt2;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.parquet.Strings;

import br.com.tim.mapreduce.refactoring.endtoend.step4.model.Step4;
import br.com.tim.mapreduce.refactoring.endtoend.utils.Step1Pt2Counters;

public class MapperStep4Pt1 extends Mapper<LongWritable, Text, Step4Pt2Key, Step4Pt2Value> {
	
	Step4Pt2Value outValue;
	private Step4Pt2Key outkey;
	private Step4 input;
	
	
	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		
		this.outValue = new Step4Pt2Value();
		this.outkey = new Step4Pt2Key();
		this.input = new Step4();
		
	}
	
	
	@Override
	protected void map(LongWritable key, Text value, Mapper<LongWritable, Text, Step4Pt2Key,Step4Pt2Value>.Context context) throws IOException, InterruptedException {
		
		outValue.clear();
		
		input.parseFromText(value);
		
		if (!Strings.isNullOrEmpty(input.getNroOrdem())) {
			
			outkey.setNroOrdem(input.getNroOrdem());
			outkey.setDatRef(input.getDatref());
			outkey.setTipo(TypeStep4Pt2.STEP4);
			
			outValue.setStep4Pt1Result(input);
			
			context.write(outkey, outValue);
			context.getCounter(Step1Pt2Counters.ITEM_MAPPER_WRITE).increment(1l);
			
		}else {
			context.getCounter(Step1Pt2Counters.ITEM_MAPPER_DISCART).increment(1l);

		}
	
	}



}
