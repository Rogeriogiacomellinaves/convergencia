package br.com.tim.mapreduce.tramit.step2;

public enum TypeStep2 {

    FALLOUT, WFMTOA, STEP1RESULT
}
