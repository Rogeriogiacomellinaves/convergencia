package br.com.tim.mapreduce.e2e.step1;

import br.com.tim.mapreduce.model.BAT509Item;
import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.io.Writable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public class E2EStep1Value implements Writable {

    protected TypeStep1 tipo;

    protected String nroOrdem;
    protected String acessoRowId;
    protected String codigoProduto;
    protected String datRef;
    protected String codContratoOltp;
    protected String codContratoAtivacao;
    protected String numeroAcesso;
    protected String customerId;
    protected String tipoProduto;
    protected String email;
    protected String uf;
    protected String tipoLogradouro;
    protected String logradouro;
    protected String numero;
    protected String complemento;
    protected String bairro;
    protected String cep;
    protected String cidade;
    protected String tecnologia;
    protected String formaPagamento;
    protected String tipoConta;
    protected String codBanco;
    protected String codAgenciaBanco;
    protected String codContaCorrente;
    protected String codDebitoAutomatico;
    protected String diaVencimento;
    protected String codContaFinanceira;
    protected String numProtocolo;
    protected String flgOrdemAutomatica;
    protected String dscTxRecorrente;
    protected String dscTxNaoRecorrente;
    protected String dscStatusItem;
    protected String nomPlanoAtual;
    protected String valPlanoAtualItem;
    protected String nomDescontoAtualItem;
    protected String valDescontoAtualItem;
    protected String flgPortabilidade;
    protected String dscOperadoraDoadora;
    protected String codDdd;
    protected String numTelefonePortado;
    protected String datJanelaPortabilidade;
    protected String horJanela;
    protected String dscEnderecoFatura;
    protected String dscAreaVoip;
    protected String cpe;
    protected String ont;
    protected String itemRoot;
    protected String dominioRoot;
    protected String tipoItem;
    protected String nomeProduto;
    protected String motivoStatus;
    protected String tipoMotivo;

    protected String categoriaItemRoot;
    protected String rowIdItemRootRoot;
    protected String tipoItemRoot;
    protected String acaoItemRoot;
    protected String acessoRowIdRoot;
    protected String statusItemRoot;
    

    private String rowIdDoItemDaOrdem;
    private String rowIdDoItemDaOrdemPai;
    private String rowIdDoItemDaOrdemRoot;


    @Override
    public void write(DataOutput dataOutput) throws IOException {
        dataOutput.writeInt(tipo.ordinal());
        dataOutput.writeUTF(nroOrdem);
        dataOutput.writeUTF(acessoRowId);
        dataOutput.writeUTF(codigoProduto);
        dataOutput.writeUTF(datRef);
        dataOutput.writeUTF(codContratoOltp);
        dataOutput.writeUTF(codContratoAtivacao);
        dataOutput.writeUTF(numeroAcesso);
        dataOutput.writeUTF(customerId);
        dataOutput.writeUTF(tipoProduto);
        dataOutput.writeUTF(email);
        dataOutput.writeUTF(uf);
        dataOutput.writeUTF(tipoLogradouro);
        dataOutput.writeUTF(logradouro);
        dataOutput.writeUTF(numero);
        dataOutput.writeUTF(complemento);
        dataOutput.writeUTF(bairro);
        dataOutput.writeUTF(cep);
        dataOutput.writeUTF(cidade);
        dataOutput.writeUTF(tecnologia);
        dataOutput.writeUTF(formaPagamento);
        dataOutput.writeUTF(tipoConta);
        dataOutput.writeUTF(codBanco);
        dataOutput.writeUTF(codAgenciaBanco);
        dataOutput.writeUTF(codContaCorrente);
        dataOutput.writeUTF(codDebitoAutomatico);
        dataOutput.writeUTF(diaVencimento);
        dataOutput.writeUTF(codContaFinanceira);
        dataOutput.writeUTF(numProtocolo);
        dataOutput.writeUTF(flgOrdemAutomatica);
        dataOutput.writeUTF(dscTxRecorrente);
        dataOutput.writeUTF(dscTxNaoRecorrente);
        dataOutput.writeUTF(dscStatusItem);
        dataOutput.writeUTF(nomPlanoAtual);
        dataOutput.writeUTF(valPlanoAtualItem);
        dataOutput.writeUTF(nomDescontoAtualItem);
        dataOutput.writeUTF(valDescontoAtualItem);
        dataOutput.writeUTF(flgPortabilidade);
        dataOutput.writeUTF(dscOperadoraDoadora);
        dataOutput.writeUTF(codDdd);
        dataOutput.writeUTF(numTelefonePortado);
        dataOutput.writeUTF(datJanelaPortabilidade);
        dataOutput.writeUTF(horJanela);
        dataOutput.writeUTF(dscEnderecoFatura);
        dataOutput.writeUTF(dscAreaVoip);
        dataOutput.writeUTF(cpe);
        dataOutput.writeUTF(ont);
        dataOutput.writeUTF(itemRoot);
        dataOutput.writeUTF(dominioRoot);
        dataOutput.writeUTF(tipoItem);
        dataOutput.writeUTF(nomeProduto);
        dataOutput.writeUTF(motivoStatus);
        dataOutput.writeUTF(tipoMotivo);
        dataOutput.writeUTF(categoriaItemRoot);
        dataOutput.writeUTF(rowIdItemRootRoot);
        dataOutput.writeUTF(tipoItemRoot);
        dataOutput.writeUTF(acaoItemRoot);
        dataOutput.writeUTF(acessoRowIdRoot);
        dataOutput.writeUTF(statusItemRoot);
        
        dataOutput.writeUTF(rowIdDoItemDaOrdem);
        dataOutput.writeUTF(rowIdDoItemDaOrdemRoot);
        dataOutput.writeUTF(rowIdDoItemDaOrdemPai);
    }

    @Override
    public void readFields(DataInput dataInput) throws IOException {
        this.tipo = TypeStep1.values()[dataInput.readInt()];
        this.nroOrdem = dataInput.readUTF();
        this.acessoRowId = dataInput.readUTF();
        this.codigoProduto = dataInput.readUTF();
        this.datRef = dataInput.readUTF();
        this.codContratoOltp = dataInput.readUTF();
        this.codContratoAtivacao = dataInput.readUTF();
        this.numeroAcesso = dataInput.readUTF();
        this.customerId = dataInput.readUTF();
        this.tipoProduto = dataInput.readUTF();
        this.email = dataInput.readUTF();
        this.uf = dataInput.readUTF();
        this.tipoLogradouro = dataInput.readUTF();
        this.logradouro = dataInput.readUTF();
        this.numero = dataInput.readUTF();
        this.complemento = dataInput.readUTF();
        this.bairro = dataInput.readUTF();
        this.cep = dataInput.readUTF();
        this.cidade = dataInput.readUTF();
        this.tecnologia = dataInput.readUTF();
        this.formaPagamento = dataInput.readUTF();
        this.tipoConta = dataInput.readUTF();
        this.codBanco = dataInput.readUTF();
        this.codAgenciaBanco = dataInput.readUTF();
        this.codContaCorrente = dataInput.readUTF();
        this.codDebitoAutomatico = dataInput.readUTF();
        this.diaVencimento = dataInput.readUTF();
        this.codContaFinanceira = dataInput.readUTF();
        this.numProtocolo = dataInput.readUTF();
        this.flgOrdemAutomatica = dataInput.readUTF();
        this.dscTxRecorrente = dataInput.readUTF();
        this.dscTxNaoRecorrente = dataInput.readUTF();
        this.dscStatusItem = dataInput.readUTF();
        this.nomPlanoAtual = dataInput.readUTF();
        this.valPlanoAtualItem = dataInput.readUTF();
        this.nomDescontoAtualItem = dataInput.readUTF();
        this.valDescontoAtualItem = dataInput.readUTF();
        this.flgPortabilidade = dataInput.readUTF();
        this.dscOperadoraDoadora = dataInput.readUTF();
        this.codDdd = dataInput.readUTF();
        this.numTelefonePortado = dataInput.readUTF();
        this.datJanelaPortabilidade = dataInput.readUTF();
        this.horJanela = dataInput.readUTF();
        this.dscEnderecoFatura = dataInput.readUTF();
        this.dscAreaVoip = dataInput.readUTF();
        this.cpe = dataInput.readUTF();
        this.ont = dataInput.readUTF();
        this.itemRoot = dataInput.readUTF();
        this.dominioRoot = dataInput.readUTF();
        this.tipoItem = dataInput.readUTF();
        this.nomeProduto = dataInput.readUTF();
        this.motivoStatus = dataInput.readUTF();
        this.tipoMotivo = dataInput.readUTF();
        this.categoriaItemRoot = dataInput.readUTF();
        this.rowIdItemRootRoot = dataInput.readUTF();
        this.tipoItemRoot = dataInput.readUTF();
        this.acaoItemRoot = dataInput.readUTF();
        this.acessoRowIdRoot = dataInput.readUTF();
        this.statusItemRoot = dataInput.readUTF();
        this.rowIdDoItemDaOrdem = dataInput.readUTF();
        this.rowIdDoItemDaOrdemRoot = dataInput.readUTF();
        this.rowIdDoItemDaOrdemPai = dataInput.readUTF();
    }

    public void setItem(BAT509Item item, TypeStep1 tipo) {
        this.clear();
        this.tipo = tipo;
        this.nroOrdem = item.getNumeroOrdem();
        this.acessoRowId = item.getAcessoRowid();
        this.codigoProduto = item.getCodigoProduto();
        this.datRef = item.getArquivo().substring(23,31);
        this.codContratoOltp = item.getIdAcessoBi();
        if(!item.getTipoItemOrdem().equals("BANDA_LARGA")) {
            
            this.numeroAcesso = item.getNumeroAcesso();
        }
        this.codContratoAtivacao = item.getServiceId();
        this.customerId = item.getCodigoContaFinanceira();
        this.tipoProduto = item.getTipoItemOrdem();

        this.email = item.getEmail();
        this.uf = item.getUfInstalacao();
        this.tipoLogradouro = item.getTipoLogradouro();
        this.logradouro = item.getLogradouroInstalacao();
        this.numero = item.getNumeroLogradouro();
        this.complemento = item.getComplemento();
        this.bairro = item.getBairro();
        this.cep = item.getCep();
        this.cidade = item.getCidade();
        this.tecnologia = item.getDscTecnologia();
        this.formaPagamento = item.getMetodoPagamento();
        this.tipoConta = item.getTipoConta();
        this.codBanco = item.getBanco();
        this.codAgenciaBanco = item.getAgencia();
        this.codContaCorrente = item.getConta();
        this.codDebitoAutomatico = item.getCodDebitoAutomatico();
        this.diaVencimento = item.getDiaVencimento();
        this.codContaFinanceira = item.getCodigoContaFinanceira();
        this.numProtocolo = item.getNumeroProtocolo();
        this.flgOrdemAutomatica = item.getFlgOrdemAut();
        this.dscTxRecorrente = item.getTaxaRecorrente();
        this.dscTxNaoRecorrente = item.getTaxaNaoRecorrente();
        this.dscStatusItem = item.getStatusItem();
        this.flgPortabilidade = item.getFlgPortabilidade();
        this.dscOperadoraDoadora = item.getOperadoraDoadora();
        this.codDdd = item.getDdd();
        this.numTelefonePortado = item.getNumeroASerPortado();
        if(StringUtils.isNotEmpty(item.getDataJanela())){
            this.datJanelaPortabilidade = item.getDataJanela().substring(0, 10);
            this.horJanela = item.getDataJanela().substring(11, 19);
        }
        this.dscEnderecoFatura = item.getEnderecoRecebimentoFatura();
        this.dscAreaVoip = item.getArea();
        if(item.getRowidItemOrdem().equals(item.getRowidItemOrdemRoot()))
            this.itemRoot = "1";
        else
            this.itemRoot = "0";
        this.dominioRoot = item.getDominioRoot();
        this.categoriaItemRoot = item.getCategoriaItemOrdem();
        this.tipoItemRoot = item.getTipoItemOrdem();
        this.acaoItemRoot = item.getAcaoItemOrdem();
        this.numeroAcesso = item.getNumeroAcesso();
        this.statusItemRoot = item.getStatusItem();
        this.tipoItem = item.getTipoItemOrdem();
        this.nomeProduto = item.getNomeProduto();
        this.motivoStatus = item.getMotivoStatus();
        this.tipoMotivo = item.getTipoMotivo();
        this.tecnologia = item.getDscTecnologia();
        this.nomPlanoAtual = item.getPlanoAtual();
        this.valPlanoAtualItem = item.getPrecoPlanoAtual();
        this.cpe = item.getCpe();
        this.ont = item.getOnt();
        this.categoriaItemRoot = item.getCategoriaItemOrdem();
        this.rowIdItemRootRoot = item.getRowidItemOrdemRoot();
        this.tipoItemRoot = item.getTipoItemOrdem();
        this.acaoItemRoot = item.getAcaoItemOrdem();
        this.acessoRowIdRoot = item.getAcessoRowid();
        this.statusItemRoot = item.getStatusItem();
        this.nomDescontoAtualItem = item.getDescontoAtual();
        this.valDescontoAtualItem = item.getPrecoDescontoAtual();
        this.rowIdDoItemDaOrdem = item.getRowidItemOrdem();
        this.rowIdDoItemDaOrdemRoot = item.getRowidItemOrdemRoot();
        this.rowIdDoItemDaOrdemPai = item.getRowidItemOrdemPai();
    }

    public String getRowIdDoItemDaOrdem() {
		return rowIdDoItemDaOrdem;
	}

	public void setRowIdDoItemDaOrdem(String rowIdDoItemDaOrdem) {
		this.rowIdDoItemDaOrdem = rowIdDoItemDaOrdem;
	}

	public String getRowIdDoItemDaOrdemPai() {
		return rowIdDoItemDaOrdemPai;
	}

	public void setRowIdDoItemDaOrdemPai(String rowIdDoItemDaOrdemPai) {
		this.rowIdDoItemDaOrdemPai = rowIdDoItemDaOrdemPai;
	}

	public String getRowIdDoItemDaOrdemRoot() {
		return rowIdDoItemDaOrdemRoot;
	}

	public void setRowIdDoItemDaOrdemRoot(String rowIdDoItemDaOrdemRoot) {
		this.rowIdDoItemDaOrdemRoot = rowIdDoItemDaOrdemRoot;
	}

	public void clear(){
        this.tipo = null;
        this.nroOrdem = "";
        this.acessoRowId = "";
        this.codigoProduto = "";
        this.datRef = "";
        this.codContratoOltp = "";
        this.codContratoAtivacao = "";
        this.numeroAcesso = "";
        this.customerId = "";
        this.tipoProduto = "";
        this.email = "";
        this.uf = "";
        this.tipoLogradouro = "";
        this.logradouro = "";
        this.numero = "";
        this.complemento = "";
        this.bairro = "";
        this.cep = "";
        this.cidade = "";
        this.tecnologia = "";
        this.formaPagamento = "";
        this.tipoConta = "";
        this.codBanco = "";
        this.codAgenciaBanco = "";
        this.codContaCorrente = "";
        this.codDebitoAutomatico = "";
        this.diaVencimento = "";
        this.codContaFinanceira = "";
        this.numProtocolo = "";
        this.flgOrdemAutomatica = "";
        this.dscTxRecorrente = "";
        this.dscTxNaoRecorrente = "";
        this.dscStatusItem = "";
        this.nomPlanoAtual = "";
        this.valPlanoAtualItem = "";
        this.nomDescontoAtualItem = "";
        this.valDescontoAtualItem = "";
        this.flgPortabilidade = "";
        this.dscOperadoraDoadora = "";
        this.codDdd = "";
        this.numTelefonePortado = "";
        this.datJanelaPortabilidade = "";
        this.horJanela = "";
        this.dscEnderecoFatura = "";
        this.dscAreaVoip = "";
        this.cpe = "";
        this.ont = "";
        this.itemRoot = "";
        this.dominioRoot = "";
        this.tipoItem = "";
        this.nomeProduto = "";
        this.motivoStatus = "";
        this.tipoMotivo = "";
        this.categoriaItemRoot = "";
        this.rowIdItemRootRoot = "";
        this.tipoItemRoot = "";
        this.acaoItemRoot = "";
        this.acessoRowIdRoot = "";
        this.statusItemRoot = "";
        this.rowIdDoItemDaOrdem = "";
        this.rowIdDoItemDaOrdemRoot = "";
        this.rowIdDoItemDaOrdemPai = "";
    }

    public TypeStep1 getTipo() {
        return tipo;
    }

    public void setTipo(TypeStep1 tipo) {
        this.tipo = tipo;
    }

    public String getTipoItem() {
        return tipoItem;
    }

    public void setTipoItem(String tipoItem) {
        this.tipoItem = tipoItem;
    }

    public String getNomeProduto() {
        return nomeProduto;
    }

    public void setNomeProduto(String nomeProduto) {
        this.nomeProduto = nomeProduto;
    }

    public String getMotivoStatus() {
        return motivoStatus;
    }

    public void setMotivoStatus(String motivoStatus) {
        this.motivoStatus = motivoStatus;
    }

    public String getTipoMotivo() {
        return tipoMotivo;
    }

    public void setTipoMotivo(String tipoMotivo) {
        this.tipoMotivo = tipoMotivo;
    }

    public String getNroOrdem() {
        return nroOrdem;
    }

    public void setNroOrdem(String nroOrdem) {
        this.nroOrdem = nroOrdem;
    }

    public String getAcessoRowId() {
        return acessoRowId;
    }

    public void setAcessoRowId(String acessoRowId) {
        this.acessoRowId = acessoRowId;
    }

    public String getCodigoProduto() {
        return codigoProduto;
    }

    public void setCodigoProduto(String codigoProduto) {
        this.codigoProduto = codigoProduto;
    }

    public String getDatRef() {
        return datRef;
    }

    public void setDatRef(String datRef) {
        this.datRef = datRef;
    }

    public String getCodContratoOltp() {
        return codContratoOltp;
    }

    public void setCodContratoOltp(String codContratoOltp) {
        this.codContratoOltp = codContratoOltp;
    }

    public String getCodContratoAtivacao() {
        return codContratoAtivacao;
    }

    public void setCodContratoAtivacao(String codContratoAtivacao) {
        this.codContratoAtivacao = codContratoAtivacao;
    }

    public String getNumeroAcesso() {
        return numeroAcesso;
    }

    public void setNumeroAcesso(String numeroAcesso) {
        this.numeroAcesso = numeroAcesso;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getTipoProduto() {
        return tipoProduto;
    }

    public void setTipoProduto(String tipoProduto) {
        this.tipoProduto = tipoProduto;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUf() {
        return uf;
    }

    public void setUf(String uf) {
        this.uf = uf;
    }

    public String getTipoLogradouro() {
        return tipoLogradouro;
    }

    public void setTipoLogradouro(String tipoLogradouro) {
        this.tipoLogradouro = tipoLogradouro;
    }

    public String getLogradouro() {
        return logradouro;
    }

    public void setLogradouro(String logradouro) {
        this.logradouro = logradouro;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getComplemento() {
        return complemento;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getTecnologia() {
        return tecnologia;
    }

    public void setTecnologia(String tecnologia) {
        this.tecnologia = tecnologia;
    }

    public String getFormaPagamento() {
        return formaPagamento;
    }

    public void setFormaPagamento(String formaPagamento) {
        this.formaPagamento = formaPagamento;
    }

    public String getTipoConta() {
        return tipoConta;
    }

    public void setTipoConta(String tipoConta) {
        this.tipoConta = tipoConta;
    }

    public String getCodBanco() {
        return codBanco;
    }

    public void setCodBanco(String codBanco) {
        this.codBanco = codBanco;
    }

    public String getCodAgenciaBanco() {
        return codAgenciaBanco;
    }

    public void setCodAgenciaBanco(String codAgenciaBanco) {
        this.codAgenciaBanco = codAgenciaBanco;
    }

    public String getCodContaCorrente() {
        return codContaCorrente;
    }

    public void setCodContaCorrente(String codContaCorrente) {
        this.codContaCorrente = codContaCorrente;
    }

    public String getCodDebitoAutomatico() {
        return codDebitoAutomatico;
    }

    public void setCodDebitoAutomatico(String codDebitoAutomatico) {
        this.codDebitoAutomatico = codDebitoAutomatico;
    }

    public String getDiaVencimento() {
        return diaVencimento;
    }

    public void setDiaVencimento(String diaVencimento) {
        this.diaVencimento = diaVencimento;
    }

    public String getCodContaFinanceira() {
        return codContaFinanceira;
    }

    public void setCodContaFinanceira(String codContaFinanceira) {
        this.codContaFinanceira = codContaFinanceira;
    }

    public String getNumProtocolo() {
        return numProtocolo;
    }

    public void setNumProtocolo(String numProtocolo) {
        this.numProtocolo = numProtocolo;
    }

    public String getFlgOrdemAutomatica() {
        return flgOrdemAutomatica;
    }

    public void setFlgOrdemAutomatica(String flgOrdemAutomatica) {
        this.flgOrdemAutomatica = flgOrdemAutomatica;
    }

    public String getDscTxRecorrente() {
        return dscTxRecorrente;
    }

    public void setDscTxRecorrente(String dscTxRecorrente) {
        this.dscTxRecorrente = dscTxRecorrente;
    }

    public String getDscTxNaoRecorrente() {
        return dscTxNaoRecorrente;
    }

    public void setDscTxNaoRecorrente(String dscTxNaoRecorrente) {
        this.dscTxNaoRecorrente = dscTxNaoRecorrente;
    }

    public String getDscStatusItem() {
        return dscStatusItem;
    }

    public void setDscStatusItem(String dscStatusItem) {
        this.dscStatusItem = dscStatusItem;
    }

    public String getNomPlanoAtual() {
        return nomPlanoAtual;
    }

    public void setNomPlanoAtual(String nomPlanoAtual) {
        this.nomPlanoAtual = nomPlanoAtual;
    }

    public String getValPlanoAtualItem() {
        return valPlanoAtualItem;
    }

    public void setValPlanoAtualItem(String valPlanoAtualItem) {
        this.valPlanoAtualItem = valPlanoAtualItem;
    }

    public String getNomDescontoAtualItem() {
        return nomDescontoAtualItem;
    }

    public void setNomDescontoAtualItem(String nomDescontoAtualItem) {
        this.nomDescontoAtualItem = nomDescontoAtualItem;
    }

    public String getValDescontoAtualItem() {
        return valDescontoAtualItem;
    }

    public void setValDescontoAtualItem(String valDescontoAtualItem) {
        this.valDescontoAtualItem = valDescontoAtualItem;
    }

    public String getFlgPortabilidade() {
        return flgPortabilidade;
    }

    public void setFlgPortabilidade(String flgPortabilidade) {
        this.flgPortabilidade = flgPortabilidade;
    }

    public String getDscOperadoraDoadora() {
        return dscOperadoraDoadora;
    }

    public void setDscOperadoraDoadora(String dscOperadoraDoadora) {
        this.dscOperadoraDoadora = dscOperadoraDoadora;
    }

    public String getCodDdd() {
        return codDdd;
    }

    public void setCodDdd(String codDdd) {
        this.codDdd = codDdd;
    }

    public String getNumTelefonePortado() {
        return numTelefonePortado;
    }

    public void setNumTelefonePortado(String numTelefonePortado) {
        this.numTelefonePortado = numTelefonePortado;
    }

    public String getDatJanelaPortabilidade() {
        return datJanelaPortabilidade;
    }

    public void setDatJanelaPortabilidade(String datJanelaPortabilidade) {
        this.datJanelaPortabilidade = datJanelaPortabilidade;
    }

    public String getHorJanela() {
        return horJanela;
    }

    public void setHorJanela(String horJanela) {
        this.horJanela = horJanela;
    }

    public String getDscEnderecoFatura() {
        return dscEnderecoFatura;
    }

    public void setDscEnderecoFatura(String dscEnderecoFatura) {
        this.dscEnderecoFatura = dscEnderecoFatura;
    }

    public String getDscAreaVoip() {
        return dscAreaVoip;
    }

    public void setDscAreaVoip(String dscAreaVoip) {
        this.dscAreaVoip = dscAreaVoip;
    }

    public String getCpe() {
        return cpe;
    }

    public void setCpe(String cpe) {
        this.cpe = cpe;
    }

    public String getOnt() {
        return ont;
    }

    public void setOnt(String ont) {
        this.ont = ont;
    }

    public String getItemRoot() {
        return itemRoot;
    }

    public void setItemRoot(String itemRoot) {
        this.itemRoot = itemRoot;
    }

    public String getDominioRoot() {
        return dominioRoot;
    }

    public void setDominioRoot(String dominioRoot) {
        this.dominioRoot = dominioRoot;
    }

    public String getCategoriaItemRoot() {
        return categoriaItemRoot;
    }

    public void setCategoriaItemRoot(String categoriaItemRoot) {
        this.categoriaItemRoot = categoriaItemRoot;
    }

    public String getRowIdItemRootRoot() {
        return rowIdItemRootRoot;
    }

    public void setRowIdItemRootRoot(String rowIdItemRootRoot) {
        this.rowIdItemRootRoot = rowIdItemRootRoot;
    }

    public String getTipoItemRoot() {
        return tipoItemRoot;
    }

    public void setTipoItemRoot(String tipoItemRoot) {
        this.tipoItemRoot = tipoItemRoot;
    }

    public String getAcaoItemRoot() {
        return acaoItemRoot;
    }

    public void setAcaoItemRoot(String acaoItemRoot) {
        this.acaoItemRoot = acaoItemRoot;
    }

    public String getAcessoRowIdRoot() {
        return acessoRowIdRoot;
    }

    public void setAcessoRowIdRoot(String acessoRowIdRoot) {
        this.acessoRowIdRoot = acessoRowIdRoot;
    }

    public String getStatusItemRoot() {
        return statusItemRoot;
    }

    public void setStatusItemRoot(String statusItemRoot) {
        this.statusItemRoot = statusItemRoot;
    }
}
