package br.com.tim.mapreduce.e2e.step7.pt3;


import br.com.tim.mapreduce.e2e.step7.pt2.E2EStep7PT2Value;

public class E2EStep7PT3OutValue {

    private String datRef;
    private String codContratoOltp;
    private String codContratoAtivacao;
    private String numeroAcesso;
    private String customerId;
    private String tipoProduto;
    private String planoAtivacaoOferta;
    private String motivoChurn;
    private String tipoChurn;
    private String email;
    private String uf;
    private String tipoLogradouro;
    private String logradouro;
    private String numero;
    private String complemento;
    private String bairro;
    private String cep;
    private String cidade;
    private String tecnologia;
    private String formaPagamento;
    private String tipoConta;
    private String codBanco;
    private String codAgenciaBanco;
    private String codContaCorrente;
    private String codDebitoAutomatico;
    private String diaVencimento;
    private String codContaFinanceira;
    private String numProtocolo;
    private String flgOrdemAutomatica;
    private String dscTxRecorrente;
    private String dscTxNaoRecorrente;
    private String dscStatusItem;
    private String nomPlanoAtual;
    private String valPlanoAtualItem;
    private String nomDescontoAtualItem;
    private String valDescontoAtualItem;
    private String flgPortabilidade;
    private String dscOperadoraDoadora;
    private String codDdd;
    private String numTelefonePortado;
    private String datJanelaPortabilidade;
    private String horJanela;
    private String dscEnderecoFatura;
    private String dscAreaVoip;
    private String cpe;
    private String ont;
    private String itemRoot;
    private String dominioRoot;
    private String nroOrdem;
    private String acessoRowId;
    private String acessoRowIdRoot;
    private String codigoProduto;
    private String datCriacaoOrdem;
    private String horCriacaoOrdem;
    private String datVenda;
    private String horaVenda;
    private String datVendaOrig;
    private String horVendaOrig;
    private String datStatusOrdem;
    private String horStatusOrdem;
    private String numOrdemSiebel;
    private String numOrdemSiebelOrig;
    private String tipoDocumento;
    private String documento;
    private String tipoVenda;
    private String loginVendedor;
    private String loginVendedorOrig;
    private String canal;
    private String canalOrig;
    private String cnpjParceiro;
    private String cnpjParceiroOrig;
    private String custCode;
    private String custCodeOrig;
    private String position;
    private String positionOrig;
    private String flgCancAntesVenda;
    private String flgVendaSubmetida;
    private String flgVendaDuplicada;
    private String flgVendaBruta;
    private String flgVendaLiquida;
    private String flgCancPosVenda;
    private String flgCancDupl;
    private String flgCancLiquido;
    private String datCancVenda;
    private String motivoCancelamento;
    private String nomeCliente;
    private String telefone;
    private String statusOrdem;
    private String semanaVenda;
    private String semanaVendaOrig;
    private String score;
    private String scoreConsumido;
    private String datFinalizacaoOrdem;
    private String qtdContratos;
    private String nomLoginResponsavel;
    private String detalheRecusaCrivo;
    private String loginCancelamentoOrdem;
    private String nomeParceiroVenda;
    private String nomeParceiroVendaOrig;
    private String velocidadeDownload;
    private String velocidadeUpload;
    private String custcodeCliente;
    private String msanOltTrafego;
    private String codContratoAtual;
    private String codConvergente;
    private String nomeVendedor;
    private String nomeVendedorOrig;

    private String nomeUsuarioCancelouOrdem;

    public void clear(){
        this.datRef = null;
        this.codContratoOltp = null;
        this.codContratoAtivacao = null;
        this.numeroAcesso = null;
        this.customerId = null;
        this.tipoProduto = null;
        this.planoAtivacaoOferta = null;
        this.motivoChurn = null;
        this.tipoChurn = null;
        this.email = null;
        this.uf = null;
        this.tipoLogradouro = null;
        this.logradouro = null;
        this.numero = null;
        this.complemento = null;
        this.bairro = null;
        this.cep = null;
        this.cidade = null;
        this.tecnologia = null;
        this.formaPagamento = null;
        this.tipoConta = null;
        this.codBanco = null;
        this.codAgenciaBanco = null;
        this.codContaCorrente = null;
        this.codDebitoAutomatico = null;
        this.diaVencimento = null;
        this.codContaFinanceira = null;
        this.numProtocolo = null;
        this.flgOrdemAutomatica = null;
        this.dscTxRecorrente = null;
        this.dscTxNaoRecorrente = null;
        this.dscStatusItem = null;
        this.nomPlanoAtual = null;
        this.valPlanoAtualItem = null;
        this.nomDescontoAtualItem = null;
        this.valDescontoAtualItem = null;
        this.flgPortabilidade = null;
        this.dscOperadoraDoadora = null;
        this.codDdd = null;
        this.numTelefonePortado = null;
        this.datJanelaPortabilidade = null;
        this.horJanela = null;
        this.dscEnderecoFatura = null;
        this.dscAreaVoip = null;
        this.cpe = null;
        this.ont = null;
        this.itemRoot = null;
        this.dominioRoot = null;
        this.nroOrdem = null;
        this.acessoRowId = null;
        this.acessoRowIdRoot = null;
        this.codigoProduto = null;
        this.datCriacaoOrdem = null;
        this.horCriacaoOrdem = null;
        this.datVenda = null;
        this.horaVenda = null;
        this.datVendaOrig = null;
        this.horVendaOrig = null;
        this.datStatusOrdem = null;
        this.horStatusOrdem = null;
        this.numOrdemSiebel = null;
        this.numOrdemSiebelOrig = null;
        this.tipoDocumento = null;
        this.documento = null;
        this.tipoVenda = null;
        this.loginVendedor = null;
        this.loginVendedorOrig = null;
        this.canal = null;
        this.canalOrig = null;
        this.cnpjParceiro = null;
        this.cnpjParceiroOrig = null;
        this.custCode = null;
        this.custCodeOrig = null;
        this.position = null;
        this.positionOrig = null;
        this.flgCancAntesVenda = null;
        this.flgVendaSubmetida = null;
        this.flgVendaDuplicada = null;
        this.flgVendaBruta = null;
        this.flgVendaLiquida = null;
        this.flgCancPosVenda = null;
        this.flgCancDupl = null;
        this.flgCancLiquido = null;
        this.datCancVenda = null;
        this.motivoCancelamento = null;
        this.nomeCliente = null;
        this.telefone = null;
        this.statusOrdem = null;
        this.semanaVenda = null;
        this.semanaVendaOrig = null;
        this.score = null;
        this.scoreConsumido = null;
        this.datFinalizacaoOrdem = null;
        this.qtdContratos = null;
        this.nomLoginResponsavel = null;
        this.detalheRecusaCrivo = null;
        this.loginCancelamentoOrdem = null;
        this.nomeParceiroVenda = null;
        this.nomeParceiroVendaOrig = null;
        this.velocidadeDownload = null;
        this.velocidadeUpload = null;
        this.custcodeCliente = null;
        this.msanOltTrafego = null;
        this.codContratoAtual = null;
        this.codConvergente = null;
        this.nomeVendedor = null;
        this.nomeVendedorOrig = null;
        this.nomeUsuarioCancelouOrdem = null;
    }

    public void clearRelt(){
        this.datRef = null;
        this.codContratoOltp = null;
        this.codContratoAtivacao = null;
        this.numeroAcesso = null;
        this.customerId = null;
        this.tipoProduto = null;
        this.planoAtivacaoOferta = null;
        this.motivoChurn = null;
        this.tipoChurn = null;
        this.email = null;
        this.uf = null;
        this.tipoLogradouro = null;
        this.logradouro = null;
        this.numero = null;
        this.complemento = null;
        this.bairro = null;
        this.cep = null;
        this.cidade = null;
        this.tecnologia = null;
        this.formaPagamento = null;
        this.tipoConta = null;
        this.codBanco = null;
        this.codAgenciaBanco = null;
        this.codContaCorrente = null;
        this.codDebitoAutomatico = null;
        this.diaVencimento = null;
        this.codContaFinanceira = null;
        this.numProtocolo = null;
        this.flgOrdemAutomatica = null;
        this.dscTxRecorrente = null;
        this.dscTxNaoRecorrente = null;
        this.dscStatusItem = null;
        this.nomPlanoAtual = null;
        this.valPlanoAtualItem = null;
        this.nomDescontoAtualItem = null;
        this.valDescontoAtualItem = null;
        this.flgPortabilidade = null;
        this.dscOperadoraDoadora = null;
        this.codDdd = null;
        this.numTelefonePortado = null;
        this.datJanelaPortabilidade = null;
        this.horJanela = null;
        this.dscEnderecoFatura = null;
        this.dscAreaVoip = null;
        this.cpe = null;
        this.ont = null;
        this.itemRoot = null;
        this.dominioRoot = null;
        this.nroOrdem = null;
        this.acessoRowId = null;
        this.acessoRowIdRoot = null;
        this.codigoProduto = null;
        this.datCriacaoOrdem = null;
        this.horCriacaoOrdem = null;
        this.datVenda = null;
        this.horaVenda = null;
        this.datVendaOrig = null;
        this.horVendaOrig = null;
        this.datStatusOrdem = null;
        this.horStatusOrdem = null;
        this.numOrdemSiebel = null;
        this.numOrdemSiebelOrig = null;
        this.tipoDocumento = null;
        this.documento = null;
        this.tipoVenda = null;
        this.loginVendedor = null;
        this.loginVendedorOrig = null;
        this.canal = null;
        this.canalOrig = null;
        this.cnpjParceiro = null;
        this.cnpjParceiroOrig = null;
        this.custCode = null;
        this.custCodeOrig = null;
        this.position = null;
        this.positionOrig = null;
        this.flgCancAntesVenda = null;
        this.flgVendaSubmetida = null;
        this.flgVendaDuplicada = null;
        this.flgVendaBruta = null;
        this.flgVendaLiquida = null;
        this.flgCancPosVenda = null;
        this.flgCancDupl = null;
        this.flgCancLiquido = null;
        this.datCancVenda = null;
        this.motivoCancelamento = null;
        this.nomeCliente = null;
        this.telefone = null;
        this.statusOrdem = null;
        this.semanaVenda = null;
        this.semanaVendaOrig = null;
        this.score = null;
        this.scoreConsumido = null;
        this.datFinalizacaoOrdem = null;
        this.qtdContratos = null;
        this.nomLoginResponsavel = null;
        this.detalheRecusaCrivo = null;
        this.loginCancelamentoOrdem = null;
        this.nomeParceiroVenda = null;
        this.nomeParceiroVendaOrig = null;
        this.velocidadeDownload = null;
        this.velocidadeUpload = null;
        this.custcodeCliente = null;
        this.msanOltTrafego = null;
        this.codContratoAtual = null;
        this.codConvergente = null;
        this.nomeVendedor = null;
        this.nomeVendedorOrig = null;
    }

    public void setRelt(E2EStep7PT3Value relt) {
        this.datRef = relt.getDatRef();
        this.codContratoOltp = relt.getCodContratoOltp();
        this.codContratoAtivacao = relt.getCodContratoAtivacao();
        this.numeroAcesso = relt.getNumeroAcesso();
        this.customerId = relt.getCustomerId();
        this.tipoProduto = relt.getTipoProduto();
        this.planoAtivacaoOferta = relt.getPlanoAtivacaoOferta();
        this.motivoChurn = relt.getMotivoChurn();
        this.tipoChurn = relt.getTipoChurn();
        this.email = relt.getEmail();
        this.uf = relt.getUf();
        this.tipoLogradouro = relt.getTipoLogradouro();
        this.logradouro = relt.getLogradouro();
        this.numero = relt.getNumero();
        this.complemento = relt.getComplemento();
        this.bairro = relt.getBairro();
        this.cep = relt.getCep();
        this.cidade = relt.getCidade();
        this.tecnologia = relt.getTecnologia();
        this.formaPagamento = relt.getFormaPagamento();
        this.tipoConta = relt.getTipoConta();
        this.codBanco = relt.getCodBanco();
        this.codAgenciaBanco = relt.getCodAgenciaBanco();
        this.codContaCorrente = relt.getCodContaCorrente();
        this.codDebitoAutomatico = relt.getCodDebitoAutomatico();
        this.diaVencimento = relt.getDiaVencimento();
        this.codContaFinanceira = relt.getCodContaFinanceira();
        this.numProtocolo = relt.getNumProtocolo();
        this.flgOrdemAutomatica = relt.getFlgOrdemAutomatica();
        this.dscTxRecorrente = relt.getDscTxRecorrente();
        this.dscTxNaoRecorrente = relt.getDscTxNaoRecorrente();
        this.dscStatusItem = relt.getDscStatusItem();
        this.nomPlanoAtual = relt.getNomPlanoAtual();
        this.valPlanoAtualItem = relt.getValPlanoAtualItem();
        this.nomDescontoAtualItem = relt.getNomDescontoAtualItem();
        this.valDescontoAtualItem = relt.getValDescontoAtualItem();
        this.flgPortabilidade = relt.getFlgPortabilidade();
        this.dscOperadoraDoadora = relt.getDscOperadoraDoadora();
        this.codDdd = relt.getCodDdd();
        this.numTelefonePortado = relt.getNumTelefonePortado();
        this.datJanelaPortabilidade = relt.getDatJanelaPortabilidade();
        this.horJanela = relt.getHorJanela();
        this.dscEnderecoFatura = relt.getDscEnderecoFatura();
        this.dscAreaVoip = relt.getDscAreaVoip();
        this.cpe = relt.getCpe();
        this.ont = relt.getOnt();
        this.itemRoot = relt.getItemRoot();
        this.dominioRoot = relt.getDominioRoot();
        this.nroOrdem = relt.getNroOrdem();
        this.acessoRowId = relt.getAcessoRowId();
        this.acessoRowIdRoot = relt.getAcessoRowIdRoot();
        this.codigoProduto = relt.getCodigoProduto();
        this.datCriacaoOrdem = relt.getDatCriacaoOrdem();
        this.horCriacaoOrdem = relt.getHorCriacaoOrdem();
        this.datVenda = relt.getDatVenda();
        this.horaVenda = relt.getHoraVenda();
        this.datVendaOrig = relt.getDatVendaOrig();
        this.horVendaOrig = relt.getHorVendaOrig();
        this.datStatusOrdem = relt.getDatStatusOrdem();
        this.horStatusOrdem = relt.getHorStatusOrdem();
        this.numOrdemSiebel = relt.getNumOrdemSiebel();
        this.numOrdemSiebelOrig = relt.getNumOrdemSiebelOrig();
        this.tipoDocumento = relt.getTipoDocumento();
        this.documento = relt.getDocumento();
        this.tipoVenda = relt.getTipoVenda();
        this.loginVendedor = relt.getLoginVendedor();
        this.loginVendedorOrig = relt.getLoginVendedorOrig();
        this.canal = relt.getCanal();
        this.canalOrig = relt.getCanalOrig();
        this.cnpjParceiro = relt.getCnpjParceiro();
        this.cnpjParceiroOrig = relt.getCnpjParceiroOrig();
        this.custCode = relt.getCustCode();
        this.custCodeOrig = relt.getCustCodeOrig();
        this.position = relt.getPosition();
        this.positionOrig = relt.getPositionOrig();
        this.flgCancAntesVenda = relt.getFlgCancAntesVenda();
        this.flgVendaSubmetida = relt.getFlgVendaSubmetida();
        this.flgVendaDuplicada = relt.getFlgVendaDuplicada();
        this.flgVendaBruta = relt.getFlgVendaBruta();
        this.flgVendaLiquida = relt.getFlgVendaLiquida();
        this.flgCancPosVenda = relt.getFlgCancPosVenda();
        this.flgCancDupl = relt.getFlgCancDupl();
        this.flgCancLiquido = relt.getFlgCancLiquido();
        this.datCancVenda = relt.getDatCancVenda();
        this.motivoCancelamento = relt.getMotivoCancelamento();
        this.nomeCliente = relt.getNomeCliente();
        this.telefone = relt.getTelefone();
        this.statusOrdem = relt.getStatusOrdem();
        this.semanaVenda = relt.getSemanaVenda();
        this.semanaVendaOrig = relt.getSemanaVendaOrig();
        this.score = relt.getScore();
        this.scoreConsumido = relt.getScoreConsumido();
        this.datFinalizacaoOrdem = relt.getDatFinalizacaoOrdem();
        this.qtdContratos = relt.getQtdContratos();
        this.nomLoginResponsavel = relt.getNomLoginResponsavel();
        this.detalheRecusaCrivo = relt.getDetalheRecusaCrivo();
        this.loginCancelamentoOrdem = relt.getLoginCancelamentoOrdem();
        this.nomeParceiroVenda = relt.getNomeParceiroVenda();
        this.nomeParceiroVendaOrig = relt.getNomeParceiroVendaOrig();
        this.velocidadeDownload = relt.getVelocidadeDownload();
        this.velocidadeUpload = relt.getVelocidadeUpload();
        this.custcodeCliente = relt.getCustcodeCliente();
        this.msanOltTrafego = relt.getMsanOltTrafego();
        this.codContratoAtual = relt.getCodContratoAtual();
        this.codConvergente = relt.getCodConvergente();
        this.nomeVendedor = relt.getNomeVendedor();
        this.nomeVendedorOrig = relt.getNomeVendedorOrig();
    }

    public void setBat510(E2EStep7PT3Value bat) {
        this.nomeUsuarioCancelouOrdem = bat.getNomeUsuarioCancelouOrdem();
    }

    @Override
    public String toString() {
        return new StringBuilder()
                .append(datRef).append("|")
                .append(codContratoOltp).append("|")
                .append(codContratoAtivacao).append("|")
                .append(numeroAcesso).append("|")
                .append(customerId).append("|")
                .append(tipoProduto).append("|")
                .append(planoAtivacaoOferta).append("|")
                .append(motivoChurn).append("|")
                .append(tipoChurn).append("|")
                .append(email).append("|")
                .append(uf).append("|")
                .append(tipoLogradouro).append("|")
                .append(logradouro).append("|")
                .append(numero).append("|")
                .append(complemento).append("|")
                .append(bairro).append("|")
                .append(cep).append("|")
                .append(cidade).append("|")
                .append(tecnologia).append("|")
                .append(formaPagamento).append("|")
                .append(tipoConta).append("|")
                .append(codBanco).append("|")
                .append(codAgenciaBanco).append("|")
                .append(codContaCorrente).append("|")
                .append(codDebitoAutomatico).append("|")
                .append(diaVencimento).append("|")
                .append(codContaFinanceira).append("|")
                .append(numProtocolo).append("|")
                .append(flgOrdemAutomatica).append("|")
                .append(dscTxRecorrente).append("|")
                .append(dscTxNaoRecorrente).append("|")
                .append(dscStatusItem).append("|")
                .append(nomPlanoAtual).append("|")
                .append(valPlanoAtualItem).append("|")
                .append(nomDescontoAtualItem).append("|")
                .append(valDescontoAtualItem).append("|")
                .append(flgPortabilidade).append("|")
                .append(dscOperadoraDoadora).append("|")
                .append(codDdd).append("|")
                .append(numTelefonePortado).append("|")
                .append(datJanelaPortabilidade).append("|")
                .append(horJanela).append("|")
                .append(dscEnderecoFatura).append("|")
                .append(dscAreaVoip).append("|")
                .append(cpe).append("|")
                .append(ont).append("|")
                .append(itemRoot).append("|")
                .append(dominioRoot).append("|")
                .append(nroOrdem).append("|")
                .append(acessoRowId).append("|")
                .append(acessoRowIdRoot).append("|")
                .append(codigoProduto).append("|")
                .append(datCriacaoOrdem).append("|")
                .append(horCriacaoOrdem).append("|")
                .append(datVenda).append("|")
                .append(horaVenda).append("|")
                .append(datVendaOrig).append("|")
                .append(horVendaOrig).append("|")
                .append(datStatusOrdem).append("|")
                .append(horStatusOrdem).append("|")
                .append(numOrdemSiebel).append("|")
                .append(numOrdemSiebelOrig).append("|")
                .append(tipoDocumento).append("|")
                .append(documento).append("|")
                .append(tipoVenda).append("|")
                .append(loginVendedor).append("|")
                .append(loginVendedorOrig).append("|")
                .append(canal).append("|")
                .append(canalOrig).append("|")
                .append(cnpjParceiro).append("|")
                .append(cnpjParceiroOrig).append("|")
                .append(custCode).append("|")
                .append(custCodeOrig).append("|")
                .append(position).append("|")
                .append(positionOrig).append("|")
                .append(flgCancAntesVenda).append("|")
                .append(flgVendaSubmetida).append("|")
                .append(flgVendaDuplicada).append("|")
                .append(flgVendaBruta).append("|")
                .append(flgVendaLiquida).append("|")
                .append(flgCancPosVenda).append("|")
                .append(flgCancDupl).append("|")
                .append(flgCancLiquido).append("|")
                .append(datCancVenda).append("|")
                .append(motivoCancelamento).append("|")
                .append(nomeCliente).append("|")
                .append(telefone).append("|")
                .append(statusOrdem).append("|")
                .append(semanaVenda).append("|")
                .append(semanaVendaOrig).append("|")
                .append(score).append("|")
                .append(scoreConsumido).append("|")
                .append(datFinalizacaoOrdem).append("|")
                .append(qtdContratos).append("|")
                .append(nomLoginResponsavel).append("|")
                .append(detalheRecusaCrivo).append("|")
                .append(loginCancelamentoOrdem).append("|")
                .append(nomeParceiroVenda).append("|")
                .append(nomeParceiroVendaOrig).append("|")
                .append(velocidadeDownload).append("|")
                .append(velocidadeUpload).append("|")
                .append(custcodeCliente).append("|")
                .append(msanOltTrafego).append("|")
                .append(codContratoAtual).append("|")
                .append(codConvergente).append("|")
                .append(nomeVendedor).append("|")
                .append(nomeVendedorOrig).append("|")
                .append(nomeUsuarioCancelouOrdem).toString();
    }
}
