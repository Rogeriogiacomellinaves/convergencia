
package br.com.tim.mapreduce.itemordem.step3;

import br.com.tim.mapreduce.itemordem.step3.model.Step2Result;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

import java.io.IOException;

public class MapperStep2Result extends org.apache.hadoop.mapreduce.Mapper<Writable,Text,IOStep3Key,IOStep3Value> {

	private IOStep3Key outkey;
	private IOStep3Value outValue;
	private Step2Result input;
	@Override
	protected void map(Writable key, Text value, Context context) throws IOException, InterruptedException {
		input.parse(value.toString());
		outkey.setKey(input);
		outValue.setStep2Result(input);
		context.write(outkey,outValue);

	}

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		super.setup(context);
		this.outkey = new IOStep3Key();
		this.outValue = new IOStep3Value();
		this.input = new Step2Result();
	}

	@Override
	protected void cleanup(Context context) throws IOException, InterruptedException {
		super.cleanup(context);
		this.clear();
	}

	private void clear(){
	   this.outValue.clear();
	}

}