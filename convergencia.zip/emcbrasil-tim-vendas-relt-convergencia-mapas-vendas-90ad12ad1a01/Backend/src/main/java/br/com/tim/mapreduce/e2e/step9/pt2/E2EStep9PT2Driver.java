package br.com.tim.mapreduce.e2e.step9.pt2;

import java.io.IOException;
import java.util.Arrays;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.InputFormat;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.CombineSequenceFileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import br.com.tim.driverutils.DriverUtility;
import br.com.tim.driverutils.DriverUtils;
import br.com.tim.driverutils.Entry;
import br.com.tim.driverutils.Partition;
import br.com.tim.exception.CommonsException;
import br.com.tim.mapreduce.e2e.step9.E2EStep9Key;
import br.com.tim.mapreduce.e2e.step9.GroupingComparator;
import br.com.tim.mapreduce.utils.Utils;
import br.com.tim.utils.CommonsConstants;

public class E2EStep9PT2Driver extends Configured implements Tool {

	private static Logger log = Logger.getLogger(E2EStep9PT2Driver.class);
	private int retorno = CommonsConstants.ERROR;

	public Entry[] entrys;

	private Job job;
	private FileSystem fs;
	private Configuration conf;
	private Path workingPath, outputPath;
	private DateTimeFormatter dtf = DateTimeFormat.forPattern("yyyyMMddhhmmss");


	@Override
	public int run(String[] args) throws Exception {
		try {
			setConfigurations(args);

			log.info("Running Pre Execution Steps.");
			preExecutionSteps();

			String jobName = fs.getConf().get("process-id");
			
			log.info("====================== JOB " + jobName + " ==============================");

			if (job.waitForCompletion(true)) {
				log.info("================== JOB " + jobName + " FINISHED SUCCESSFULY ====================");

				log.info("======================== Running post processing steps... =================================");
				postExecutionJob();

				retorno = CommonsConstants.SUCCESS;
			} else {
				log.info("============================= Executando o ROLLBACK... ====================================");
				rollback();
			}
		} catch (Exception e) {
			log.error("Erro genérico ao executar o Driver... ", e);
			log.info("============================= Executando o ROLLBACK... ====================================");
			rollback();
			throw new CommonsException(e.getMessage(), e);
		}

		return retorno;
	}

	public static void main(String[] args) throws Exception {
		log.info("=================== BEGIN PROCESS =========================");

		E2EStep9PT2Driver driver = new E2EStep9PT2Driver();
		int exitCode = ToolRunner.run(driver, args);
		log.info("Exit code: " + exitCode);
		log.info("=================== END PROCESS ==========================");
		System.exit(exitCode);
	}

	private void setConfigurations(String args[]) throws IOException {


		PropertyConfigurator.configure(System.getProperty(CommonsConstants.LOG4J_CONFIGURATION));

		conf = new Configuration();
		conf.addResource(new Path(System.getProperty(CommonsConstants.ENVIRONMENT_CONFIGURATION)));
		conf.addResource(new Path(System.getProperty(CommonsConstants.PROJECT_CONFIGURATION)));

		fs = FileSystem.newInstance(conf);

		job = Job.getInstance(conf);
		job.setJarByClass(E2EStep9PT2Driver.class);
		job.setMapOutputKeyClass(E2EStep9Key.class);
		job.setMapOutputValueClass(E2EStep9PT2Value.class);
		job.setReducerClass(E2EStep9PT2Reducer.class);
		job.setOutputKeyClass(NullWritable.class);
		job.setOutputValueClass(Text.class);
		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);
		job.setPartitionerClass(JoinPartitioner.class);
		job.setGroupingComparatorClass(GroupingComparator.class);

		workingPath = new Path(this.fs.getConf().get("working-path"));

		outputPath = new Path(this.fs.getConf().get("output-path"));
		Utils.reprocessDay(args, job);

		log.info("Data em execução: " + job.getConfiguration().get("dat-ref"));

		entrys = getEntry(CombineSequenceFileInputFormat.class);

		TextOutputFormat.setOutputPath(job,workingPath);
		try{
			DriverUtils.addInputPaths(args, conf, this.job, 1, entrys);
		} catch (Exception e){}

	}

	protected Entry[] getEntry(Class<? extends InputFormat> inputFormat) {

		int defaultMinusDays = Integer.valueOf(this.fs.getConf().get("lookback-days", "1"));

        Entry bat226 = new Entry("bat226", "input-path-bat226", true, false, false, true, inputFormat, MapperBat226.class,
                new Partition("dat_from_filename_part", Partition.Format.DATE_DAY, CommonsConstants.YYYYMMDD, defaultMinusDays, -1, true));

		Entry result = new Entry("step9-pt1", "input-path-step9-pt1", true, true, TextInputFormat.class, MapperStep9PT1Result.class);


		return Arrays.asList(result, bat226).toArray(new Entry[] {});

	}

	protected void postExecutionJob() throws Exception {
		log.info("Movendo " + workingPath + " para " + outputPath);
		DriverUtility.move(fs, outputPath, workingPath, "*");
	}

	protected void rollback() {

	}

	protected void preExecutionSteps() throws Exception {

		if (fs.exists(workingPath)){
			log.info("Removendo " + workingPath);
			fs.delete(workingPath,true);
		}
		
		if (fs.exists(outputPath)){
			log.info("Removendo " + outputPath);
			fs.delete(outputPath,true);
		}

	}

}
