package br.com.tim.mapreduce.refactoring.endtoend.step1.pt3;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

public class GroupingComparator extends WritableComparator {

    public GroupingComparator() {
        super(E2EStep1pt3Key.class, true);
    }

    @SuppressWarnings({"rawtypes"})
    @Override
    public int compare(WritableComparable a, WritableComparable b) {
        E2EStep1pt3Key keyA = (E2EStep1pt3Key) a;
        E2EStep1pt3Key keyB = (E2EStep1pt3Key) b;

        return keyA.compareToGrouping(keyB);
    }

}
