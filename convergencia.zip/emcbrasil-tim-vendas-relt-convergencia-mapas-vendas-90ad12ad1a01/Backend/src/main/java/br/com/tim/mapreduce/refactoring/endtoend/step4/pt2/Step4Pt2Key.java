package br.com.tim.mapreduce.refactoring.endtoend.step4.pt2;

import com.google.common.collect.ComparisonChain;
import br.com.tim.mapreduce.refactoring.endtoend.GroupComparable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Objects;


public class Step4Pt2Key implements GroupComparable<Step4Pt2Key>{
	
	private String nroOrdem;
	private String datRef;
	private TypeStep4Pt2 tipo;
	
	@Override
	public void write(DataOutput output) throws IOException {
		output.writeInt(tipo.ordinal());
		output.writeUTF(this.nroOrdem);
		output.writeUTF(this.datRef);
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		this.tipo = TypeStep4Pt2.values()[in.readInt()];
		this.nroOrdem = in.readUTF();
		this.datRef = in.readUTF();
	}

	public String getNroOrdem() {
		return nroOrdem;
	}

	public void setNroOrdem(String nroOrdem) {
		this.nroOrdem = nroOrdem;
	}

	public void setDatRef(String datRef){this.datRef = datRef;}

	public void setTipo(TypeStep4Pt2 tipo) {
		this.tipo = tipo;
	}

	@Override
	public int compareTo(Step4Pt2Key o) {
		return ComparisonChain.start().compare(this.nroOrdem, o.nroOrdem).compare(this.tipo, o.tipo).compare(this.datRef, o.datRef)
				.result();
	}

	@Override
	public int compareToGrouping(Step4Pt2Key o) {
		return ComparisonChain.start().compare(this.nroOrdem, o.nroOrdem).result();
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		Step4Pt2Key key = (Step4Pt2Key) o;
		return Objects.equals(nroOrdem, key.nroOrdem);
	}

	public int hashCodeJoin() {

		return Objects.hash(nroOrdem);
	}

	@Override
	public int hashCode() {

		return Objects.hash(nroOrdem);
	}
}
