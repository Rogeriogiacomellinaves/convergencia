package br.com.tim.mapreduce.refactoring.endtoend.step4.pt4;

public enum TypeStep4Pt4 {

    Fiber, RELT
}
