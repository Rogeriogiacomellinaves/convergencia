package br.com.tim.mapreduce.refactoring.endtoend.step1.pt3;

public enum TypeStep1pt3 {
	
	WFMTOA, RELT
	
}
