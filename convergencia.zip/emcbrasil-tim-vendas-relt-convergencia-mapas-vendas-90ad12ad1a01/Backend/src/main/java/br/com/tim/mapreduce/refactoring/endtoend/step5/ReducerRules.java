package br.com.tim.mapreduce.refactoring.endtoend.step5;

import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.joda.time.LocalDate;

import br.com.tim.mapreduce.refactoring.endtoend.step5.pt1.Step5OutputValue;


public class ReducerRules {
	
	
	private static final String CONCLUIDA = "Concluída";
	private static final String PENDENTE_PORTABILIDADE = "Pendente de Portabilidade";
	private static final String APROCISIONAMENTO = "Em Aprovisionamento";
	
	
	public static boolean possuiStatus(List<Map.Entry<LocalDate, Step5OutputValue>> list) {
		
		
		for (Map.Entry<LocalDate, Step5OutputValue> v : list) {
			
			if(v.getValue().isOrdemAtual()) {
				
				
			}
			
			
		}
		
		if (list.get(0).getValue().getStatusOrdem().equals(CONCLUIDA) ||
				list.get(0).getValue().getStatusOrdem().equals(PENDENTE_PORTABILIDADE) ||
				list.get(0).getValue().getStatusOrdem().equals(APROCISIONAMENTO)) {
			return true;	
		}else {
			
			if (list.size()>1) {
				for (Map.Entry<LocalDate, Step5OutputValue> v : list) {
				
					if (v.getValue().getStatusOrdem().equals(CONCLUIDA) ||
							v.getValue().getStatusOrdem().equals(PENDENTE_PORTABILIDADE) ||
							v.getValue().getStatusOrdem().equals(APROCISIONAMENTO)) {
						return true;
					
					}else {
					
						return false;
					
					}
				}
			}
			
		}
		return false;
		
	}
	
	
	public static boolean isCancPosVenda(List<Map.Entry<LocalDate, Step5OutputValue>> list) {
		
		
		if (list.get(0).getValue().getFlgCancPosVenda().equals("1")) {
			
			if (list.size()>0) {
				
				for (Map.Entry<LocalDate, Step5OutputValue> v : list) {
					
					if (v.getValue().getFlgCancPosVenda().equals("0")) {
						return false;
					}
					
					return true;
				
				}
			}
			
		}
		return false;
		
	}
	
	
	
	public static boolean isFlgCancLiq(Step5OutputValue firstValue) {
		
		if (firstValue.getFlgCancPosVenda().equals("1") ||
				firstValue.getFlgCancDupl().equals("0")) {
			return true;
		}else {
			return false;
		}
		
	}
	
	
	//fazer no reducer uma verificação se o campo da flag bruta é 0 ou 1, essa regra é a primeira
	
	public boolean hasFlgCancLiq(List<Map.Entry<LocalDate, Step5OutputValue>> list) {
		
		
		for(Map.Entry<LocalDate, Step5OutputValue> v : list) {
			
			if (v.getValue().getFlgCancLiquido().equals("1")) {
				return true;
			}
			
		}

		return false;
	
	}
	
	
    public static List<Map.Entry<LocalDate, Double>> sortMapByKey(Map<LocalDate, Double> map){
        List<Map.Entry<LocalDate, Double>> list = new LinkedList<Map.Entry<LocalDate, Double>>(map.entrySet());

        Collections.sort(list, new Comparator<Map.Entry<LocalDate, Double>>() {
            public int compare(Map.Entry<LocalDate, Double> o1, Map.Entry<LocalDate, Double> o2) {
                return (o2.getKey()).compareTo(o1.getKey());
            }
        });

        return list;
    }
	
    
    
    public static List<Map.Entry<LocalDate, Step5OutputValue>> sortMapByKeyStep3(Map<LocalDate, Step5OutputValue> map){
        List<Map.Entry<LocalDate, Step5OutputValue>> list = new LinkedList<Map.Entry<LocalDate, Step5OutputValue>>(map.entrySet());

        Collections.sort(list, new Comparator<Map.Entry<LocalDate, Step5OutputValue>>() {
            public int compare(Map.Entry<LocalDate, Step5OutputValue> o1, Map.Entry<LocalDate, Step5OutputValue> o2) {
                return (o2.getKey()).compareTo(o1.getKey());
            }
        });

        return list;
    }

    


}
