package br.com.tim.mapreduce.refactoring.endtoend.step4.pt4;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Objects;

import com.google.common.collect.ComparisonChain;

import br.com.tim.mapreduce.refactoring.endtoend.GroupComparable;

public class E2EStep4Pt4Key implements GroupComparable<E2EStep4Pt4Key> {

	private String numAcesso;
	private TypeStep4Pt4 tipo;

	@Override
	public void write(DataOutput output) throws IOException {
		output.writeInt(tipo.ordinal());
		output.writeUTF(this.numAcesso);
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		this.tipo = TypeStep4Pt4.values()[in.readInt()];
		this.numAcesso = in.readUTF();
	}

	public String getNumAcesso() {
		return numAcesso;
	}

	public void setTipo(TypeStep4Pt4 tipo) {
		this.tipo = tipo;
	}

	public void setNumAcesso(String numAcesso) {
		this.numAcesso = numAcesso;
	}

	@Override
	public int compareTo(E2EStep4Pt4Key o) {
		return ComparisonChain.start().compare(this.numAcesso, o.numAcesso).compare(this.tipo, o.tipo)
				.result();
	}

	@Override
	public int compareToGrouping(E2EStep4Pt4Key o) {
		return ComparisonChain.start().compare(this.numAcesso, o.numAcesso).result();
	}

	public int hashCodeJoin() {

		return Objects.hash(numAcesso);
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		E2EStep4Pt4Key key = (E2EStep4Pt4Key) o;
		return Objects.equals(numAcesso, key.numAcesso);
	}


	@Override
	public int hashCode() {

		return Objects.hash(numAcesso);
	}
}