
package br.com.tim.mapreduce.e2e.step2;

import br.com.tim.mapreduce.e2e.step2.model.Step1Result;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

import java.io.IOException;

public class MapperStep1Result extends org.apache.hadoop.mapreduce.Mapper<Writable,Text,E2EStep2Key,E2EStep2Value> {

	private E2EStep2Key outkey;
	private E2EStep2Value outValue;
	private Step1Result input;
	@Override
	protected void map(Writable key, Text value, Context context) throws IOException, InterruptedException {
		input.parse(value.toString());
		outkey.setNroOrdem(input.getNroOrdem());
		outkey.setDatRef(context.getConfiguration().get("dat-ref"));
		outkey.setTipo(TypeStep2.RELT);
		outValue.setStep1Result(input);
		context.write(outkey, outValue);
	}

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		super.setup(context);
		this.outkey = new E2EStep2Key();
		this.outValue = new E2EStep2Value();
		this.input = new Step1Result();
	}

	@Override
	protected void cleanup(Context context) throws IOException, InterruptedException {
		super.cleanup(context);
		this.clear();
	}

	private void clear(){
	   this.outValue.clear();
	}

}