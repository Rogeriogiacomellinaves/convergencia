package br.com.tim.mapreduce.refactoring.endtoend.step1.pt2;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.parquet.Strings;

import br.com.tim.mapreduce.refactoring.endtoend.step1.pt2.model.Step1Result;
import br.com.tim.mapreduce.refactoring.endtoend.utils.Step1Pt2Counters;

public class MapperStep1 extends Mapper<LongWritable, Text, Step1Pt2Key, Step1Pt2Value> {
	
	Step1Pt2Value outValue;
	private Step1Pt2Key outkey;
	private Step1Result input;
	
	
	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		
		this.outValue = new Step1Pt2Value();
		this.outkey = new Step1Pt2Key();
		this.input = new Step1Result();
		
	}
	
	
	@Override
	protected void map(LongWritable key, Text value, Mapper<LongWritable, Text, Step1Pt2Key,Step1Pt2Value>.Context context) throws IOException, InterruptedException {
		
		outValue.clear();
		
		input.parseFromText(value);
		
		if (!Strings.isNullOrEmpty(input.getNroOrdem())) {
			
			outkey.setNroOrdem(input.getNroOrdem());
			outkey.setDatRef(context.getConfiguration().get("dat_ref"));
			outkey.setTipo(TypeStep1Pt2.ITEM);
			
			outValue.setStep1Result(input);
			
			context.write(outkey, outValue);
			context.getCounter(Step1Pt2Counters.ITEM_MAPPER_WRITE).increment(1l);
			
		}else {
			context.getCounter(Step1Pt2Counters.ITEM_MAPPER_DISCART).increment(1l);

		}
	
	}



}
