package br.com.tim.mapreduce.refactoring.endtoend.step1.pt1;

public enum TypeStep1Pt1 {

   HIST, ROOT, PLANO_ATUAL,PLANO, DESCONTO, LIVE, MOVEL
   
}