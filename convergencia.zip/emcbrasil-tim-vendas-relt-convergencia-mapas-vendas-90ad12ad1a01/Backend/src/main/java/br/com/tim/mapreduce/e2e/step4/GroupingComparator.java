package br.com.tim.mapreduce.e2e.step4;

import br.com.tim.mapreduce.e2e.step3.E2EStep3Key;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

public class GroupingComparator extends WritableComparator {

    public GroupingComparator() {
        super(E2EStep4Key.class, true);
    }

    @SuppressWarnings({"rawtypes"})
    @Override
    public int compare(WritableComparable a, WritableComparable b) {
        E2EStep4Key keyA = (E2EStep4Key) a;
        E2EStep4Key keyB = (E2EStep4Key) b;

        return keyA.compareToGrouping(keyB);
    }

}
