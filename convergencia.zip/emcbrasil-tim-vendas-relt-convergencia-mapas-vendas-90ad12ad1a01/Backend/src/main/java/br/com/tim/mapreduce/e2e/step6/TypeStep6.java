package br.com.tim.mapreduce.e2e.step6;

public enum TypeStep6 {

    BAT223, RELT
}
