package br.com.tim.mapreduce.refactoring.endtoend.step4.pt1;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.parquet.Strings;

import br.com.tim.mapreduce.refactoring.endtoend.step4.model.MapaHist;
import br.com.tim.mapreduce.refactoring.endtoend.step4.utils.MapaHistCounters;

public class MapaHistMapper extends Mapper<Writable,Text, Step4Key, Step4Value>{
	
	
	Step4Value outValue;
	private Step4Key outKey;
	private MapaHist mapaHist;
	
	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		
		this.outValue = new Step4Value();
		this.outKey = new Step4Key();
		this.mapaHist = new MapaHist();
		
	}
	
	protected void map(Writable key, Text value,  Mapper<Writable, Text,Step4Key, Step4Value>.Context context) throws IOException, InterruptedException{
	
		outValue.reset();
		mapaHist.clean();
		
		mapaHist.parseFromText(value);
		
		if (!Strings.isNullOrEmpty(mapaHist.getRowIdItemOrdem())) {
			
			outKey.setRowIdOrdem(mapaHist.getRowIdItemOrdem());
			outKey.setDatRef(mapaHist.getDatref());
			outKey.setTipo(TypeStep4.MAPA_HIST);
			
			outValue.update(TypeStep4.MAPA_HIST, mapaHist);
			
			context.write(outKey, outValue);
			context.getCounter(MapaHistCounters.MAPA_HIST_MAPPER_WRITE).increment(1l);
			
		}else {
			context.getCounter(MapaHistCounters.MAPA_HIST_MAPPER_DISCART).increment(1l);

		}
		
		
		
	}
	
	

}
