package br.com.tim.mapreduce.itemordem.step3;

import org.apache.commons.lang3.StringUtils;

public class IOStep3OutValue{

    protected String nroOrdem;
    protected String nomBairro;
    protected String cep;
    protected String nomCidade;
    protected String numCNPJParcVenda;
    protected String dscComplemento;
    protected String datDesconexao;
    protected String datVenda;
    protected String dscLogradouro;
    protected String numLogradouro;
    protected String nomPlanoAtual;
    protected String nomPlanoNovo;
    protected String numTelefone;
    protected String dscTipoLogradouro;
    protected String nomProduto;
    protected String dscTipoMotivo;
    protected String sglUFInstalacao;
    protected String datRefOrdem;
    protected String dscAcaoItemOrdem;
    protected String dscStatusItem;
    protected String email;
    protected String dscTipoOrdem;
    protected String dscFormaPgto;
    protected String codCtaFinanceira;
    protected String codContratoOltp;
    protected String numProtocolo;
    protected String datCriacaoOrdem;
    protected String datHorCriacaoOrdem;
    protected String datStatusOrdem;
    protected String datSuspensao;
    protected String datReativacao;
    protected String codServiceId;
    protected String nomContato;
    protected String dscMotivoStatusItem;
    protected String nomLoginResponsavel;
    protected String nomLoginVendedor;
    protected String dscCanalVenda;
    protected String valPlanoAtual;
    protected String nomDescontoAtual;
    protected String valDescontoAtual;
    protected String valPlanoNovo;
    protected String nomDescontoNovo;
    protected String valDescontoNovo;
    protected String flgPortabilidade;
    protected String codDdd;
    protected String numTelefonePortado;
    protected String datJanelaPortabilidade;
    protected String dscEstorno;
    protected String numBilheteEstornado;
    protected String dscMotivoEstorno;
    protected String dscStatusOrdemWfm;
    protected String datHoraStatusWfm;
    protected String diaVencimento;
    protected String dscTipoConta;
    protected String dscEnderecoFatura;
    protected String dscAreaVoip;
    protected String codBanco;
    protected String codAgenciaBco;
    protected String codContaCorrente;
    protected String datAltFormaPgto;
    protected String codDebitoAutomatico;
    protected String codItemOrdem;
    protected String nomParceiroVenda;
    protected String idItemOrdPai;
    protected String idItemOrdem;
    protected String dscCategoriaItem;
    protected String tecnologia;
    protected String cpe;
    protected String ont;
    protected String velocidadeContratada;
    protected String custcode;
    protected String numTelefone2;
    protected String numTelefone3;
    protected String dominioRoot;
    protected String datRef;


    public void setStep2Result(IOStep3Value result) {
        this.nroOrdem = result.getNroOrdem();
        this.nomBairro = result.getNomBairro();
        this.cep = result.getCep();
        this.nomCidade = result.getNomCidade();
        this.dscComplemento = result.getDscComplemento();
        this.datDesconexao = result.getDatDesconexao();
        this.dscLogradouro = result.getDscLogradouro();
        this.numLogradouro = result.getNumLogradouro();
        this.nomPlanoAtual = result.getNomPlanoAtual();
        this.nomPlanoNovo = result.getNomPlanoNovo();
        this.numTelefone = result.getNumTelefone();
        this.dscTipoLogradouro = result.getDscTipoLogradouro();
        this.nomProduto = result.getNomProduto();
        this.dscTipoMotivo = result.getDscTipoMotivo();
        this.sglUFInstalacao = result.getSglUFInstalacao();
        this.dscAcaoItemOrdem = result.getDscAcaoItemOrdem();
        this.dscStatusItem = result.getDscStatusItem();
        this.email = result.getEmail();
        this.dscFormaPgto = result.getDscFormaPgto();
        this.codCtaFinanceira = result.getCodCtaFinanceira();
        this.codContratoOltp = result.getCodContratoOltp();
        this.numProtocolo = result.getNumProtocolo();
        this.datSuspensao = result.getDatSuspensao();
        this.datReativacao = result.getDatReativacao();
        this.codServiceId = result.getCodServiceId();
        this.dscMotivoStatusItem = result.getDscMotivoStatusItem();
        this.valPlanoAtual = result.getValPlanoAtual();
        this.nomDescontoAtual = result.getNomDescontoAtual();
        this.valDescontoAtual = result.getValDescontoAtual();
        this.valPlanoNovo = result.getValPlanoNovo();
        this.nomDescontoNovo = result.getNomDescontoNovo();
        this.valDescontoNovo = result.getValDescontoNovo();
        this.flgPortabilidade = result.getFlgPortabilidade();
        this.codDdd = result.getCodDdd();
        this.numTelefonePortado = result.getNumTelefonePortado();
        this.datJanelaPortabilidade = result.getDatJanelaPortabilidade();
        this.dscEstorno = result.getDscEstorno();
        this.numBilheteEstornado = result.getNumBilheteEstornado();
        this.dscMotivoEstorno = result.getDscMotivoEstorno();
        this.dscStatusOrdemWfm = result.getDscStatusOrdemWfm();
        this.datHoraStatusWfm = result.getDatHoraStatusWfm();
        this.diaVencimento = result.getDiaVencimento();
        this.dscTipoConta = result.getDscTipoConta();
        this.dscEnderecoFatura = result.getDscEnderecoFatura();
        this.dscAreaVoip = result.getDscAreaVoip();
        this.codBanco = result.getCodBanco();
        this.codAgenciaBco = result.getCodAgenciaBco();
        this.codContaCorrente = result.getCodContaCorrente();
        this.datAltFormaPgto = result.getDatAltFormaPgto();
        this.codDebitoAutomatico = result.getCodDebitoAutomatico();
        this.codItemOrdem = result.getCodItemOrdem();
        this.idItemOrdPai = result.getIdItemOrdPai();
        this.idItemOrdem = result.getIdItemOrdem();
        this.dscCategoriaItem = result.getDscCategoriaItem();
        this.tecnologia = result.getTecnologia();
        this.cpe = result.getCpe();
        this.ont = result.getOnt();
        this.velocidadeContratada = result.getVelocidadeContratada();
        this.numCNPJParcVenda = result.getNumCNPJParcVenda();
        this.datVenda = result.getDatVenda();
        this.datRefOrdem = result.getDatRef();
        this.dscTipoOrdem = result.getDscTipoOrdem();
        this.datCriacaoOrdem = StringUtils.substring(result.getDatCriacaoOrdem(), 0, 10);
        this.datHorCriacaoOrdem = result.getDatCriacaoOrdem();
        this.datStatusOrdem = result.getDatStatusOrdem();
        this.nomContato = result.getNomContato();
        this.nomLoginResponsavel = result.getNomLoginResponsavel();
        this.nomLoginVendedor = result.getNomLoginVendedor();
        this.dscCanalVenda = result.getDscCanalVenda();
        this.nomParceiroVenda = result.getNomParceiroVenda();
        this.numTelefone2 = result.getNumTelefone2();
        this.numTelefone3 = result.getNumTelefone3();
        this.dominioRoot = result.getDominioRoot();
    }

    public void setBAT230(IOStep3Value bat) {
        this.custcode = bat.getCustcode();
    }

    public void clear(){
        this.nroOrdem = "";
        this.nomBairro = "";
        this.cep = "";
        this.nomCidade = "";
        this.numCNPJParcVenda = "";
        this.dscComplemento = "";
        this.datDesconexao = "";
        this.datVenda = "";
        this.dscLogradouro = "";
        this.numLogradouro = "";
        this.nomPlanoAtual = "";
        this.nomPlanoNovo = "";
        this.numTelefone = "";
        this.dscTipoLogradouro = "";
        this.nomProduto = "";
        this.dscTipoMotivo = "";
        this.sglUFInstalacao = "";
        this.datRefOrdem = "";
        this.dscAcaoItemOrdem = "";
        this.dscStatusItem = "";
        this.email = "";
        this.dscTipoOrdem = "";
        this.dscFormaPgto = "";
        this.codCtaFinanceira = "";
        this.codContratoOltp = "";
        this.numProtocolo = "";
        this.datCriacaoOrdem = "";
        this.datHorCriacaoOrdem = "";
        this.datStatusOrdem = "";
        this.datSuspensao = "";
        this.datReativacao = "";
        this.codServiceId = "";
        this.nomContato = "";
        this.dscMotivoStatusItem = "";
        this.nomLoginResponsavel = "";
        this.nomLoginVendedor = "";
        this.dscCanalVenda = "";
        this.valPlanoAtual = "";
        this.nomDescontoAtual = "";
        this.valDescontoAtual = "";
        this.valPlanoNovo = "";
        this.nomDescontoNovo = "";
        this.valDescontoNovo = "";
        this.flgPortabilidade = "";
        this.codDdd = "";
        this.numTelefonePortado = "";
        this.datJanelaPortabilidade = "";
        this.dscEstorno = "";
        this.numBilheteEstornado = "";
        this.dscMotivoEstorno = "";
        this.dscStatusOrdemWfm ="";
        this.datHoraStatusWfm = "";
        this.diaVencimento = "";
        this.dscTipoConta = "";
        this.dscEnderecoFatura = "";
        this.dscAreaVoip = "";
        this.codBanco = "";
        this.codAgenciaBco = "";
        this.codContaCorrente = "";
        this.datAltFormaPgto = "";
        this.codDebitoAutomatico = "";
        this.codItemOrdem = "";
        this.nomParceiroVenda = "";
        this.idItemOrdPai = "";
        this.idItemOrdem = "";
        this.dscCategoriaItem = "";
        this.tecnologia = "";
        this.cpe = "";
        this.ont = "";
        this.velocidadeContratada = "";
        this.custcode = "";
        this.numTelefone2 = "";
        this.numTelefone3 = "";
        this.dominioRoot = "";
        this.datRef = "";
    }

    public void clearResultStep2(){
        this.nroOrdem = "";
        this.nomBairro = "";
        this.cep = "";
        this.nomCidade = "";
        this.numCNPJParcVenda = "";
        this.dscComplemento = "";
        this.datDesconexao = "";
        this.datVenda = "";
        this.dscLogradouro = "";
        this.numLogradouro = "";
        this.nomPlanoAtual = "";
        this.nomPlanoNovo = "";
        this.numTelefone = "";
        this.dscTipoLogradouro = "";
        this.nomProduto = "";
        this.dscTipoMotivo = "";
        this.sglUFInstalacao = "";
        this.datRefOrdem = "";
        this.dscAcaoItemOrdem = "";
        this.dscStatusItem = "";
        this.email = "";
        this.dscTipoOrdem = "";
        this.dscFormaPgto = "";
        this.codCtaFinanceira = "";
        this.codContratoOltp = "";
        this.numProtocolo = "";
        this.datCriacaoOrdem = "";
        this.datStatusOrdem = "";
        this.datSuspensao = "";
        this.datReativacao = "";
        this.codServiceId = "";
        this.nomContato = "";
        this.dscMotivoStatusItem = "";
        this.nomLoginResponsavel = "";
        this.nomLoginVendedor = "";
        this.dscCanalVenda = "";
        this.valPlanoAtual = "";
        this.nomDescontoAtual = "";
        this.valDescontoAtual = "";
        this.valPlanoNovo = "";
        this.nomDescontoNovo = "";
        this.valDescontoNovo = "";
        this.flgPortabilidade = "";
        this.codDdd = "";
        this.numTelefonePortado = "";
        this.datJanelaPortabilidade = "";
        this.dscEstorno = "";
        this.numBilheteEstornado = "";
        this.dscMotivoEstorno = "";
        this.dscStatusOrdemWfm ="";
        this.datHoraStatusWfm = "";
        this.diaVencimento = "";
        this.dscTipoConta = "";
        this.dscEnderecoFatura = "";
        this.dscAreaVoip = "";
        this.codBanco = "";
        this.codAgenciaBco = "";
        this.codContaCorrente = "";
        this.datAltFormaPgto = "";
        this.codDebitoAutomatico = "";
        this.codItemOrdem = "";
        this.nomParceiroVenda = "";
        this.idItemOrdPai = "";
        this.idItemOrdem = "";
        this.dscCategoriaItem = "";
        this.tecnologia = "";
        this.cpe = "";
        this.ont = "";
        this.velocidadeContratada = "";
        this.numTelefone2 = "";
        this.numTelefone3 = "";
        this.dominioRoot = "";
    }

    public String toString(){
        return new StringBuilder()
                .append(nroOrdem).append("|")
                .append(nomBairro).append("|")
                .append(cep).append("|")
                .append(nomCidade).append("|")
                .append(numCNPJParcVenda).append("|")
                .append(dscComplemento).append("|")
                .append(datDesconexao).append("|")
                .append(datVenda).append("|")
                .append(dscLogradouro).append("|")
                .append(numLogradouro).append("|")
                .append(nomPlanoAtual).append("|")
                .append(nomPlanoNovo).append("|")
                .append(numTelefone).append("|")
                .append(dscTipoLogradouro).append("|")
                .append(nomProduto).append("|")
                .append(dscTipoMotivo).append("|")
                .append(sglUFInstalacao).append("|")
                .append(datRefOrdem).append("|")
                .append(dscAcaoItemOrdem).append("|")
                .append(dscStatusItem).append("|")
                .append(email).append("|")
                .append(dscTipoOrdem).append("|")
                .append(dscFormaPgto).append("|")
                .append(codCtaFinanceira).append("|")
                .append(codContratoOltp).append("|")
                .append(numProtocolo).append("|")
                .append(datCriacaoOrdem).append("|")
                .append(datHorCriacaoOrdem).append("|")
                .append(datStatusOrdem).append("|")
                .append(datSuspensao).append("|")
                .append(datReativacao).append("|")
                .append(codServiceId).append("|")
                .append(nomContato).append("|")
                .append(dscMotivoStatusItem).append("|")
                .append(nomLoginResponsavel).append("|")
                .append(nomLoginVendedor).append("|")
                .append(dscCanalVenda).append("|")
                .append(valPlanoAtual).append("|")
                .append(nomDescontoAtual).append("|")
                .append(valDescontoAtual).append("|")
                .append(valPlanoNovo).append("|")
                .append(nomDescontoNovo).append("|")
                .append(valDescontoNovo).append("|")
                .append(flgPortabilidade).append("|")
                .append(codDdd).append("|")
                .append(numTelefonePortado).append("|")
                .append(datJanelaPortabilidade).append("|")
                .append(dscEstorno).append("|")
                .append(numBilheteEstornado).append("|")
                .append(dscMotivoEstorno).append("|")
                .append(dscStatusOrdemWfm).append("|")
                .append(datHoraStatusWfm).append("|")
                .append(diaVencimento).append("|")
                .append(dscTipoConta).append("|")
                .append(dscEnderecoFatura).append("|")
                .append(dscAreaVoip).append("|")
                .append(codBanco).append("|")
                .append(codAgenciaBco).append("|")
                .append(codContaCorrente).append("|")
                .append(datAltFormaPgto).append("|")
                .append(codDebitoAutomatico).append("|")
                .append(codItemOrdem).append("|")
                .append(nomParceiroVenda).append("|")
                .append(idItemOrdPai).append("|")
                .append(idItemOrdem).append("|")
                .append(dscCategoriaItem).append("|")
                .append(tecnologia).append("|")
                .append(cpe).append("|")
                .append(ont).append("|")
                .append(velocidadeContratada).append("|")
                .append(custcode).append("|")
                .append(numTelefone2).append("|")
                .append(numTelefone3).append("|")
                .append(dominioRoot).append("|")
                .append(datRef)
                .toString();
    }

    public void setDatRef(String datRef) {
        this.datRef = datRef;
    }
}
