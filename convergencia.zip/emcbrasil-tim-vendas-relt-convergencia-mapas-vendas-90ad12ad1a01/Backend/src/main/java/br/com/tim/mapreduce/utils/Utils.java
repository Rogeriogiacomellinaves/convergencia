package br.com.tim.mapreduce.utils;

import org.apache.hadoop.mapreduce.Job;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;

import br.com.tim.driverutils.DriverConstants;

public class Utils {

	public static void reprocessDay(String[] args, Job job) {

		if (args.length == 0) {
			job.getConfiguration().set("dat-ref",
					DateTimeFormat.forPattern("yyyyMMdd").print(LocalDate.now().minusDays(1)).replace("-", ""));

		} else if (args[0].startsWith(DriverConstants.REPROCESS_DAY + "=")
				&& args[0].length() == DriverConstants.REPROCESS_DAY.length() + "=yyyy-MM-dd".length()) {
			job.getConfiguration().set("dat-ref",
					LocalDate.parse(args[0].substring(DriverConstants.REPROCESS_DAY.length() + 1),
							DateTimeFormat.forPattern("yyyy-MM-dd")).toString().replace("-", ""));
		} else {
			throw new IllegalArgumentException(
					"Deve-se passar a data por parametro no seguinte formato: \\\"reprocess-day=yyyy-MM-dd\\\"");
		}
		
	}
	
}
