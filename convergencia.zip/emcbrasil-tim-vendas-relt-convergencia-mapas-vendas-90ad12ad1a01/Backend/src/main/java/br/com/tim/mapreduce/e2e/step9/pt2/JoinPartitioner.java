package br.com.tim.mapreduce.e2e.step9.pt2;

import br.com.tim.mapreduce.e2e.step9.E2EStep9Key;
import org.apache.hadoop.mapreduce.Partitioner;

public class JoinPartitioner extends Partitioner<E2EStep9Key, E2EStep9PT2Value> {

    @Override
    public int getPartition(E2EStep9Key taggedKey, E2EStep9PT2Value value, int numPartitions) {
        return Math.abs(taggedKey.hashCodeJoin() % numPartitions);
    }
}