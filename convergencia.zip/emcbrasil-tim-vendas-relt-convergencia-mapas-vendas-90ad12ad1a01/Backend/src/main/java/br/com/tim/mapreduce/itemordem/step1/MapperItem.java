package br.com.tim.mapreduce.itemordem.step1;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

import br.com.tim.mapreduce.model.BAT509Item;
import br.com.tim.mr.utils.TaggedKey;

public class MapperItem extends org.apache.hadoop.mapreduce.Mapper<Writable,Text,TaggedKey,IOStep1Value> {

	private TaggedKey outkey;
	private IOStep1Value outValue;
	private BAT509Item input;
	@Override
	protected void map(Writable key, org.apache.hadoop.io.Text value, Context context) throws IOException, InterruptedException {
		input.parse(value.toString());
		outkey.set(input.getNumeroOrdem(), 2);
		outValue.setItem(input);
		if(input.getTipoItemOrdem().toUpperCase().trim().equals("TIM_FIBER") ||
		   input.getTipoItemOrdem().toUpperCase().trim().equals("BANDA_LARGA") ||
		   input.getTipoItemOrdem().toUpperCase().trim().equals("TIM_FIXO_VOIP")) {
			context.write(outkey, outValue);
		}
	}

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		super.setup(context);
		this.outkey = new TaggedKey();
		this.outValue = new IOStep1Value();
		this.input = new BAT509Item();
	}

	@Override
	protected void cleanup(Context context) throws IOException, InterruptedException {
		super.cleanup(context);
		this.clear();
	}

	private void clear(){
	   this.outValue.clear();
	}

}