package br.com.tim.mapreduce.itemordem.step2;

public class IOStep2OutValue {

    private String nroOrdem;
    private String nomBairro;
    private String cep;
    private String nomCidade;
    private String numCNPJParcVenda;
    private String dscComplemento;
    private String datDesconexao;
    private String datVenda;
    private String dscLogradouro;
    private String numLogradouro;
    private String nomPlanoAtual;
    private String nomPlanoNovo;
    private String numTelefone;
    private String dscTipoLogradouro;
    private String nomProduto;
    private String dscTipoMotivo;
    private String sglUFInstalacao;
    private String datRef;
    private String dscAcaoItemOrdem;
    private String dscStatusItem;
    private String email;
    private String dscTipoOrdem;
    private String dscFormaPgto;
    private String codCtaFinanceira;
    private String codContratoOltp;
    private String numProtocolo;
    private String datCriacaoOrdem;
    private String datStatusOrdem;
    private String datSuspensao;
    private String datReativacao;
    private String codServiceId;
    private String nomContato;
    private String dscMotivoStatusItem;
    private String nomLoginResponsavel;
    private String nomLoginVendedor;
    private String dscCanalVenda;
    private String valPlanoAtual;
    private String nomDescontoAtual;
    private String valDescontoAtual;
    private String valPlanoNovo;
    private String nomDescontoNovo;
    private String valDescontoNovo;
    private String flgPortabilidade;
    private String codDdd;
    private String numTelefonePortado;
    private String datJanelaPortabilidade;
    private String dscEstorno;
    private String numBilheteEstornado;
    private String dscMotivoEstorno;
    private String dscStatusOrdemWfm;
    private String datHoraStatusWfm;
    private String diaVencimento;
    private String dscTipoConta;
    private String dscEnderecoFatura;
    private String dscAreaVoip;
    private String codBanco;
    private String codAgenciaBco;
    private String codContaCorrente;
    private String datAltFormaPgto;
    private String codDebitoAutomatico;
    private String codItemOrdem;
    private String nomParceiroVenda;
    private String idItemOrdPai;
    private String idItemOrdem;
    private String dscCategoriaItem;
    private String tecnologia;
    private String cpe;
    private String ont;
    private String velocidadeContratada;
    private String numTelefone2;
    private String numtelefone3;
    private String dominioRoot;

    public void clear(){
        this.nroOrdem = "";
        this.nomBairro = "";
        this.cep = "";
        this.nomCidade = "";
        this.numCNPJParcVenda = "";
        this.dscComplemento = "";
        this.datDesconexao = "";
        this.datVenda = "";
        this.dscLogradouro = "";
        this.numLogradouro = "";
        this.nomPlanoAtual = "";
        this.nomPlanoNovo = "";
        this.numTelefone = "";
        this.dscTipoLogradouro = "";
        this.nomProduto = "";
        this.dscTipoMotivo = "";
        this.sglUFInstalacao = "";
        this.datRef = "";
        this.dscAcaoItemOrdem = "";
        this.dscStatusItem = "";
        this.email = "";
        this.dscTipoOrdem = "";
        this.dscFormaPgto = "";
        this.codCtaFinanceira = "";
        this.codContratoOltp = "";
        this.numProtocolo = "";
        this.datCriacaoOrdem = "";
        this.datStatusOrdem = "";
        this.datSuspensao = "";
        this.datReativacao = "";
        this.codServiceId = "";
        this.nomContato = "";
        this.dscMotivoStatusItem = "";
        this.nomLoginResponsavel = "";
        this.nomLoginVendedor = "";
        this.dscCanalVenda = "";
        this.valPlanoAtual = "";
        this.nomDescontoAtual = "";
        this.valDescontoAtual = "";
        this.valPlanoNovo = "";
        this.nomDescontoNovo = "";
        this.valDescontoNovo = "";
        this.flgPortabilidade = "";
        this.codDdd = "";
        this.numTelefonePortado = "";
        this.datJanelaPortabilidade = "";
        this.dscEstorno = "";
        this.numBilheteEstornado = "";
        this.dscMotivoEstorno = "";
        this.dscStatusOrdemWfm = "";
        this.datHoraStatusWfm = "";
        this.diaVencimento = "";
        this.dscTipoConta = "";
        this.dscEnderecoFatura = "";
        this.dscAreaVoip = "";
        this.codBanco = "";
        this.codAgenciaBco = "";
        this.codContaCorrente = "";
        this.datAltFormaPgto = "";
        this.codDebitoAutomatico = "";
        this.codItemOrdem = "";
        this.nomParceiroVenda = "";
        this.idItemOrdPai = "";
        this.idItemOrdem = "";
        this.dscCategoriaItem = "";
        this.tecnologia = "";
        this.cpe = "";
        this.ont = "";
        this.numTelefone2 = "";
        this.numtelefone3 = "";
        this.velocidadeContratada = "";
        this.dominioRoot = "";
    }

    public void clearStep1Result(){
        this.nroOrdem = "";
        this.nomBairro = "";
        this.cep = "";
        this.nomCidade = "";
        this.numCNPJParcVenda = "";
        this.dscComplemento = "";
        this.datDesconexao = "";
        this.datVenda = "";
        this.dscLogradouro = "";
        this.numLogradouro = "";
        this.nomPlanoAtual = "";
        this.nomPlanoNovo = "";
        this.numTelefone = "";
        this.dscTipoLogradouro = "";
        this.nomProduto = "";
        this.dscTipoMotivo = "";
        this.sglUFInstalacao = "";
        this.datRef = "";
        this.dscAcaoItemOrdem = "";
        this.dscStatusItem = "";
        this.email = "";
        this.dscTipoOrdem = "";
        this.dscFormaPgto = "";
        this.codCtaFinanceira = "";
        this.codContratoOltp = "";
        this.numProtocolo = "";
        this.datCriacaoOrdem = "";
        this.datStatusOrdem = "";
        this.datSuspensao = "";
        this.datReativacao = "";
        this.codServiceId = "";
        this.nomContato = "";
        this.dscMotivoStatusItem = "";
        this.nomLoginResponsavel = "";
        this.nomLoginVendedor = "";
        this.dscCanalVenda = "";
        this.valPlanoAtual = "";
        this.nomDescontoAtual = "";
        this.valDescontoAtual = "";
        this.valPlanoNovo = "";
        this.nomDescontoNovo = "";
        this.valDescontoNovo = "";
        this.flgPortabilidade = "";
        this.codDdd = "";
        this.numTelefonePortado = "";
        this.datJanelaPortabilidade = "";
        this.dscEstorno = "";
        this.numBilheteEstornado = "";
        this.dscMotivoEstorno = "";
        this.dscStatusOrdemWfm = "";
        this.datHoraStatusWfm = "";
        this.diaVencimento = "";
        this.dscTipoConta = "";
        this.dscEnderecoFatura = "";
        this.dscAreaVoip = "";
        this.codBanco = "";
        this.codAgenciaBco = "";
        this.codContaCorrente = "";
        this.datAltFormaPgto = "";
        this.codDebitoAutomatico = "";
        this.codItemOrdem = "";
        this.nomParceiroVenda = "";
        this.idItemOrdPai = "";
        this.idItemOrdem = "";
        this.dscCategoriaItem = "";
        this.tecnologia = "";
        this.cpe = "";
        this.ont = "";
        this.numTelefone2 = "";
        this.numtelefone3 = "";
        this.dominioRoot = "";
    }

    public void setStep1Result(IOStep2Value obj) {
        this.nroOrdem = obj.getNroOrdem();
        this.nomBairro = obj.getNomBairro();
        this.cep = obj.getCep();
        this.nomCidade = obj.getNomCidade();
        this.dscComplemento = obj.getDscComplemento();
        this.datDesconexao = obj.getDatDesconexao();
        this.dscLogradouro = obj.getDscLogradouro();
        this.numLogradouro = obj.getNumLogradouro();
        this.nomPlanoAtual = obj.getNomPlanoAtual();
        this.nomPlanoNovo = obj.getNomPlanoNovo();
        this.numTelefone = obj.getNumTelefone();
        this.dscTipoLogradouro = obj.getDscTipoLogradouro();
        this.nomProduto = obj.getNomProduto();
        this.dscTipoMotivo = obj.getDscTipoMotivo();
        this.sglUFInstalacao = obj.getSglUFInstalacao();
        this.dscAcaoItemOrdem = obj.getDscAcaoItemOrdem();
        this.dscStatusItem = obj.getDscStatusItem();
        this.email = obj.getEmail();
        this.dscFormaPgto = obj.getDscFormaPgto();
        this.codCtaFinanceira = obj.getCodCtaFinanceira();
        this.codContratoOltp = obj.getCodContratoOltp();
        this.numProtocolo = obj.getNumProtocolo();
        this.datSuspensao = obj.getDatSuspensao();
        this.datReativacao = obj.getDatReativacao();
        this.codServiceId = obj.getCodServiceId();
        this.dscMotivoStatusItem = obj.getDscMotivoStatusItem();
        this.valPlanoAtual = obj.getValPlanoAtual();
        this.nomDescontoAtual = obj.getNomDescontoAtual();
        this.valDescontoAtual = obj.getValDescontoAtual();
        this.valPlanoNovo = obj.getValPlanoNovo();
        this.nomDescontoNovo = obj.getNomDescontoNovo();
        this.valDescontoNovo = obj.getValDescontoNovo();
        this.flgPortabilidade = obj.getFlgPortabilidade();
        this.codDdd = obj.getCodDdd();
        this.numTelefonePortado = obj.getNumTelefonePortado();
        this.datJanelaPortabilidade = obj.getDatJanelaPortabilidade();
        this.dscEstorno = obj.getDscEstorno();
        this.numBilheteEstornado = obj.getNumBilheteEstornado();
        this.dscMotivoEstorno = obj.getDscMotivoEstorno();
        this.dscStatusOrdemWfm = obj.getDscStatusOrdemWfm();
        this.datHoraStatusWfm = obj.getDatHoraStatusWfm();
        this.diaVencimento = obj.getDiaVencimento();
        this.dscTipoConta = obj.getDscTipoConta();
        this.dscEnderecoFatura = obj.getDscEnderecoFatura();
        this.dscAreaVoip = obj.getDscAreaVoip();
        this.codBanco = obj.getCodBanco();
        this.codAgenciaBco = obj.getCodAgenciaBco();
        this.codContaCorrente = obj.getCodContaCorrente();
        this.datAltFormaPgto = obj.getDatAltFormaPgto();
        this.codDebitoAutomatico = obj.getCodDebitoAutomatico();
        this.codItemOrdem = obj.getCodItemOrdem();
        this.idItemOrdPai = obj.getIdItemOrdPai();
        this.idItemOrdem = obj.getIdItemOrdem();
        this.dscCategoriaItem = obj.getDscCategoriaItem();
        this.tecnologia = obj.getTecnologia();
        this.cpe = obj.getCpe();
        this.ont = obj.getOnt();
        this.numCNPJParcVenda = obj.getNumCNPJParcVenda();
        this.datVenda = obj.getDatVenda();
        this.datRef = obj.getDatRef();
        this.dscTipoOrdem = obj.getDscTipoOrdem();
        this.datCriacaoOrdem = obj.getDatCriacaoOrdem();
        this.datStatusOrdem = obj.getDatStatusOrdem();
        this.nomContato = obj.getNomContato();
        this.nomLoginResponsavel = obj.getNomLoginResponsavel();
        this.nomLoginVendedor = obj.getNomLoginVendedor();
        this.dscCanalVenda = obj.getDscCanalVenda();
        this.nomParceiroVenda = obj.getNomParceiroVenda();
        this.numTelefone2 = obj.getNumTelefone2();
        this.numtelefone3 = obj.getNumTelefone3();
        this.dominioRoot = obj.getDominioRoot();
    }

    public void setBAT513(IOStep2Value bat) {
        this.velocidadeContratada = bat.getVelocidadeContratada();
    }

    @Override
    public String toString() {
        return new StringBuilder()
                .append(nroOrdem).append("|")
                .append(nomBairro).append("|")
                .append(cep).append("|")
                .append(nomCidade).append("|")
                .append(numCNPJParcVenda).append("|")
                .append(dscComplemento).append("|")
                .append(datDesconexao).append("|")
                .append(datVenda).append("|")
                .append(dscLogradouro).append("|")
                .append(numLogradouro).append("|")
                .append(nomPlanoAtual).append("|")
                .append(nomPlanoNovo).append("|")
                .append(numTelefone).append("|")
                .append(dscTipoLogradouro).append("|")
                .append(nomProduto).append("|")
                .append(dscTipoMotivo).append("|")
                .append(sglUFInstalacao).append("|")
                .append(datRef).append("|")
                .append(dscAcaoItemOrdem).append("|")
                .append(dscStatusItem).append("|")
                .append(email).append("|")
                .append(dscTipoOrdem).append("|")
                .append(dscFormaPgto).append("|")
                .append(codCtaFinanceira).append("|")
                .append(codContratoOltp).append("|")
                .append(numProtocolo).append("|")
                .append(datCriacaoOrdem).append("|")
                .append(datStatusOrdem).append("|")
                .append(datSuspensao).append("|")
                .append(datReativacao).append("|")
                .append(codServiceId).append("|")
                .append(nomContato).append("|")
                .append(dscMotivoStatusItem).append("|")
                .append(nomLoginResponsavel).append("|")
                .append(nomLoginVendedor).append("|")
                .append(dscCanalVenda).append("|")
                .append(valPlanoAtual).append("|")
                .append(nomDescontoAtual).append("|")
                .append(valDescontoAtual).append("|")
                .append(valPlanoNovo).append("|")
                .append(nomDescontoNovo).append("|")
                .append(valDescontoNovo).append("|")
                .append(flgPortabilidade).append("|")
                .append(codDdd).append("|")
                .append(numTelefonePortado).append("|")
                .append(datJanelaPortabilidade).append("|")
                .append(dscEstorno).append("|")
                .append(numBilheteEstornado).append("|")
                .append(dscMotivoEstorno).append("|")
                .append(dscStatusOrdemWfm).append("|")
                .append(datHoraStatusWfm).append("|")
                .append(diaVencimento).append("|")
                .append(dscTipoConta).append("|")
                .append(dscEnderecoFatura).append("|")
                .append(dscAreaVoip).append("|")
                .append(codBanco).append("|")
                .append(codAgenciaBco).append("|")
                .append(codContaCorrente).append("|")
                .append(datAltFormaPgto).append("|")
                .append(codDebitoAutomatico).append("|")
                .append(codItemOrdem).append("|")
                .append(nomParceiroVenda).append("|")
                .append(idItemOrdPai).append("|")
                .append(idItemOrdem).append("|")
                .append(dscCategoriaItem).append("|")
                .append(tecnologia).append("|")
                .append(cpe).append("|")
                .append(ont).append("|")
                .append(velocidadeContratada).append("|")
                .append(numTelefone2).append("|")
                .append(numtelefone3).append("|")
                .append(dominioRoot)
                .toString();
    }
}
