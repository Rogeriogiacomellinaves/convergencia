package br.com.tim.mapreduce.itemordem.step3;

public enum TypeStep3 {

    BAT230, RESULTSTEP2
}
