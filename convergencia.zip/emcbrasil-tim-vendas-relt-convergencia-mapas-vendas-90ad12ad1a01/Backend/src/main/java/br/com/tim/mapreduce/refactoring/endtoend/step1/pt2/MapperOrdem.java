
package br.com.tim.mapreduce.refactoring.endtoend.step1.pt2;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.parquet.Strings;

import br.com.tim.mapreduce.refactoring.endtoend.utils.Step1Pt2Counters;
import br.com.tim.mapreduce.refactoring.model.BAT509Order;

public class MapperOrdem extends Mapper<Writable,Text,Step1Pt2Key,Step1Pt2Value> {

	Step1Pt2Value outValue;
	private Step1Pt2Key outkey;
	private BAT509Order input;
	
	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		
		this.outValue = new Step1Pt2Value();
		this.outkey = new Step1Pt2Key();
		this.input = new BAT509Order();
	}
	
	protected void map(Writable key, Text value,  Mapper<Writable, Text, Step1Pt2Key,Step1Pt2Value>.Context context) throws IOException, InterruptedException {
		
		outValue.clear();
		
		input.parseFromText(value);
		
		if (!Strings.isNullOrEmpty(input.getNumeroOrdem())) {
			
			outkey.setNroOrdem(input.getNumeroOrdem());
			outkey.setDatRef(input.getArquivo().substring(17, 25));
			outkey.setTipo(TypeStep1Pt2.ORDER);
			
			outValue.setOrdem(input);
			
			context.write(outkey, outValue);
			context.getCounter(Step1Pt2Counters.ORDER_MAPPER_WRITE).increment(1l);
		}else {
			
			context.getCounter(Step1Pt2Counters.ORDER_MAPPER_DISCART).increment(1l);

		}

		
	}




}