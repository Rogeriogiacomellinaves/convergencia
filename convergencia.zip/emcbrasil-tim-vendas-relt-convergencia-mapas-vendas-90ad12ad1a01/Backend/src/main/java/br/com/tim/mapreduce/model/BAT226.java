package br.com.tim.mapreduce.model;

import org.apache.commons.lang3.StringUtils;

public class BAT226 {

   private String positionName;
   private String positionPai;
   private String divisionPai;
   private String organizationPai;
   private String positionType;
   private String rowid;
   private String loteid;
   private String arquivo;
   private String arquivots;
   private String currentdate;
   private String datFromFilename;

    public BAT226() {

        this.positionName = null;
        this.positionPai = null;
        this.divisionPai = null;
        this.organizationPai = null;
        this.positionType = null;
        this.rowid = null;
        this.loteid = null;
        this.arquivo = null;
        this.arquivots = null;
        this.currentdate = null;
        this.datFromFilename = null;

    }

    public void setBAT226(String positionName, String positionPai, String divisionPai, String organizationPai, String positionType, String rowid,
                          String loteid, String arquivo, String arquivots, String currentdate, String datFromFilename) {
        this.positionName = positionName;
        this.positionPai = positionPai;
        this.divisionPai = divisionPai;
        this.organizationPai = organizationPai;
        this.positionType = positionType;
        this.rowid = rowid;
        this.loteid = loteid;
        this.arquivo = arquivo;
        this.arquivots = arquivots;
        this.currentdate = currentdate;
        this.datFromFilename = datFromFilename;
    }

    public boolean parse(String textString) {
        if (StringUtils.isNotBlank(textString)) {
            String[] cols = textString.split("\\|", -1);
            int i = 0;
            this.setBAT226(cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                           cols[i++]);
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        String delimiter = "|";

        sb.append(positionName).append(delimiter)
          .append(positionPai).append(delimiter)
          .append(divisionPai).append(delimiter)
          .append(organizationPai).append(delimiter)
          .append(positionType).append(delimiter)
          .append(rowid).append(delimiter)
          .append(loteid).append(delimiter)
          .append(arquivo).append(delimiter)
          .append(arquivots).append(delimiter)
          .append(currentdate).append(delimiter)
          .append(datFromFilename);

        return sb.toString();

    }

    public String getPositionName() {
        return positionName;
    }

    public void setPositionName(String positionName) {
        this.positionName = positionName;
    }

    public String getPositionPai() {
        return positionPai;
    }

    public void setPositionPai(String positionPai) {
        this.positionPai = positionPai;
    }

    public String getDivisionPai() {
        return divisionPai;
    }

    public void setDivisionPai(String divisionPai) {
        this.divisionPai = divisionPai;
    }

    public String getOrganizationPai() {
        return organizationPai;
    }

    public void setOrganizationPai(String organizationPai) {
        this.organizationPai = organizationPai;
    }

    public String getPositionType() {
        return positionType;
    }

    public void setPositionType(String positionType) {
        this.positionType = positionType;
    }

    public String getRowid() {
        return rowid;
    }

    public void setRowid(String rowid) {
        this.rowid = rowid;
    }

    public String getLoteid() {
        return loteid;
    }

    public void setLoteid(String loteid) {
        this.loteid = loteid;
    }

    public String getArquivo() {
        return arquivo;
    }

    public void setArquivo(String arquivo) {
        this.arquivo = arquivo;
    }

    public String getArquivots() {
        return arquivots;
    }

    public void setArquivots(String arquivots) {
        this.arquivots = arquivots;
    }

    public String getCurrentdate() {
        return currentdate;
    }

    public void setCurrentdate(String currentdate) {
        this.currentdate = currentdate;
    }

    public String getDatFromFilename() {
        return datFromFilename;
    }

    public void setDatFromFilename(String datFromFilename) {
        this.datFromFilename = datFromFilename;
    }
}
