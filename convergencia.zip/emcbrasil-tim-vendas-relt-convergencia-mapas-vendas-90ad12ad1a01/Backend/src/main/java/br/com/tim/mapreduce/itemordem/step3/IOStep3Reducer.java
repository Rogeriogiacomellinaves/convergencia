package br.com.tim.mapreduce.itemordem.step3;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.log4j.Logger;

import java.io.IOException;

public class IOStep3Reducer extends org.apache.hadoop.mapreduce.Reducer<IOStep3Key,IOStep3Value,NullWritable,Text> {

    protected static final Logger LOG = Logger.getLogger(IOStep3Reducer.class);
    private IOStep3OutValue outValue;

    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        super.setup(context);
        outValue = new IOStep3OutValue();
    }

    @Override
    protected void reduce(IOStep3Key key, Iterable<IOStep3Value> values, Context context) throws InterruptedException {

        outValue.clear();
        outValue.setDatRef(context.getConfiguration().get("dat-ref"));

        try {
            for (IOStep3Value value : values) {
                if (value.getTipo().equals(TypeStep3.BAT230)){
                    outValue.setBAT230(value);
                }else if (value.getTipo().equals(TypeStep3.RESULTSTEP2)){
                    outValue.clearResultStep2();
                    outValue.setStep2Result(value);
                    context.write(NullWritable.get(),new Text(outValue.toString()));
                }
            }

        } catch (Exception e) {
            LOG.error(" ############ ERROR EXECUTION REDUCER ############ ");
            LOG.error(e.getMessage());
            throw new InterruptedException(e.getMessage());
        }
    }



    @Override
    protected void cleanup(Context context) throws IOException, InterruptedException {
        super.cleanup(context);

    }
}


