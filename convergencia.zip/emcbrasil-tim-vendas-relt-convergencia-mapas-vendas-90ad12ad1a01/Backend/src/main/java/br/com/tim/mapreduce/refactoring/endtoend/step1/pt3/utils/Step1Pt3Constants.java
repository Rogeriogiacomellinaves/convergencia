package br.com.tim.mapreduce.refactoring.endtoend.step1.pt3.utils;

public class Step1Pt3Constants {
	
	
	public static final String STEP1PT3_NAME = "process-id-pt3";
	
	public static final String WFTMOA_LOOK_BACK_DAYS = "lookback-days-wfmtoa";
	
	public static final String WFTMOA_FACT_INPUT = "input-path-wfmtoa";
	
	public static final String WFTMOA_NAME = "wfmtoa";

	public static final String STEP1PT2_FACT_INPUT = "input-path-step1-pt2";
	
	public static final String STEP1PT2_NAME = "step1-pt2";
	
	public static final String STEP1PT3_OUTPUT = "working-path-job3";





}
