package br.com.tim.mapreduce.e2e.step10;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

public class GroupingComparator extends WritableComparator {

    public GroupingComparator() {
        super(E2EStep10Key.class, true);
    }

    @SuppressWarnings({"rawtypes"})
    @Override
    public int compare(WritableComparable a, WritableComparable b) {
        E2EStep10Key keyA = (E2EStep10Key) a;
        E2EStep10Key keyB = (E2EStep10Key) b;

        return keyA.compareToGrouping(keyB);
    }

}
