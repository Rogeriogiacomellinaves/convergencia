package br.com.tim.mapreduce.refactoring.endtoend.step5.pt1;

public enum TypeStep5 {
	
	ORDEM

}
