
package br.com.tim.mapreduce.refactoring.endtoend.step4.pt4;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

import br.com.tim.mapreduce.refactoring.endtoend.step1.pt4.utils.Step1Pt4Counters;
import br.com.tim.mapreduce.refactoring.endtoend.step4.model.Step4;

public class MapperStep4Pt3Result extends org.apache.hadoop.mapreduce.Mapper<Writable,Text,E2EStep4Pt4Key,E2EStep4Pt4Value> {

	private E2EStep4Pt4Key outkey;
	private E2EStep4Pt4Value outValue;
	private Step4 input;
	@Override
	protected void map(Writable key, Text value, Context context) throws IOException, InterruptedException {
		
		
		input.parseFromText(value);
		/*if(StringUtils.isEmpty(input.getNumeroAcesso()))
			outkey.setNumAcesso(input.getCodContratoAtivacao());
		else*/
		outkey.setNumAcesso(input.getCodContFinanceira());
		outkey.setTipo(TypeStep4Pt4.RELT);
		outValue.Step1Pt3Result(input);
		context.write(outkey, outValue);
		context.getCounter(Step1Pt4Counters.STEP1PT3_MAPPER_WRITE).increment(1l);
	}

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		super.setup(context);
		this.outkey = new E2EStep4Pt4Key();
		this.outValue = new E2EStep4Pt4Value();
		this.input = new Step4();
	}

	@Override
	protected void cleanup(Context context) throws IOException, InterruptedException {
		super.cleanup(context);
		this.clear();
	}

	private void clear(){
	   this.outValue.clear();
	}

}