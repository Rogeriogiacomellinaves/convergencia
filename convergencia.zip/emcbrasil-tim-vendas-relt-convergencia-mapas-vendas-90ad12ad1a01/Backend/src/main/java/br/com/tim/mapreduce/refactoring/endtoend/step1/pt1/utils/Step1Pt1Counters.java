package br.com.tim.mapreduce.refactoring.endtoend.step1.pt1.utils;

public enum Step1Pt1Counters {
	
	STEP1_MAPPER_WRITE, STEP1_REDUCER_WRITE, STEP1_REDUCER_READ, STEP1_MAPPER_WRITE_PLANO

}
