package br.com.tim.mapreduce.e2e.step10.model;

import org.apache.commons.lang3.StringUtils;

public class Step9PT2Result {

	private String datRef;
	private String datCriacaoOrdem;
	private String horCriacaoOrdem;
	private String datVenda;
	private String horaVenda;
	private String datVendaOrig;
	private String horVendaOrig;
	private String datStatusOrdem;
	private String horStatusOrdem;
	private String numOrdemSiebel;
	private String numOrdemSiebelOrig;
	private String codContratoOltp;
	private String codContratoAtivacao;
	private String codContratoAtual;
	private String numeroAcesso;
	private String customerId;
	private String tipoDocumento;
	private String documento;
	private String tipoVenda;
	private String tipoProduto;
	private String velocidadeDownload;
	private String velocidadeUpload;
	private String planoAtivacaoOferta;
	private String loginVendedor;
	private String loginVendedorOrig;
	private String nomeVendedor;
	private String nomeVendedorOrig;
	private String canal;
	private String canalOrig;
	private String cnpjParceiro;
	private String cnpjParceiroOrig;
	private String custCode;
	private String custCodeOrig;
	private String position;
	private String positionOrig;
	private String parceiro;
	private String parceiroOrig;
	private String flgCancAntesVenda;
	private String flgVendaSubmetida;
	private String flgVendaDuplicada;
	private String flgVendaBruta;
	private String flgVendaLiquida;
	private String flgGross;
	private String flgChurn;
	private String flgCancPosVenda;
	private String flgCancDupl;
	private String flgCancLiquido;
	private String datGross;
	private String datChurn;
	private String motivoChurn;
	private String tipoChurn;
	private String datCancVenda;
	private String motivoCancelamento;
	private String nomeCliente;
	private String telefone;
	private String email;
	private String uf;
	private String tipoLogradouro;
	private String logradouro;
	private String numero;
	private String complemento;
	private String bairro;
	private String cep;
	private String cidade;
	private String msanOltTrafego;
	private String statusOrdem;
	private String tecnologia;
	private String formaPagamento;
	private String tipoConta;
	private String codBanco;
	private String codAgenciaBanco;
	private String codContaCorrente;
	private String codDebitoAutomatico;
	private String diaVencimento;
	private String semanaVenda;
	private String semanaVendaOrig;
	private String score;
	private String scoreConsumido;
	private String datFinalizacaoOrdem;
	private String qtdContratos;
	private String codContaFinanceira;
	private String numProtocolo;
	private String flgOrdemAutomatica;
	private String dscTxRecorrente;
	private String dscTxNaoRecorrente;
	private String dscStatusItem;
	private String nomLoginResponsavel;
	private String nomPlanoAtual;
	private String valPlanoAtualItem;
	private String nomDescontoAtualItem;
	private String valDescontoAtualItem;
	private String flgPortabilidade;
	private String dscOperadoraDoadora;
	private String codDdd;
	private String numTelefonePortado;
	private String datJanelaPortabilidade;
	private String horJanela;
	private String dscEnderecoFatura;
	private String dscAreaVoip;
	private String cpe;
	private String ont;
	private String codConvergente;
	private String detalheRecusaCrivo;
	private String itemRoot;
	private String loginCancelamentoOrdem;
	private String nomeUsuarioCancelouOrdem;
	private String custcodeCliente;
	private String dominioRoot;
	private String datRefRelt;

	public void setStep9PT2Result(String datRef, String datCriacaoOrdem, String horCriacaoOrdem, String datVenda,
			String horaVenda, String datVendaOrig, String horVendaOrig, String datStatusOrdem, String horStatusOrdem,
			String numOrdemSiebel, String numOrdemSiebelOrig, String codContratoOltp, String codContratoAtivacao,
			String codContratoAtual, String numeroAcesso, String customerId, String tipoDocumento, String documento,
			String tipoVenda, String tipoProduto, String velocidadeDownload, String velocidadeUpload,
			String planoAtivacaoOferta, String loginVendedor, String loginVendedorOrig, String nomeVendedor,
			String nomeVendedorOrig, String canal, String canalOrig, String cnpjParceiro, String cnpjParceiroOrig,
			String custCode, String custCodeOrig, String position, String positionOrig, String parceiro,
			String parceiroOrig, String flgCancAntesVenda, String flgVendaSubmetida, String flgVendaDuplicada,
			String flgVendaBruta, String flgVendaLiquida, String flgGross, String flgChurn, String flgCancPosVenda,
			String flgCancDupl, String flgCancLiquido, String datGross, String datChurn, String motivoChurn,
			String tipoChurn, String datCancVenda, String motivoCancelamento, String nomeCliente, String telefone,
			String email, String uf, String tipoLogradouro, String logradouro, String numero, String complemento,
			String bairro, String cep, String cidade, String msanOltTrafego, String statusOrdem, String tecnologia,
			String formaPagamento, String tipoConta, String codBanco, String codAgenciaBanco, String codContaCorrente,
			String codDebitoAutomatico, String diaVencimento, String semanaVenda, String semanaVendaOrig, String score,
			String scoreConsumido, String datFinalizacaoOrdem, String qtdContratos, String codContaFinanceira,
			String numProtocolo, String flgOrdemAutomatica, String dscTxRecorrente, String dscTxNaoRecorrente,
			String dscStatusItem, String nomLoginResponsavel, String nomPlanoAtual, String valPlanoAtualItem,
			String nomDescontoAtualItem, String valDescontoAtualItem, String flgPortabilidade,
			String dscOperadoraDoadora, String codDdd, String numTelefonePortado, String datJanelaPortabilidade,
			String horJanela, String dscEnderecoFatura, String dscAreaVoip, String cpe, String ont,
			String codConvergente, String detalheRecusaCrivo, String itemRoot, String loginCancelamentoOrdem,
			String nomeUsuarioCancelouOrdem, String custcodeCliente, String dominioRoot, String datRefRelt) {

		this.datRef = datRef;
		this.datCriacaoOrdem = datCriacaoOrdem;
		this.horCriacaoOrdem = horCriacaoOrdem;
		this.datVenda = datVenda;
		this.horaVenda = horaVenda;
		this.datVendaOrig = datVendaOrig;
		this.horVendaOrig = horVendaOrig;
		this.datStatusOrdem = datStatusOrdem;
		this.horStatusOrdem = horStatusOrdem;
		this.numOrdemSiebel = numOrdemSiebel;
		this.numOrdemSiebelOrig = numOrdemSiebelOrig;
		this.codContratoOltp = codContratoOltp;
		this.codContratoAtivacao = codContratoAtivacao;
		this.codContratoAtual = codContratoAtual;
		this.numeroAcesso = numeroAcesso;
		this.customerId = customerId;
		this.tipoDocumento = tipoDocumento;
		this.documento = documento;
		this.tipoVenda = tipoVenda;
		this.tipoProduto = tipoProduto;
		this.velocidadeDownload = velocidadeDownload;
		this.velocidadeUpload = velocidadeUpload;
		this.planoAtivacaoOferta = planoAtivacaoOferta;
		this.loginVendedor = loginVendedor;
		this.loginVendedorOrig = loginVendedorOrig;
		this.nomeVendedor = nomeVendedor;
		this.nomeVendedorOrig = nomeVendedorOrig;
		this.canal = canal;
		this.canalOrig = canalOrig;
		this.cnpjParceiro = cnpjParceiro;
		this.cnpjParceiroOrig = cnpjParceiroOrig;
		this.custCode = custCode;
		this.custCodeOrig = custCodeOrig;
		this.position = position;
		this.positionOrig = positionOrig;
		this.parceiro = parceiro;
		this.parceiroOrig = parceiroOrig;
		this.flgCancAntesVenda = flgCancAntesVenda;
		this.flgVendaSubmetida = flgVendaSubmetida;
		this.flgVendaDuplicada = flgVendaDuplicada;
		this.flgVendaBruta = flgVendaBruta;
		this.flgVendaLiquida = flgVendaLiquida;
		this.flgGross = flgGross;
		this.flgChurn = flgChurn;
		this.flgCancPosVenda = flgCancPosVenda;
		this.flgCancDupl = flgCancDupl;
		this.flgCancLiquido = flgCancLiquido;
		this.datGross = datGross;
		this.datChurn = datChurn;
		this.motivoChurn = motivoChurn;
		this.tipoChurn = tipoChurn;
		this.datCancVenda = datCancVenda;
		this.motivoCancelamento = motivoCancelamento;
		this.nomeCliente = nomeCliente;
		this.telefone = telefone;
		this.email = email;
		this.uf = uf;
		this.tipoLogradouro = tipoLogradouro;
		this.logradouro = logradouro;
		this.numero = numero;
		this.complemento = complemento;
		this.bairro = bairro;
		this.cep = cep;
		this.cidade = cidade;
		this.msanOltTrafego = msanOltTrafego;
		this.statusOrdem = statusOrdem;
		this.tecnologia = tecnologia;
		this.formaPagamento = formaPagamento;
		this.tipoConta = tipoConta;
		this.codBanco = codBanco;
		this.codAgenciaBanco = codAgenciaBanco;
		this.codContaCorrente = codContaCorrente;
		this.codDebitoAutomatico = codDebitoAutomatico;
		this.diaVencimento = diaVencimento;
		this.semanaVenda = semanaVenda;
		this.semanaVendaOrig = semanaVendaOrig;
		this.score = score;
		this.scoreConsumido = scoreConsumido;
		this.datFinalizacaoOrdem = datFinalizacaoOrdem;
		this.qtdContratos = qtdContratos;
		this.codContaFinanceira = codContaFinanceira;
		this.numProtocolo = numProtocolo;
		this.flgOrdemAutomatica = flgOrdemAutomatica;
		this.dscTxRecorrente = dscTxRecorrente;
		this.dscTxNaoRecorrente = dscTxNaoRecorrente;
		this.dscStatusItem = dscStatusItem;
		this.nomLoginResponsavel = nomLoginResponsavel;
		this.nomPlanoAtual = nomPlanoAtual;
		this.valPlanoAtualItem = valPlanoAtualItem;
		this.nomDescontoAtualItem = nomDescontoAtualItem;
		this.valDescontoAtualItem = valDescontoAtualItem;
		this.flgPortabilidade = flgPortabilidade;
		this.dscOperadoraDoadora = dscOperadoraDoadora;
		this.codDdd = codDdd;
		this.numTelefonePortado = numTelefonePortado;
		this.datJanelaPortabilidade = datJanelaPortabilidade;
		this.horJanela = horJanela;
		this.dscEnderecoFatura = dscEnderecoFatura;
		this.dscAreaVoip = dscAreaVoip;
		this.cpe = cpe;
		this.ont = ont;
		this.codConvergente = codConvergente;
		this.detalheRecusaCrivo = detalheRecusaCrivo;
		this.itemRoot = itemRoot;
		this.loginCancelamentoOrdem = loginCancelamentoOrdem;
		this.nomeUsuarioCancelouOrdem = nomeUsuarioCancelouOrdem;
		this.custcodeCliente = custcodeCliente;
		this.dominioRoot = dominioRoot;
		this.datRefRelt = datRefRelt;

	}

	public boolean parse(String textString) {
		if (StringUtils.isNotBlank(textString)) {
			String[] cols = textString.split("\\|", -1);
			int i = 0;
			this.setStep9PT2Result(cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++]);
			return true;
		}
		return false;
	}

	public String getDatRef() {
		return datRef;
	}

	public void setDatRef(String datRef) {
		this.datRef = datRef;
	}

	public String getDatCriacaoOrdem() {
		return datCriacaoOrdem;
	}

	public void setDatCriacaoOrdem(String datCriacaoOrdem) {
		this.datCriacaoOrdem = datCriacaoOrdem;
	}

	public String getHorCriacaoOrdem() {
		return horCriacaoOrdem;
	}

	public void setHorCriacaoOrdem(String horCriacaoOrdem) {
		this.horCriacaoOrdem = horCriacaoOrdem;
	}

	public String getDatVenda() {
		return datVenda;
	}

	public void setDatVenda(String datVenda) {
		this.datVenda = datVenda;
	}

	public String getHoraVenda() {
		return horaVenda;
	}

	public void setHoraVenda(String horaVenda) {
		this.horaVenda = horaVenda;
	}

	public String getDatVendaOrig() {
		return datVendaOrig;
	}

	public void setDatVendaOrig(String datVendaOrig) {
		this.datVendaOrig = datVendaOrig;
	}

	public String getHorVendaOrig() {
		return horVendaOrig;
	}

	public void setHorVendaOrig(String horVendaOrig) {
		this.horVendaOrig = horVendaOrig;
	}

	public String getDatStatusOrdem() {
		return datStatusOrdem;
	}

	public void setDatStatusOrdem(String datStatusOrdem) {
		this.datStatusOrdem = datStatusOrdem;
	}

	public String getHorStatusOrdem() {
		return horStatusOrdem;
	}

	public void setHorStatusOrdem(String horStatusOrdem) {
		this.horStatusOrdem = horStatusOrdem;
	}

	public String getNumOrdemSiebel() {
		return numOrdemSiebel;
	}

	public void setNumOrdemSiebel(String numOrdemSiebel) {
		this.numOrdemSiebel = numOrdemSiebel;
	}

	public String getNumOrdemSiebelOrig() {
		return numOrdemSiebelOrig;
	}

	public void setNumOrdemSiebelOrig(String numOrdemSiebelOrig) {
		this.numOrdemSiebelOrig = numOrdemSiebelOrig;
	}

	public String getCodContratoOltp() {
		return codContratoOltp;
	}

	public void setCodContratoOltp(String codContratoOltp) {
		this.codContratoOltp = codContratoOltp;
	}

	public String getCodContratoAtivacao() {
		return codContratoAtivacao;
	}

	public void setCodContratoAtivacao(String codContratoAtivacao) {
		this.codContratoAtivacao = codContratoAtivacao;
	}

	public String getCodContratoAtual() {
		return codContratoAtual;
	}

	public void setCodContratoAtual(String codContratoAtual) {
		this.codContratoAtual = codContratoAtual;
	}

	public String getNumeroAcesso() {
		return numeroAcesso;
	}

	public void setNumeroAcesso(String numeroAcesso) {
		this.numeroAcesso = numeroAcesso;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public String getDocumento() {
		return documento;
	}

	public void setDocumento(String documento) {
		this.documento = documento;
	}

	public String getTipoVenda() {
		return tipoVenda;
	}

	public void setTipoVenda(String tipoVenda) {
		this.tipoVenda = tipoVenda;
	}

	public String getTipoProduto() {
		return tipoProduto;
	}

	public void setTipoProduto(String tipoProduto) {
		this.tipoProduto = tipoProduto;
	}

	public String getVelocidadeDownload() {
		return velocidadeDownload;
	}

	public void setVelocidadeDownload(String velocidadeDownload) {
		this.velocidadeDownload = velocidadeDownload;
	}

	public String getVelocidadeUpload() {
		return velocidadeUpload;
	}

	public void setVelocidadeUpload(String velocidadeUpload) {
		this.velocidadeUpload = velocidadeUpload;
	}

	public String getPlanoAtivacaoOferta() {
		return planoAtivacaoOferta;
	}

	public void setPlanoAtivacaoOferta(String planoAtivacaoOferta) {
		this.planoAtivacaoOferta = planoAtivacaoOferta;
	}

	public String getLoginVendedor() {
		return loginVendedor;
	}

	public void setLoginVendedor(String loginVendedor) {
		this.loginVendedor = loginVendedor;
	}

	public String getLoginVendedorOrig() {
		return loginVendedorOrig;
	}

	public void setLoginVendedorOrig(String loginVendedorOrig) {
		this.loginVendedorOrig = loginVendedorOrig;
	}

	public String getNomeVendedor() {
		return nomeVendedor;
	}

	public void setNomeVendedor(String nomeVendedor) {
		this.nomeVendedor = nomeVendedor;
	}

	public String getNomeVendedorOrig() {
		return nomeVendedorOrig;
	}

	public void setNomeVendedorOrig(String nomeVendedorOrig) {
		this.nomeVendedorOrig = nomeVendedorOrig;
	}

	public String getCanal() {
		return canal;
	}

	public void setCanal(String canal) {
		this.canal = canal;
	}

	public String getCanalOrig() {
		return canalOrig;
	}

	public void setCanalOrig(String canalOrig) {
		this.canalOrig = canalOrig;
	}

	public String getCnpjParceiro() {
		return cnpjParceiro;
	}

	public void setCnpjParceiro(String cnpjParceiro) {
		this.cnpjParceiro = cnpjParceiro;
	}

	public String getCnpjParceiroOrig() {
		return cnpjParceiroOrig;
	}

	public void setCnpjParceiroOrig(String cnpjParceiroOrig) {
		this.cnpjParceiroOrig = cnpjParceiroOrig;
	}

	public String getCustCode() {
		return custCode;
	}

	public void setCustCode(String custCode) {
		this.custCode = custCode;
	}

	public String getCustCodeOrig() {
		return custCodeOrig;
	}

	public void setCustCodeOrig(String custCodeOrig) {
		this.custCodeOrig = custCodeOrig;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getPositionOrig() {
		return positionOrig;
	}

	public void setPositionOrig(String positionOrig) {
		this.positionOrig = positionOrig;
	}

	public String getParceiro() {
		return parceiro;
	}

	public void setParceiro(String parceiro) {
		this.parceiro = parceiro;
	}

	public String getParceiroOrig() {
		return parceiroOrig;
	}

	public void setParceiroOrig(String parceiroOrig) {
		this.parceiroOrig = parceiroOrig;
	}

	public String getFlgCancAntesVenda() {
		return flgCancAntesVenda;
	}

	public void setFlgCancAntesVenda(String flgCancAntesVenda) {
		this.flgCancAntesVenda = flgCancAntesVenda;
	}

	public String getFlgVendaSubmetida() {
		return flgVendaSubmetida;
	}

	public void setFlgVendaSubmetida(String flgVendaSubmetida) {
		this.flgVendaSubmetida = flgVendaSubmetida;
	}

	public String getFlgVendaDuplicada() {
		return flgVendaDuplicada;
	}

	public void setFlgVendaDuplicada(String flgVendaDuplicada) {
		this.flgVendaDuplicada = flgVendaDuplicada;
	}

	public String getFlgVendaBruta() {
		return flgVendaBruta;
	}

	public void setFlgVendaBruta(String flgVendaBruta) {
		this.flgVendaBruta = flgVendaBruta;
	}

	public String getFlgVendaLiquida() {
		return flgVendaLiquida;
	}

	public void setFlgVendaLiquida(String flgVendaLiquida) {
		this.flgVendaLiquida = flgVendaLiquida;
	}

	public String getFlgGross() {
		return flgGross;
	}

	public void setFlgGross(String flgGross) {
		this.flgGross = flgGross;
	}

	public String getFlgChurn() {
		return flgChurn;
	}

	public void setFlgChurn(String flgChurn) {
		this.flgChurn = flgChurn;
	}

	public String getFlgCancPosVenda() {
		return flgCancPosVenda;
	}

	public void setFlgCancPosVenda(String flgCancPosVenda) {
		this.flgCancPosVenda = flgCancPosVenda;
	}

	public String getFlgCancDupl() {
		return flgCancDupl;
	}

	public void setFlgCancDupl(String flgCancDupl) {
		this.flgCancDupl = flgCancDupl;
	}

	public String getFlgCancLiquido() {
		return flgCancLiquido;
	}

	public void setFlgCancLiquido(String flgCancLiquido) {
		this.flgCancLiquido = flgCancLiquido;
	}

	public String getDatGross() {
		return datGross;
	}

	public void setDatGross(String datGross) {
		this.datGross = datGross;
	}

	public String getDatChurn() {
		return datChurn;
	}

	public void setDatChurn(String datChurn) {
		this.datChurn = datChurn;
	}

	public String getMotivoChurn() {
		return motivoChurn;
	}

	public void setMotivoChurn(String motivoChurn) {
		this.motivoChurn = motivoChurn;
	}

	public String getTipoChurn() {
		return tipoChurn;
	}

	public void setTipoChurn(String tipoChurn) {
		this.tipoChurn = tipoChurn;
	}

	public String getDatCancVenda() {
		return datCancVenda;
	}

	public void setDatCancVenda(String datCancVenda) {
		this.datCancVenda = datCancVenda;
	}

	public String getMotivoCancelamento() {
		return motivoCancelamento;
	}

	public void setMotivoCancelamento(String motivoCancelamento) {
		this.motivoCancelamento = motivoCancelamento;
	}

	public String getNomeCliente() {
		return nomeCliente;
	}

	public void setNomeCliente(String nomeCliente) {
		this.nomeCliente = nomeCliente;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	public String getTipoLogradouro() {
		return tipoLogradouro;
	}

	public void setTipoLogradouro(String tipoLogradouro) {
		this.tipoLogradouro = tipoLogradouro;
	}

	public String getLogradouro() {
		return logradouro;
	}

	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getComplemento() {
		return complemento;
	}

	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getMsanOltTrafego() {
		return msanOltTrafego;
	}

	public void setMsanOltTrafego(String msanOltTrafego) {
		this.msanOltTrafego = msanOltTrafego;
	}

	public String getStatusOrdem() {
		return statusOrdem;
	}

	public void setStatusOrdem(String statusOrdem) {
		this.statusOrdem = statusOrdem;
	}

	public String getTecnologia() {
		return tecnologia;
	}

	public void setTecnologia(String tecnologia) {
		this.tecnologia = tecnologia;
	}

	public String getFormaPagamento() {
		return formaPagamento;
	}

	public void setFormaPagamento(String formaPagamento) {
		this.formaPagamento = formaPagamento;
	}

	public String getTipoConta() {
		return tipoConta;
	}

	public void setTipoConta(String tipoConta) {
		this.tipoConta = tipoConta;
	}

	public String getCodBanco() {
		return codBanco;
	}

	public void setCodBanco(String codBanco) {
		this.codBanco = codBanco;
	}

	public String getCodAgenciaBanco() {
		return codAgenciaBanco;
	}

	public void setCodAgenciaBanco(String codAgenciaBanco) {
		this.codAgenciaBanco = codAgenciaBanco;
	}

	public String getCodContaCorrente() {
		return codContaCorrente;
	}

	public void setCodContaCorrente(String codContaCorrente) {
		this.codContaCorrente = codContaCorrente;
	}

	public String getCodDebitoAutomatico() {
		return codDebitoAutomatico;
	}

	public void setCodDebitoAutomatico(String codDebitoAutomatico) {
		this.codDebitoAutomatico = codDebitoAutomatico;
	}

	public String getDiaVencimento() {
		return diaVencimento;
	}

	public void setDiaVencimento(String diaVencimento) {
		this.diaVencimento = diaVencimento;
	}

	public String getSemanaVenda() {
		return semanaVenda;
	}

	public void setSemanaVenda(String semanaVenda) {
		this.semanaVenda = semanaVenda;
	}

	public String getSemanaVendaOrig() {
		return semanaVendaOrig;
	}

	public void setSemanaVendaOrig(String semanaVendaOrig) {
		this.semanaVendaOrig = semanaVendaOrig;
	}

	public String getScore() {
		return score;
	}

	public void setScore(String score) {
		this.score = score;
	}

	public String getScoreConsumido() {
		return scoreConsumido;
	}

	public void setScoreConsumido(String scoreConsumido) {
		this.scoreConsumido = scoreConsumido;
	}

	public String getDatFinalizacaoOrdem() {
		return datFinalizacaoOrdem;
	}

	public void setDatFinalizacaoOrdem(String datFinalizacaoOrdem) {
		this.datFinalizacaoOrdem = datFinalizacaoOrdem;
	}

	public String getQtdContratos() {
		return qtdContratos;
	}

	public void setQtdContratos(String qtdContratos) {
		this.qtdContratos = qtdContratos;
	}

	public String getCodContaFinanceira() {
		return codContaFinanceira;
	}

	public void setCodContaFinanceira(String codContaFinanceira) {
		this.codContaFinanceira = codContaFinanceira;
	}

	public String getNumProtocolo() {
		return numProtocolo;
	}

	public void setNumProtocolo(String numProtocolo) {
		this.numProtocolo = numProtocolo;
	}

	public String getFlgOrdemAutomatica() {
		return flgOrdemAutomatica;
	}

	public void setFlgOrdemAutomatica(String flgOrdemAutomatica) {
		this.flgOrdemAutomatica = flgOrdemAutomatica;
	}

	public String getDscTxRecorrente() {
		return dscTxRecorrente;
	}

	public void setDscTxRecorrente(String dscTxRecorrente) {
		this.dscTxRecorrente = dscTxRecorrente;
	}

	public String getDscTxNaoRecorrente() {
		return dscTxNaoRecorrente;
	}

	public void setDscTxNaoRecorrente(String dscTxNaoRecorrente) {
		this.dscTxNaoRecorrente = dscTxNaoRecorrente;
	}

	public String getDscStatusItem() {
		return dscStatusItem;
	}

	public void setDscStatusItem(String dscStatusItem) {
		this.dscStatusItem = dscStatusItem;
	}

	public String getNomLoginResponsavel() {
		return nomLoginResponsavel;
	}

	public void setNomLoginResponsavel(String nomLoginResponsavel) {
		this.nomLoginResponsavel = nomLoginResponsavel;
	}

	public String getNomPlanoAtual() {
		return nomPlanoAtual;
	}

	public void setNomPlanoAtual(String nomPlanoAtual) {
		this.nomPlanoAtual = nomPlanoAtual;
	}

	public String getValPlanoAtualItem() {
		return valPlanoAtualItem;
	}

	public void setValPlanoAtualItem(String valPlanoAtualItem) {
		this.valPlanoAtualItem = valPlanoAtualItem;
	}

	public String getNomDescontoAtualItem() {
		return nomDescontoAtualItem;
	}

	public void setNomDescontoAtualItem(String nomDescontoAtualItem) {
		this.nomDescontoAtualItem = nomDescontoAtualItem;
	}

	public String getValDescontoAtualItem() {
		return valDescontoAtualItem;
	}

	public void setValDescontoAtualItem(String valDescontoAtualItem) {
		this.valDescontoAtualItem = valDescontoAtualItem;
	}

	public String getFlgPortabilidade() {
		return flgPortabilidade;
	}

	public void setFlgPortabilidade(String flgPortabilidade) {
		this.flgPortabilidade = flgPortabilidade;
	}

	public String getDscOperadoraDoadora() {
		return dscOperadoraDoadora;
	}

	public void setDscOperadoraDoadora(String dscOperadoraDoadora) {
		this.dscOperadoraDoadora = dscOperadoraDoadora;
	}

	public String getCodDdd() {
		return codDdd;
	}

	public void setCodDdd(String codDdd) {
		this.codDdd = codDdd;
	}

	public String getNumTelefonePortado() {
		return numTelefonePortado;
	}

	public void setNumTelefonePortado(String numTelefonePortado) {
		this.numTelefonePortado = numTelefonePortado;
	}

	public String getDatJanelaPortabilidade() {
		return datJanelaPortabilidade;
	}

	public void setDatJanelaPortabilidade(String datJanelaPortabilidade) {
		this.datJanelaPortabilidade = datJanelaPortabilidade;
	}

	public String getHorJanela() {
		return horJanela;
	}

	public void setHorJanela(String horJanela) {
		this.horJanela = horJanela;
	}

	public String getDscEnderecoFatura() {
		return dscEnderecoFatura;
	}

	public void setDscEnderecoFatura(String dscEnderecoFatura) {
		this.dscEnderecoFatura = dscEnderecoFatura;
	}

	public String getDscAreaVoip() {
		return dscAreaVoip;
	}

	public void setDscAreaVoip(String dscAreaVoip) {
		this.dscAreaVoip = dscAreaVoip;
	}

	public String getCpe() {
		return cpe;
	}

	public void setCpe(String cpe) {
		this.cpe = cpe;
	}

	public String getOnt() {
		return ont;
	}

	public void setOnt(String ont) {
		this.ont = ont;
	}

	public String getCodConvergente() {
		return codConvergente;
	}

	public void setCodConvergente(String codConvergente) {
		this.codConvergente = codConvergente;
	}

	public String getDetalheRecusaCrivo() {
		return detalheRecusaCrivo;
	}

	public void setDetalheRecusaCrivo(String detalheRecusaCrivo) {
		this.detalheRecusaCrivo = detalheRecusaCrivo;
	}

	public String getItemRoot() {
		return itemRoot;
	}

	public void setItemRoot(String itemRoot) {
		this.itemRoot = itemRoot;
	}

	public String getLoginCancelamentoOrdem() {
		return loginCancelamentoOrdem;
	}

	public void setLoginCancelamentoOrdem(String loginCancelamentoOrdem) {
		this.loginCancelamentoOrdem = loginCancelamentoOrdem;
	}

	public String getNomeUsuarioCancelouOrdem() {
		return nomeUsuarioCancelouOrdem;
	}

	public void setNomeUsuarioCancelouOrdem(String nomeUsuarioCancelouOrdem) {
		this.nomeUsuarioCancelouOrdem = nomeUsuarioCancelouOrdem;
	}

	public String getCustcodeCliente() {
		return custcodeCliente;
	}

	public void setCustcodeCliente(String custcodeCliente) {
		this.custcodeCliente = custcodeCliente;
	}

	public String getDominioRoot() {
		return dominioRoot;
	}

	public void setDominioRoot(String dominioRoot) {
		this.dominioRoot = dominioRoot;
	}

	public String getDatRefRelt() {
		return datRefRelt;
	}

	public void setDatRefRelt(String datRefRelt) {
		this.datRefRelt = datRefRelt;
	}

}
