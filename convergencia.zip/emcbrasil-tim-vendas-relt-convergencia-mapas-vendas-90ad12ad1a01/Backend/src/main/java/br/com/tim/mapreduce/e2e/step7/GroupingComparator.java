package br.com.tim.mapreduce.e2e.step7;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

public class GroupingComparator extends WritableComparator {

    public GroupingComparator() {
        super(E2EStep7Key.class, true);
    }

    @SuppressWarnings({"rawtypes"})
    @Override
    public int compare(WritableComparable a, WritableComparable b) {
        E2EStep7Key keyA = (E2EStep7Key) a;
        E2EStep7Key keyB = (E2EStep7Key) b;

        return keyA.compareToGrouping(keyB);
    }

}
