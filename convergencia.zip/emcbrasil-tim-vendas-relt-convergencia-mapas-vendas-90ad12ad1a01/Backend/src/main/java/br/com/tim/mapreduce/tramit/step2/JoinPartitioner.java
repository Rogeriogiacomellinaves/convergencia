package br.com.tim.mapreduce.tramit.step2;

import org.apache.hadoop.mapreduce.Partitioner;

public class JoinPartitioner extends Partitioner<TramitStep2Key, TramitStep2Value> {

    @Override
    public int getPartition(TramitStep2Key taggedKey, TramitStep2Value value, int numPartitions) {
        return Math.abs(taggedKey.hashCodeJoin() % numPartitions);
    }
}