package br.com.tim.mapreduce.refactoring.model;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

import com.google.common.base.Strings;

import br.com.tim.mapreduce.refactoring.endtoend.step1.pt2.enums.OrderEnum;
import br.com.tim.utils.CommonsConstants;

public class BAT509Order implements Writable{

    private String rowId;
    private String loteId;
    private String arquivo;
    private String arquivoTs;
    private String currentDate;
    private String numeroOrdem;
    private String numeroCliente;
    private String statusOrdem;
    private String dataCriacaoOrdem;
    private String dataVenda;
    private String dataStatusOrdem;
    private String tipoOrdem;
    private String subTipoOrdem;
    private String flagVendaLiquida;
    private String codigoOrdemOriginal;
    private String dataVendaOriginal;
    private String procurador;
    private String nomeContato;
    private String cpf;
    private String scoreCliente;
    private String scoreConsumido;
    private String saldoScore;
    private String scoreConsumidoOrdem;
    private String totalTaxasRecorrentes;
    private String totalTaxasNaoRecorrentes;
    private String totalTaxas;
    private String numeroContratos;
    private String loginResponsavel;
    private String canalCriacaoOrdem;
    private String loginVendedor;
    private String canalVenda;
    private String cnpjParceiroVenda;
    private String nomeParceiroVenda;
    private String msanReserva;
    private String msanInstalacao;
    private String motivoCancelamentoOrdem;
    private String loginCancelamentoOrdem;
    private String motivoRecusaCrivo;
    private String motivoRecusaSGF;
    private String usuarioLinha;
    private String statusOrdemWFM;
    private String nomeCliente;
    private String codigoContrato;
    private String datafinalizacaoOrdem;
    private String telefoneContato1;
    private String telefoneContato2;
    private String telefoneContato3;
    private String numeroOrdemAMDOCS;
    private String statusAlcada;
    private String dataStatusAlcada;
    private String chaveCrivo;
    private String limiteAparelho;
    private String limiteAparelhoConsumido;
    private String valorAparelhoOrdem;
    private String saldoLimiteAparelho;
    private String custcodePDV;
    private String canalEntrada;
    private String numeroBpTim;
    private String customerId;
    private String campanha;
    private String perfilLogin;
    private String ruaEntrega;
    private String numeroEntrega;
    private String complementoEntrega;
    private String cepEntrega;
    private String bairroEntrega;
    private String estadoEntrega;
    private String cidadeEntrega;
    private String alteracaoEndereco;
    private String pessoaAutorizada1;
    private String pessoaAutorizada2;
    private String pessoaAutorizada3;
    private String idContrato;
    private String matriculaResponsavel;
    private String cpfVendedor;
    private String codDsf;
    private String canal;
    private String regional;
    private String uf;
    private String nomeFantasia;
    private String tipoOrdemOrigem;
    private String ufEnderecoWttx;
    private String cidadeEnderecoWttx;
    private String cepEnderecoWttx;
    private String bairroEnderecoWttx;
    private String tipoLogEnderecoWttx;
    private String logEnderecoWttx;
    private String numLogEnderecoWttx;
    private String complementoLogEnderecoWttx;
    private String flgConvergente;
    private String dscMelhorOferta;
    private String accntId;

    public BAT509Order() {
        this.clean();
    }

    public BAT509Order(String rowId, String loteId, String arquivo, String arquivoTs, String currentDate, String numeroOrdem, String numeroCliente, String statusOrdem, String dataCriacaoOrdem, String dataVenda, String dataStatusOrdem, String tipoOrdem, String subTipoOrdem, String flagVendaLiquida, String codigoOrdemOriginal, String dataVendaOriginal, String procurador, String nomeContato, String cpf, String scoreCliente, String scoreConsumido, String saldoScore, String scoreConsumidoOrdem, String totalTaxasRecorrentes, String totalTaxasNaoRecorrentes, String totalTaxas, String numeroContratos, String loginResponsavel, String canalCriacaoOrdem, String loginVendedor, String canalVenda, String cnpjParceiroVenda, String nomeParceiroVenda, String msanReserva, String msanInstalacao, String motivoCancelamentoOrdem, String loginCancelamentoOrdem, String motivoRecusaCrivo, String motivoRecusaSGF, String usuarioLinha, String statusOrdemWFM, String nomeCliente, String codigoContrato, String datafinalizacaoOrdem, String telefoneContato1, String telefoneContato2, String telefoneContato3, String numeroOrdemAMDOCS, String statusAlcada, String dataStatusAlcada, String chaveCrivo, String limiteAparelho, String limiteAparelhoConsumido, String valorAparelhoOrdem, String saldoLimiteAparelho, String custcodePDV, String canalEntrada, String numeroBpTim, String customerId, String campanha, String perfilLogin, String ruaEntrega, String numeroEntrega, String complementoEntrega, String cepEntrega, String bairroEntrega, String estadoEntrega, String cidadeEntrega, String alteracaoEndereco, String pessoaAutorizada1, String pessoaAutorizada2, String pessoaAutorizada3, String idContrato, String matriculaResponsavel, String cpfVendedor, String codDsf, String canal, String regional, String uf, String nomeFantasia, String tipoOrdemOrigem, String ufEnderecoWttx, String cidadeEnderecoWttx, String cepEnderecoWttx, String bairroEnderecoWttx, String tipoLogEnderecoWttx, String logEnderecoWttx, String numLogEnderecoWttx, String complementoLogEnderecoWttx, String flgConvergente, String dscMelhorOferta, String accntId) {
        this.rowId = rowId;
        this.loteId = loteId;
        this.arquivo = arquivo;
        this.arquivoTs = arquivoTs;
        this.currentDate = currentDate;
        this.numeroOrdem = numeroOrdem;
        this.numeroCliente = numeroCliente;
        this.statusOrdem = statusOrdem;
        this.dataCriacaoOrdem = dataCriacaoOrdem;
        this.dataVenda = dataVenda;
        this.dataStatusOrdem = dataStatusOrdem;
        this.tipoOrdem = tipoOrdem;
        this.subTipoOrdem = subTipoOrdem;
        this.flagVendaLiquida = flagVendaLiquida;
        this.codigoOrdemOriginal = codigoOrdemOriginal;
        this.dataVendaOriginal = dataVendaOriginal;
        this.procurador = procurador;
        this.nomeContato = nomeContato;
        this.cpf = cpf;
        this.scoreCliente = scoreCliente;
        this.scoreConsumido = scoreConsumido;
        this.saldoScore = saldoScore;
        this.scoreConsumidoOrdem = scoreConsumidoOrdem;
        this.totalTaxasRecorrentes = totalTaxasRecorrentes;
        this.totalTaxasNaoRecorrentes = totalTaxasNaoRecorrentes;
        this.totalTaxas = totalTaxas;
        this.numeroContratos = numeroContratos;
        this.loginResponsavel = loginResponsavel;
        this.canalCriacaoOrdem = canalCriacaoOrdem;
        this.loginVendedor = loginVendedor;
        this.canalVenda = canalVenda;
        this.cnpjParceiroVenda = cnpjParceiroVenda;
        this.nomeParceiroVenda = nomeParceiroVenda;
        this.msanReserva = msanReserva;
        this.msanInstalacao = msanInstalacao;
        this.motivoCancelamentoOrdem = motivoCancelamentoOrdem;
        this.loginCancelamentoOrdem = loginCancelamentoOrdem;
        this.motivoRecusaCrivo = motivoRecusaCrivo;
        this.motivoRecusaSGF = motivoRecusaSGF;
        this.usuarioLinha = usuarioLinha;
        this.statusOrdemWFM = statusOrdemWFM;
        this.nomeCliente = nomeCliente;
        this.codigoContrato = codigoContrato;
        this.datafinalizacaoOrdem = datafinalizacaoOrdem;
        this.telefoneContato1 = telefoneContato1;
        this.telefoneContato2 = telefoneContato2;
        this.telefoneContato3 = telefoneContato3;
        this.numeroOrdemAMDOCS = numeroOrdemAMDOCS;
        this.statusAlcada = statusAlcada;
        this.dataStatusAlcada = dataStatusAlcada;
        this.chaveCrivo = chaveCrivo;
        this.limiteAparelho = limiteAparelho;
        this.limiteAparelhoConsumido = limiteAparelhoConsumido;
        this.valorAparelhoOrdem = valorAparelhoOrdem;
        this.saldoLimiteAparelho = saldoLimiteAparelho;
        this.custcodePDV = custcodePDV;
        this.canalEntrada = canalEntrada;
        this.numeroBpTim = numeroBpTim;
        this.customerId = customerId;
        this.campanha = campanha;
        this.perfilLogin = perfilLogin;
        this.ruaEntrega = ruaEntrega;
        this.numeroEntrega = numeroEntrega;
        this.complementoEntrega = complementoEntrega;
        this.cepEntrega = cepEntrega;
        this.bairroEntrega = bairroEntrega;
        this.estadoEntrega = estadoEntrega;
        this.cidadeEntrega = cidadeEntrega;
        this.alteracaoEndereco = alteracaoEndereco;
        this.pessoaAutorizada1 = pessoaAutorizada1;
        this.pessoaAutorizada2 = pessoaAutorizada2;
        this.pessoaAutorizada3 = pessoaAutorizada3;
        this.idContrato = idContrato;
        this.matriculaResponsavel = matriculaResponsavel;
        this.cpfVendedor = cpfVendedor;
        this.codDsf = codDsf;
        this.canal = canal;
        this.regional = regional;
        this.uf = uf;
        this.nomeFantasia = nomeFantasia;
        this.tipoOrdemOrigem = tipoOrdemOrigem;
        this.ufEnderecoWttx = ufEnderecoWttx;
        this.cidadeEnderecoWttx = cidadeEnderecoWttx;
        this.cepEnderecoWttx = cepEnderecoWttx;
        this.bairroEnderecoWttx = bairroEnderecoWttx;
        this.tipoLogEnderecoWttx = tipoLogEnderecoWttx;
        this.logEnderecoWttx = logEnderecoWttx;
        this.numLogEnderecoWttx = numLogEnderecoWttx;
        this.complementoLogEnderecoWttx = complementoLogEnderecoWttx;
        this.flgConvergente = flgConvergente;
        this.dscMelhorOferta = dscMelhorOferta;
        this.accntId = accntId;
    }

    public void parseFromText(Text text) {
		this.clean();

		if (!Strings.isNullOrEmpty(text.toString())) {

			String[] line = text.toString().split(CommonsConstants.FILE_SPLIT_REGEX, -1);

			if (line.length > 0) {
                this.rowId = line[OrderEnum.rowId.ordinal()].trim();
                this.loteId = line[OrderEnum.loteId.ordinal()].trim();
                this.arquivo = line[OrderEnum.arquivo.ordinal()].trim();
                this.arquivoTs = line[OrderEnum.arquivoTs.ordinal()].trim();
                this.currentDate = line[OrderEnum.currentDate.ordinal()].trim();
				this.numeroOrdem = line[OrderEnum.numeroOrdem.ordinal()].trim();
				this.numeroCliente = line[OrderEnum.numeroCliente.ordinal()].trim();
				this.statusOrdem = line[OrderEnum.statusOrdem.ordinal()].trim();
				this.dataCriacaoOrdem = line[OrderEnum.dataCriacaoOrdem.ordinal()].trim();
				this.dataVenda = line[OrderEnum.dataVenda.ordinal()].trim();
				this.dataStatusOrdem = line[OrderEnum.dataStatusOrdem.ordinal()].trim();
				this.tipoOrdem = line[OrderEnum.tipoOrdem.ordinal()].trim();
				this.subTipoOrdem = line[OrderEnum.subTipoOrdem.ordinal()].trim();
				this.flagVendaLiquida = line[OrderEnum.flagVendaLiquida.ordinal()].trim();
				this.codigoOrdemOriginal = line[OrderEnum.codigoOrdemOriginal.ordinal()].trim();
				this.dataVendaOriginal = line[OrderEnum.dataVendaOriginal.ordinal()].trim();
				this.procurador = line[OrderEnum.procurador.ordinal()].trim();
				this.nomeContato = line[OrderEnum.nomeContato.ordinal()].trim();
				this.cpf = line[OrderEnum.cpf.ordinal()].trim();
				this.scoreCliente = line[OrderEnum.scoreCliente.ordinal()].trim();
				this.scoreConsumido = line[OrderEnum.scoreConsumido.ordinal()].trim();
				this.saldoScore = line[OrderEnum.saldoScore.ordinal()].trim();
				this.scoreConsumidoOrdem = line[OrderEnum.scoreConsumidoOrdem.ordinal()].trim();
				this.totalTaxasRecorrentes = line[OrderEnum.totalTaxasRecorrentes.ordinal()].trim();
				this.totalTaxasNaoRecorrentes = line[OrderEnum.totalTaxasNaoRecorrentes.ordinal()].trim();
				this.totalTaxas = line[OrderEnum.totalTaxas.ordinal()].trim();
				this.numeroContratos = line[OrderEnum.numeroContratos.ordinal()].trim();
				this.loginResponsavel = line[OrderEnum.loginResponsavel.ordinal()].trim();
				this.canalCriacaoOrdem = line[OrderEnum.canalCriacaoOrdem.ordinal()].trim();
				this.loginVendedor = line[OrderEnum.loginVendedor.ordinal()].trim();
				this.canalVenda = line[OrderEnum.canalVenda.ordinal()].trim();
				this.cnpjParceiroVenda = line[OrderEnum.cnpjParceiroVenda.ordinal()].trim();
				this.nomeParceiroVenda = line[OrderEnum.nomeParceiroVenda.ordinal()].trim();
				this.msanReserva = line[OrderEnum.msanReserva.ordinal()].trim();
				this.msanInstalacao = line[OrderEnum.msanInstalacao.ordinal()].trim();
				this.motivoCancelamentoOrdem = line[OrderEnum.motivoCancelamentoOrdem.ordinal()].trim();
				this.loginCancelamentoOrdem = line[OrderEnum.loginCancelamentoOrdem.ordinal()].trim();
				this.motivoRecusaCrivo = line[OrderEnum.motivoRecusaCrivo.ordinal()].trim();
				this.motivoRecusaSGF = line[OrderEnum.motivoRecusaSGF.ordinal()].trim();
				this.usuarioLinha = line[OrderEnum.usuarioLinha.ordinal()].trim();
				this.statusOrdemWFM = line[OrderEnum.statusOrdemWFM.ordinal()].trim();
				this.nomeCliente = line[OrderEnum.nomeCliente.ordinal()].trim();
				this.codigoContrato = line[OrderEnum.codigoContrato.ordinal()].trim();
				this.datafinalizacaoOrdem = line[OrderEnum.datafinalizacaoOrdem.ordinal()].trim();
				this.telefoneContato1 = line[OrderEnum.telefoneContato1.ordinal()].trim();
				this.telefoneContato2 = line[OrderEnum.telefoneContato2.ordinal()].trim();
				this.telefoneContato3 = line[OrderEnum.telefoneContato3.ordinal()].trim();
				this.numeroOrdemAMDOCS = line[OrderEnum.numeroOrdemAMDOCS.ordinal()].trim();
				this.statusAlcada = line[OrderEnum.statusAlcada.ordinal()].trim();
				this.dataStatusAlcada = line[OrderEnum.dataStatusAlcada.ordinal()].trim();
				this.chaveCrivo = line[OrderEnum.chaveCrivo.ordinal()].trim();
				this.limiteAparelho = line[OrderEnum.limiteAparelho.ordinal()].trim();
				this.limiteAparelhoConsumido = line[OrderEnum.limiteAparelhoConsumido.ordinal()].trim();
				this.valorAparelhoOrdem = line[OrderEnum.valorAparelhoOrdem.ordinal()].trim();
				this.saldoLimiteAparelho = line[OrderEnum.saldoLimiteAparelho.ordinal()].trim();
				this.custcodePDV = line[OrderEnum.custcodePDV.ordinal()].trim();
				this.canalEntrada = line[OrderEnum.canalEntrada.ordinal()].trim();
				this.numeroBpTim = line[OrderEnum.numeroBpTim.ordinal()].trim();
				this.customerId = line[OrderEnum.customerId.ordinal()].trim();
				this.campanha = line[OrderEnum.campanha.ordinal()].trim();
				this.perfilLogin = line[OrderEnum.perfilLogin.ordinal()].trim();
				this.ruaEntrega = line[OrderEnum.ruaEntrega.ordinal()].trim();
				this.numeroEntrega = line[OrderEnum.numeroEntrega.ordinal()].trim();
				this.complementoEntrega = line[OrderEnum.complementoEntrega.ordinal()].trim();
				this.cepEntrega = line[OrderEnum.cepEntrega.ordinal()].trim();
				this.bairroEntrega = line[OrderEnum.bairroEntrega.ordinal()].trim();
				this.estadoEntrega = line[OrderEnum.estadoEntrega.ordinal()].trim();
				this.cidadeEntrega = line[OrderEnum.cidadeEntrega.ordinal()].trim();
				this.alteracaoEndereco = line[OrderEnum.alteracaoEndereco.ordinal()].trim();
				this.pessoaAutorizada1 = line[OrderEnum.pessoaAutorizada1.ordinal()].trim();
				this.pessoaAutorizada2 = line[OrderEnum.pessoaAutorizada2.ordinal()].trim();
				this.pessoaAutorizada3 = line[OrderEnum.pessoaAutorizada3.ordinal()].trim();
				this.idContrato = line[OrderEnum.idContrato.ordinal()].trim();
				this.matriculaResponsavel = line[OrderEnum.matriculaResponsavel.ordinal()].trim();
				this.cpfVendedor = line[OrderEnum.cpfVendedor.ordinal()].trim();
				this.codDsf = line[OrderEnum.codDsf.ordinal()].trim();
				this.canal = line[OrderEnum.canal.ordinal()].trim();
				this.regional = line[OrderEnum.regional.ordinal()].trim();
				this.uf = line[OrderEnum.uf.ordinal()].trim();
				this.nomeFantasia = line[OrderEnum.nomeFantasia.ordinal()].trim();
				this.tipoOrdemOrigem = line[OrderEnum.tipoOrdemOrigem.ordinal()].trim();
				this.ufEnderecoWttx = line[OrderEnum.ufEnderecoWttx.ordinal()].trim();
				this.cidadeEnderecoWttx = line[OrderEnum.CidadeEnderecoWttx.ordinal()].trim();
				this.cepEnderecoWttx = line[OrderEnum.CepEnderecoWttx.ordinal()].trim();
				this.bairroEnderecoWttx = line[OrderEnum.BairroEnderecoWttx.ordinal()].trim();
				this.tipoLogEnderecoWttx = line[OrderEnum.tipoLogEnderecoWttx.ordinal()].trim();
				this.logEnderecoWttx = line[OrderEnum.logEnderecoWttx.ordinal()].trim();
				this.numLogEnderecoWttx = line[OrderEnum.numLogEnderecoWttx.ordinal()].trim();
				this.complementoLogEnderecoWttx = line[OrderEnum.complementoLogEnderecoWttx.ordinal()].trim();
				this.flgConvergente = line[OrderEnum.flgConvergente.ordinal()].trim();
				this.dscMelhorOferta = line[OrderEnum.dscMelhorOferta.ordinal()].trim();
                this.accntId = line[OrderEnum.accntId.ordinal()].trim();
			}
		}
	}

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        String delimiter = "|";
        sb.append(numeroOrdem).append(delimiter)
          .append(numeroCliente).append(delimiter)
          .append(statusOrdem).append(delimiter)
          .append(dataCriacaoOrdem).append(delimiter)
          .append(dataVenda).append(delimiter)
          .append(dataStatusOrdem).append(delimiter)
          .append(tipoOrdem).append(delimiter)
          .append(subTipoOrdem).append(delimiter)
          .append(flagVendaLiquida).append(delimiter)
          .append(codigoOrdemOriginal).append(delimiter)
          .append(dataVendaOriginal).append(delimiter)
          .append(procurador).append(delimiter)
          .append(nomeContato).append(delimiter)
          .append(cpf).append(delimiter)
          .append(scoreCliente).append(delimiter)
          .append(scoreConsumido).append(delimiter)
          .append(saldoScore).append(delimiter)
          .append(scoreConsumidoOrdem).append(delimiter)
          .append(totalTaxasRecorrentes).append(delimiter)
          .append(totalTaxasNaoRecorrentes).append(delimiter)
          .append(totalTaxas).append(delimiter)
          .append(numeroContratos).append(delimiter)
          .append(loginResponsavel).append(delimiter)
          .append(canalCriacaoOrdem).append(delimiter)
          .append(loginVendedor).append(delimiter)
          .append(canalVenda).append(delimiter)
          .append(cnpjParceiroVenda).append(delimiter)
          .append(nomeParceiroVenda).append(delimiter)
          .append(msanReserva).append(delimiter)
          .append(msanInstalacao).append(delimiter)
          .append(motivoCancelamentoOrdem).append(delimiter)
          .append(loginCancelamentoOrdem).append(delimiter)
          .append(motivoRecusaCrivo).append(delimiter)
          .append(motivoRecusaSGF).append(delimiter)
          .append(usuarioLinha).append(delimiter)
          .append(statusOrdemWFM).append(delimiter)
          .append(nomeCliente).append(delimiter)
          .append(codigoContrato).append(delimiter)
          .append(datafinalizacaoOrdem).append(delimiter)
          .append(telefoneContato1).append(delimiter)
          .append(telefoneContato2).append(delimiter)
          .append(telefoneContato3).append(delimiter)
          .append(numeroOrdemAMDOCS).append(delimiter)
          .append(statusAlcada).append(delimiter)
          .append(dataStatusAlcada).append(delimiter)
          .append(chaveCrivo).append(delimiter)
          .append(limiteAparelho).append(delimiter)
          .append(limiteAparelhoConsumido).append(delimiter)
          .append(valorAparelhoOrdem).append(delimiter)
          .append(saldoLimiteAparelho).append(delimiter)
          .append(custcodePDV).append(delimiter)
          .append(canalEntrada).append(delimiter)
          .append(numeroBpTim).append(delimiter)
          .append(customerId).append(delimiter)
          .append(campanha).append(delimiter)
          .append(perfilLogin).append(delimiter)
          .append(ruaEntrega).append(delimiter)
          .append(numeroEntrega).append(delimiter)
          .append(complementoEntrega).append(delimiter)
          .append(cepEntrega).append(delimiter)
          .append(bairroEntrega).append(delimiter)
          .append(estadoEntrega).append(delimiter)
          .append(cidadeEntrega).append(delimiter)
          .append(alteracaoEndereco).append(delimiter)
          .append(pessoaAutorizada1).append(delimiter)
          .append(pessoaAutorizada2).append(delimiter)
          .append(pessoaAutorizada3).append(delimiter)
          .append(idContrato).append(delimiter)
          .append(matriculaResponsavel).append(delimiter)
          .append(cpfVendedor).append(delimiter)
          .append(rowId).append(delimiter)
          .append(loteId).append(delimiter)
          .append(arquivo).append(delimiter)
          .append(arquivoTs).append(delimiter)
          .append(currentDate).append(delimiter)
          .append(canal).append(delimiter)
          .append(regional).append(delimiter)
          .append(uf).append(delimiter)
          .append(nomeFantasia).append(delimiter)
          .append(tipoOrdemOrigem).append(delimiter)
          .append(ufEnderecoWttx).append(delimiter)
          .append(cidadeEnderecoWttx).append(delimiter)
          .append(cepEnderecoWttx).append(delimiter)
          .append(bairroEnderecoWttx).append(delimiter)
          .append(tipoLogEnderecoWttx).append(delimiter)
          .append(logEnderecoWttx).append(delimiter)
          .append(numLogEnderecoWttx).append(delimiter)
          .append(complementoLogEnderecoWttx).append(delimiter)
          .append(flgConvergente);

        return sb.toString();

    }
    
    public void clean () {
        this.rowId = CommonsConstants.EMPTY;
        this.loteId = CommonsConstants.EMPTY;
        this.arquivo = CommonsConstants.EMPTY;
        this.arquivoTs = CommonsConstants.EMPTY;
        this.currentDate = CommonsConstants.EMPTY;
    	this.numeroOrdem = CommonsConstants.EMPTY;
        this.numeroCliente = CommonsConstants.EMPTY;
        this.statusOrdem = CommonsConstants.EMPTY;
        this.dataCriacaoOrdem = CommonsConstants.EMPTY;
        this.dataVenda = CommonsConstants.EMPTY;
        this.dataStatusOrdem = CommonsConstants.EMPTY;
        this.tipoOrdem = CommonsConstants.EMPTY;
        this.subTipoOrdem = CommonsConstants.EMPTY;
        this.flagVendaLiquida = CommonsConstants.EMPTY;
        this.codigoOrdemOriginal = CommonsConstants.EMPTY;
        this.dataVendaOriginal = CommonsConstants.EMPTY;
        this.procurador = CommonsConstants.EMPTY;
        this.nomeContato = CommonsConstants.EMPTY;
        this.cpf = CommonsConstants.EMPTY;
        this.scoreCliente = CommonsConstants.EMPTY;
        this.scoreConsumido = CommonsConstants.EMPTY;
        this.saldoScore = CommonsConstants.EMPTY;
        this.scoreConsumidoOrdem = CommonsConstants.EMPTY;
        this.totalTaxasRecorrentes = CommonsConstants.EMPTY;
        this.totalTaxasNaoRecorrentes = CommonsConstants.EMPTY;
        this.totalTaxas = CommonsConstants.EMPTY;
        this.numeroContratos = CommonsConstants.EMPTY;
        this.loginResponsavel = CommonsConstants.EMPTY;
        this.canalCriacaoOrdem = CommonsConstants.EMPTY;
        this.loginVendedor = CommonsConstants.EMPTY;
        this.canalVenda = CommonsConstants.EMPTY;
        this.cnpjParceiroVenda = CommonsConstants.EMPTY;
        this.nomeParceiroVenda = CommonsConstants.EMPTY;
        this.msanReserva = CommonsConstants.EMPTY;
        this.msanInstalacao = CommonsConstants.EMPTY;
        this.motivoCancelamentoOrdem = CommonsConstants.EMPTY;
        this.loginCancelamentoOrdem = CommonsConstants.EMPTY;
        this.motivoRecusaCrivo = CommonsConstants.EMPTY;
        this.motivoRecusaSGF = CommonsConstants.EMPTY;
        this.usuarioLinha = CommonsConstants.EMPTY;
        this.statusOrdemWFM = CommonsConstants.EMPTY;
        this.nomeCliente = CommonsConstants.EMPTY;
        this.codigoContrato = CommonsConstants.EMPTY;
        this.datafinalizacaoOrdem = CommonsConstants.EMPTY;
        this.telefoneContato1 = CommonsConstants.EMPTY;
        this.telefoneContato2 = CommonsConstants.EMPTY;
        this.telefoneContato3 = CommonsConstants.EMPTY;
        this.numeroOrdemAMDOCS = CommonsConstants.EMPTY;
        this.statusAlcada = CommonsConstants.EMPTY;
        this.dataStatusAlcada = CommonsConstants.EMPTY;
        this.chaveCrivo = CommonsConstants.EMPTY;
        this.limiteAparelho = CommonsConstants.EMPTY;
        this.limiteAparelhoConsumido = CommonsConstants.EMPTY;
        this.valorAparelhoOrdem = CommonsConstants.EMPTY;
        this.saldoLimiteAparelho = CommonsConstants.EMPTY;
        this.custcodePDV = CommonsConstants.EMPTY;
        this.canalEntrada = CommonsConstants.EMPTY;
        this.numeroBpTim = CommonsConstants.EMPTY;
        this.customerId = CommonsConstants.EMPTY;
        this.campanha = CommonsConstants.EMPTY;
        this.perfilLogin = CommonsConstants.EMPTY;
        this.ruaEntrega = CommonsConstants.EMPTY;
        this.numeroEntrega = CommonsConstants.EMPTY;
        this.complementoEntrega = CommonsConstants.EMPTY;
        this.cepEntrega = CommonsConstants.EMPTY;
        this.bairroEntrega = CommonsConstants.EMPTY;
        this.estadoEntrega = CommonsConstants.EMPTY;
        this.cidadeEntrega = CommonsConstants.EMPTY;
        this.alteracaoEndereco = CommonsConstants.EMPTY;
        this.pessoaAutorizada1 = CommonsConstants.EMPTY;
        this.pessoaAutorizada2 = CommonsConstants.EMPTY;
        this.pessoaAutorizada3 = CommonsConstants.EMPTY;
        this.idContrato = CommonsConstants.EMPTY;
        this.matriculaResponsavel = CommonsConstants.EMPTY;
        this.cpfVendedor = CommonsConstants.EMPTY;
        this.codDsf = CommonsConstants.EMPTY;
        this.canal = CommonsConstants.EMPTY;
        this.regional = CommonsConstants.EMPTY;
        this.uf = CommonsConstants.EMPTY;
        this.nomeFantasia = CommonsConstants.EMPTY;
        this.tipoOrdemOrigem = CommonsConstants.EMPTY;
        this.ufEnderecoWttx = CommonsConstants.EMPTY;
        this.cidadeEnderecoWttx = CommonsConstants.EMPTY;
        this.cepEnderecoWttx = CommonsConstants.EMPTY;
        this.bairroEnderecoWttx = CommonsConstants.EMPTY;
        this.tipoLogEnderecoWttx = CommonsConstants.EMPTY;
        this.logEnderecoWttx = CommonsConstants.EMPTY;
        this.numLogEnderecoWttx = CommonsConstants.EMPTY;
        this.complementoLogEnderecoWttx = CommonsConstants.EMPTY;
        this.flgConvergente = CommonsConstants.EMPTY;
        this.dscMelhorOferta = CommonsConstants.EMPTY;
        this.accntId = CommonsConstants.EMPTY;
    }

    public String getRowId() {
        return rowId;
    }

    public void setRowId(String rowId) {
        this.rowId = rowId;
    }

    public String getLoteId() {
        return loteId;
    }

    public void setLoteId(String loteId) {
        this.loteId = loteId;
    }

    public String getArquivo() {
        return arquivo;
    }

    public void setArquivo(String arquivo) {
        this.arquivo = arquivo;
    }

    public String getArquivoTs() {
        return arquivoTs;
    }

    public void setArquivoTs(String arquivoTs) {
        this.arquivoTs = arquivoTs;
    }

    public String getCurrentDate() {
        return currentDate;
    }

    public void setCurrentDate(String currentDate) {
        this.currentDate = currentDate;
    }

    public String getNumeroOrdem() {
        return numeroOrdem;
    }

    public void setNumeroOrdem(String numeroOrdem) {
        this.numeroOrdem = numeroOrdem;
    }

    public String getNumeroCliente() {
        return numeroCliente;
    }

    public void setNumeroCliente(String numeroCliente) {
        this.numeroCliente = numeroCliente;
    }

    public String getStatusOrdem() {
        return statusOrdem;
    }

    public void setStatusOrdem(String statusOrdem) {
        this.statusOrdem = statusOrdem;
    }

    public String getDataCriacaoOrdem() {
        return dataCriacaoOrdem;
    }

    public void setDataCriacaoOrdem(String dataCriacaoOrdem) {
        this.dataCriacaoOrdem = dataCriacaoOrdem;
    }

    public String getDataVenda() {
        return dataVenda;
    }

    public void setDataVenda(String dataVenda) {
        this.dataVenda = dataVenda;
    }

    public String getDataStatusOrdem() {
        return dataStatusOrdem;
    }

    public void setDataStatusOrdem(String dataStatusOrdem) {
        this.dataStatusOrdem = dataStatusOrdem;
    }

    public String getTipoOrdem() {
        return tipoOrdem;
    }

    public void setTipoOrdem(String tipoOrdem) {
        this.tipoOrdem = tipoOrdem;
    }

    public String getSubTipoOrdem() {
        return subTipoOrdem;
    }

    public void setSubTipoOrdem(String subTipoOrdem) {
        this.subTipoOrdem = subTipoOrdem;
    }

    public String getFlagVendaLiquida() {
        return flagVendaLiquida;
    }

    public void setFlagVendaLiquida(String flagVendaLiquida) {
        this.flagVendaLiquida = flagVendaLiquida;
    }

    public String getCodigoOrdemOriginal() {
        return codigoOrdemOriginal;
    }

    public void setCodigoOrdemOriginal(String codigoOrdemOriginal) {
        this.codigoOrdemOriginal = codigoOrdemOriginal;
    }

    public String getDataVendaOriginal() {
        return dataVendaOriginal;
    }

    public void setDataVendaOriginal(String dataVendaOriginal) {
        this.dataVendaOriginal = dataVendaOriginal;
    }

    public String getProcurador() {
        return procurador;
    }

    public void setProcurador(String procurador) {
        this.procurador = procurador;
    }

    public String getNomeContato() {
        return nomeContato;
    }

    public void setNomeContato(String nomeContato) {
        this.nomeContato = nomeContato;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getScoreCliente() {
        return scoreCliente;
    }

    public void setScoreCliente(String scoreCliente) {
        this.scoreCliente = scoreCliente;
    }

    public String getScoreConsumido() {
        return scoreConsumido;
    }

    public void setScoreConsumido(String scoreConsumido) {
        this.scoreConsumido = scoreConsumido;
    }

    public String getSaldoScore() {
        return saldoScore;
    }

    public void setSaldoScore(String saldoScore) {
        this.saldoScore = saldoScore;
    }

    public String getScoreConsumidoOrdem() {
        return scoreConsumidoOrdem;
    }

    public void setScoreConsumidoOrdem(String scoreConsumidoOrdem) {
        this.scoreConsumidoOrdem = scoreConsumidoOrdem;
    }

    public String getTotalTaxasRecorrentes() {
        return totalTaxasRecorrentes;
    }

    public void setTotalTaxasRecorrentes(String totalTaxasRecorrentes) {
        this.totalTaxasRecorrentes = totalTaxasRecorrentes;
    }

    public String getTotalTaxasNaoRecorrentes() {
        return totalTaxasNaoRecorrentes;
    }

    public void setTotalTaxasNaoRecorrentes(String totalTaxasNaoRecorrentes) {
        this.totalTaxasNaoRecorrentes = totalTaxasNaoRecorrentes;
    }

    public String getTotalTaxas() {
        return totalTaxas;
    }

    public void setTotalTaxas(String totalTaxas) {
        this.totalTaxas = totalTaxas;
    }

    public String getNumeroContratos() {
        return numeroContratos;
    }

    public void setNumeroContratos(String numeroContratos) {
        this.numeroContratos = numeroContratos;
    }

    public String getLoginResponsavel() {
        return loginResponsavel;
    }

    public void setLoginResponsavel(String loginResponsavel) {
        this.loginResponsavel = loginResponsavel;
    }

    public String getCanalCriacaoOrdem() {
        return canalCriacaoOrdem;
    }

    public void setCanalCriacaoOrdem(String canalCriacaoOrdem) {
        this.canalCriacaoOrdem = canalCriacaoOrdem;
    }

    public String getLoginVendedor() {
        return loginVendedor;
    }

    public void setLoginVendedor(String loginVendedor) {
        this.loginVendedor = loginVendedor;
    }

    public String getCanalVenda() {
        return canalVenda;
    }

    public void setCanalVenda(String canalVenda) {
        this.canalVenda = canalVenda;
    }

    public String getCnpjParceiroVenda() {
        return cnpjParceiroVenda;
    }

    public void setCnpjParceiroVenda(String cnpjParceiroVenda) {
        this.cnpjParceiroVenda = cnpjParceiroVenda;
    }

    public String getNomeParceiroVenda() {
        return nomeParceiroVenda;
    }

    public void setNomeParceiroVenda(String nomeParceiroVenda) {
        this.nomeParceiroVenda = nomeParceiroVenda;
    }

    public String getMsanReserva() {
        return msanReserva;
    }

    public void setMsanReserva(String msanReserva) {
        this.msanReserva = msanReserva;
    }

    public String getMsanInstalacao() {
        return msanInstalacao;
    }

    public void setMsanInstalacao(String msanInstalacao) {
        this.msanInstalacao = msanInstalacao;
    }

    public String getMotivoCancelamentoOrdem() {
        return motivoCancelamentoOrdem;
    }

    public void setMotivoCancelamentoOrdem(String motivoCancelamentoOrdem) {
        this.motivoCancelamentoOrdem = motivoCancelamentoOrdem;
    }

    public String getLoginCancelamentoOrdem() {
        return loginCancelamentoOrdem;
    }

    public void setLoginCancelamentoOrdem(String loginCancelamentoOrdem) {
        this.loginCancelamentoOrdem = loginCancelamentoOrdem;
    }

    public String getMotivoRecusaCrivo() {
        return motivoRecusaCrivo;
    }

    public void setMotivoRecusaCrivo(String motivoRecusaCrivo) {
        this.motivoRecusaCrivo = motivoRecusaCrivo;
    }

    public String getMotivoRecusaSGF() {
        return motivoRecusaSGF;
    }

    public void setMotivoRecusaSGF(String motivoRecusaSGF) {
        this.motivoRecusaSGF = motivoRecusaSGF;
    }

    public String getUsuarioLinha() {
        return usuarioLinha;
    }

    public void setUsuarioLinha(String usuarioLinha) {
        this.usuarioLinha = usuarioLinha;
    }

    public String getStatusOrdemWFM() {
        return statusOrdemWFM;
    }

    public void setStatusOrdemWFM(String statusOrdemWFM) {
        this.statusOrdemWFM = statusOrdemWFM;
    }

    public String getNomeCliente() {
        return nomeCliente;
    }

    public void setNomeCliente(String nomeCliente) {
        this.nomeCliente = nomeCliente;
    }

    public String getCodigoContrato() {
        return codigoContrato;
    }

    public void setCodigoContrato(String codigoContrato) {
        this.codigoContrato = codigoContrato;
    }

    public String getDatafinalizacaoOrdem() {
        return datafinalizacaoOrdem;
    }

    public void setDatafinalizacaoOrdem(String datafinalizacaoOrdem) {
        this.datafinalizacaoOrdem = datafinalizacaoOrdem;
    }

    public String getTelefoneContato1() {
        return telefoneContato1;
    }

    public void setTelefoneContato1(String telefoneContato1) {
        this.telefoneContato1 = telefoneContato1;
    }

    public String getTelefoneContato2() {
        return telefoneContato2;
    }

    public void setTelefoneContato2(String telefoneContato2) {
        this.telefoneContato2 = telefoneContato2;
    }

    public String getTelefoneContato3() {
        return telefoneContato3;
    }

    public void setTelefoneContato3(String telefoneContato3) {
        this.telefoneContato3 = telefoneContato3;
    }

    public String getNumeroOrdemAMDOCS() {
        return numeroOrdemAMDOCS;
    }

    public void setNumeroOrdemAMDOCS(String numeroOrdemAMDOCS) {
        this.numeroOrdemAMDOCS = numeroOrdemAMDOCS;
    }

    public String getStatusAlcada() {
        return statusAlcada;
    }

    public void setStatusAlcada(String statusAlcada) {
        this.statusAlcada = statusAlcada;
    }

    public String getDataStatusAlcada() {
        return dataStatusAlcada;
    }

    public void setDataStatusAlcada(String dataStatusAlcada) {
        this.dataStatusAlcada = dataStatusAlcada;
    }

    public String getChaveCrivo() {
        return chaveCrivo;
    }

    public void setChaveCrivo(String chaveCrivo) {
        this.chaveCrivo = chaveCrivo;
    }

    public String getLimiteAparelho() {
        return limiteAparelho;
    }

    public void setLimiteAparelho(String limiteAparelho) {
        this.limiteAparelho = limiteAparelho;
    }

    public String getLimiteAparelhoConsumido() {
        return limiteAparelhoConsumido;
    }

    public void setLimiteAparelhoConsumido(String limiteAparelhoConsumido) {
        this.limiteAparelhoConsumido = limiteAparelhoConsumido;
    }

    public String getValorAparelhoOrdem() {
        return valorAparelhoOrdem;
    }

    public void setValorAparelhoOrdem(String valorAparelhoOrdem) {
        this.valorAparelhoOrdem = valorAparelhoOrdem;
    }

    public String getSaldoLimiteAparelho() {
        return saldoLimiteAparelho;
    }

    public void setSaldoLimiteAparelho(String saldoLimiteAparelho) {
        this.saldoLimiteAparelho = saldoLimiteAparelho;
    }

    public String getCustcodePDV() {
        return custcodePDV;
    }

    public void setCustcodePDV(String custcodePDV) {
        this.custcodePDV = custcodePDV;
    }

    public String getCanalEntrada() {
        return canalEntrada;
    }

    public void setCanalEntrada(String canalEntrada) {
        this.canalEntrada = canalEntrada;
    }

    public String getNumeroBpTim() {
        return numeroBpTim;
    }

    public void setNumeroBpTim(String numeroBpTim) {
        this.numeroBpTim = numeroBpTim;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getCampanha() {
        return campanha;
    }

    public void setCampanha(String campanha) {
        this.campanha = campanha;
    }

    public String getPerfilLogin() {
        return perfilLogin;
    }

    public void setPerfilLogin(String perfilLogin) {
        this.perfilLogin = perfilLogin;
    }

    public String getRuaEntrega() {
        return ruaEntrega;
    }

    public void setRuaEntrega(String ruaEntrega) {
        this.ruaEntrega = ruaEntrega;
    }

    public String getNumeroEntrega() {
        return numeroEntrega;
    }

    public void setNumeroEntrega(String numeroEntrega) {
        this.numeroEntrega = numeroEntrega;
    }

    public String getComplementoEntrega() {
        return complementoEntrega;
    }

    public void setComplementoEntrega(String complementoEntrega) {
        this.complementoEntrega = complementoEntrega;
    }

    public String getCepEntrega() {
        return cepEntrega;
    }

    public void setCepEntrega(String cepEntrega) {
        this.cepEntrega = cepEntrega;
    }

    public String getBairroEntrega() {
        return bairroEntrega;
    }

    public void setBairroEntrega(String bairroEntrega) {
        this.bairroEntrega = bairroEntrega;
    }

    public String getEstadoEntrega() {
        return estadoEntrega;
    }

    public void setEstadoEntrega(String estadoEntrega) {
        this.estadoEntrega = estadoEntrega;
    }

    public String getCidadeEntrega() {
        return cidadeEntrega;
    }

    public void setCidadeEntrega(String cidadeEntrega) {
        this.cidadeEntrega = cidadeEntrega;
    }

    public String getAlteracaoEndereco() {
        return alteracaoEndereco;
    }

    public void setAlteracaoEndereco(String alteracaoEndereco) {
        this.alteracaoEndereco = alteracaoEndereco;
    }

    public String getPessoaAutorizada1() {
        return pessoaAutorizada1;
    }

    public void setPessoaAutorizada1(String pessoaAutorizada1) {
        this.pessoaAutorizada1 = pessoaAutorizada1;
    }

    public String getPessoaAutorizada2() {
        return pessoaAutorizada2;
    }

    public void setPessoaAutorizada2(String pessoaAutorizada2) {
        this.pessoaAutorizada2 = pessoaAutorizada2;
    }

    public String getPessoaAutorizada3() {
        return pessoaAutorizada3;
    }

    public void setPessoaAutorizada3(String pessoaAutorizada3) {
        this.pessoaAutorizada3 = pessoaAutorizada3;
    }

    public String getIdContrato() {
        return idContrato;
    }

    public void setIdContrato(String idContrato) {
        this.idContrato = idContrato;
    }

    public String getMatriculaResponsavel() {
        return matriculaResponsavel;
    }

    public void setMatriculaResponsavel(String matriculaResponsavel) {
        this.matriculaResponsavel = matriculaResponsavel;
    }

    public String getCpfVendedor() {
        return cpfVendedor;
    }

    public void setCpfVendedor(String cpfVendedor) {
        this.cpfVendedor = cpfVendedor;
    }

    public String getCodDsf() {
        return codDsf;
    }

    public void setCodDsf(String codDsf) {
        this.codDsf = codDsf;
    }

    public String getCanal() {
        return canal;
    }

    public void setCanal(String canal) {
        this.canal = canal;
    }

    public String getRegional() {
        return regional;
    }

    public void setRegional(String regional) {
        this.regional = regional;
    }

    public String getUf() {
        return uf;
    }

    public void setUf(String uf) {
        this.uf = uf;
    }

    public String getNomeFantasia() {
        return nomeFantasia;
    }

    public void setNomeFantasia(String nomeFantasia) {
        this.nomeFantasia = nomeFantasia;
    }

    public String getTipoOrdemOrigem() {
        return tipoOrdemOrigem;
    }

    public void setTipoOrdemOrigem(String tipoOrdemOrigem) {
        this.tipoOrdemOrigem = tipoOrdemOrigem;
    }

    public String getUfEnderecoWttx() {
        return ufEnderecoWttx;
    }

    public void setUfEnderecoWttx(String ufEnderecoWttx) {
        this.ufEnderecoWttx = ufEnderecoWttx;
    }

    public String getCidadeEnderecoWttx() {
        return cidadeEnderecoWttx;
    }

    public void setCidadeEnderecoWttx(String cidadeEnderecoWttx) {
        this.cidadeEnderecoWttx = cidadeEnderecoWttx;
    }

    public String getCepEnderecoWttx() {
        return cepEnderecoWttx;
    }

    public void setCepEnderecoWttx(String cepEnderecoWttx) {
        this.cepEnderecoWttx = cepEnderecoWttx;
    }

    public String getBairroEnderecoWttx() {
        return bairroEnderecoWttx;
    }

    public void setBairroEnderecoWttx(String bairroEnderecoWttx) {
        this.bairroEnderecoWttx = bairroEnderecoWttx;
    }

    public String getTipoLogEnderecoWttx() {
        return tipoLogEnderecoWttx;
    }

    public void setTipoLogEnderecoWttx(String tipoLogEnderecoWttx) {
        this.tipoLogEnderecoWttx = tipoLogEnderecoWttx;
    }

    public String getLogEnderecoWttx() {
        return logEnderecoWttx;
    }

    public void setLogEnderecoWttx(String logEnderecoWttx) {
        this.logEnderecoWttx = logEnderecoWttx;
    }

    public String getNumLogEnderecoWttx() {
        return numLogEnderecoWttx;
    }

    public void setNumLogEnderecoWttx(String numLogEnderecoWttx) {
        this.numLogEnderecoWttx = numLogEnderecoWttx;
    }

    public String getComplementoLogEnderecoWttx() {
        return complementoLogEnderecoWttx;
    }

    public void setComplementoLogEnderecoWttx(String complementoLogEnderecoWttx) {
        this.complementoLogEnderecoWttx = complementoLogEnderecoWttx;
    }

    public String getFlgConvergente() {
        return flgConvergente;
    }

    public void setFlgConvergente(String flgConvergente) {
        this.flgConvergente = flgConvergente;
    }

    public String getDscMelhorOferta() {
        return dscMelhorOferta;
    }

    public void setDscMelhorOferta(String dscMelhorOferta) {
        this.dscMelhorOferta = dscMelhorOferta;
    }

    public String getAccntId() {
        return accntId;
    }

    public void setAccntId(String accntId) {
        this.accntId = accntId;
    }

    @Override
	public void write(DataOutput out) throws IOException {
        out.writeUTF(this.rowId);
        out.writeUTF(this.loteId);
        out.writeUTF(this.arquivo);
        out.writeUTF(this.arquivoTs);
        out.writeUTF(this.currentDate);
		out.writeUTF(this.numeroOrdem);
		out.writeUTF(this.numeroCliente);
		out.writeUTF(this.statusOrdem);
		out.writeUTF(this.dataCriacaoOrdem);
		out.writeUTF(this.dataVenda);
		out.writeUTF(this.dataStatusOrdem);
		out.writeUTF(this.tipoOrdem);
		out.writeUTF(this.subTipoOrdem);
		out.writeUTF(this.flagVendaLiquida);
		out.writeUTF(this.codigoOrdemOriginal);
		out.writeUTF(this.dataVendaOriginal);
		out.writeUTF(this.procurador);
		out.writeUTF(this.nomeContato);
		out.writeUTF(this.cpf);
		out.writeUTF(this.scoreCliente);
		out.writeUTF(this.scoreConsumido);
		out.writeUTF(this.saldoScore);
		out.writeUTF(this.scoreConsumidoOrdem);
		out.writeUTF(this.totalTaxasRecorrentes);
		out.writeUTF(this.totalTaxasNaoRecorrentes);
		out.writeUTF(this.totalTaxas);
		out.writeUTF(this.numeroContratos);
		out.writeUTF(this.loginResponsavel);
		out.writeUTF(this.canalCriacaoOrdem);
		out.writeUTF(this.loginVendedor);
		out.writeUTF(this.canalVenda);
		out.writeUTF(this.cnpjParceiroVenda);
		out.writeUTF(this.nomeParceiroVenda);
		out.writeUTF(this.msanReserva);
		out.writeUTF(this.msanInstalacao);
		out.writeUTF(this.motivoCancelamentoOrdem);
		out.writeUTF(this.loginCancelamentoOrdem);
		out.writeUTF(this.motivoRecusaCrivo);
		out.writeUTF(this.motivoRecusaSGF);
		out.writeUTF(this.usuarioLinha);
		out.writeUTF(this.statusOrdemWFM);
		out.writeUTF(this.nomeCliente);
		out.writeUTF(this.codigoContrato);
		out.writeUTF(this.datafinalizacaoOrdem);
		out.writeUTF(this.telefoneContato1);
		out.writeUTF(this.telefoneContato2);
		out.writeUTF(this.telefoneContato3);
		out.writeUTF(this.numeroOrdemAMDOCS);
		out.writeUTF(this.statusAlcada);
		out.writeUTF(this.dataStatusAlcada);
		out.writeUTF(this.chaveCrivo);
		out.writeUTF(this.limiteAparelho);
		out.writeUTF(this.limiteAparelhoConsumido);
		out.writeUTF(this.valorAparelhoOrdem);
		out.writeUTF(this.saldoLimiteAparelho);
		out.writeUTF(this.custcodePDV);
		out.writeUTF(this.canalEntrada);
		out.writeUTF(this.numeroBpTim);
		out.writeUTF(this.customerId);
		out.writeUTF(this.campanha);
		out.writeUTF(this.perfilLogin);
		out.writeUTF(this.ruaEntrega);
		out.writeUTF(this.numeroEntrega);
		out.writeUTF(this.complementoEntrega);
		out.writeUTF(this.cepEntrega);
		out.writeUTF(this.bairroEntrega);
		out.writeUTF(this.estadoEntrega);
		out.writeUTF(this.cidadeEntrega);
		out.writeUTF(this.alteracaoEndereco);
		out.writeUTF(this.pessoaAutorizada1);
		out.writeUTF(this.pessoaAutorizada2);
		out.writeUTF(this.pessoaAutorizada3);
		out.writeUTF(this.idContrato);
		out.writeUTF(this.matriculaResponsavel);
		out.writeUTF(this.cpfVendedor);
		out.writeUTF(this.codDsf);
		out.writeUTF(this.canal);
		out.writeUTF(this.regional);
		out.writeUTF(this.uf);
		out.writeUTF(this.nomeFantasia);
		out.writeUTF(this.tipoOrdemOrigem);
		out.writeUTF(this.ufEnderecoWttx);
		out.writeUTF(this.cidadeEnderecoWttx);
		out.writeUTF(this.cepEnderecoWttx);
		out.writeUTF(this.bairroEnderecoWttx);
		out.writeUTF(this.tipoLogEnderecoWttx);
		out.writeUTF(this.logEnderecoWttx);
		out.writeUTF(this.numLogEnderecoWttx);
		out.writeUTF(this.complementoLogEnderecoWttx);
		out.writeUTF(this.flgConvergente);
		out.writeUTF(this.dscMelhorOferta);
        out.writeUTF(this.accntId);
	}

	@Override
	public void readFields(DataInput in) throws IOException {
        this.rowId = in.readUTF();
        this.loteId = in.readUTF();
        this.arquivo = in.readUTF();
        this.arquivoTs = in.readUTF();
        this.currentDate = in.readUTF();
		this.numeroOrdem = in.readUTF();
		this.numeroCliente = in.readUTF();
		this.statusOrdem = in.readUTF();
		this.dataCriacaoOrdem = in.readUTF();
		this.dataVenda = in.readUTF();
		this.dataStatusOrdem = in.readUTF();
		this.tipoOrdem = in.readUTF();
		this.subTipoOrdem = in.readUTF();
		this.flagVendaLiquida = in.readUTF();
		this.codigoOrdemOriginal = in.readUTF();
		this.dataVendaOriginal = in.readUTF();
		this.procurador = in.readUTF();
		this.nomeContato = in.readUTF();
		this.cpf = in.readUTF();
		this.scoreCliente = in.readUTF();
		this.scoreConsumido = in.readUTF();
		this.saldoScore = in.readUTF();
		this.scoreConsumidoOrdem = in.readUTF();
		this.totalTaxasRecorrentes = in.readUTF();
		this.totalTaxasNaoRecorrentes = in.readUTF();
		this.totalTaxas = in.readUTF();
		this.numeroContratos = in.readUTF();
		this.loginResponsavel = in.readUTF();
		this.canalCriacaoOrdem = in.readUTF();
		this.loginVendedor = in.readUTF();
		this.canalVenda = in.readUTF();
		this.cnpjParceiroVenda = in.readUTF();
		this.nomeParceiroVenda = in.readUTF();
		this.msanReserva = in.readUTF();
		this.msanInstalacao = in.readUTF();
		this.motivoCancelamentoOrdem = in.readUTF();
		this.loginCancelamentoOrdem = in.readUTF();
		this.motivoRecusaCrivo = in.readUTF();
		this.motivoRecusaSGF = in.readUTF();
		this.usuarioLinha = in.readUTF();
		this.statusOrdemWFM = in.readUTF();
		this.nomeCliente = in.readUTF();
		this.codigoContrato = in.readUTF();
		this.datafinalizacaoOrdem = in.readUTF();
		this.telefoneContato1 = in.readUTF();
		this.telefoneContato2 = in.readUTF();
		this.telefoneContato3 = in.readUTF();
		this.numeroOrdemAMDOCS = in.readUTF();
		this.statusAlcada = in.readUTF();
		this.dataStatusAlcada = in.readUTF();
		this.chaveCrivo = in.readUTF();
		this.limiteAparelho = in.readUTF();
		this.limiteAparelhoConsumido = in.readUTF();
		this.valorAparelhoOrdem = in.readUTF();
		this.saldoLimiteAparelho = in.readUTF();
		this.custcodePDV = in.readUTF();
		this.canalEntrada = in.readUTF();
		this.numeroBpTim = in.readUTF();
		this.customerId = in.readUTF();
		this.campanha = in.readUTF();
		this.perfilLogin = in.readUTF();
		this.ruaEntrega = in.readUTF();
		this.numeroEntrega = in.readUTF();
		this.complementoEntrega = in.readUTF();
		this.cepEntrega = in.readUTF();
		this.bairroEntrega = in.readUTF();
		this.estadoEntrega = in.readUTF();
		this.cidadeEntrega = in.readUTF();
		this.alteracaoEndereco = in.readUTF();
		this.pessoaAutorizada1 = in.readUTF();
		this.pessoaAutorizada2 = in.readUTF();
		this.pessoaAutorizada3 = in.readUTF();
		this.idContrato = in.readUTF();
		this.matriculaResponsavel = in.readUTF();
		this.cpfVendedor = in.readUTF();
		this.codDsf = in.readUTF();
		this.canal = in.readUTF();
		this.regional = in.readUTF();
		this.uf = in.readUTF();
		this.nomeFantasia = in.readUTF();
		this.tipoOrdemOrigem = in.readUTF();
		this.ufEnderecoWttx = in.readUTF();
		this.cidadeEnderecoWttx = in.readUTF();
		this.cepEnderecoWttx = in.readUTF();
		this.bairroEnderecoWttx = in.readUTF();
		this.tipoLogEnderecoWttx = in.readUTF();
		this.logEnderecoWttx = in.readUTF();
		this.numLogEnderecoWttx = in.readUTF();
		this.complementoLogEnderecoWttx = in.readUTF();
		this.flgConvergente = in.readUTF();
		this.dscMelhorOferta = in.readUTF();
		this.accntId = in.readUTF();
	}
}
