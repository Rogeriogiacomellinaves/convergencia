package br.com.tim.mapreduce.itemordem.step2;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

public class GroupingComparator extends WritableComparator {

    public GroupingComparator() {
        super(IOStep2Key.class, true);
    }

    @SuppressWarnings({"rawtypes"})
    @Override
    public int compare(WritableComparable a, WritableComparable b) {
        IOStep2Key keyA = (IOStep2Key) a;
        IOStep2Key keyB = (IOStep2Key) b;

        return keyA.compareToGrouping(keyB);
    }

}
