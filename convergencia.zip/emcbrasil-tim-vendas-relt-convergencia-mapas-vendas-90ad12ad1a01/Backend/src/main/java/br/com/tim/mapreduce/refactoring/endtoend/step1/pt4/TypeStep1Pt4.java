package br.com.tim.mapreduce.refactoring.endtoend.step1.pt4;

public enum TypeStep1Pt4 {

    Fiber, RELT
}
