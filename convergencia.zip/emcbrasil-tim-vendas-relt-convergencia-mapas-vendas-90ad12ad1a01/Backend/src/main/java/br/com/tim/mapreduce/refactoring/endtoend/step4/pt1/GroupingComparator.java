package br.com.tim.mapreduce.refactoring.endtoend.step4.pt1;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;


public class GroupingComparator extends WritableComparator{
	
	public GroupingComparator() {
		super(Step4Key.class, true);
	}

	
    @SuppressWarnings({"rawtypes"})
    @Override
    public int compare(WritableComparable a, WritableComparable b) {
    	Step4Key keyA = (Step4Key) a;
    	Step4Key keyB = (Step4Key) b;

        return keyA.compareToGrouping(keyB);
    }

}
