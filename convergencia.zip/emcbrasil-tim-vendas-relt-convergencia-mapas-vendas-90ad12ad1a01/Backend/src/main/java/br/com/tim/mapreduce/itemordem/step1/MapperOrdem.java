package br.com.tim.mapreduce.itemordem.step1;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

import br.com.tim.mapreduce.model.BAT509Order;
import br.com.tim.mr.utils.TaggedKey;

public class MapperOrdem extends org.apache.hadoop.mapreduce.Mapper<Writable,Text,TaggedKey,IOStep1Value> {

	private TaggedKey outkey;
	private IOStep1Value outValue;
	private BAT509Order input;
	@Override
	protected void map(Writable key, Text value, Context context) throws IOException, InterruptedException {
		input.parse(value.toString());
		outValue.setOrdem(input);
		outkey.set(input.getNumeroOrdem(), 0);
		context.write(outkey,outValue);

	}

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		super.setup(context);
		this.outkey = new TaggedKey();
		this.outValue = new IOStep1Value();
		this.input = new BAT509Order();
	}

	@Override
	protected void cleanup(Context context) throws IOException, InterruptedException {
		super.cleanup(context);
		this.clear();
	}

	private void clear(){
	   this.outValue.clear();
	}

}