package br.com.tim.mapreduce.e2e.step5;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

public class GroupingComparator extends WritableComparator {

    public GroupingComparator() {
        super(E2EStep5Key.class, true);
    }

    @SuppressWarnings({"rawtypes"})
    @Override
    public int compare(WritableComparable a, WritableComparable b) {
        E2EStep5Key keyA = (E2EStep5Key) a;
        E2EStep5Key keyB = (E2EStep5Key) b;

        return keyA.compareToGrouping(keyB);
    }

}
