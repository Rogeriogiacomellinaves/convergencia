package br.com.tim.mapreduce.refactoring.endtoend.step6.pt1;

import java.time.LocalDate;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import br.com.tim.driverutils.DriverUtils;
import br.com.tim.driverutils.Entry;
import br.com.tim.exception.CommonsException;
import br.com.tim.kerberos.KerberosAuth;
import br.com.tim.kerberos.KerberosAuthException;
import br.com.tim.mapreduce.refactoring.endtoend.step6.utils.Step6Constants;
import br.com.tim.metric.JobMetric;
import br.com.tim.metric.JobMetricHelper;
import br.com.tim.metric.MetricConstants;
import br.com.tim.mr.GenericMetricsDriver;
import br.com.tim.utils.CommonsConstants;
import br.com.tim.utils.PropertiesConfig;

public class Step6Driver extends GenericMetricsDriver{
	
	private static Logger log = Logger.getLogger(Step6Driver.class);
	private Configuration conf;
	private String[] args;
	private FileSystem fs;
	private String stagingPath;
	private static java.time.format.DateTimeFormatter dtf = java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private String dat_ref;

    
    
    public Step6Driver(String args[]) {
    	
    	this.args = args;
    	
    }
    
    
    public static void main(String[] args) throws Exception {
    	
		log.info("============================== BEGIN STEP 4 pt4 - duplicações JOB ======================================");
		Step6Driver driver = new Step6Driver(args);
		int exitCode = ToolRunner.run(driver, args);
		log.info("Exit code: " + exitCode);
		log.info("=============================== END STEP 4 pt4 - duplicações JOB =======================================");
		System.exit(exitCode);
    	
    }
    
	protected Job job1;

	
	protected JobMetric metrics = null;
	private int retorno = CommonsConstants.ERROR;

	public String timeExecution;
	public LocalDate dateRef;
    
    
	public int run(String[] arg) throws Exception {

		Date inicio = new Date();
		try {

			if (!PropertiesConfig.systemPropertiesValidate()) {
				if (StringUtils.isEmpty(System.getProperty(CommonsConstants.LOG4J_CONFIGURATION)))
					System.err.println("System property: " + CommonsConstants.LOG4J_CONFIGURATION + " is not set.");
				if (StringUtils.isEmpty(System.getProperty(CommonsConstants.PROJECT_CONFIGURATION)))
					System.err.println("System property: " + CommonsConstants.PROJECT_CONFIGURATION + " is not set.");
				if (StringUtils.isEmpty(System.getProperty(CommonsConstants.ENVIRONMENT_CONFIGURATION)))
					System.err.println("System property: " + CommonsConstants.ENVIRONMENT_CONFIGURATION + " is not set.");
				System.exit(CommonsConstants.ERROR);
			}

			PropertyConfigurator.configure(System.getProperty(CommonsConstants.LOG4J_CONFIGURATION));

			Configuration conf = getConf();
			conf.addResource(new Path(System.getProperty(CommonsConstants.ENVIRONMENT_CONFIGURATION)));
			conf.addResource(new Path(System.getProperty(MetricConstants.JOB_METRICS_CONFIGURATION)));
			conf.addResource(new Path(System.getProperty(CommonsConstants.PROJECT_CONFIGURATION)));
			

			// Kerberos Authentication MapReduce
			try {
				KerberosAuth.authenticate(conf);
			} catch (KerberosAuthException e) {
				throw new Exception(e);
			}

			
			/* ====== CONFIGURE STEP 1 ====== */
            this.job1 = Job.getInstance(conf);
			configureStep2pt1();

			log.info("=============  FIM DO CONFIGURE ==================");
			// Create metrics file
			String metricsFilePath = System.getProperty(MetricConstants.GENERIC_FILE_METRICS_DEFINITION);
			String customMetrics = System.getProperty(MetricConstants.CUSTOM_FILE_METRICS_DEFINITION);

			// create JobMetric main job
			if (customMetrics != null)
				metrics = new JobMetric(conf, metricsFilePath, customMetrics);
			else
				metrics = new JobMetric(conf, metricsFilePath);

			if (job1.waitForCompletion(true) && job1.isSuccessful()) {

				log.info("===== Job Finished SUCCESSFULY =====");
				Thread.sleep(Long.valueOf(conf.get(MetricConstants.MILLIS_TO_WAIT)));

				log.info("======================== Running post processing steps... =================================");
				postExecutionSteps();
				retorno = CommonsConstants.SUCCESS;
				log.info("===== Saving Job Metrics ======");
				JobMetricHelper.generateMetrics(this.job1, this.getStagingPath(), metrics);

			} else {
				// Roll back actions in case of any problem during the process.
				log.info("===== ROLLING BACK ======");
				rollback();
				log.info("===== Saving Job Metrics ======");
				JobMetricHelper.generateMetrics(this.job1, this.getStagingPath(), metrics);
			}

		} catch (Exception e) {
			log.error("Generic error executing driver... ", e);
			log.info("===== Saving Job Metrics ======");
			JobMetricHelper.generateMetrics(this.job1, this.getStagingPath(), metrics);
			log.info("===== ROLLING BACK ======");
			rollback();
			throw new CommonsException(e.getMessage(), e);
		}

		log.info("---- Elapsed Time: " + (new Date().getTime() - inicio.getTime()) / 1000 + " seconds.");

		return retorno;

	}
	
    
    
	@Override
	protected void configure() throws Exception {
		
	}
	
	
	protected void configureStep2pt1() throws Exception {
		
		conf = this.job1.getConfiguration();
		fs = FileSystem.get(conf);		
		
		try {
			this.configureCommonsStep1();
            this.setProcessDate();
            job1.getConfiguration().set("dat_ref", dat_ref);
		} catch (Exception ex) {
			throw new Exception("Error configuring JOB Commons :" + ex.getMessage());
		}
		
	
	    Entry Step5ResultEntry = new Entry(conf.get(Step6Constants.STEP6PT1), Step6Constants.STEP5_FACT_INPUT, true, true, TextInputFormat.class, Step5Mapper.class);
	    
	    DriverUtils.addInputPaths(args, conf, job1, Step5ResultEntry);
	    log.info("Data em execução: " + job1.getConfiguration().get("dat_ref"));
		
	    // Staging PATH
        this.stagingPath = conf.get(Step6Constants.STEP6_OUTPUT);
	    Path stagingPathDir = new Path(this.stagingPath);
		
        if (fs.exists(stagingPathDir)) {
            log.info("WARN: Staging: " + stagingPathDir.toString() + " already exists, deleting it...");
            fs.delete(stagingPathDir, true);
        }
		
		log.info("Staging Path: " + stagingPathDir.toString());
		TextOutputFormat.setOutputPath(this.job1,stagingPathDir);
	    
	}
	
	
	
	private void configureCommonsStep1() throws Exception{
		
		this.job1.setJobName(conf.get("process-id"));
		this.job1.setJarByClass(Step6Driver.class);
		this.job1.setReducerClass(Step6Reducer.class);
		this.job1.setMapOutputKeyClass(Text.class);
		this.job1.setMapOutputValueClass(Step6Value.class);
		this.job1.setOutputKeyClass(NullWritable.class);
		this.job1.setOutputValueClass(Text.class);



	}
	
	
    private void setProcessDate() {
        dat_ref = dtf.format(LocalDate.now().minusDays(1));

        if (args.length == 1) {
            if (args[0].contains("reprocess-day")) {
                dat_ref = args[0].split("\\=")[1];
            } else if (args[0].contains("reprocess-month")) {
                dat_ref = args[0].split("\\=")[1] + "-01";
            }
        }

    }

}
