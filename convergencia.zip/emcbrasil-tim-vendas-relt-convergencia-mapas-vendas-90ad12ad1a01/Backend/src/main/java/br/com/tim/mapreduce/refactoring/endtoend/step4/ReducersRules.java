package br.com.tim.mapreduce.refactoring.endtoend.step4;

public class ReducersRules {

}
