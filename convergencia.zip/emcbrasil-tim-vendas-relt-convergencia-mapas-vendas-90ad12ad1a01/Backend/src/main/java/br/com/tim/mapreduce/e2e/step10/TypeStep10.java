package br.com.tim.mapreduce.e2e.step10;

public enum TypeStep10 {
	
	WFMTOA, RELT
	
}
