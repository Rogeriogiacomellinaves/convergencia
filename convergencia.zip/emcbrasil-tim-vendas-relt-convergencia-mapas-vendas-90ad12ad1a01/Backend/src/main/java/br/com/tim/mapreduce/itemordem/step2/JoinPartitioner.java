package br.com.tim.mapreduce.itemordem.step2;

import org.apache.hadoop.mapreduce.Partitioner;

public class JoinPartitioner extends Partitioner<IOStep2Key, IOStep2Value> {

    @Override
    public int getPartition(IOStep2Key taggedKey, IOStep2Value value, int numPartitions) {
        return Math.abs(taggedKey.hashCodeJoin() % numPartitions);
    }
}