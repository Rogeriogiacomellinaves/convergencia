package br.com.tim.mapreduce.refactoring.endtoend.step4.model;

import br.com.tim.mapreduce.refactoring.endtoend.step4.enums.Bat222;
import br.com.tim.utils.CommonsConstants;

public class Bat222Model {
    private String socialsecno;
    private String titulo;
    private String nome;
    private String tipo;
    private String sexo;
    private String nacionalidade;
    private String estado_civil;
    private String e_mail;
    private String telefone_contato;
    private String data_nascimento;
    private String status;
    private String cnae;
    private String score;
    private String flag_deficiente;
    private String tipo_deficiencia;
    private String flag_emancipado;
    private String segmento__cliente;
    private String tipo_documento;
    private String numero_documento;
    private String orgao_expedidor_documento;
    private String uf_expedidor_documento;
    private String validade_documento;
    private String numero_inscricao_estadual;
    private String uf_inscricao_estadual;
    private String numero_inscricao_municipal;
    private String municipio_inscricao_municipal;
    private String natureza_juridica;
    private String porte_empresa;
    private String numero_funcionarios;
    private String nome_mae;
    private String tipo_logradouro;
    private String logradouro;
    private String namero_endereco;
    private String complemento;
    private String bairro;
    private String cidade;
    private String uf;
    private String cep;
    private String caixa_postal;
    private String row_id_endereco;
    private String data_ativacao_crm;
    private String login_resp_ativacao;
    private String perfil_login_resp_ativacao;
    private String pdv_resp_ativacao;
    private String data_modificacao;
    private String login_resp_modificacao;
    private String perfil_login_resp_modificacao;
    private String pdv_resp_modificacao;
    private String rowid;
    private String loteid;
    private String arquivo;
    private String arquivots;
    private String currentdate;
    private String flg_convergente;
    private String tpo_cadastro;
    private String dsc_orgao_emissor_inscricao_estadual;
    private String num_telefone_contato_2;
    private String num_telefone_contato_3;
    private String dat_fundacao;
    private String dat_emissao;
    private String dsc_grupo_empresarial;
    private String dsc_ramo_atividade;
    private String dsc_cnae;
    private String cod_cnae_secundario;
    private String dsc_cnae_secundario;
    private String vlr_renda_informada;
    private String dsc_capital_social;
    private String vlr_medio_conta_concorrencia;
    private String cod_natureza_juridica;
    private String nom_pais_origem;
    private String vlr_faturamento_presumido;
    private String dsc_carteira_pertencente;
    private String row_id_cliente;


    public void parseFromText(String text) {

        String[] fields = text.split(CommonsConstants.FILE_SPLIT_REGEX, -1);

        this.socialsecno = fields[Bat222.SOCIALSECNO.ordinal()];
        this.titulo = fields[Bat222.TITULO.ordinal()];
        this.nome = fields[Bat222.NOME.ordinal()];
        this.tipo = fields[Bat222.TIPO.ordinal()];
        this.sexo = fields[Bat222.SEXO.ordinal()];
        this.nacionalidade = fields[Bat222.NACIONALIDADE.ordinal()];
        this.estado_civil = fields[Bat222.ESTADO_CIVIL.ordinal()];
        this.e_mail = fields[Bat222.E_MAIL.ordinal()];
        this.telefone_contato = fields[Bat222.TELEFONE_CONTATO.ordinal()];
        this.data_nascimento = fields[Bat222.DATA_NASCIMENTO.ordinal()];
        this.status = fields[Bat222.STATUS.ordinal()];
        this.cnae = fields[Bat222.CNAE.ordinal()];
        this.score = fields[Bat222.SCORE.ordinal()];
        this.flag_deficiente = fields[Bat222.FLAG_DEFICIENTE.ordinal()];
        this.tipo_deficiencia = fields[Bat222.TIPO_DEFICIENCIA.ordinal()];
        this.flag_emancipado = fields[Bat222.FLAG_EMANCIPADO.ordinal()];
        this.segmento__cliente = fields[Bat222.SEGMENTO__CLIENTE.ordinal()];
        this.tipo_documento = fields[Bat222.TIPO_DOCUMENTO.ordinal()];
        this.numero_documento = fields[Bat222.NUMERO_DOCUMENTO.ordinal()];
        this.orgao_expedidor_documento = fields[Bat222.ORGAO_EXPEDIDOR_DOCUMENTO.ordinal()];
        this.uf_expedidor_documento = fields[Bat222.UF_EXPEDIDOR_DOCUMENTO.ordinal()];
        this.validade_documento = fields[Bat222.VALIDADE_DOCUMENTO.ordinal()];
        this.numero_inscricao_estadual = fields[Bat222.NUMERO_INSCRICAO_ESTADUAL.ordinal()];
        this.uf_inscricao_estadual = fields[Bat222.UF_INSCRICAO_ESTADUAL.ordinal()];
        this.numero_inscricao_municipal = fields[Bat222.NUMERO_INSCRICAO_MUNICIPAL.ordinal()];
        this.municipio_inscricao_municipal = fields[Bat222.MUNICIPIO_INSCRICAO_MUNICIPAL.ordinal()];
        this.natureza_juridica = fields[Bat222.NATUREZA_JURIDICA.ordinal()];
        this.porte_empresa = fields[Bat222.PORTE_EMPRESA.ordinal()];
        this.numero_funcionarios = fields[Bat222.NUMERO_FUNCIONARIOS.ordinal()];
        this.nome_mae = fields[Bat222.NOME_MAE.ordinal()];
        this.tipo_logradouro = fields[Bat222.TIPO_LOGRADOURO.ordinal()];
        this.logradouro = fields[Bat222.LOGRADOURO.ordinal()];
        this.namero_endereco = fields[Bat222.NAMERO_ENDERECO.ordinal()];
        this.complemento = fields[Bat222.COMPLEMENTO.ordinal()];
        this.bairro = fields[Bat222.BAIRRO.ordinal()];
        this.cidade = fields[Bat222.CIDADE.ordinal()];
        this.uf = fields[Bat222.UF.ordinal()];
        this.cep = fields[Bat222.CEP.ordinal()];
        this.caixa_postal = fields[Bat222.CAIXA_POSTAL.ordinal()];
        this.row_id_endereco = fields[Bat222.ROW_ID_ENDERECO.ordinal()];
        this.data_ativacao_crm = fields[Bat222.DATA_ATIVACAO_CRM.ordinal()];
        this.login_resp_ativacao = fields[Bat222.LOGIN_RESP_ATIVACAO.ordinal()];
        this.perfil_login_resp_ativacao = fields[Bat222.PERFIL_LOGIN_RESP_ATIVACAO.ordinal()];
        this.pdv_resp_ativacao = fields[Bat222.PDV_RESP_ATIVACAO.ordinal()];
        this.data_modificacao = fields[Bat222.DATA_MODIFICACAO.ordinal()];
        this.login_resp_modificacao = fields[Bat222.LOGIN_RESP_MODIFICACAO.ordinal()];
        this.perfil_login_resp_modificacao = fields[Bat222.PERFIL_LOGIN_RESP_MODIFICACAO.ordinal()];
        this.pdv_resp_modificacao = fields[Bat222.PDV_RESP_MODIFICACAO.ordinal()];
        this.rowid = fields[Bat222.ROWID.ordinal()];
        this.loteid = fields[Bat222.LOTEID.ordinal()];
        this.arquivo = fields[Bat222.ARQUIVO.ordinal()];
        this.arquivots = fields[Bat222.ARQUIVOTS.ordinal()];
        this.currentdate = fields[Bat222.CURRENTDATE.ordinal()];
        this.flg_convergente = fields[Bat222.FLG_CONVERGENTE.ordinal()];
        this.tpo_cadastro = fields[Bat222.TPO_CADASTRO.ordinal()];
        this.dsc_orgao_emissor_inscricao_estadual = fields[Bat222.DSC_ORGAO_EMISSOR_INSCRICAO_ESTADUAL.ordinal()];
        this.num_telefone_contato_2 = fields[Bat222.NUM_TELEFONE_CONTATO_2.ordinal()];
        this.num_telefone_contato_3 = fields[Bat222.NUM_TELEFONE_CONTATO_3.ordinal()];
        this.dat_fundacao = fields[Bat222.DAT_FUNDACAO.ordinal()];
        this.dat_emissao = fields[Bat222.DAT_EMISSAO.ordinal()];
        this.dsc_grupo_empresarial = fields[Bat222.DSC_GRUPO_EMPRESARIAL.ordinal()];
        this.dsc_ramo_atividade = fields[Bat222.DSC_RAMO_ATIVIDADE.ordinal()];
        this.dsc_cnae = fields[Bat222.DSC_CNAE.ordinal()];
        this.cod_cnae_secundario = fields[Bat222.COD_CNAE_SECUNDARIO.ordinal()];
        this.dsc_cnae_secundario = fields[Bat222.DSC_CNAE_SECUNDARIO.ordinal()];
        this.vlr_renda_informada = fields[Bat222.VLR_RENDA_INFORMADA.ordinal()];
        this.dsc_capital_social = fields[Bat222.DSC_CAPITAL_SOCIAL.ordinal()];
        this.vlr_medio_conta_concorrencia = fields[Bat222.VLR_MEDIO_CONTA_CONCORRENCIA.ordinal()];
        this.cod_natureza_juridica = fields[Bat222.COD_NATUREZA_JURIDICA.ordinal()];
        this.nom_pais_origem = fields[Bat222.NOM_PAIS_ORIGEM.ordinal()];
        this.vlr_faturamento_presumido = fields[Bat222.VLR_FATURAMENTO_PRESUMIDO.ordinal()];
        this.dsc_carteira_pertencente = fields[Bat222.DSC_CARTEIRA_PERTENCENTE.ordinal()];
        this.row_id_cliente = fields[Bat222.ROW_ID_CLIENTE.ordinal()];
    }

    public String getSocialsecno() {
        return socialsecno;
    }

    public void setSocialsecno(String socialsecno) {
        this.socialsecno = socialsecno;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getNacionalidade() {
        return nacionalidade;
    }

    public void setNacionalidade(String nacionalidade) {
        this.nacionalidade = nacionalidade;
    }

    public String getEstado_civil() {
        return estado_civil;
    }

    public void setEstado_civil(String estado_civil) {
        this.estado_civil = estado_civil;
    }

    public String getE_mail() {
        return e_mail;
    }

    public void setE_mail(String e_mail) {
        this.e_mail = e_mail;
    }

    public String getTelefone_contato() {
        return telefone_contato;
    }

    public void setTelefone_contato(String telefone_contato) {
        this.telefone_contato = telefone_contato;
    }

    public String getData_nascimento() {
        return data_nascimento;
    }

    public void setData_nascimento(String data_nascimento) {
        this.data_nascimento = data_nascimento;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCnae() {
        return cnae;
    }

    public void setCnae(String cnae) {
        this.cnae = cnae;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    public String getFlag_deficiente() {
        return flag_deficiente;
    }

    public void setFlag_deficiente(String flag_deficiente) {
        this.flag_deficiente = flag_deficiente;
    }

    public String getTipo_deficiencia() {
        return tipo_deficiencia;
    }

    public void setTipo_deficiencia(String tipo_deficiencia) {
        this.tipo_deficiencia = tipo_deficiencia;
    }

    public String getFlag_emancipado() {
        return flag_emancipado;
    }

    public void setFlag_emancipado(String flag_emancipado) {
        this.flag_emancipado = flag_emancipado;
    }

    public String getSegmento__cliente() {
        return segmento__cliente;
    }

    public void setSegmento__cliente(String segmento__cliente) {
        this.segmento__cliente = segmento__cliente;
    }

    public String getTipo_documento() {
        return tipo_documento;
    }

    public void setTipo_documento(String tipo_documento) {
        this.tipo_documento = tipo_documento;
    }

    public String getNumero_documento() {
        return numero_documento;
    }

    public void setNumero_documento(String numero_documento) {
        this.numero_documento = numero_documento;
    }

    public String getOrgao_expedidor_documento() {
        return orgao_expedidor_documento;
    }

    public void setOrgao_expedidor_documento(String orgao_expedidor_documento) {
        this.orgao_expedidor_documento = orgao_expedidor_documento;
    }

    public String getUf_expedidor_documento() {
        return uf_expedidor_documento;
    }

    public void setUf_expedidor_documento(String uf_expedidor_documento) {
        this.uf_expedidor_documento = uf_expedidor_documento;
    }

    public String getValidade_documento() {
        return validade_documento;
    }

    public void setValidade_documento(String validade_documento) {
        this.validade_documento = validade_documento;
    }

    public String getNumero_inscricao_estadual() {
        return numero_inscricao_estadual;
    }

    public void setNumero_inscricao_estadual(String numero_inscricao_estadual) {
        this.numero_inscricao_estadual = numero_inscricao_estadual;
    }

    public String getUf_inscricao_estadual() {
        return uf_inscricao_estadual;
    }

    public void setUf_inscricao_estadual(String uf_inscricao_estadual) {
        this.uf_inscricao_estadual = uf_inscricao_estadual;
    }

    public String getNumero_inscricao_municipal() {
        return numero_inscricao_municipal;
    }

    public void setNumero_inscricao_municipal(String numero_inscricao_municipal) {
        this.numero_inscricao_municipal = numero_inscricao_municipal;
    }

    public String getMunicipio_inscricao_municipal() {
        return municipio_inscricao_municipal;
    }

    public void setMunicipio_inscricao_municipal(String municipio_inscricao_municipal) {
        this.municipio_inscricao_municipal = municipio_inscricao_municipal;
    }

    public String getNatureza_juridica() {
        return natureza_juridica;
    }

    public void setNatureza_juridica(String natureza_juridica) {
        this.natureza_juridica = natureza_juridica;
    }

    public String getPorte_empresa() {
        return porte_empresa;
    }

    public void setPorte_empresa(String porte_empresa) {
        this.porte_empresa = porte_empresa;
    }

    public String getNumero_funcionarios() {
        return numero_funcionarios;
    }

    public void setNumero_funcionarios(String numero_funcionarios) {
        this.numero_funcionarios = numero_funcionarios;
    }

    public String getNome_mae() {
        return nome_mae;
    }

    public void setNome_mae(String nome_mae) {
        this.nome_mae = nome_mae;
    }

    public String getTipo_logradouro() {
        return tipo_logradouro;
    }

    public void setTipo_logradouro(String tipo_logradouro) {
        this.tipo_logradouro = tipo_logradouro;
    }

    public String getLogradouro() {
        return logradouro;
    }

    public void setLogradouro(String logradouro) {
        this.logradouro = logradouro;
    }

    public String getNamero_endereco() {
        return namero_endereco;
    }

    public void setNamero_endereco(String namero_endereco) {
        this.namero_endereco = namero_endereco;
    }

    public String getComplemento() {
        return complemento;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getUf() {
        return uf;
    }

    public void setUf(String uf) {
        this.uf = uf;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getCaixa_postal() {
        return caixa_postal;
    }

    public void setCaixa_postal(String caixa_postal) {
        this.caixa_postal = caixa_postal;
    }

    public String getRow_id_endereco() {
        return row_id_endereco;
    }

    public void setRow_id_endereco(String row_id_endereco) {
        this.row_id_endereco = row_id_endereco;
    }

    public String getData_ativacao_crm() {
        return data_ativacao_crm;
    }

    public void setData_ativacao_crm(String data_ativacao_crm) {
        this.data_ativacao_crm = data_ativacao_crm;
    }

    public String getLogin_resp_ativacao() {
        return login_resp_ativacao;
    }

    public void setLogin_resp_ativacao(String login_resp_ativacao) {
        this.login_resp_ativacao = login_resp_ativacao;
    }

    public String getPerfil_login_resp_ativacao() {
        return perfil_login_resp_ativacao;
    }

    public void setPerfil_login_resp_ativacao(String perfil_login_resp_ativacao) {
        this.perfil_login_resp_ativacao = perfil_login_resp_ativacao;
    }

    public String getPdv_resp_ativacao() {
        return pdv_resp_ativacao;
    }

    public void setPdv_resp_ativacao(String pdv_resp_ativacao) {
        this.pdv_resp_ativacao = pdv_resp_ativacao;
    }

    public String getData_modificacao() {
        return data_modificacao;
    }

    public void setData_modificacao(String data_modificacao) {
        this.data_modificacao = data_modificacao;
    }

    public String getLogin_resp_modificacao() {
        return login_resp_modificacao;
    }

    public void setLogin_resp_modificacao(String login_resp_modificacao) {
        this.login_resp_modificacao = login_resp_modificacao;
    }

    public String getPerfil_login_resp_modificacao() {
        return perfil_login_resp_modificacao;
    }

    public void setPerfil_login_resp_modificacao(String perfil_login_resp_modificacao) {
        this.perfil_login_resp_modificacao = perfil_login_resp_modificacao;
    }

    public String getPdv_resp_modificacao() {
        return pdv_resp_modificacao;
    }

    public void setPdv_resp_modificacao(String pdv_resp_modificacao) {
        this.pdv_resp_modificacao = pdv_resp_modificacao;
    }

    public String getRowid() {
        return rowid;
    }

    public void setRowid(String rowid) {
        this.rowid = rowid;
    }

    public String getLoteid() {
        return loteid;
    }

    public void setLoteid(String loteid) {
        this.loteid = loteid;
    }

    public String getArquivo() {
        return arquivo;
    }

    public void setArquivo(String arquivo) {
        this.arquivo = arquivo;
    }

    public String getArquivots() {
        return arquivots;
    }

    public void setArquivots(String arquivots) {
        this.arquivots = arquivots;
    }

    public String getCurrentdate() {
        return currentdate;
    }

    public void setCurrentdate(String currentdate) {
        this.currentdate = currentdate;
    }

    public String getFlg_convergente() {
        return flg_convergente;
    }

    public void setFlg_convergente(String flg_convergente) {
        this.flg_convergente = flg_convergente;
    }

    public String getTpo_cadastro() {
        return tpo_cadastro;
    }

    public void setTpo_cadastro(String tpo_cadastro) {
        this.tpo_cadastro = tpo_cadastro;
    }

    public String getDsc_orgao_emissor_inscricao_estadual() {
        return dsc_orgao_emissor_inscricao_estadual;
    }

    public void setDsc_orgao_emissor_inscricao_estadual(String dsc_orgao_emissor_inscricao_estadual) {
        this.dsc_orgao_emissor_inscricao_estadual = dsc_orgao_emissor_inscricao_estadual;
    }

    public String getNum_telefone_contato_2() {
        return num_telefone_contato_2;
    }

    public void setNum_telefone_contato_2(String num_telefone_contato_2) {
        this.num_telefone_contato_2 = num_telefone_contato_2;
    }

    public String getNum_telefone_contato_3() {
        return num_telefone_contato_3;
    }

    public void setNum_telefone_contato_3(String num_telefone_contato_3) {
        this.num_telefone_contato_3 = num_telefone_contato_3;
    }

    public String getDat_fundacao() {
        return dat_fundacao;
    }

    public void setDat_fundacao(String dat_fundacao) {
        this.dat_fundacao = dat_fundacao;
    }

    public String getDat_emissao() {
        return dat_emissao;
    }

    public void setDat_emissao(String dat_emissao) {
        this.dat_emissao = dat_emissao;
    }

    public String getDsc_grupo_empresarial() {
        return dsc_grupo_empresarial;
    }

    public void setDsc_grupo_empresarial(String dsc_grupo_empresarial) {
        this.dsc_grupo_empresarial = dsc_grupo_empresarial;
    }

    public String getDsc_ramo_atividade() {
        return dsc_ramo_atividade;
    }

    public void setDsc_ramo_atividade(String dsc_ramo_atividade) {
        this.dsc_ramo_atividade = dsc_ramo_atividade;
    }

    public String getDsc_cnae() {
        return dsc_cnae;
    }

    public void setDsc_cnae(String dsc_cnae) {
        this.dsc_cnae = dsc_cnae;
    }

    public String getCod_cnae_secundario() {
        return cod_cnae_secundario;
    }

    public void setCod_cnae_secundario(String cod_cnae_secundario) {
        this.cod_cnae_secundario = cod_cnae_secundario;
    }

    public String getDsc_cnae_secundario() {
        return dsc_cnae_secundario;
    }

    public void setDsc_cnae_secundario(String dsc_cnae_secundario) {
        this.dsc_cnae_secundario = dsc_cnae_secundario;
    }

    public String getVlr_renda_informada() {
        return vlr_renda_informada;
    }

    public void setVlr_renda_informada(String vlr_renda_informada) {
        this.vlr_renda_informada = vlr_renda_informada;
    }

    public String getDsc_capital_social() {
        return dsc_capital_social;
    }

    public void setDsc_capital_social(String dsc_capital_social) {
        this.dsc_capital_social = dsc_capital_social;
    }

    public String getVlr_medio_conta_concorrencia() {
        return vlr_medio_conta_concorrencia;
    }

    public void setVlr_medio_conta_concorrencia(String vlr_medio_conta_concorrencia) {
        this.vlr_medio_conta_concorrencia = vlr_medio_conta_concorrencia;
    }

    public String getCod_natureza_juridica() {
        return cod_natureza_juridica;
    }

    public void setCod_natureza_juridica(String cod_natureza_juridica) {
        this.cod_natureza_juridica = cod_natureza_juridica;
    }

    public String getNom_pais_origem() {
        return nom_pais_origem;
    }

    public void setNom_pais_origem(String nom_pais_origem) {
        this.nom_pais_origem = nom_pais_origem;
    }

    public String getVlr_faturamento_presumido() {
        return vlr_faturamento_presumido;
    }

    public void setVlr_faturamento_presumido(String vlr_faturamento_presumido) {
        this.vlr_faturamento_presumido = vlr_faturamento_presumido;
    }

    public String getDsc_carteira_pertencente() {
        return dsc_carteira_pertencente;
    }

    public void setDsc_carteira_pertencente(String dsc_carteira_pertencente) {
        this.dsc_carteira_pertencente = dsc_carteira_pertencente;
    }

    public String getRow_id_cliente() {
        return row_id_cliente;
    }

    public void setRow_id_cliente(String row_id_cliente) {
        this.row_id_cliente = row_id_cliente;
    }
}
