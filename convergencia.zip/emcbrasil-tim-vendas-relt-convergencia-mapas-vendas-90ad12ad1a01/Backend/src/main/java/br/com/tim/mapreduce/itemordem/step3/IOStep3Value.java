package br.com.tim.mapreduce.itemordem.step3;


import br.com.tim.mapreduce.itemordem.step3.model.Step2Result;
import br.com.tim.mapreduce.model.BAT230;
import org.apache.hadoop.io.Writable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public class IOStep3Value implements Writable {

    protected TypeStep3 tipo;
    protected String nroOrdem;
    protected String nomBairro;
    protected String cep;
    protected String nomCidade;
    protected String numCNPJParcVenda;
    protected String dscComplemento;
    protected String datDesconexao;
    protected String datVenda;
    protected String dscLogradouro;
    protected String numLogradouro;
    protected String nomPlanoAtual;
    protected String nomPlanoNovo;
    protected String numTelefone;
    protected String dscTipoLogradouro;
    protected String nomProduto;
    protected String dscTipoMotivo;
    protected String sglUFInstalacao;
    protected String datRef;
    protected String dscAcaoItemOrdem;
    protected String dscStatusItem;
    protected String email;
    protected String dscTipoOrdem;
    protected String dscFormaPgto;
    protected String codCtaFinanceira;
    protected String codContratoOltp;
    protected String numProtocolo;
    protected String datCriacaoOrdem;
    protected String datStatusOrdem;
    protected String datSuspensao;
    protected String datReativacao;
    protected String codServiceId;
    protected String nomContato;
    protected String dscMotivoStatusItem;
    protected String nomLoginResponsavel;
    protected String nomLoginVendedor;
    protected String dscCanalVenda;
    protected String valPlanoAtual;
    protected String nomDescontoAtual;
    protected String valDescontoAtual;
    protected String valPlanoNovo;
    protected String nomDescontoNovo;
    protected String valDescontoNovo;
    protected String flgPortabilidade;
    protected String codDdd;
    protected String numTelefonePortado;
    protected String datJanelaPortabilidade;
    protected String dscEstorno;
    protected String numBilheteEstornado;
    protected String dscMotivoEstorno;
    protected String diaVencimento;
    protected String dscTipoConta;
    protected String dscEnderecoFatura;
    protected String dscAreaVoip;
    protected String codBanco;
    protected String codAgenciaBco;
    protected String codContaCorrente;
    protected String datAltFormaPgto;
    protected String codDebitoAutomatico;
    protected String codItemOrdem;
    protected String nomParceiroVenda;
    protected String idItemOrdPai;
    protected String idItemOrdem;
    protected String dscCategoriaItem;
    protected String tecnologia;
    protected String cpe;
    protected String ont;
    protected String velocidadeContratada;
    protected String custcode;
    protected String numTelefone2;
    protected String numTelefone3;
    protected String dominioRoot;
    protected String dscStatusOrdemWfm;
    protected String datHoraStatusWfm;

    @Override
    public void write(DataOutput dataOutput) throws IOException {
        dataOutput.writeInt(tipo.ordinal());
        dataOutput.writeUTF(nroOrdem);
        dataOutput.writeUTF(nomBairro);
        dataOutput.writeUTF(cep);
        dataOutput.writeUTF(nomCidade);
        dataOutput.writeUTF(numCNPJParcVenda);
        dataOutput.writeUTF(dscComplemento);
        dataOutput.writeUTF(datDesconexao);
        dataOutput.writeUTF(datVenda);
        dataOutput.writeUTF(dscLogradouro);
        dataOutput.writeUTF(numLogradouro);
        dataOutput.writeUTF(nomPlanoAtual);
        dataOutput.writeUTF(nomPlanoNovo);
        dataOutput.writeUTF(numTelefone);
        dataOutput.writeUTF(dscTipoLogradouro);
        dataOutput.writeUTF(nomProduto);
        dataOutput.writeUTF(dscTipoMotivo);
        dataOutput.writeUTF(sglUFInstalacao);
        dataOutput.writeUTF(datRef);
        dataOutput.writeUTF(dscAcaoItemOrdem);
        dataOutput.writeUTF(dscStatusItem);
        dataOutput.writeUTF(email);
        dataOutput.writeUTF(dscTipoOrdem);
        dataOutput.writeUTF(dscFormaPgto);
        dataOutput.writeUTF(codCtaFinanceira);
        dataOutput.writeUTF(codContratoOltp);
        dataOutput.writeUTF(numProtocolo);
        dataOutput.writeUTF(datCriacaoOrdem);
        dataOutput.writeUTF(datStatusOrdem);
        dataOutput.writeUTF(datSuspensao);
        dataOutput.writeUTF(datReativacao);
        dataOutput.writeUTF(codServiceId);
        dataOutput.writeUTF(nomContato);
        dataOutput.writeUTF(dscMotivoStatusItem);
        dataOutput.writeUTF(nomLoginResponsavel);
        dataOutput.writeUTF(nomLoginVendedor);
        dataOutput.writeUTF(dscCanalVenda);
        dataOutput.writeUTF(valPlanoAtual);
        dataOutput.writeUTF(nomDescontoAtual);
        dataOutput.writeUTF(valDescontoAtual);
        dataOutput.writeUTF(valPlanoNovo);
        dataOutput.writeUTF(nomDescontoNovo);
        dataOutput.writeUTF(valDescontoNovo);
        dataOutput.writeUTF(flgPortabilidade);
        dataOutput.writeUTF(codDdd);
        dataOutput.writeUTF(numTelefonePortado);
        dataOutput.writeUTF(datJanelaPortabilidade);
        dataOutput.writeUTF(dscEstorno);
        dataOutput.writeUTF(numBilheteEstornado);
        dataOutput.writeUTF(dscMotivoEstorno);
        dataOutput.writeUTF(diaVencimento);
        dataOutput.writeUTF(dscTipoConta);
        dataOutput.writeUTF(dscEnderecoFatura);
        dataOutput.writeUTF(dscAreaVoip);
        dataOutput.writeUTF(codBanco);
        dataOutput.writeUTF(codAgenciaBco);
        dataOutput.writeUTF(codContaCorrente);
        dataOutput.writeUTF(datAltFormaPgto);
        dataOutput.writeUTF(codDebitoAutomatico);
        dataOutput.writeUTF(codItemOrdem);
        dataOutput.writeUTF(nomParceiroVenda);
        dataOutput.writeUTF(idItemOrdPai);
        dataOutput.writeUTF(idItemOrdem);
        dataOutput.writeUTF(dscCategoriaItem);
        dataOutput.writeUTF(tecnologia);
        dataOutput.writeUTF(cpe);
        dataOutput.writeUTF(ont);
        dataOutput.writeUTF(velocidadeContratada);
        dataOutput.writeUTF(custcode);
        dataOutput.writeUTF(numTelefone2);
        dataOutput.writeUTF(numTelefone3);
        dataOutput.writeUTF(dominioRoot);
        dataOutput.writeUTF(dscStatusOrdemWfm);
        dataOutput.writeUTF(datHoraStatusWfm);
    }

    @Override
    public void readFields(DataInput dataInput) throws IOException {
        this.tipo = TypeStep3.values()[dataInput.readInt()];
        this.nroOrdem = dataInput.readUTF();
        this.nomBairro = dataInput.readUTF();
        this.cep = dataInput.readUTF();
        this.nomCidade = dataInput.readUTF();
        this.numCNPJParcVenda = dataInput.readUTF();
        this.dscComplemento = dataInput.readUTF();
        this.datDesconexao = dataInput.readUTF();
        this.datVenda = dataInput.readUTF();
        this.dscLogradouro = dataInput.readUTF();
        this.numLogradouro = dataInput.readUTF();
        this.nomPlanoAtual = dataInput.readUTF();
        this.nomPlanoNovo = dataInput.readUTF();
        this.numTelefone = dataInput.readUTF();
        this.dscTipoLogradouro = dataInput.readUTF();
        this.nomProduto = dataInput.readUTF();
        this.dscTipoMotivo = dataInput.readUTF();
        this.sglUFInstalacao = dataInput.readUTF();
        this.datRef = dataInput.readUTF();
        this.dscAcaoItemOrdem = dataInput.readUTF();
        this.dscStatusItem = dataInput.readUTF();
        this.email = dataInput.readUTF();
        this.dscTipoOrdem = dataInput.readUTF();
        this.dscFormaPgto = dataInput.readUTF();
        this.codCtaFinanceira = dataInput.readUTF();
        this.codContratoOltp = dataInput.readUTF();
        this.numProtocolo = dataInput.readUTF();
        this.datCriacaoOrdem = dataInput.readUTF();
        this.datStatusOrdem = dataInput.readUTF();
        this.datSuspensao = dataInput.readUTF();
        this.datReativacao = dataInput.readUTF();
        this.codServiceId = dataInput.readUTF();
        this.nomContato = dataInput.readUTF();
        this.dscMotivoStatusItem = dataInput.readUTF();
        this.nomLoginResponsavel = dataInput.readUTF();
        this.nomLoginVendedor = dataInput.readUTF();
        this.dscCanalVenda = dataInput.readUTF();
        this.valPlanoAtual = dataInput.readUTF();
        this.nomDescontoAtual = dataInput.readUTF();
        this.valDescontoAtual = dataInput.readUTF();
        this.valPlanoNovo = dataInput.readUTF();
        this.nomDescontoNovo = dataInput.readUTF();
        this.valDescontoNovo = dataInput.readUTF();
        this.flgPortabilidade = dataInput.readUTF();
        this.codDdd = dataInput.readUTF();
        this.numTelefonePortado = dataInput.readUTF();
        this.datJanelaPortabilidade = dataInput.readUTF();
        this.dscEstorno = dataInput.readUTF();
        this.numBilheteEstornado = dataInput.readUTF();
        this.dscMotivoEstorno = dataInput.readUTF();
        this.diaVencimento = dataInput.readUTF();
        this.dscTipoConta = dataInput.readUTF();
        this.dscEnderecoFatura = dataInput.readUTF();
        this.dscAreaVoip = dataInput.readUTF();
        this.codBanco = dataInput.readUTF();
        this.codAgenciaBco = dataInput.readUTF();
        this.codContaCorrente = dataInput.readUTF();
        this.datAltFormaPgto = dataInput.readUTF();
        this.codDebitoAutomatico = dataInput.readUTF();
        this.codItemOrdem = dataInput.readUTF();
        this.nomParceiroVenda = dataInput.readUTF();
        this.idItemOrdPai = dataInput.readUTF();
        this.idItemOrdem = dataInput.readUTF();
        this.dscCategoriaItem = dataInput.readUTF();
        this.tecnologia = dataInput.readUTF();
        this.cpe = dataInput.readUTF();
        this.ont = dataInput.readUTF();
        this.velocidadeContratada = dataInput.readUTF();
        this.custcode = dataInput.readUTF();
        this.numTelefone2 = dataInput.readUTF();
        this.numTelefone3 = dataInput.readUTF();
        this.dominioRoot = dataInput.readUTF();
        this.dscStatusOrdemWfm = dataInput.readUTF();
        this.datHoraStatusWfm = dataInput.readUTF();
    }

    public void setStep2Result(Step2Result result) {
        this.clear();
        this.tipo = TypeStep3.RESULTSTEP2;
        this.nroOrdem = result.getNroOrdem();
        this.nomBairro = result.getNomBairro();
        this.cep = result.getCep();
        this.nomCidade = result.getNomCidade();
        this.dscComplemento = result.getDscComplemento();
        this.datDesconexao = result.getDatDesconexao();
        this.dscLogradouro = result.getDscLogradouro();
        this.numLogradouro = result.getNumLogradouro();
        this.nomPlanoAtual = result.getNomPlanoAtual();
        this.nomPlanoNovo = result.getNomPlanoNovo();
        this.numTelefone = result.getNumTelefone();
        this.dscTipoLogradouro = result.getDscTipoLogradouro();
        this.nomProduto = result.getNomProduto();
        this.dscTipoMotivo = result.getDscTipoMotivo();
        this.sglUFInstalacao = result.getSglUFInstalacao();
        this.dscAcaoItemOrdem = result.getDscAcaoItemOrdem();
        this.dscStatusItem = result.getDscStatusItem();
        this.email = result.getEmail();
        this.dscFormaPgto = result.getDscFormaPgto();
        this.codCtaFinanceira = result.getCodCtaFinanceira();
        this.codContratoOltp = result.getCodContratoOltp();
        this.numProtocolo = result.getNumProtocolo();
        this.datSuspensao = result.getDatSuspensao();
        this.datReativacao = result.getDatReativacao();
        this.codServiceId = result.getCodServiceId();
        this.dscMotivoStatusItem = result.getDscMotivoStatusItem();
        this.valPlanoAtual = result.getValPlanoAtual();
        this.nomDescontoAtual = result.getNomDescontoAtual();
        this.valDescontoAtual = result.getValDescontoAtual();
        this.valPlanoNovo = result.getValPlanoNovo();
        this.nomDescontoNovo = result.getNomDescontoNovo();
        this.valDescontoNovo = result.getValDescontoNovo();
        this.flgPortabilidade = result.getFlgPortabilidade();
        this.codDdd = result.getCodDdd();
        this.numTelefonePortado = result.getNumTelefonePortado();
        this.datJanelaPortabilidade = result.getDatJanelaPortabilidade();
        this.dscEstorno = result.getDscEstorno();
        this.numBilheteEstornado = result.getNumBilheteEstornado();
        this.dscMotivoEstorno = result.getDscMotivoEstorno();
        this.diaVencimento = result.getDiaVencimento();
        this.dscTipoConta = result.getDscTipoConta();
        this.dscEnderecoFatura = result.getDscEnderecoFatura();
        this.dscAreaVoip = result.getDscAreaVoip();
        this.codBanco = result.getCodBanco();
        this.codAgenciaBco = result.getCodAgenciaBco();
        this.codContaCorrente = result.getCodContaCorrente();
        this.datAltFormaPgto = result.getDatAltFormaPgto();
        this.codDebitoAutomatico = result.getCodDebitoAutomatico();
        this.codItemOrdem = result.getCodItemOrdem();
        this.idItemOrdPai = result.getIdItemOrdPai();
        this.idItemOrdem = result.getIdItemOrdem();
        this.dscCategoriaItem = result.getDscCategoriaItem();
        this.tecnologia = result.getTecnologia();
        this.cpe = result.getCpe();
        this.ont = result.getOnt();
        this.velocidadeContratada = result.getVelocidadeContratada();
        this.numCNPJParcVenda = result.getNumCNPJParcVenda();
        this.datVenda = result.getDatVenda();
        this.datRef = result.getDatRef();
        this.dscTipoOrdem = result.getDscTipoOrdem();
        this.datCriacaoOrdem = result.getDatCriacaoOrdem();
        this.datStatusOrdem = result.getDatStatusOrdem();
        this.nomContato = result.getNomContato();
        this.nomLoginResponsavel = result.getNomLoginResponsavel();
        this.nomLoginVendedor = result.getNomLoginVendedor();
        this.dscCanalVenda = result.getDscCanalVenda();
        this.nomParceiroVenda = result.getNomParceiroVenda();
        this.numTelefone2 = result.getNumTelefone2();
        this.numTelefone3 = result.getNumTelefone3();
        this.dominioRoot = result.getDominioRoot();
        this.dscStatusOrdemWfm = result.getDscStatusOrdemWfm();
        this.datHoraStatusWfm = result.getDatHoraStatusWfm();
    }

    public void setBAT230(BAT230 bat) {
        this.clear();
        this.tipo = TypeStep3.BAT230;
        this.custcode = bat.getCustcode();
    }

    public void clear(){
        this.tipo = null;
        this.nroOrdem = "";
        this.nomBairro = "";
        this.cep = "";
        this.nomCidade = "";
        this.numCNPJParcVenda = "";
        this.dscComplemento = "";
        this.datDesconexao = "";
        this.datVenda = "";
        this.dscLogradouro = "";
        this.numLogradouro = "";
        this.nomPlanoAtual = "";
        this.nomPlanoNovo = "";
        this.numTelefone = "";
        this.dscTipoLogradouro = "";
        this.nomProduto = "";
        this.dscTipoMotivo = "";
        this.sglUFInstalacao = "";
        this.datRef = "";
        this.dscAcaoItemOrdem = "";
        this.dscStatusItem = "";
        this.email = "";
        this.dscTipoOrdem = "";
        this.dscFormaPgto = "";
        this.codCtaFinanceira = "";
        this.codContratoOltp = "";
        this.numProtocolo = "";
        this.datCriacaoOrdem = "";
        this.datStatusOrdem = "";
        this.datSuspensao = "";
        this.datReativacao = "";
        this.codServiceId = "";
        this.nomContato = "";
        this.dscMotivoStatusItem = "";
        this.nomLoginResponsavel = "";
        this.nomLoginVendedor = "";
        this.dscCanalVenda = "";
        this.valPlanoAtual = "";
        this.nomDescontoAtual = "";
        this.valDescontoAtual = "";
        this.valPlanoNovo = "";
        this.nomDescontoNovo = "";
        this.valDescontoNovo = "";
        this.flgPortabilidade = "";
        this.codDdd = "";
        this.numTelefonePortado = "";
        this.datJanelaPortabilidade = "";
        this.dscEstorno = "";
        this.numBilheteEstornado = "";
        this.dscMotivoEstorno = "";
        this.diaVencimento = "";
        this.dscTipoConta = "";
        this.dscEnderecoFatura = "";
        this.dscAreaVoip = "";
        this.codBanco = "";
        this.codAgenciaBco = "";
        this.codContaCorrente = "";
        this.datAltFormaPgto = "";
        this.codDebitoAutomatico = "";
        this.codItemOrdem = "";
        this.nomParceiroVenda = "";
        this.idItemOrdPai = "";
        this.idItemOrdem = "";
        this.dscCategoriaItem = "";
        this.tecnologia = "";
        this.cpe = "";
        this.ont = "";
        this.velocidadeContratada = "";
        this.custcode = "";
        this.numTelefone2 = "";
        this.numTelefone3 = "";
        this.dominioRoot = "";
        this.dscStatusOrdemWfm = "";
        this.datHoraStatusWfm = "";
    }

    public String getDominioRoot() {
        return dominioRoot;
    }

    public void setDominioRoot(String dominioRoot) {
        this.dominioRoot = dominioRoot;
    }

    public String getNroOrdem() {
        return nroOrdem;
    }

    public void setNroOrdem(String nroOrdem) {
        this.nroOrdem = nroOrdem;
    }

    public String getNomBairro() {
        return nomBairro;
    }

    public void setNomBairro(String nomBairro) {
        this.nomBairro = nomBairro;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getNomCidade() {
        return nomCidade;
    }

    public void setNomCidade(String nomCidade) {
        this.nomCidade = nomCidade;
    }

    public String getNumCNPJParcVenda() {
        return numCNPJParcVenda;
    }

    public void setNumCNPJParcVenda(String numCNPJParcVenda) {
        this.numCNPJParcVenda = numCNPJParcVenda;
    }

    public String getDscComplemento() {
        return dscComplemento;
    }

    public void setDscComplemento(String dscComplemento) {
        this.dscComplemento = dscComplemento;
    }

    public String getDatDesconexao() {
        return datDesconexao;
    }

    public void setDatDesconexao(String datDesconexao) {
        this.datDesconexao = datDesconexao;
    }

    public String getDatVenda() {
        return datVenda;
    }

    public void setDatVenda(String datVenda) {
        this.datVenda = datVenda;
    }

    public String getDscLogradouro() {
        return dscLogradouro;
    }

    public void setDscLogradouro(String dscLogradouro) {
        this.dscLogradouro = dscLogradouro;
    }

    public String getNumLogradouro() {
        return numLogradouro;
    }

    public void setNumLogradouro(String numLogradouro) {
        this.numLogradouro = numLogradouro;
    }

    public String getNomPlanoAtual() {
        return nomPlanoAtual;
    }

    public void setNomPlanoAtual(String nomPlanoAtual) {
        this.nomPlanoAtual = nomPlanoAtual;
    }

    public String getNomPlanoNovo() {
        return nomPlanoNovo;
    }

    public void setNomPlanoNovo(String nomPlanoNovo) {
        this.nomPlanoNovo = nomPlanoNovo;
    }

    public String getNumTelefone() {
        return numTelefone;
    }

    public void setNumTelefone(String numTelefone) {
        this.numTelefone = numTelefone;
    }

    public String getDscTipoLogradouro() {
        return dscTipoLogradouro;
    }

    public void setDscTipoLogradouro(String dscTipoLogradouro) {
        this.dscTipoLogradouro = dscTipoLogradouro;
    }

    public String getNomProduto() {
        return nomProduto;
    }

    public void setNomProduto(String nomProduto) {
        this.nomProduto = nomProduto;
    }

    public String getDscTipoMotivo() {
        return dscTipoMotivo;
    }

    public void setDscTipoMotivo(String dscTipoMotivo) {
        this.dscTipoMotivo = dscTipoMotivo;
    }

    public String getSglUFInstalacao() {
        return sglUFInstalacao;
    }

    public void setSglUFInstalacao(String sglUFInstalacao) {
        this.sglUFInstalacao = sglUFInstalacao;
    }

    public String getDatRef() {
        return datRef;
    }

    public void setDatRef(String datRef) {
        this.datRef = datRef;
    }

    public String getDscAcaoItemOrdem() {
        return dscAcaoItemOrdem;
    }

    public void setDscAcaoItemOrdem(String dscAcaoItemOrdem) {
        this.dscAcaoItemOrdem = dscAcaoItemOrdem;
    }

    public String getDscStatusItem() {
        return dscStatusItem;
    }

    public void setDscStatusItem(String dscStatusItem) {
        this.dscStatusItem = dscStatusItem;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDscTipoOrdem() {
        return dscTipoOrdem;
    }

    public void setDscTipoOrdem(String dscTipoOrdem) {
        this.dscTipoOrdem = dscTipoOrdem;
    }

    public String getDscFormaPgto() {
        return dscFormaPgto;
    }

    public void setDscFormaPgto(String dscFormaPgto) {
        this.dscFormaPgto = dscFormaPgto;
    }

    public String getCodCtaFinanceira() {
        return codCtaFinanceira;
    }

    public void setCodCtaFinanceira(String codCtaFinanceira) {
        this.codCtaFinanceira = codCtaFinanceira;
    }

    public String getCodContratoOltp() {
        return codContratoOltp;
    }

    public void setCodContratoOltp(String codContratoOltp) {
        this.codContratoOltp = codContratoOltp;
    }

    public String getNumProtocolo() {
        return numProtocolo;
    }

    public void setNumProtocolo(String numProtocolo) {
        this.numProtocolo = numProtocolo;
    }

    public String getDatCriacaoOrdem() {
        return datCriacaoOrdem;
    }

    public void setDatCriacaoOrdem(String datCriacaoOrdem) {
        this.datCriacaoOrdem = datCriacaoOrdem;
    }

    public String getDatStatusOrdem() {
        return datStatusOrdem;
    }

    public void setDatStatusOrdem(String datStatusOrdem) {
        this.datStatusOrdem = datStatusOrdem;
    }

    public String getDatSuspensao() {
        return datSuspensao;
    }

    public void setDatSuspensao(String datSuspensao) {
        this.datSuspensao = datSuspensao;
    }

    public String getDatReativacao() {
        return datReativacao;
    }

    public void setDatReativacao(String datReativacao) {
        this.datReativacao = datReativacao;
    }

    public String getCodServiceId() {
        return codServiceId;
    }

    public void setCodServiceId(String codServiceId) {
        this.codServiceId = codServiceId;
    }

    public String getNomContato() {
        return nomContato;
    }

    public void setNomContato(String nomContato) {
        this.nomContato = nomContato;
    }

    public String getDscMotivoStatusItem() {
        return dscMotivoStatusItem;
    }

    public void setDscMotivoStatusItem(String dscMotivoStatusItem) {
        this.dscMotivoStatusItem = dscMotivoStatusItem;
    }

    public String getNomLoginResponsavel() {
        return nomLoginResponsavel;
    }

    public void setNomLoginResponsavel(String nomLoginResponsavel) {
        this.nomLoginResponsavel = nomLoginResponsavel;
    }

    public String getNomLoginVendedor() {
        return nomLoginVendedor;
    }

    public void setNomLoginVendedor(String nomLoginVendedor) {
        this.nomLoginVendedor = nomLoginVendedor;
    }

    public String getDscCanalVenda() {
        return dscCanalVenda;
    }

    public void setDscCanalVenda(String dscCanalVenda) {
        this.dscCanalVenda = dscCanalVenda;
    }

    public String getValPlanoAtual() {
        return valPlanoAtual;
    }

    public void setValPlanoAtual(String valPlanoAtual) {
        this.valPlanoAtual = valPlanoAtual;
    }

    public String getNomDescontoAtual() {
        return nomDescontoAtual;
    }

    public void setNomDescontoAtual(String nomDescontoAtual) {
        this.nomDescontoAtual = nomDescontoAtual;
    }

    public String getValDescontoAtual() {
        return valDescontoAtual;
    }

    public void setValDescontoAtual(String valDescontoAtual) {
        this.valDescontoAtual = valDescontoAtual;
    }

    public String getValPlanoNovo() {
        return valPlanoNovo;
    }

    public void setValPlanoNovo(String valPlanoNovo) {
        this.valPlanoNovo = valPlanoNovo;
    }

    public String getNomDescontoNovo() {
        return nomDescontoNovo;
    }

    public void setNomDescontoNovo(String nomDescontoNovo) {
        this.nomDescontoNovo = nomDescontoNovo;
    }

    public String getValDescontoNovo() {
        return valDescontoNovo;
    }

    public void setValDescontoNovo(String valDescontoNovo) {
        this.valDescontoNovo = valDescontoNovo;
    }

    public String getFlgPortabilidade() {
        return flgPortabilidade;
    }

    public void setFlgPortabilidade(String flgPortabilidade) {
        this.flgPortabilidade = flgPortabilidade;
    }

    public String getCodDdd() {
        return codDdd;
    }

    public void setCodDdd(String codDdd) {
        this.codDdd = codDdd;
    }

    public String getNumTelefonePortado() {
        return numTelefonePortado;
    }

    public void setNumTelefonePortado(String numTelefonePortado) {
        this.numTelefonePortado = numTelefonePortado;
    }

    public String getDatJanelaPortabilidade() {
        return datJanelaPortabilidade;
    }

    public void setDatJanelaPortabilidade(String datJanelaPortabilidade) {
        this.datJanelaPortabilidade = datJanelaPortabilidade;
    }

    public String getDscEstorno() {
        return dscEstorno;
    }

    public void setDscEstorno(String dscEstorno) {
        this.dscEstorno = dscEstorno;
    }

    public String getNumBilheteEstornado() {
        return numBilheteEstornado;
    }

    public void setNumBilheteEstornado(String numBilheteEstornado) {
        this.numBilheteEstornado = numBilheteEstornado;
    }

    public String getDscMotivoEstorno() {
        return dscMotivoEstorno;
    }

    public void setDscMotivoEstorno(String dscMotivoEstorno) {
        this.dscMotivoEstorno = dscMotivoEstorno;
    }

    public String getDiaVencimento() {
        return diaVencimento;
    }

    public void setDiaVencimento(String diaVencimento) {
        this.diaVencimento = diaVencimento;
    }

    public String getDscTipoConta() {
        return dscTipoConta;
    }

    public void setDscTipoConta(String dscTipoConta) {
        this.dscTipoConta = dscTipoConta;
    }

    public String getDscEnderecoFatura() {
        return dscEnderecoFatura;
    }

    public void setDscEnderecoFatura(String dscEnderecoFatura) {
        this.dscEnderecoFatura = dscEnderecoFatura;
    }

    public String getDscAreaVoip() {
        return dscAreaVoip;
    }

    public void setDscAreaVoip(String dscAreaVoip) {
        this.dscAreaVoip = dscAreaVoip;
    }

    public String getCodBanco() {
        return codBanco;
    }

    public void setCodBanco(String codBanco) {
        this.codBanco = codBanco;
    }

    public String getCodAgenciaBco() {
        return codAgenciaBco;
    }

    public void setCodAgenciaBco(String codAgenciaBco) {
        this.codAgenciaBco = codAgenciaBco;
    }

    public String getCodContaCorrente() {
        return codContaCorrente;
    }

    public void setCodContaCorrente(String codContaCorrente) {
        this.codContaCorrente = codContaCorrente;
    }

    public String getDatAltFormaPgto() {
        return datAltFormaPgto;
    }

    public void setDatAltFormaPgto(String datAltFormaPgto) {
        this.datAltFormaPgto = datAltFormaPgto;
    }

    public String getCodDebitoAutomatico() {
        return codDebitoAutomatico;
    }

    public void setCodDebitoAutomatico(String codDebitoAutomatico) {
        this.codDebitoAutomatico = codDebitoAutomatico;
    }

    public String getCodItemOrdem() {
        return codItemOrdem;
    }

    public void setCodItemOrdem(String codItemOrdem) {
        this.codItemOrdem = codItemOrdem;
    }

    public String getNomParceiroVenda() {
        return nomParceiroVenda;
    }

    public void setNomParceiroVenda(String nomParceiroVenda) {
        this.nomParceiroVenda = nomParceiroVenda;
    }

    public String getIdItemOrdPai() {
        return idItemOrdPai;
    }

    public void setIdItemOrdPai(String idItemOrdPai) {
        this.idItemOrdPai = idItemOrdPai;
    }

    public String getIdItemOrdem() {
        return idItemOrdem;
    }

    public void setIdItemOrdem(String idItemOrdem) {
        this.idItemOrdem = idItemOrdem;
    }

    public String getDscCategoriaItem() {
        return dscCategoriaItem;
    }

    public void setDscCategoriaItem(String dscCategoriaItem) {
        this.dscCategoriaItem = dscCategoriaItem;
    }

    public String getTecnologia() {
        return tecnologia;
    }

    public void setTecnologia(String tecnologia) {
        this.tecnologia = tecnologia;
    }

    public String getCpe() {
        return cpe;
    }

    public void setCpe(String cpe) {
        this.cpe = cpe;
    }

    public String getOnt() {
        return ont;
    }

    public void setOnt(String ont) {
        this.ont = ont;
    }

    public String getVelocidadeContratada() {
        return velocidadeContratada;
    }

    public void setVelocidadeContratada(String velocidadeContratada) {
        this.velocidadeContratada = velocidadeContratada;
    }

    public String getCustcode() {
        return custcode;
    }

    public void setCustcode(String custcode) {
        this.custcode = custcode;
    }

    public void setTipo(TypeStep3 tipo) {
        this.tipo = tipo;
    }

    public String getNumTelefone2() {
        return numTelefone2;
    }

    public void setNumTelefone2(String numTelefone2) {
        this.numTelefone2 = numTelefone2;
    }

    public String getNumTelefone3() {
        return numTelefone3;
    }

    public void setNumTelefone3(String numTelefone3) {
        this.numTelefone3 = numTelefone3;
    }

    public TypeStep3 getTipo() {
        return tipo;
    }

	public String getDscStatusOrdemWfm() {
		return dscStatusOrdemWfm;
	}

	public void setDscStatusOrdemWfm(String dscStatusOrdemWfm) {
		this.dscStatusOrdemWfm = dscStatusOrdemWfm;
	}

	public String getDatHoraStatusWfm() {
		return datHoraStatusWfm;
	}

	public void setDatHoraStatusWfm(String datHoraStatusWfm) {
		this.datHoraStatusWfm = datHoraStatusWfm;
	}
    
}
