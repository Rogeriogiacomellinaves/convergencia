package br.com.tim.mapreduce.refactoring.model;

import org.apache.commons.lang3.StringUtils;

import br.com.tim.utils.CommonsConstants;

public class BAT222Cliente {
	
	private String socialsecno;
	private String titulo;
	private String nome;
	private String tipo;
	private String sexo;
	private String nacionalidade;
	private String estadoCivil;
	private String eMail;
	private String telefoneContato;
	private String dataNascimento;
	private String status;
	private String cnae;
	private String score;
	private String flagDeficiente;
	private String tipoDeficiencia;
	private String flagEmancipado;
	private String segmento_cliente;
	private String tipoDocumento;
	private String numeroDocumento;
	private String orgaoExpedidorDocumento;
	private String ufExpedidorDocumento;
	private String validadeDocumento;
	private String numeroInscricaoEstadual;
	private String ufInscricaoEstadual;
	private String numeroInscricaoMunicipal;
	private String municipioInscricaoMunicipal;
	private String naturezaJuridica;
	private String porteEmpresa;
	private String numeroFuncionarios;
	private String nomeMae;
	private String tipoLogradouro;
	private String logradouro;
	private String nameroEndereco;
	private String complemento;
	private String bairro;
	private String cidade;
	private String uf;
	private String cep;
	private String caixaPostal;
	private String rowIdEndereco;
	private String dataAtivacaoCrm;
	private String loginRespAtivacao;
	private String perfilLoginRespAtivacao;
	private String pdvRespAtivacao;
	private String dataModificacao;
	private String loginRespModificacao;
	private String perfilLoginRespModificacao;
	private String pdvRespModificacao;
	private String rowid;
	private String loteid;
	private String arquivo;
	private String arquivots;
	private String currentdate;
	private String flgConvergente;
	private String tpoCadastro;
	private String dscOrgaoEmissorInscricaoEstadual;
	private String numTelefoneContato2;
	private String numTelefoneContato3;
	private String datFundacao;
	private String datEmissao;
	private String dscGrupoEmpresarial;
	private String dscRamoAtividade;
	private String dscCnae;
	private String codCnaeSecundario;
	private String dscCnaeSecundario;
	private String vlrRendaInformada;
	private String dscCapitalSocial;
	private String vlrMedioContaConcorrencia;
	private String codNaturezaJuridica;
	private String nomPaisOrigem;
	private String vlrFaturamentoPresumido;
	private String dscCarteiraPertencente;
	private String rowIdCliente;
	
	
    public static BAT222Cliente parseFromText(String text) {
        if (!StringUtils.isEmpty(text)) {
            String[] cols = text.split(CommonsConstants.FILE_SPLIT_REGEX, -1);
            int i = 0;
            
			return new BAT222Cliente(cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++]);
        }
        return new BAT222Cliente();
    }

            
	public BAT222Cliente() {
		
		this.clear();

	}
	
	public BAT222Cliente(String socialsecno, String titulo, String nome, String tipo, String sexo, String nacionalidade,
			String estadoCivil, String eMail, String telefoneContato, String dataNascimento, String status, String cnae,
			String score, String flagDeficiente, String tipoDeficiencia, String flagEmancipado, String segmento_cliente,
			String tipoDocumento, String numeroDocumento, String orgaoExpedidorDocumento, String ufExpedidorDocumento,
			String validadeDocumento, String numeroInscricaoEstadual, String ufInscricaoEstadual,
			String numeroInscricaoMunicipal, String municipioInscricaoMunicipal, String naturezaJuridica,
			String porteEmpresa, String numeroFuncionarios, String nomeMae, String tipoLogradouro, String logradouro,
			String nameroEndereco, String complemento, String bairro, String cidade, String uf, String cep,
			String caixaPostal, String rowIdEndereco, String dataAtivacaoCrm, String loginRespAtivacao,
			String perfilLoginRespAtivacao, String pdvRespAtivacao, String dataModificacao, String loginRespModificacao,
			String perfilLoginRespModificacao, String pdvRespModificacao, String rowid, String loteid, String arquivo,
			String arquivots, String currentdate, String flgConvergente, String tpoCadastro,
			String dscOrgaoEmissorInscricaoEstadual, String numTelefoneContato2, String numTelefoneContato3,
			String datFundacao, String datEmissao, String dscGrupoEmpresarial, String dscRamoAtividade, String dscCnae,
			String codCnaeSecundario, String dscCnaeSecundario, String vlrRendaInformada, String dscCapitalSocial,
			String vlrMedioContaConcorrencia, String codNaturezaJuridica, String nomPaisOrigem,
			String vlrFaturamentoPresumido, String dscCarteiraPertencente, String rowIdCliente) {

		this.socialsecno = socialsecno;
		this.titulo = titulo;
		this.nome = nome;
		this.tipo = tipo;
		this.sexo = sexo;
		this.nacionalidade = nacionalidade;
		this.estadoCivil = estadoCivil;
		this.eMail = eMail;
		this.telefoneContato = telefoneContato;
		this.dataNascimento = dataNascimento;
		this.status = status;
		this.cnae = cnae;
		this.score = score;
		this.flagDeficiente = flagDeficiente;
		this.tipoDeficiencia = tipoDeficiencia;
		this.flagEmancipado = flagEmancipado;
		this.segmento_cliente = segmento_cliente;
		this.tipoDocumento = tipoDocumento;
		this.numeroDocumento = numeroDocumento;
		this.orgaoExpedidorDocumento = orgaoExpedidorDocumento;
		this.ufExpedidorDocumento = ufExpedidorDocumento;
		this.validadeDocumento = validadeDocumento;
		this.numeroInscricaoEstadual = numeroInscricaoEstadual;
		this.ufInscricaoEstadual = ufInscricaoEstadual;
		this.numeroInscricaoMunicipal = numeroInscricaoMunicipal;
		this.municipioInscricaoMunicipal = municipioInscricaoMunicipal;
		this.naturezaJuridica = naturezaJuridica;
		this.porteEmpresa = porteEmpresa;
		this.numeroFuncionarios = numeroFuncionarios;
		this.nomeMae = nomeMae;
		this.tipoLogradouro = tipoLogradouro;
		this.logradouro = logradouro;
		this.nameroEndereco = nameroEndereco;
		this.complemento = complemento;
		this.bairro = bairro;
		this.cidade = cidade;
		this.uf = uf;
		this.cep = cep;
		this.caixaPostal = caixaPostal;
		this.rowIdEndereco = rowIdEndereco;
		this.dataAtivacaoCrm = dataAtivacaoCrm;
		this.loginRespAtivacao = loginRespAtivacao;
		this.perfilLoginRespAtivacao = perfilLoginRespAtivacao;
		this.pdvRespAtivacao = pdvRespAtivacao;
		this.dataModificacao = dataModificacao;
		this.loginRespModificacao = loginRespModificacao;
		this.perfilLoginRespModificacao = perfilLoginRespModificacao;
		this.pdvRespModificacao = pdvRespModificacao;
		this.rowid = rowid;
		this.loteid = loteid;
		this.arquivo = arquivo;
		this.arquivots = arquivots;
		this.currentdate = currentdate;
		this.flgConvergente = flgConvergente;
		this.tpoCadastro = tpoCadastro;
		this.dscOrgaoEmissorInscricaoEstadual = dscOrgaoEmissorInscricaoEstadual;
		this.numTelefoneContato2 = numTelefoneContato2;
		this.numTelefoneContato3 = numTelefoneContato3;
		this.datFundacao = datFundacao;
		this.datEmissao = datEmissao;
		this.dscGrupoEmpresarial = dscGrupoEmpresarial;
		this.dscRamoAtividade = dscRamoAtividade;
		this.dscCnae = dscCnae;
		this.codCnaeSecundario = codCnaeSecundario;
		this.dscCnaeSecundario = dscCnaeSecundario;
		this.vlrRendaInformada = vlrRendaInformada;
		this.dscCapitalSocial = dscCapitalSocial;
		this.vlrMedioContaConcorrencia = vlrMedioContaConcorrencia;
		this.codNaturezaJuridica = codNaturezaJuridica;
		this.nomPaisOrigem = nomPaisOrigem;
		this.vlrFaturamentoPresumido = vlrFaturamentoPresumido;
		this.dscCarteiraPertencente = dscCarteiraPertencente;
		this.rowIdCliente = rowIdCliente;
	}

	
	public void clear() {
		
		this.socialsecno = CommonsConstants.EMPTY;
		this.titulo = CommonsConstants.EMPTY;
		this.nome = CommonsConstants.EMPTY;
		this.tipo = CommonsConstants.EMPTY;
		this.sexo = CommonsConstants.EMPTY;
		this.nacionalidade = CommonsConstants.EMPTY;
		this.estadoCivil = CommonsConstants.EMPTY;
		this.eMail = CommonsConstants.EMPTY;
		this.telefoneContato = CommonsConstants.EMPTY;
		this.dataNascimento = CommonsConstants.EMPTY;
		this.status = CommonsConstants.EMPTY;
		this.cnae = CommonsConstants.EMPTY;
		this.score = CommonsConstants.EMPTY;
		this.flagDeficiente = CommonsConstants.EMPTY;
		this.tipoDeficiencia = CommonsConstants.EMPTY;
		this.flagEmancipado = CommonsConstants.EMPTY;
		this.segmento_cliente = CommonsConstants.EMPTY;
		this.tipoDocumento = CommonsConstants.EMPTY;
		this.numeroDocumento = CommonsConstants.EMPTY;
		this.orgaoExpedidorDocumento = CommonsConstants.EMPTY;
		this.ufExpedidorDocumento = CommonsConstants.EMPTY;
		this.validadeDocumento = CommonsConstants.EMPTY;
		this.numeroInscricaoEstadual = CommonsConstants.EMPTY;
		this.ufInscricaoEstadual = CommonsConstants.EMPTY;
		this.numeroInscricaoMunicipal = CommonsConstants.EMPTY;
		this.municipioInscricaoMunicipal = CommonsConstants.EMPTY;
		this.naturezaJuridica = CommonsConstants.EMPTY;
		this.porteEmpresa = CommonsConstants.EMPTY;
		this.numeroFuncionarios = CommonsConstants.EMPTY;
		this.nomeMae = CommonsConstants.EMPTY;
		this.tipoLogradouro = CommonsConstants.EMPTY;
		this.logradouro = CommonsConstants.EMPTY;
		this.nameroEndereco = CommonsConstants.EMPTY;
		this.complemento = CommonsConstants.EMPTY;
		this.bairro = CommonsConstants.EMPTY;
		this.cidade = CommonsConstants.EMPTY;
		this.uf = CommonsConstants.EMPTY;
		this.cep = CommonsConstants.EMPTY;
		this.caixaPostal = CommonsConstants.EMPTY;
		this.rowIdEndereco = CommonsConstants.EMPTY;
		this.dataAtivacaoCrm = CommonsConstants.EMPTY;
		this.loginRespAtivacao = CommonsConstants.EMPTY;
		this.perfilLoginRespAtivacao = CommonsConstants.EMPTY;
		this.pdvRespAtivacao = CommonsConstants.EMPTY;
		this.dataModificacao = CommonsConstants.EMPTY;
		this.loginRespModificacao = CommonsConstants.EMPTY;
		this.perfilLoginRespModificacao = CommonsConstants.EMPTY;
		this.pdvRespModificacao = CommonsConstants.EMPTY;
		this.rowid = CommonsConstants.EMPTY;
		this.loteid = CommonsConstants.EMPTY;
		this.arquivo = CommonsConstants.EMPTY;
		this.arquivots = CommonsConstants.EMPTY;
		this.currentdate = CommonsConstants.EMPTY;
		this.flgConvergente = CommonsConstants.EMPTY;
		this.tpoCadastro = CommonsConstants.EMPTY;
		this.dscOrgaoEmissorInscricaoEstadual = CommonsConstants.EMPTY;
		this.numTelefoneContato2 = CommonsConstants.EMPTY;
		this.numTelefoneContato3 = CommonsConstants.EMPTY;
		this.datFundacao = CommonsConstants.EMPTY;
		this.datEmissao = CommonsConstants.EMPTY;
		this.dscGrupoEmpresarial = CommonsConstants.EMPTY;
		this.dscRamoAtividade = CommonsConstants.EMPTY;
		this.dscCnae = CommonsConstants.EMPTY;
		this.codCnaeSecundario = CommonsConstants.EMPTY;
		this.dscCnaeSecundario = CommonsConstants.EMPTY;
		this.vlrRendaInformada = CommonsConstants.EMPTY;
		this.dscCapitalSocial = CommonsConstants.EMPTY;
		this.vlrMedioContaConcorrencia = CommonsConstants.EMPTY;
		this.codNaturezaJuridica = CommonsConstants.EMPTY;
		this.nomPaisOrigem = CommonsConstants.EMPTY;
		this.vlrFaturamentoPresumido = CommonsConstants.EMPTY;
		this.dscCarteiraPertencente = CommonsConstants.EMPTY;
		this.rowIdCliente = CommonsConstants.EMPTY;
		
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((arquivo == null) ? 0 : arquivo.hashCode());
		result = prime * result + ((arquivots == null) ? 0 : arquivots.hashCode());
		result = prime * result + ((bairro == null) ? 0 : bairro.hashCode());
		result = prime * result + ((caixaPostal == null) ? 0 : caixaPostal.hashCode());
		result = prime * result + ((cep == null) ? 0 : cep.hashCode());
		result = prime * result + ((cidade == null) ? 0 : cidade.hashCode());
		result = prime * result + ((cnae == null) ? 0 : cnae.hashCode());
		result = prime * result + ((codCnaeSecundario == null) ? 0 : codCnaeSecundario.hashCode());
		result = prime * result + ((codNaturezaJuridica == null) ? 0 : codNaturezaJuridica.hashCode());
		result = prime * result + ((complemento == null) ? 0 : complemento.hashCode());
		result = prime * result + ((currentdate == null) ? 0 : currentdate.hashCode());
		result = prime * result + ((datEmissao == null) ? 0 : datEmissao.hashCode());
		result = prime * result + ((datFundacao == null) ? 0 : datFundacao.hashCode());
		result = prime * result + ((dataAtivacaoCrm == null) ? 0 : dataAtivacaoCrm.hashCode());
		result = prime * result + ((dataModificacao == null) ? 0 : dataModificacao.hashCode());
		result = prime * result + ((dataNascimento == null) ? 0 : dataNascimento.hashCode());
		result = prime * result + ((dscCapitalSocial == null) ? 0 : dscCapitalSocial.hashCode());
		result = prime * result + ((dscCarteiraPertencente == null) ? 0 : dscCarteiraPertencente.hashCode());
		result = prime * result + ((dscCnae == null) ? 0 : dscCnae.hashCode());
		result = prime * result + ((dscCnaeSecundario == null) ? 0 : dscCnaeSecundario.hashCode());
		result = prime * result + ((dscGrupoEmpresarial == null) ? 0 : dscGrupoEmpresarial.hashCode());
		result = prime * result
				+ ((dscOrgaoEmissorInscricaoEstadual == null) ? 0 : dscOrgaoEmissorInscricaoEstadual.hashCode());
		result = prime * result + ((dscRamoAtividade == null) ? 0 : dscRamoAtividade.hashCode());
		result = prime * result + ((eMail == null) ? 0 : eMail.hashCode());
		result = prime * result + ((estadoCivil == null) ? 0 : estadoCivil.hashCode());
		result = prime * result + ((flagDeficiente == null) ? 0 : flagDeficiente.hashCode());
		result = prime * result + ((flagEmancipado == null) ? 0 : flagEmancipado.hashCode());
		result = prime * result + ((flgConvergente == null) ? 0 : flgConvergente.hashCode());
		result = prime * result + ((loginRespAtivacao == null) ? 0 : loginRespAtivacao.hashCode());
		result = prime * result + ((loginRespModificacao == null) ? 0 : loginRespModificacao.hashCode());
		result = prime * result + ((logradouro == null) ? 0 : logradouro.hashCode());
		result = prime * result + ((loteid == null) ? 0 : loteid.hashCode());
		result = prime * result + ((municipioInscricaoMunicipal == null) ? 0 : municipioInscricaoMunicipal.hashCode());
		result = prime * result + ((nacionalidade == null) ? 0 : nacionalidade.hashCode());
		result = prime * result + ((nameroEndereco == null) ? 0 : nameroEndereco.hashCode());
		result = prime * result + ((naturezaJuridica == null) ? 0 : naturezaJuridica.hashCode());
		result = prime * result + ((nomPaisOrigem == null) ? 0 : nomPaisOrigem.hashCode());
		result = prime * result + ((nome == null) ? 0 : nome.hashCode());
		result = prime * result + ((nomeMae == null) ? 0 : nomeMae.hashCode());
		result = prime * result + ((numTelefoneContato2 == null) ? 0 : numTelefoneContato2.hashCode());
		result = prime * result + ((numTelefoneContato3 == null) ? 0 : numTelefoneContato3.hashCode());
		result = prime * result + ((numeroDocumento == null) ? 0 : numeroDocumento.hashCode());
		result = prime * result + ((numeroFuncionarios == null) ? 0 : numeroFuncionarios.hashCode());
		result = prime * result + ((numeroInscricaoEstadual == null) ? 0 : numeroInscricaoEstadual.hashCode());
		result = prime * result + ((numeroInscricaoMunicipal == null) ? 0 : numeroInscricaoMunicipal.hashCode());
		result = prime * result + ((orgaoExpedidorDocumento == null) ? 0 : orgaoExpedidorDocumento.hashCode());
		result = prime * result + ((pdvRespAtivacao == null) ? 0 : pdvRespAtivacao.hashCode());
		result = prime * result + ((pdvRespModificacao == null) ? 0 : pdvRespModificacao.hashCode());
		result = prime * result + ((perfilLoginRespAtivacao == null) ? 0 : perfilLoginRespAtivacao.hashCode());
		result = prime * result + ((perfilLoginRespModificacao == null) ? 0 : perfilLoginRespModificacao.hashCode());
		result = prime * result + ((porteEmpresa == null) ? 0 : porteEmpresa.hashCode());
		result = prime * result + ((rowIdCliente == null) ? 0 : rowIdCliente.hashCode());
		result = prime * result + ((rowIdEndereco == null) ? 0 : rowIdEndereco.hashCode());
		result = prime * result + ((rowid == null) ? 0 : rowid.hashCode());
		result = prime * result + ((score == null) ? 0 : score.hashCode());
		result = prime * result + ((segmento_cliente == null) ? 0 : segmento_cliente.hashCode());
		result = prime * result + ((sexo == null) ? 0 : sexo.hashCode());
		result = prime * result + ((socialsecno == null) ? 0 : socialsecno.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result + ((telefoneContato == null) ? 0 : telefoneContato.hashCode());
		result = prime * result + ((tipo == null) ? 0 : tipo.hashCode());
		result = prime * result + ((tipoDeficiencia == null) ? 0 : tipoDeficiencia.hashCode());
		result = prime * result + ((tipoDocumento == null) ? 0 : tipoDocumento.hashCode());
		result = prime * result + ((tipoLogradouro == null) ? 0 : tipoLogradouro.hashCode());
		result = prime * result + ((titulo == null) ? 0 : titulo.hashCode());
		result = prime * result + ((tpoCadastro == null) ? 0 : tpoCadastro.hashCode());
		result = prime * result + ((uf == null) ? 0 : uf.hashCode());
		result = prime * result + ((ufExpedidorDocumento == null) ? 0 : ufExpedidorDocumento.hashCode());
		result = prime * result + ((ufInscricaoEstadual == null) ? 0 : ufInscricaoEstadual.hashCode());
		result = prime * result + ((validadeDocumento == null) ? 0 : validadeDocumento.hashCode());
		result = prime * result + ((vlrFaturamentoPresumido == null) ? 0 : vlrFaturamentoPresumido.hashCode());
		result = prime * result + ((vlrMedioContaConcorrencia == null) ? 0 : vlrMedioContaConcorrencia.hashCode());
		result = prime * result + ((vlrRendaInformada == null) ? 0 : vlrRendaInformada.hashCode());
		return result;
	}

	
	

	public String getSocialsecno() {
		return socialsecno;
	}


	public void setSocialsecno(String socialsecno) {
		this.socialsecno = socialsecno;
	}


	public String getTitulo() {
		return titulo;
	}


	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}


	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}


	public String getTipo() {
		return tipo;
	}


	public void setTipo(String tipo) {
		this.tipo = tipo;
	}


	public String getSexo() {
		return sexo;
	}


	public void setSexo(String sexo) {
		this.sexo = sexo;
	}


	public String getNacionalidade() {
		return nacionalidade;
	}


	public void setNacionalidade(String nacionalidade) {
		this.nacionalidade = nacionalidade;
	}


	public String getEstadoCivil() {
		return estadoCivil;
	}


	public void setEstadoCivil(String estadoCivil) {
		this.estadoCivil = estadoCivil;
	}


	public String geteMail() {
		return eMail;
	}


	public void seteMail(String eMail) {
		this.eMail = eMail;
	}


	public String getTelefoneContato() {
		return telefoneContato;
	}


	public void setTelefoneContato(String telefoneContato) {
		this.telefoneContato = telefoneContato;
	}


	public String getDataNascimento() {
		return dataNascimento;
	}


	public void setDataNascimento(String dataNascimento) {
		this.dataNascimento = dataNascimento;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getCnae() {
		return cnae;
	}


	public void setCnae(String cnae) {
		this.cnae = cnae;
	}


	public String getScore() {
		return score;
	}


	public void setScore(String score) {
		this.score = score;
	}


	public String getFlagDeficiente() {
		return flagDeficiente;
	}


	public void setFlagDeficiente(String flagDeficiente) {
		this.flagDeficiente = flagDeficiente;
	}


	public String getTipoDeficiencia() {
		return tipoDeficiencia;
	}


	public void setTipoDeficiencia(String tipoDeficiencia) {
		this.tipoDeficiencia = tipoDeficiencia;
	}


	public String getFlagEmancipado() {
		return flagEmancipado;
	}


	public void setFlagEmancipado(String flagEmancipado) {
		this.flagEmancipado = flagEmancipado;
	}


	public String getSegmento_cliente() {
		return segmento_cliente;
	}


	public void setSegmento_cliente(String segmento_cliente) {
		this.segmento_cliente = segmento_cliente;
	}


	public String getTipoDocumento() {
		return tipoDocumento;
	}


	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}


	public String getNumeroDocumento() {
		return numeroDocumento;
	}


	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}


	public String getOrgaoExpedidorDocumento() {
		return orgaoExpedidorDocumento;
	}


	public void setOrgaoExpedidorDocumento(String orgaoExpedidorDocumento) {
		this.orgaoExpedidorDocumento = orgaoExpedidorDocumento;
	}


	public String getUfExpedidorDocumento() {
		return ufExpedidorDocumento;
	}


	public void setUfExpedidorDocumento(String ufExpedidorDocumento) {
		this.ufExpedidorDocumento = ufExpedidorDocumento;
	}


	public String getValidadeDocumento() {
		return validadeDocumento;
	}


	public void setValidadeDocumento(String validadeDocumento) {
		this.validadeDocumento = validadeDocumento;
	}


	public String getNumeroInscricaoEstadual() {
		return numeroInscricaoEstadual;
	}


	public void setNumeroInscricaoEstadual(String numeroInscricaoEstadual) {
		this.numeroInscricaoEstadual = numeroInscricaoEstadual;
	}


	public String getUfInscricaoEstadual() {
		return ufInscricaoEstadual;
	}


	public void setUfInscricaoEstadual(String ufInscricaoEstadual) {
		this.ufInscricaoEstadual = ufInscricaoEstadual;
	}


	public String getNumeroInscricaoMunicipal() {
		return numeroInscricaoMunicipal;
	}


	public void setNumeroInscricaoMunicipal(String numeroInscricaoMunicipal) {
		this.numeroInscricaoMunicipal = numeroInscricaoMunicipal;
	}


	public String getMunicipioInscricaoMunicipal() {
		return municipioInscricaoMunicipal;
	}


	public void setMunicipioInscricaoMunicipal(String municipioInscricaoMunicipal) {
		this.municipioInscricaoMunicipal = municipioInscricaoMunicipal;
	}


	public String getNaturezaJuridica() {
		return naturezaJuridica;
	}


	public void setNaturezaJuridica(String naturezaJuridica) {
		this.naturezaJuridica = naturezaJuridica;
	}


	public String getPorteEmpresa() {
		return porteEmpresa;
	}


	public void setPorteEmpresa(String porteEmpresa) {
		this.porteEmpresa = porteEmpresa;
	}


	public String getNumeroFuncionarios() {
		return numeroFuncionarios;
	}


	public void setNumeroFuncionarios(String numeroFuncionarios) {
		this.numeroFuncionarios = numeroFuncionarios;
	}


	public String getNomeMae() {
		return nomeMae;
	}


	public void setNomeMae(String nomeMae) {
		this.nomeMae = nomeMae;
	}


	public String getTipoLogradouro() {
		return tipoLogradouro;
	}


	public void setTipoLogradouro(String tipoLogradouro) {
		this.tipoLogradouro = tipoLogradouro;
	}


	public String getLogradouro() {
		return logradouro;
	}


	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}


	public String getNameroEndereco() {
		return nameroEndereco;
	}


	public void setNameroEndereco(String nameroEndereco) {
		this.nameroEndereco = nameroEndereco;
	}


	public String getComplemento() {
		return complemento;
	}


	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}


	public String getBairro() {
		return bairro;
	}


	public void setBairro(String bairro) {
		this.bairro = bairro;
	}


	public String getCidade() {
		return cidade;
	}


	public void setCidade(String cidade) {
		this.cidade = cidade;
	}


	public String getUf() {
		return uf;
	}


	public void setUf(String uf) {
		this.uf = uf;
	}


	public String getCep() {
		return cep;
	}


	public void setCep(String cep) {
		this.cep = cep;
	}


	public String getCaixaPostal() {
		return caixaPostal;
	}


	public void setCaixaPostal(String caixaPostal) {
		this.caixaPostal = caixaPostal;
	}


	public String getRowIdEndereco() {
		return rowIdEndereco;
	}


	public void setRowIdEndereco(String rowIdEndereco) {
		this.rowIdEndereco = rowIdEndereco;
	}


	public String getDataAtivacaoCrm() {
		return dataAtivacaoCrm;
	}


	public void setDataAtivacaoCrm(String dataAtivacaoCrm) {
		this.dataAtivacaoCrm = dataAtivacaoCrm;
	}


	public String getLoginRespAtivacao() {
		return loginRespAtivacao;
	}


	public void setLoginRespAtivacao(String loginRespAtivacao) {
		this.loginRespAtivacao = loginRespAtivacao;
	}


	public String getPerfilLoginRespAtivacao() {
		return perfilLoginRespAtivacao;
	}


	public void setPerfilLoginRespAtivacao(String perfilLoginRespAtivacao) {
		this.perfilLoginRespAtivacao = perfilLoginRespAtivacao;
	}


	public String getPdvRespAtivacao() {
		return pdvRespAtivacao;
	}


	public void setPdvRespAtivacao(String pdvRespAtivacao) {
		this.pdvRespAtivacao = pdvRespAtivacao;
	}


	public String getDataModificacao() {
		return dataModificacao;
	}


	public void setDataModificacao(String dataModificacao) {
		this.dataModificacao = dataModificacao;
	}


	public String getLoginRespModificacao() {
		return loginRespModificacao;
	}


	public void setLoginRespModificacao(String loginRespModificacao) {
		this.loginRespModificacao = loginRespModificacao;
	}


	public String getPerfilLoginRespModificacao() {
		return perfilLoginRespModificacao;
	}


	public void setPerfilLoginRespModificacao(String perfilLoginRespModificacao) {
		this.perfilLoginRespModificacao = perfilLoginRespModificacao;
	}


	public String getPdvRespModificacao() {
		return pdvRespModificacao;
	}


	public void setPdvRespModificacao(String pdvRespModificacao) {
		this.pdvRespModificacao = pdvRespModificacao;
	}


	public String getRowid() {
		return rowid;
	}


	public void setRowid(String rowid) {
		this.rowid = rowid;
	}


	public String getLoteid() {
		return loteid;
	}


	public void setLoteid(String loteid) {
		this.loteid = loteid;
	}


	public String getArquivo() {
		return arquivo;
	}


	public void setArquivo(String arquivo) {
		this.arquivo = arquivo;
	}


	public String getArquivots() {
		return arquivots;
	}


	public void setArquivots(String arquivots) {
		this.arquivots = arquivots;
	}


	public String getCurrentdate() {
		return currentdate;
	}


	public void setCurrentdate(String currentdate) {
		this.currentdate = currentdate;
	}


	public String getFlgConvergente() {
		return flgConvergente;
	}


	public void setFlgConvergente(String flgConvergente) {
		this.flgConvergente = flgConvergente;
	}


	public String getTpoCadastro() {
		return tpoCadastro;
	}


	public void setTpoCadastro(String tpoCadastro) {
		this.tpoCadastro = tpoCadastro;
	}


	public String getDscOrgaoEmissorInscricaoEstadual() {
		return dscOrgaoEmissorInscricaoEstadual;
	}


	public void setDscOrgaoEmissorInscricaoEstadual(String dscOrgaoEmissorInscricaoEstadual) {
		this.dscOrgaoEmissorInscricaoEstadual = dscOrgaoEmissorInscricaoEstadual;
	}


	public String getNumTelefoneContato2() {
		return numTelefoneContato2;
	}


	public void setNumTelefoneContato2(String numTelefoneContato2) {
		this.numTelefoneContato2 = numTelefoneContato2;
	}


	public String getNumTelefoneContato3() {
		return numTelefoneContato3;
	}


	public void setNumTelefoneContato3(String numTelefoneContato3) {
		this.numTelefoneContato3 = numTelefoneContato3;
	}


	public String getDatFundacao() {
		return datFundacao;
	}


	public void setDatFundacao(String datFundacao) {
		this.datFundacao = datFundacao;
	}


	public String getDatEmissao() {
		return datEmissao;
	}


	public void setDatEmissao(String datEmissao) {
		this.datEmissao = datEmissao;
	}


	public String getDscGrupoEmpresarial() {
		return dscGrupoEmpresarial;
	}


	public void setDscGrupoEmpresarial(String dscGrupoEmpresarial) {
		this.dscGrupoEmpresarial = dscGrupoEmpresarial;
	}


	public String getDscRamoAtividade() {
		return dscRamoAtividade;
	}


	public void setDscRamoAtividade(String dscRamoAtividade) {
		this.dscRamoAtividade = dscRamoAtividade;
	}


	public String getDscCnae() {
		return dscCnae;
	}


	public void setDscCnae(String dscCnae) {
		this.dscCnae = dscCnae;
	}


	public String getCodCnaeSecundario() {
		return codCnaeSecundario;
	}


	public void setCodCnaeSecundario(String codCnaeSecundario) {
		this.codCnaeSecundario = codCnaeSecundario;
	}


	public String getDscCnaeSecundario() {
		return dscCnaeSecundario;
	}


	public void setDscCnaeSecundario(String dscCnaeSecundario) {
		this.dscCnaeSecundario = dscCnaeSecundario;
	}


	public String getVlrRendaInformada() {
		return vlrRendaInformada;
	}


	public void setVlrRendaInformada(String vlrRendaInformada) {
		this.vlrRendaInformada = vlrRendaInformada;
	}


	public String getDscCapitalSocial() {
		return dscCapitalSocial;
	}


	public void setDscCapitalSocial(String dscCapitalSocial) {
		this.dscCapitalSocial = dscCapitalSocial;
	}


	public String getVlrMedioContaConcorrencia() {
		return vlrMedioContaConcorrencia;
	}


	public void setVlrMedioContaConcorrencia(String vlrMedioContaConcorrencia) {
		this.vlrMedioContaConcorrencia = vlrMedioContaConcorrencia;
	}


	public String getCodNaturezaJuridica() {
		return codNaturezaJuridica;
	}


	public void setCodNaturezaJuridica(String codNaturezaJuridica) {
		this.codNaturezaJuridica = codNaturezaJuridica;
	}


	public String getNomPaisOrigem() {
		return nomPaisOrigem;
	}


	public void setNomPaisOrigem(String nomPaisOrigem) {
		this.nomPaisOrigem = nomPaisOrigem;
	}


	public String getVlrFaturamentoPresumido() {
		return vlrFaturamentoPresumido;
	}


	public void setVlrFaturamentoPresumido(String vlrFaturamentoPresumido) {
		this.vlrFaturamentoPresumido = vlrFaturamentoPresumido;
	}


	public String getDscCarteiraPertencente() {
		return dscCarteiraPertencente;
	}


	public void setDscCarteiraPertencente(String dscCarteiraPertencente) {
		this.dscCarteiraPertencente = dscCarteiraPertencente;
	}


	public String getRowIdCliente() {
		return rowIdCliente;
	}


	public void setRowIdCliente(String rowIdCliente) {
		this.rowIdCliente = rowIdCliente;
	}

	

	@Override
	public String toString() {
		return "BAT222Cliente [socialsecno=" + socialsecno + ", titulo=" + titulo + ", nome=" + nome + ", tipo=" + tipo
				+ ", sexo=" + sexo + ", nacionalidade=" + nacionalidade + ", estadoCivil=" + estadoCivil + ", eMail="
				+ eMail + ", telefoneContato=" + telefoneContato + ", dataNascimento=" + dataNascimento + ", status="
				+ status + ", cnae=" + cnae + ", score=" + score + ", flagDeficiente=" + flagDeficiente
				+ ", tipoDeficiencia=" + tipoDeficiencia + ", flagEmancipado=" + flagEmancipado + ", segmento_cliente="
				+ segmento_cliente + ", tipoDocumento=" + tipoDocumento + ", numeroDocumento=" + numeroDocumento
				+ ", orgaoExpedidorDocumento=" + orgaoExpedidorDocumento + ", ufExpedidorDocumento="
				+ ufExpedidorDocumento + ", validadeDocumento=" + validadeDocumento + ", numeroInscricaoEstadual="
				+ numeroInscricaoEstadual + ", ufInscricaoEstadual=" + ufInscricaoEstadual
				+ ", numeroInscricaoMunicipal=" + numeroInscricaoMunicipal + ", municipioInscricaoMunicipal="
				+ municipioInscricaoMunicipal + ", naturezaJuridica=" + naturezaJuridica + ", porteEmpresa="
				+ porteEmpresa + ", numeroFuncionarios=" + numeroFuncionarios + ", nomeMae=" + nomeMae
				+ ", tipoLogradouro=" + tipoLogradouro + ", logradouro=" + logradouro + ", nameroEndereco="
				+ nameroEndereco + ", complemento=" + complemento + ", bairro=" + bairro + ", cidade=" + cidade
				+ ", uf=" + uf + ", cep=" + cep + ", caixaPostal=" + caixaPostal + ", rowIdEndereco=" + rowIdEndereco
				+ ", dataAtivacaoCrm=" + dataAtivacaoCrm + ", loginRespAtivacao=" + loginRespAtivacao
				+ ", perfilLoginRespAtivacao=" + perfilLoginRespAtivacao + ", pdvRespAtivacao=" + pdvRespAtivacao
				+ ", dataModificacao=" + dataModificacao + ", loginRespModificacao=" + loginRespModificacao
				+ ", perfilLoginRespModificacao=" + perfilLoginRespModificacao + ", pdvRespModificacao="
				+ pdvRespModificacao + ", rowid=" + rowid + ", loteid=" + loteid + ", arquivo=" + arquivo
				+ ", arquivots=" + arquivots + ", currentdate=" + currentdate + ", flgConvergente=" + flgConvergente
				+ ", tpoCadastro=" + tpoCadastro + ", dscOrgaoEmissorInscricaoEstadual="
				+ dscOrgaoEmissorInscricaoEstadual + ", numTelefoneContato2=" + numTelefoneContato2
				+ ", numTelefoneContato3=" + numTelefoneContato3 + ", datFundacao=" + datFundacao + ", datEmissao="
				+ datEmissao + ", dscGrupoEmpresarial=" + dscGrupoEmpresarial + ", dscRamoAtividade=" + dscRamoAtividade
				+ ", dscCnae=" + dscCnae + ", codCnaeSecundario=" + codCnaeSecundario + ", dscCnaeSecundario="
				+ dscCnaeSecundario + ", vlrRendaInformada=" + vlrRendaInformada + ", dscCapitalSocial="
				+ dscCapitalSocial + ", vlrMedioContaConcorrencia=" + vlrMedioContaConcorrencia
				+ ", codNaturezaJuridica=" + codNaturezaJuridica + ", nomPaisOrigem=" + nomPaisOrigem
				+ ", vlrFaturamentoPresumido=" + vlrFaturamentoPresumido + ", dscCarteiraPertencente="
				+ dscCarteiraPertencente + ", rowIdCliente=" + rowIdCliente + "]";
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BAT222Cliente other = (BAT222Cliente) obj;
		if (arquivo == null) {
			if (other.arquivo != null)
				return false;
		} else if (!arquivo.equals(other.arquivo))
			return false;
		if (arquivots == null) {
			if (other.arquivots != null)
				return false;
		} else if (!arquivots.equals(other.arquivots))
			return false;
		if (bairro == null) {
			if (other.bairro != null)
				return false;
		} else if (!bairro.equals(other.bairro))
			return false;
		if (caixaPostal == null) {
			if (other.caixaPostal != null)
				return false;
		} else if (!caixaPostal.equals(other.caixaPostal))
			return false;
		if (cep == null) {
			if (other.cep != null)
				return false;
		} else if (!cep.equals(other.cep))
			return false;
		if (cidade == null) {
			if (other.cidade != null)
				return false;
		} else if (!cidade.equals(other.cidade))
			return false;
		if (cnae == null) {
			if (other.cnae != null)
				return false;
		} else if (!cnae.equals(other.cnae))
			return false;
		if (codCnaeSecundario == null) {
			if (other.codCnaeSecundario != null)
				return false;
		} else if (!codCnaeSecundario.equals(other.codCnaeSecundario))
			return false;
		if (codNaturezaJuridica == null) {
			if (other.codNaturezaJuridica != null)
				return false;
		} else if (!codNaturezaJuridica.equals(other.codNaturezaJuridica))
			return false;
		if (complemento == null) {
			if (other.complemento != null)
				return false;
		} else if (!complemento.equals(other.complemento))
			return false;
		if (currentdate == null) {
			if (other.currentdate != null)
				return false;
		} else if (!currentdate.equals(other.currentdate))
			return false;
		if (datEmissao == null) {
			if (other.datEmissao != null)
				return false;
		} else if (!datEmissao.equals(other.datEmissao))
			return false;
		if (datFundacao == null) {
			if (other.datFundacao != null)
				return false;
		} else if (!datFundacao.equals(other.datFundacao))
			return false;
		if (dataAtivacaoCrm == null) {
			if (other.dataAtivacaoCrm != null)
				return false;
		} else if (!dataAtivacaoCrm.equals(other.dataAtivacaoCrm))
			return false;
		if (dataModificacao == null) {
			if (other.dataModificacao != null)
				return false;
		} else if (!dataModificacao.equals(other.dataModificacao))
			return false;
		if (dataNascimento == null) {
			if (other.dataNascimento != null)
				return false;
		} else if (!dataNascimento.equals(other.dataNascimento))
			return false;
		if (dscCapitalSocial == null) {
			if (other.dscCapitalSocial != null)
				return false;
		} else if (!dscCapitalSocial.equals(other.dscCapitalSocial))
			return false;
		if (dscCarteiraPertencente == null) {
			if (other.dscCarteiraPertencente != null)
				return false;
		} else if (!dscCarteiraPertencente.equals(other.dscCarteiraPertencente))
			return false;
		if (dscCnae == null) {
			if (other.dscCnae != null)
				return false;
		} else if (!dscCnae.equals(other.dscCnae))
			return false;
		if (dscCnaeSecundario == null) {
			if (other.dscCnaeSecundario != null)
				return false;
		} else if (!dscCnaeSecundario.equals(other.dscCnaeSecundario))
			return false;
		if (dscGrupoEmpresarial == null) {
			if (other.dscGrupoEmpresarial != null)
				return false;
		} else if (!dscGrupoEmpresarial.equals(other.dscGrupoEmpresarial))
			return false;
		if (dscOrgaoEmissorInscricaoEstadual == null) {
			if (other.dscOrgaoEmissorInscricaoEstadual != null)
				return false;
		} else if (!dscOrgaoEmissorInscricaoEstadual.equals(other.dscOrgaoEmissorInscricaoEstadual))
			return false;
		if (dscRamoAtividade == null) {
			if (other.dscRamoAtividade != null)
				return false;
		} else if (!dscRamoAtividade.equals(other.dscRamoAtividade))
			return false;
		if (eMail == null) {
			if (other.eMail != null)
				return false;
		} else if (!eMail.equals(other.eMail))
			return false;
		if (estadoCivil == null) {
			if (other.estadoCivil != null)
				return false;
		} else if (!estadoCivil.equals(other.estadoCivil))
			return false;
		if (flagDeficiente == null) {
			if (other.flagDeficiente != null)
				return false;
		} else if (!flagDeficiente.equals(other.flagDeficiente))
			return false;
		if (flagEmancipado == null) {
			if (other.flagEmancipado != null)
				return false;
		} else if (!flagEmancipado.equals(other.flagEmancipado))
			return false;
		if (flgConvergente == null) {
			if (other.flgConvergente != null)
				return false;
		} else if (!flgConvergente.equals(other.flgConvergente))
			return false;
		if (loginRespAtivacao == null) {
			if (other.loginRespAtivacao != null)
				return false;
		} else if (!loginRespAtivacao.equals(other.loginRespAtivacao))
			return false;
		if (loginRespModificacao == null) {
			if (other.loginRespModificacao != null)
				return false;
		} else if (!loginRespModificacao.equals(other.loginRespModificacao))
			return false;
		if (logradouro == null) {
			if (other.logradouro != null)
				return false;
		} else if (!logradouro.equals(other.logradouro))
			return false;
		if (loteid == null) {
			if (other.loteid != null)
				return false;
		} else if (!loteid.equals(other.loteid))
			return false;
		if (municipioInscricaoMunicipal == null) {
			if (other.municipioInscricaoMunicipal != null)
				return false;
		} else if (!municipioInscricaoMunicipal.equals(other.municipioInscricaoMunicipal))
			return false;
		if (nacionalidade == null) {
			if (other.nacionalidade != null)
				return false;
		} else if (!nacionalidade.equals(other.nacionalidade))
			return false;
		if (nameroEndereco == null) {
			if (other.nameroEndereco != null)
				return false;
		} else if (!nameroEndereco.equals(other.nameroEndereco))
			return false;
		if (naturezaJuridica == null) {
			if (other.naturezaJuridica != null)
				return false;
		} else if (!naturezaJuridica.equals(other.naturezaJuridica))
			return false;
		if (nomPaisOrigem == null) {
			if (other.nomPaisOrigem != null)
				return false;
		} else if (!nomPaisOrigem.equals(other.nomPaisOrigem))
			return false;
		if (nome == null) {
			if (other.nome != null)
				return false;
		} else if (!nome.equals(other.nome))
			return false;
		if (nomeMae == null) {
			if (other.nomeMae != null)
				return false;
		} else if (!nomeMae.equals(other.nomeMae))
			return false;
		if (numTelefoneContato2 == null) {
			if (other.numTelefoneContato2 != null)
				return false;
		} else if (!numTelefoneContato2.equals(other.numTelefoneContato2))
			return false;
		if (numTelefoneContato3 == null) {
			if (other.numTelefoneContato3 != null)
				return false;
		} else if (!numTelefoneContato3.equals(other.numTelefoneContato3))
			return false;
		if (numeroDocumento == null) {
			if (other.numeroDocumento != null)
				return false;
		} else if (!numeroDocumento.equals(other.numeroDocumento))
			return false;
		if (numeroFuncionarios == null) {
			if (other.numeroFuncionarios != null)
				return false;
		} else if (!numeroFuncionarios.equals(other.numeroFuncionarios))
			return false;
		if (numeroInscricaoEstadual == null) {
			if (other.numeroInscricaoEstadual != null)
				return false;
		} else if (!numeroInscricaoEstadual.equals(other.numeroInscricaoEstadual))
			return false;
		if (numeroInscricaoMunicipal == null) {
			if (other.numeroInscricaoMunicipal != null)
				return false;
		} else if (!numeroInscricaoMunicipal.equals(other.numeroInscricaoMunicipal))
			return false;
		if (orgaoExpedidorDocumento == null) {
			if (other.orgaoExpedidorDocumento != null)
				return false;
		} else if (!orgaoExpedidorDocumento.equals(other.orgaoExpedidorDocumento))
			return false;
		if (pdvRespAtivacao == null) {
			if (other.pdvRespAtivacao != null)
				return false;
		} else if (!pdvRespAtivacao.equals(other.pdvRespAtivacao))
			return false;
		if (pdvRespModificacao == null) {
			if (other.pdvRespModificacao != null)
				return false;
		} else if (!pdvRespModificacao.equals(other.pdvRespModificacao))
			return false;
		if (perfilLoginRespAtivacao == null) {
			if (other.perfilLoginRespAtivacao != null)
				return false;
		} else if (!perfilLoginRespAtivacao.equals(other.perfilLoginRespAtivacao))
			return false;
		if (perfilLoginRespModificacao == null) {
			if (other.perfilLoginRespModificacao != null)
				return false;
		} else if (!perfilLoginRespModificacao.equals(other.perfilLoginRespModificacao))
			return false;
		if (porteEmpresa == null) {
			if (other.porteEmpresa != null)
				return false;
		} else if (!porteEmpresa.equals(other.porteEmpresa))
			return false;
		if (rowIdCliente == null) {
			if (other.rowIdCliente != null)
				return false;
		} else if (!rowIdCliente.equals(other.rowIdCliente))
			return false;
		if (rowIdEndereco == null) {
			if (other.rowIdEndereco != null)
				return false;
		} else if (!rowIdEndereco.equals(other.rowIdEndereco))
			return false;
		if (rowid == null) {
			if (other.rowid != null)
				return false;
		} else if (!rowid.equals(other.rowid))
			return false;
		if (score == null) {
			if (other.score != null)
				return false;
		} else if (!score.equals(other.score))
			return false;
		if (segmento_cliente == null) {
			if (other.segmento_cliente != null)
				return false;
		} else if (!segmento_cliente.equals(other.segmento_cliente))
			return false;
		if (sexo == null) {
			if (other.sexo != null)
				return false;
		} else if (!sexo.equals(other.sexo))
			return false;
		if (socialsecno == null) {
			if (other.socialsecno != null)
				return false;
		} else if (!socialsecno.equals(other.socialsecno))
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		if (telefoneContato == null) {
			if (other.telefoneContato != null)
				return false;
		} else if (!telefoneContato.equals(other.telefoneContato))
			return false;
		if (tipo == null) {
			if (other.tipo != null)
				return false;
		} else if (!tipo.equals(other.tipo))
			return false;
		if (tipoDeficiencia == null) {
			if (other.tipoDeficiencia != null)
				return false;
		} else if (!tipoDeficiencia.equals(other.tipoDeficiencia))
			return false;
		if (tipoDocumento == null) {
			if (other.tipoDocumento != null)
				return false;
		} else if (!tipoDocumento.equals(other.tipoDocumento))
			return false;
		if (tipoLogradouro == null) {
			if (other.tipoLogradouro != null)
				return false;
		} else if (!tipoLogradouro.equals(other.tipoLogradouro))
			return false;
		if (titulo == null) {
			if (other.titulo != null)
				return false;
		} else if (!titulo.equals(other.titulo))
			return false;
		if (tpoCadastro == null) {
			if (other.tpoCadastro != null)
				return false;
		} else if (!tpoCadastro.equals(other.tpoCadastro))
			return false;
		if (uf == null) {
			if (other.uf != null)
				return false;
		} else if (!uf.equals(other.uf))
			return false;
		if (ufExpedidorDocumento == null) {
			if (other.ufExpedidorDocumento != null)
				return false;
		} else if (!ufExpedidorDocumento.equals(other.ufExpedidorDocumento))
			return false;
		if (ufInscricaoEstadual == null) {
			if (other.ufInscricaoEstadual != null)
				return false;
		} else if (!ufInscricaoEstadual.equals(other.ufInscricaoEstadual))
			return false;
		if (validadeDocumento == null) {
			if (other.validadeDocumento != null)
				return false;
		} else if (!validadeDocumento.equals(other.validadeDocumento))
			return false;
		if (vlrFaturamentoPresumido == null) {
			if (other.vlrFaturamentoPresumido != null)
				return false;
		} else if (!vlrFaturamentoPresumido.equals(other.vlrFaturamentoPresumido))
			return false;
		if (vlrMedioContaConcorrencia == null) {
			if (other.vlrMedioContaConcorrencia != null)
				return false;
		} else if (!vlrMedioContaConcorrencia.equals(other.vlrMedioContaConcorrencia))
			return false;
		if (vlrRendaInformada == null) {
			if (other.vlrRendaInformada != null)
				return false;
		} else if (!vlrRendaInformada.equals(other.vlrRendaInformada))
			return false;
		return true;
	}
	
	
	
}
