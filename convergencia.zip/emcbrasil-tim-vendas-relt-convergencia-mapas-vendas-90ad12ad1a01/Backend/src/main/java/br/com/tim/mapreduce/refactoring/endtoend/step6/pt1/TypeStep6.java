package br.com.tim.mapreduce.refactoring.endtoend.step6.pt1;

public enum TypeStep6 {
	
	STEP5

}
