package br.com.tim.mapreduce.refactoring.endtoend.step4.pt6;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

public class GroupingComparator extends WritableComparator {

    public GroupingComparator() {
        super(Step4Pt6Key.class, true);
    }

    @SuppressWarnings({"rawtypes"})
    @Override
    public int compare(WritableComparable a, WritableComparable b) {
    	Step4Pt6Key keyA = (Step4Pt6Key) a;
    	Step4Pt6Key keyB = (Step4Pt6Key) b;

        return keyA.compareToGrouping(keyB);
    }

}
