package br.com.tim.mapreduce.e2e.step2;


import br.com.tim.utils.StringUtil;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TreeSet;

public class E2EStep2OutValue {

    private String datRef;
    private String codContratoOltp;
    private String codContratoAtivacao;
    private String numeroAcesso;
    private String customerId;
    private String tipoProduto;
    private String planoAtivacaoOferta;
    private String motivoChurn;
    public String getNumeroAcesso() {
		return numeroAcesso;
	}

	public void setNumeroAcesso(String numeroAcesso) {
		this.numeroAcesso = numeroAcesso;
	}

	public String getMotivoChurn() {
		return motivoChurn;
	}

	public void setMotivoChurn(String motivoChurn) {
		this.motivoChurn = motivoChurn;
	}

	public String getTipoChurn() {
		return tipoChurn;
	}

	public void setTipoChurn(String tipoChurn) {
		this.tipoChurn = tipoChurn;
	}

	private String tipoChurn;
    private String email;
    private String uf;
    private String tipoLogradouro;
    private String logradouro;
    private String numero;
    private String complemento;
    private String bairro;
    private String cep;
    private String cidade;
    private String tecnologia;
    private String formaPagamento;
    private String tipoConta;
    private String codBanco;
    private String codAgenciaBanco;
    private String codContaCorrente;
    private String codDebitoAutomatico;
    private String diaVencimento;
    private String codContaFinanceira;
    private String numProtocolo;
    private String flgOrdemAutomatica;
    private String dscTxRecorrente;
    private String dscTxNaoRecorrente;
    private String dscStatusItem;
    private String nomPlanoAtual;
    private String valPlanoAtualItem;
    private String nomDescontoAtualItem;
    private String valDescontoAtualItem;
    private String flgPortabilidade;
    private String dscOperadoraDoadora;
    private String codDdd;
    private String numTelefonePortado;
    private String datJanelaPortabilidade;
    private String horJanela;
    private String dscEnderecoFatura;
    private String dscAreaVoip;
    private String cpe;
    private String ont;
    private String itemRoot;
    private String dominioRoot;
    private String nroOrdem;
    private String acessoRowId;
    private String acessoRowIdRoot;
    private String codigoProduto;

    private String datCriacaoOrdem;
    private String horCriacaoOrdem;
    private String datVenda;
    private String horaVenda;
    private String datVendaOrig;
    private String horVendaOrig;
    private String datStatusOrdem;
    private String horStatusOrdem;
    private String numOrdemSiebel;
    private String numOrdemSiebelOrig;
    private String tipoDocumento;
    private String documento;
    private String tipoVenda;
    private String loginVendedor;
    private String loginVendedorOrig;
    private String canal;
    private String canalOrig;
    private String cnpjParceiro;
    private String cnpjParceiroOrig;
    private String custCode;
    private String custCodeOrig;
    private String position;
    private String positionOrig;
    private String flgCancAntesVenda;
    private String flgVendaSubmetida;
    private String flgVendaDuplicada;
    private String flgVendaBruta;
    private String flgVendaLiquida;
    private String flgCancPosVenda;
    private String flgCancDupl;
    private String flgCancLiquido;
    private String datCancVenda;
    private String motivoCancelamento;
    private String nomeCliente;
    private String telefone;
    private String statusOrdem;
    private String semanaVenda;
    private String semanaVendaOrig;
    private String score;
    private String scoreConsumido;
    private String datFinalizacaoOrdem;
    private String qtdContratos;
    private String nomLoginResponsavel;
    private String detalheRecusaCrivo;
    private String loginCancelamentoOrdem;
    private String nomeParceiroVenda;
    private String nomeParceiroVendaOrig;


    private TreeSet<String> dupl = new TreeSet<String>();
    private TreeSet<String> brut = new TreeSet<String>();
    private boolean definido;
    private int contflg0;
    private int contflg1;

    DateTimeFormatter dtf = DateTimeFormat.forPattern("MM/dd/yyyy HH:mm:ss");

    public void clear(){
        this.datRef = "";
        this.codContratoOltp = "";
        this.codContratoAtivacao = "";
        this.numeroAcesso = "";
        this.customerId = "";
        this.tipoProduto = "";
        this.planoAtivacaoOferta = "";
        this.motivoChurn = "";
        this.tipoChurn = "";
        this.email = "";
        this.uf = "";
        this.tipoLogradouro = "";
        this.logradouro = "";
        this.numero = "";
        this.complemento = "";
        this.bairro = "";
        this.cep = "";
        this.cidade = "";
        this.tecnologia = "";
        this.formaPagamento = "";
        this.tipoConta = "";
        this.codBanco = "";
        this.codAgenciaBanco = "";
        this.codContaCorrente = "";
        this.codDebitoAutomatico = "";
        this.diaVencimento = "";
        this.codContaFinanceira = "";
        this.numProtocolo = "";
        this.flgOrdemAutomatica = "";
        this.dscTxRecorrente = "";
        this.dscTxNaoRecorrente = "";
        this.dscStatusItem = "";
        this.nomPlanoAtual = "";
        this.valPlanoAtualItem = "";
        this.nomDescontoAtualItem = "";
        this.valDescontoAtualItem = "";
        this.flgPortabilidade = "";
        this.dscOperadoraDoadora = "";
        this.codDdd = "";
        this.numTelefonePortado = "";
        this.datJanelaPortabilidade = "";
        this.horJanela = "";
        this.dscEnderecoFatura = "";
        this.dscAreaVoip = "";
        this.cpe = "";
        this.ont = "";
        this.itemRoot = "";
        this.dominioRoot = "";
        this.nroOrdem = "";
        this.acessoRowId = "";
        this.acessoRowIdRoot = "";
        this.codigoProduto = "";
        this.datCriacaoOrdem = "";
        this.horCriacaoOrdem = "";
        this.datVenda = "";
        this.horaVenda = "";
        this.datVendaOrig = "";
        this.horVendaOrig = "";
        this.datStatusOrdem = "";
        this.horStatusOrdem = "";
        this.numOrdemSiebel = "";
        this.numOrdemSiebelOrig = "";
        this.tipoDocumento = "";
        this.documento = "";
        this.tipoVenda = "";
        this.loginVendedor = "";
        this.loginVendedorOrig = "";
        this.canal = "";
        this.canalOrig = "";
        this.cnpjParceiro = "";
        this.cnpjParceiroOrig = "";
        this.custCode = "";
        this.custCodeOrig = "";
        this.position = "";
        this.positionOrig = "";
        this.flgCancAntesVenda = "";
        this.flgVendaSubmetida = "";
        this.flgVendaDuplicada = "";
        this.flgVendaBruta = "";
        this.flgVendaLiquida = "";
        this.flgCancPosVenda = "";
        this.flgCancDupl = "";
        this.flgCancLiquido = "";
        this.datCancVenda = "";
        this.motivoCancelamento = "";
        this.nomeCliente = "";
        this.telefone = "";
        this.statusOrdem = "";
        this.semanaVenda = "";
        this.semanaVendaOrig = "";
        this.score = "";
        this.scoreConsumido = "";
        this.datFinalizacaoOrdem = "";
        this.qtdContratos = "";
        this.nomLoginResponsavel = "";
        this.detalheRecusaCrivo = "";
        this.loginCancelamentoOrdem = "";
        this.nomeParceiroVenda = "";
        this.nomeParceiroVendaOrig = "";
        dupl.clear();
        brut.clear();
        definido = false;
        contflg0 = 0;
        contflg1 = 1;
    }

    public void clearRelt(){
        this.datRef = "";
        this.codContratoOltp = "";
        this.codContratoAtivacao = "";
        this.numeroAcesso = "";
        this.customerId = "";
        this.tipoProduto = "";
        this.planoAtivacaoOferta = "";
        this.motivoChurn = "";
        this.tipoChurn = "";
        this.email = "";
        this.uf = "";
        this.tipoLogradouro = "";
        this.logradouro = "";
        this.numero = "";
        this.complemento = "";
        this.bairro = "";
        this.cep = "";
        this.cidade = "";
        this.tecnologia = "";
        this.formaPagamento = "";
        this.tipoConta = "";
        this.codBanco = "";
        this.codAgenciaBanco = "";
        this.codContaCorrente = "";
        this.codDebitoAutomatico = "";
        this.diaVencimento = "";
        this.codContaFinanceira = "";
        this.numProtocolo = "";
        this.flgOrdemAutomatica = "";
        this.dscTxRecorrente = "";
        this.dscTxNaoRecorrente = "";
        this.dscStatusItem = "";
        this.nomPlanoAtual = "";
        this.valPlanoAtualItem = "";
        this.nomDescontoAtualItem = "";
        this.valDescontoAtualItem = "";
        this.flgPortabilidade = "";
        this.dscOperadoraDoadora = "";
        this.codDdd = "";
        this.numTelefonePortado = "";
        this.datJanelaPortabilidade = "";
        this.horJanela = "";
        this.dscEnderecoFatura = "";
        this.dscAreaVoip = "";
        this.cpe = "";
        this.ont = "";
        this.itemRoot = "";
        this.dominioRoot = "";
        this.nroOrdem = "";
        this.acessoRowId = "";
        this.acessoRowIdRoot = "";
        this.codigoProduto = "";
    }

    public void setRelt(E2EStep2Value relt) {
        this.datRef = relt.getDatRef();
        this.codContratoOltp = relt.getCodContratoOltp();
        this.codContratoAtivacao = relt.getCodContratoAtivacao();
        this.numeroAcesso = relt.getNumeroAcesso();
        this.customerId = relt.getCustomerId();
        this.tipoProduto = relt.getTipoProduto();
        this.planoAtivacaoOferta = relt.getPlanoAtivacaoOferta();
        this.motivoChurn = relt.getMotivoChurn();
        this.tipoChurn = relt.getTipoChurn();
        this.email = relt.getEmail();
        this.uf = relt.getUf();
        this.tipoLogradouro = relt.getTipoLogradouro();
        this.logradouro = relt.getLogradouro();
        this.numero = relt.getNumero();
        this.complemento = relt.getComplemento();
        this.bairro = relt.getBairro();
        this.cep = relt.getCep();
        this.cidade = relt.getCidade();
        this.tecnologia = relt.getTecnologia();
        this.formaPagamento = relt.getFormaPagamento();
        this.tipoConta = relt.getTipoConta();
        this.codBanco = relt.getCodBanco();
        this.codAgenciaBanco = relt.getCodAgenciaBanco();
        this.codContaCorrente = relt.getCodContaCorrente();
        this.codDebitoAutomatico = relt.getCodDebitoAutomatico();
        this.diaVencimento = relt.getDiaVencimento();
        this.codContaFinanceira = relt.getCodContaFinanceira();
        this.numProtocolo = relt.getNumProtocolo();
        this.flgOrdemAutomatica = relt.getFlgOrdemAutomatica();
        this.dscTxRecorrente = relt.getDscTxRecorrente();
        this.dscTxNaoRecorrente = relt.getDscTxNaoRecorrente();
        this.dscStatusItem = relt.getDscStatusItem();
        this.nomPlanoAtual = relt.getNomPlanoAtual();
        this.valPlanoAtualItem = relt.getValPlanoAtualItem();
        this.nomDescontoAtualItem = relt.getNomDescontoAtualItem();
        this.valDescontoAtualItem = relt.getValDescontoAtualItem();
        this.flgPortabilidade = relt.getFlgPortabilidade();
        this.dscOperadoraDoadora = relt.getDscOperadoraDoadora();
        this.codDdd = relt.getCodDdd();
        this.numTelefonePortado = relt.getNumTelefonePortado();
        this.datJanelaPortabilidade = relt.getDatJanelaPortabilidade();
        this.horJanela = relt.getHorJanela();
        this.dscEnderecoFatura = relt.getDscEnderecoFatura();
        this.dscAreaVoip = relt.getDscAreaVoip();
        this.cpe = relt.getCpe();
        this.ont = relt.getOnt();
        this.itemRoot = relt.getItemRoot();
        this.dominioRoot = relt.getDominioRoot();
        this.nroOrdem = relt.getNroOrdem();
        this.acessoRowId = relt.getAcessoRowId();
        this.acessoRowIdRoot = relt.getAcessoRowIdRoot();
        this.codigoProduto = relt.getCodigoProduto();
    }

    public void setOrdem(E2EStep2Value ordem) {
        this.datCriacaoOrdem = ordem.getDatCriacaoOrdem();
        this.horCriacaoOrdem = ordem.getHorCriacaoOrdem();
        this.datVenda = ordem.getDatVenda();
        this.horaVenda = ordem.getHoraVenda();
        this.datStatusOrdem = ordem.getDatStatusOrdem();
        this.horStatusOrdem = ordem.getHorStatusOrdem();
        this.numOrdemSiebel = ordem.getNumOrdemSiebel();
        this.tipoDocumento = ordem.getTipoDocumento();
        this.documento = ordem.getDocumento();
        this.tipoVenda = ordem.getTipoVenda();
        this.loginVendedor = ordem.getLoginVendedor();
        this.canal = ordem.getCanal();
        this.cnpjParceiro = ordem.getCnpjParceiro();
        this.custCode = ordem.getCustCode();
        this.position = ordem.getPosition();
        this.flgCancAntesVenda = ordem.getFlgCancAntesVenda();
        this.flgVendaSubmetida = ordem.getFlgVendaSubmetida();
        this.flgCancPosVenda = ordem.getFlgCancPosVenda();

        this.flgVendaDuplicada = "0";
        if(StringUtils.isNotEmpty(ordem.getDatVenda())){
            if(!dupl.add(ordem.getTipoOrdem() + ordem.getNomeCliente()))
                this.flgVendaDuplicada = "1";
        }

        this.flgVendaBruta = "1";
        if(StringUtils.isNotEmpty(ordem.getDatVenda())){
            if(!brut.add(ordem.getTipoOrdem() + ordem.getNomeCliente()))
                this.flgVendaBruta = "0";
        }

        if(this.flgCancPosVenda.equals("0")) {
            this.flgCancDupl = "0";
            contflg0++;
        }
        else if(this.flgCancPosVenda.equals("1")) {
            contflg1++;
            if (this.flgCancPosVenda.equals("1") && contflg0 == 0)
                this.flgCancDupl = "0";
            else if(contflg1 == 1)
                this.flgCancDupl = "0";
            else if (ordem.getStatusOrdem().equals("Concluída"))
                this.flgCancDupl = "1";
            else if (ordem.getStatusOrdem().equals("Em Aprovisionamento"))
                this.flgCancDupl = "1";
        }


        if(this.flgCancPosVenda.equals("1") && this.flgCancDupl.equals("0"))
            this.flgCancLiquido = "1";
        else
            this.flgCancLiquido = "0";

        if(this.flgVendaBruta.equals("0"))
            this.flgVendaLiquida = "0";
        else if(this.flgVendaBruta.equals("1") && this.flgCancLiquido.equals("1")){
            this.flgVendaLiquida = "0";
            definido = true;
        }
        else if(this.flgVendaBruta.equals("1") && !definido)
            this.flgVendaLiquida = "1";
        this.datCancVenda = ordem.getDatCancVenda();
        this.motivoCancelamento = ordem.getMotivoCancelamento();
        this.nomeCliente = ordem.getNomeCliente();
        this.telefone = ordem.getTelefone();
        this.statusOrdem = ordem.getStatusOrdem();
        this.semanaVenda = ordem.getSemanaVenda();
        this.score = ordem.getScore();
        this.scoreConsumido = ordem.getScoreConsumido();
        this.datFinalizacaoOrdem = ordem.getDatFinalizacaoOrdem();
        this.qtdContratos = ordem.getQtdContratos();
        this.nomLoginResponsavel = ordem.getNomLoginResponsavel();
        this.detalheRecusaCrivo = ordem.getDetalheRecusaCrivo();
        this.loginCancelamentoOrdem = ordem.getLoginCancelamentoOrdem();
        this.nomeParceiroVenda = ordem.getNomeParceiroVenda();
    }

    public void setFirstOrdem(E2EStep2Value ordem) {
        this.datCriacaoOrdem = ordem.getDatCriacaoOrdem();
        this.horCriacaoOrdem = ordem.getHorCriacaoOrdem();
        this.datVenda = ordem.getDatVenda();
        this.horaVenda = ordem.getHoraVenda();
        this.datVendaOrig = ordem.getDatVenda();
        this.horVendaOrig = ordem.getHoraVenda();
        this.datStatusOrdem = ordem.getDatStatusOrdem();
        this.horStatusOrdem = ordem.getHorStatusOrdem();
        this.numOrdemSiebel = ordem.getNumOrdemSiebel();
        this.numOrdemSiebelOrig = ordem.getNumOrdemSiebel();
        this.tipoDocumento = ordem.getTipoDocumento();
        this.documento = ordem.getDocumento();
        this.tipoVenda = ordem.getTipoVenda();
        this.loginVendedor = ordem.getLoginVendedor();
        this.loginVendedorOrig = ordem.getLoginVendedor();
        this.canal = ordem.getCanal();
        this.canalOrig = ordem.getCanal();
        this.cnpjParceiro = ordem.getCnpjParceiro();
        this.cnpjParceiroOrig = ordem.getCnpjParceiro();
        this.custCode = ordem.getCustCode();
        this.custCodeOrig = ordem.getCustCode();
        this.position = ordem.getPosition();
        this.positionOrig = ordem.getPosition();
        this.flgCancAntesVenda = ordem.getFlgCancAntesVenda();
        this.flgVendaSubmetida = ordem.getFlgVendaSubmetida();
        this.flgCancPosVenda = ordem.getFlgCancPosVenda();

        this.flgVendaDuplicada = "0";
        if(StringUtils.isNotEmpty(ordem.getDatVenda())){
            if(!dupl.add(ordem.getTipoOrdem() + ordem.getNomeCliente()))
                this.flgVendaDuplicada = "1";
        }

        this.flgVendaBruta = "1";
        if(StringUtils.isNotEmpty(ordem.getDatVenda())){
            if(!brut.add(ordem.getTipoOrdem() + ordem.getNomeCliente()))
                this.flgVendaBruta = "0";
        }

        if(this.flgCancPosVenda.equals("0")) {
            this.flgCancDupl = "0";
            contflg0++;
        }
        else if(this.flgCancPosVenda.equals("1")) {
            contflg1++;
            if (this.flgCancPosVenda.equals("1") && contflg0 == 0)
                this.flgCancDupl = "0";
            else if(contflg1 == 1)
                this.flgCancDupl = "0";
            else if (ordem.getStatusOrdem().equals("Concluída"))
                this.flgCancDupl = "1";
            else if (ordem.getStatusOrdem().equals("Em Aprovisionamento"))
                this.flgCancDupl = "1";
        }

        if(this.flgCancPosVenda.equals("1") && this.flgCancDupl.equals("0"))
            this.flgCancLiquido = "1";
        else
            this.flgCancLiquido = "0";

        if(this.flgVendaBruta.equals("0"))
            this.flgVendaLiquida = "0";
        else if(this.flgVendaBruta.equals("1") && this.flgCancLiquido.equals("1")){
            this.flgVendaLiquida = "0";
            definido = true;
        }
        else if(this.flgVendaBruta.equals("1") && !definido)
            flgVendaLiquida = "1";
        this.datCancVenda = ordem.getDatCancVenda();
        this.motivoCancelamento = ordem.getMotivoCancelamento();
        this.nomeCliente = ordem.getNomeCliente();
        this.telefone = ordem.getTelefone();
        this.statusOrdem = ordem.getStatusOrdem();
        this.semanaVenda = ordem.getSemanaVenda();

        if (StringUtils.isNotEmpty(ordem.getSemanaVenda())) {
            this.semanaVendaOrig = ordem.getSemanaVenda();
        } else
            this.semanaVendaOrig = StringUtils.EMPTY;

        this.score = ordem.getScore();
        this.scoreConsumido = ordem.getScoreConsumido();
        this.datFinalizacaoOrdem = ordem.getDatFinalizacaoOrdem();
        this.qtdContratos = ordem.getQtdContratos();
        this.nomLoginResponsavel = ordem.getNomLoginResponsavel();
        this.detalheRecusaCrivo = ordem.getDetalheRecusaCrivo();
        this.loginCancelamentoOrdem = ordem.getLoginCancelamentoOrdem();
        this.nomeParceiroVenda = ordem.getNomeParceiroVenda();
        this.nomeParceiroVendaOrig = ordem.getNomeParceiroVenda();
    }

    @Override
    public String toString() {
        return new StringBuilder()
                   .append(datRef).append("|")
                   .append(codContratoOltp).append("|")
                   .append(codContratoAtivacao).append("|")
                   .append(numeroAcesso).append("|")
                   .append(customerId).append("|")
                   .append(tipoProduto).append("|")
                   .append(planoAtivacaoOferta).append("|")
                   .append(motivoChurn).append("|")
                   .append(tipoChurn).append("|")
                   .append(email).append("|")
                   .append(uf).append("|")
                   .append(tipoLogradouro).append("|")
                   .append(logradouro).append("|")
                   .append(numero).append("|")
                   .append(complemento).append("|")
                   .append(bairro).append("|")
                   .append(cep).append("|")
                   .append(cidade).append("|")
                   .append(tecnologia).append("|")
                   .append(formaPagamento).append("|")
                   .append(tipoConta).append("|")
                   .append(codBanco).append("|")
                   .append(codAgenciaBanco).append("|")
                   .append(codContaCorrente).append("|")
                   .append(codDebitoAutomatico).append("|")
                   .append(diaVencimento).append("|")
                   .append(codContaFinanceira).append("|")
                   .append(numProtocolo).append("|")
                   .append(flgOrdemAutomatica).append("|")
                   .append(dscTxRecorrente).append("|")
                   .append(dscTxNaoRecorrente).append("|")
                   .append(dscStatusItem).append("|")
                   .append(nomPlanoAtual).append("|")
                   .append(valPlanoAtualItem).append("|")
                   .append(nomDescontoAtualItem).append("|")
                   .append(valDescontoAtualItem).append("|")
                   .append(flgPortabilidade).append("|")
                   .append(dscOperadoraDoadora).append("|")
                   .append(codDdd).append("|")
                   .append(numTelefonePortado).append("|")
                   .append(datJanelaPortabilidade).append("|")
                   .append(horJanela).append("|")
                   .append(dscEnderecoFatura).append("|")
                   .append(dscAreaVoip).append("|")
                   .append(cpe).append("|")
                   .append(ont).append("|")
                   .append(itemRoot).append("|")
                   .append(dominioRoot).append("|")
                   .append(nroOrdem).append("|")
                   .append(acessoRowId).append("|")
                   .append(acessoRowIdRoot).append("|")
                   .append(codigoProduto).append("|")
                   .append(datCriacaoOrdem).append("|")
                   .append(horCriacaoOrdem).append("|")
                   .append(datVenda).append("|")
                   .append(horaVenda).append("|")
                   .append(datVendaOrig).append("|")
                   .append(horVendaOrig).append("|")
                   .append(datStatusOrdem).append("|")
                   .append(horStatusOrdem).append("|")
                   .append(numOrdemSiebel).append("|")
                   .append(numOrdemSiebelOrig).append("|")
                   .append(tipoDocumento).append("|")
                   .append(documento).append("|")
                   .append(tipoVenda).append("|")
                   .append(loginVendedor).append("|")
                   .append(loginVendedorOrig).append("|")
                   .append(canal).append("|")
                   .append(canalOrig).append("|")
                   .append(cnpjParceiro).append("|")
                   .append(cnpjParceiroOrig).append("|")
                   .append(custCode).append("|")
                   .append(custCodeOrig).append("|")
                   .append(position).append("|")
                   .append(positionOrig).append("|")
                   .append(flgCancAntesVenda).append("|")
                   .append(flgVendaSubmetida).append("|")
                   .append(flgVendaDuplicada).append("|")
                   .append(flgVendaBruta).append("|")
                   .append(flgVendaLiquida).append("|")
                   .append(flgCancPosVenda).append("|")
                   .append(flgCancDupl).append("|")
                   .append(flgCancLiquido).append("|")
                   .append(datCancVenda).append("|")
                   .append(motivoCancelamento).append("|")
                   .append(nomeCliente).append("|")
                   .append(telefone).append("|")
                   .append(statusOrdem).append("|")
                   .append(semanaVenda).append("|")
                   .append(semanaVendaOrig).append("|")
                   .append(score).append("|")
                   .append(scoreConsumido).append("|")
                   .append(datFinalizacaoOrdem).append("|")
                   .append(qtdContratos).append("|")
                   .append(nomLoginResponsavel).append("|")
                   .append(detalheRecusaCrivo).append("|")
                   .append(loginCancelamentoOrdem).append("|")
                   .append(nomeParceiroVenda).append("|")
                   .append(nomeParceiroVendaOrig).toString();
    }
}
