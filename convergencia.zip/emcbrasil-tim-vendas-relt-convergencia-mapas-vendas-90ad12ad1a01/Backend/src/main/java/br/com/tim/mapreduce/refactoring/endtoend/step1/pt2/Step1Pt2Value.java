package br.com.tim.mapreduce.refactoring.endtoend.step1.pt2;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.io.Writable;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import br.com.tim.mapreduce.refactoring.endtoend.step1.pt2.model.Step1Result;
import br.com.tim.mapreduce.refactoring.model.BAT509Order;

public class Step1Pt2Value implements Writable {
	
	
	

	protected TypeStep1Pt2 tipo;
	 protected String datRef;
	    protected String codContratoOltp;
	    protected String codContratoAtivacao;
	    protected String numeroAcesso;
	    protected String customerId;
	    protected String tipoProduto;
	    protected String planoAtivacaoOferta;
	    protected String motivoChurn;
	    protected String tipoChurn;
	    protected String email;
	    protected String uf;
	    protected String tipoLogradouro;
	    protected String logradouro;
	    protected String numero;
	    protected String complemento;
	    protected String bairro;
	    protected String cep;
	    protected String cidade;
	    protected String tecnologia;
	    protected String formaPagamento;
	    protected String tipoConta;
	    protected String codBanco;
	    protected String codAgenciaBanco;
	    protected String codContaCorrente;
	    protected String codDebitoAutomatico;
	    protected String diaVencimento;
	    protected String codContaFinanceira;
	    protected String numProtocolo;
	    protected String flgOrdemAutomatica;
	    protected String dscTxRecorrente;
	    protected String dscTxNaoRecorrente;
	    protected String dscStatusItem;
	    protected String nomPlanoAtual;
	    protected String valPlanoAtualItem;
	    protected String nomDescontoAtualItem;
	    protected String valDescontoAtualItem;
	    protected String flgPortabilidade;
	    protected String dscOperadoraDoadora;
	    protected String codDdd;
	    protected String numTelefonePortado;
	    protected String datJanelaPortabilidade;
	    protected String horJanela;
	    protected String dscEnderecoFatura;
	    protected String dscAreaVoip;
	    protected String cpe;
	    protected String ont;
	    protected String itemRoot;
	    protected String dominioRoot;
	    protected String nroOrdem;
	    protected String acessoRowId;
	    protected String acessoRowIdRoot;
	    protected String codigoProduto;

	    protected String datCriacaoOrdem;
	    protected String horCriacaoOrdem;
	    protected String datVenda;
	    protected String horaVenda;
	    protected String datStatusOrdem;
	    protected String horStatusOrdem;
	    protected String numOrdemSiebel;
	    protected String tipoDocumento;
	    protected String documento;
	    protected String tipoVenda;
	    protected String loginVendedor;
	    protected String canal;
	    protected String cnpjParceiro;
	    protected String custCode;
	    protected String position;
	    protected String flgCancAntesVenda;
	    protected String flgVendaSubmetida;
	    protected String flgVendaDuplicada;
	    protected String flgVendaBruta;
	    protected String flgVendaLiquida;
	    protected String flgCancPosVenda;
	    protected String flgCancDupl;
	    protected String flgCancLiquido;
	    protected String datCancVenda;
	    protected String motivoCancelamento;
	    protected String nomeCliente;
	    protected String telefone;
	    protected String statusOrdem;
	    protected String semanaVenda;
	    protected String score;
	    protected String scoreConsumido;
	    protected String datFinalizacaoOrdem;
	    protected String qtdContratos;
	    protected String nomLoginResponsavel;
	    protected String detalheRecusaCrivo;
	    protected String loginCancelamentoOrdem;
	    protected String nomeParceiroVenda;
	    protected String tipoOrdem;
	    
	    protected String rowIdDoItemDaOrdem;
	    protected String rowIdDoItemDaOrdemPai;
	    protected String categoriaItemOrdem;

	    DateTimeFormatter dtf = DateTimeFormat.forPattern("MM/dd/yyyy HH:mm:ss");
	    DateTimeFormatter yyyyMMdd = DateTimeFormat.forPattern("yyyyMMdd");
	    Pattern pattern = Pattern.compile("\\d+");

	    @Override
	    public void write(DataOutput dataOutput) throws IOException {
	        dataOutput.writeInt(tipo.ordinal());
	        dataOutput.writeUTF(datRef);
	        dataOutput.writeUTF(codContratoOltp);
	        dataOutput.writeUTF(codContratoAtivacao);
	        dataOutput.writeUTF(numeroAcesso);
	        dataOutput.writeUTF(customerId);
	        dataOutput.writeUTF(tipoProduto);
	        dataOutput.writeUTF(planoAtivacaoOferta);
	        dataOutput.writeUTF(motivoChurn);
	        dataOutput.writeUTF(tipoChurn);
	        dataOutput.writeUTF(email);
	        dataOutput.writeUTF(uf);
	        dataOutput.writeUTF(tipoLogradouro);
	        dataOutput.writeUTF(logradouro);
	        dataOutput.writeUTF(numero);
	        dataOutput.writeUTF(complemento);
	        dataOutput.writeUTF(bairro);
	        dataOutput.writeUTF(cep);
	        dataOutput.writeUTF(cidade);
	        dataOutput.writeUTF(tecnologia);
	        dataOutput.writeUTF(formaPagamento);
	        dataOutput.writeUTF(tipoConta);
	        dataOutput.writeUTF(codBanco);
	        dataOutput.writeUTF(codAgenciaBanco);
	        dataOutput.writeUTF(codContaCorrente);
	        dataOutput.writeUTF(codDebitoAutomatico);
	        dataOutput.writeUTF(diaVencimento);
	        dataOutput.writeUTF(codContaFinanceira);
	        dataOutput.writeUTF(numProtocolo);
	        dataOutput.writeUTF(flgOrdemAutomatica);
	        dataOutput.writeUTF(dscTxRecorrente);
	        dataOutput.writeUTF(dscTxNaoRecorrente);
	        dataOutput.writeUTF(dscStatusItem);
	        dataOutput.writeUTF(nomPlanoAtual);
	        dataOutput.writeUTF(valPlanoAtualItem);
	        dataOutput.writeUTF(nomDescontoAtualItem);
	        dataOutput.writeUTF(valDescontoAtualItem);
	        dataOutput.writeUTF(flgPortabilidade);
	        dataOutput.writeUTF(dscOperadoraDoadora);
	        dataOutput.writeUTF(codDdd);
	        dataOutput.writeUTF(numTelefonePortado);
	        dataOutput.writeUTF(datJanelaPortabilidade);
	        dataOutput.writeUTF(horJanela);
	        dataOutput.writeUTF(dscEnderecoFatura);
	        dataOutput.writeUTF(dscAreaVoip);
	        dataOutput.writeUTF(cpe);
	        dataOutput.writeUTF(ont);
	        dataOutput.writeUTF(itemRoot);
	        dataOutput.writeUTF(dominioRoot);
	        dataOutput.writeUTF(nroOrdem);
	        dataOutput.writeUTF(acessoRowId);
	        dataOutput.writeUTF(acessoRowIdRoot);
	        dataOutput.writeUTF(codigoProduto);
	        dataOutput.writeUTF(datCriacaoOrdem);
	        dataOutput.writeUTF(horCriacaoOrdem);
	        dataOutput.writeUTF(datVenda);
	        dataOutput.writeUTF(horaVenda);
	        dataOutput.writeUTF(datStatusOrdem);
	        dataOutput.writeUTF(horStatusOrdem);
	        dataOutput.writeUTF(numOrdemSiebel);
	        dataOutput.writeUTF(tipoDocumento);
	        dataOutput.writeUTF(documento);
	        dataOutput.writeUTF(tipoVenda);
	        dataOutput.writeUTF(loginVendedor);
	        dataOutput.writeUTF(canal);
	        dataOutput.writeUTF(cnpjParceiro);
	        dataOutput.writeUTF(custCode);
	        dataOutput.writeUTF(position);
	        dataOutput.writeUTF(flgCancAntesVenda);
	        dataOutput.writeUTF(flgVendaSubmetida);
	        dataOutput.writeUTF(flgVendaDuplicada);
	        dataOutput.writeUTF(flgVendaBruta);
	        dataOutput.writeUTF(flgVendaLiquida);
	        dataOutput.writeUTF(flgCancPosVenda);
	        dataOutput.writeUTF(flgCancDupl);
	        dataOutput.writeUTF(flgCancLiquido);
	        dataOutput.writeUTF(datCancVenda);
	        dataOutput.writeUTF(motivoCancelamento);
	        dataOutput.writeUTF(nomeCliente);
	        dataOutput.writeUTF(telefone);
	        dataOutput.writeUTF(statusOrdem);
	        dataOutput.writeUTF(semanaVenda);
	        dataOutput.writeUTF(score);
	        dataOutput.writeUTF(scoreConsumido);
	        dataOutput.writeUTF(datFinalizacaoOrdem);
	        dataOutput.writeUTF(qtdContratos);
	        dataOutput.writeUTF(nomLoginResponsavel);
	        dataOutput.writeUTF(detalheRecusaCrivo);
	        dataOutput.writeUTF(loginCancelamentoOrdem);
	        dataOutput.writeUTF(nomeParceiroVenda);
	        dataOutput.writeUTF(tipoOrdem);
	        dataOutput.writeUTF(rowIdDoItemDaOrdem);
	        dataOutput.writeUTF(rowIdDoItemDaOrdemPai);
	        dataOutput.writeUTF(categoriaItemOrdem);

	    }

	    @Override
	    public void readFields(DataInput dataInput) throws IOException {
	        this.tipo = TypeStep1Pt2.values()[dataInput.readInt()];
	        this.datRef = dataInput.readUTF();
	        this.codContratoOltp = dataInput.readUTF();
	        this.codContratoAtivacao = dataInput.readUTF();
	        this.numeroAcesso = dataInput.readUTF();
	        this.customerId = dataInput.readUTF();
	        this.tipoProduto = dataInput.readUTF();
	        this.planoAtivacaoOferta = dataInput.readUTF();
	        this.motivoChurn = dataInput.readUTF();
	        this.tipoChurn = dataInput.readUTF();
	        this.email = dataInput.readUTF();
	        this.uf = dataInput.readUTF();
	        this.tipoLogradouro = dataInput.readUTF();
	        this.logradouro = dataInput.readUTF();
	        this.numero = dataInput.readUTF();
	        this.complemento = dataInput.readUTF();
	        this.bairro = dataInput.readUTF();
	        this.cep = dataInput.readUTF();
	        this.cidade = dataInput.readUTF();
	        this.tecnologia = dataInput.readUTF();
	        this.formaPagamento = dataInput.readUTF();
	        this.tipoConta = dataInput.readUTF();
	        this.codBanco = dataInput.readUTF();
	        this.codAgenciaBanco = dataInput.readUTF();
	        this.codContaCorrente = dataInput.readUTF();
	        this.codDebitoAutomatico = dataInput.readUTF();
	        this.diaVencimento = dataInput.readUTF();
	        this.codContaFinanceira = dataInput.readUTF();
	        this.numProtocolo = dataInput.readUTF();
	        this.flgOrdemAutomatica = dataInput.readUTF();
	        this.dscTxRecorrente = dataInput.readUTF();
	        this.dscTxNaoRecorrente = dataInput.readUTF();
	        this.dscStatusItem = dataInput.readUTF();
	        this.nomPlanoAtual = dataInput.readUTF();
	        this.valPlanoAtualItem = dataInput.readUTF();
	        this.nomDescontoAtualItem = dataInput.readUTF();
	        this.valDescontoAtualItem = dataInput.readUTF();
	        this.flgPortabilidade = dataInput.readUTF();
	        this.dscOperadoraDoadora = dataInput.readUTF();
	        this.codDdd = dataInput.readUTF();
	        this.numTelefonePortado = dataInput.readUTF();
	        this.datJanelaPortabilidade = dataInput.readUTF();
	        this.horJanela = dataInput.readUTF();
	        this.dscEnderecoFatura = dataInput.readUTF();
	        this.dscAreaVoip = dataInput.readUTF();
	        this.cpe = dataInput.readUTF();
	        this.ont = dataInput.readUTF();
	        this.itemRoot = dataInput.readUTF();
	        this.dominioRoot = dataInput.readUTF();
	        this.nroOrdem = dataInput.readUTF();
	        this.acessoRowId = dataInput.readUTF();
	        this.acessoRowIdRoot = dataInput.readUTF();
	        this.codigoProduto = dataInput.readUTF();
	        this.datCriacaoOrdem = dataInput.readUTF();
	        this.horCriacaoOrdem = dataInput.readUTF();
	        this.datVenda = dataInput.readUTF();
	        this.horaVenda = dataInput.readUTF();
	        this.datStatusOrdem = dataInput.readUTF();
	        this.horStatusOrdem = dataInput.readUTF();
	        this.numOrdemSiebel = dataInput.readUTF();
	        this.tipoDocumento = dataInput.readUTF();
	        this.documento = dataInput.readUTF();
	        this.tipoVenda = dataInput.readUTF();
	        this.loginVendedor = dataInput.readUTF();
	        this.canal = dataInput.readUTF();
	        this.cnpjParceiro = dataInput.readUTF();
	        this.custCode = dataInput.readUTF();
	        this.position = dataInput.readUTF();
	        this.flgCancAntesVenda = dataInput.readUTF();
	        this.flgVendaSubmetida = dataInput.readUTF();
	        this.flgVendaDuplicada = dataInput.readUTF();
	        this.flgVendaBruta = dataInput.readUTF();
	        this.flgVendaLiquida = dataInput.readUTF();
	        this.flgCancPosVenda = dataInput.readUTF();
	        this.flgCancDupl = dataInput.readUTF();
	        this.flgCancLiquido = dataInput.readUTF();
	        this.datCancVenda = dataInput.readUTF();
	        this.motivoCancelamento = dataInput.readUTF();
	        this.nomeCliente = dataInput.readUTF();
	        this.telefone = dataInput.readUTF();
	        this.statusOrdem = dataInput.readUTF();
	        this.semanaVenda = dataInput.readUTF();
	        this.score = dataInput.readUTF();
	        this.scoreConsumido = dataInput.readUTF();
	        this.datFinalizacaoOrdem = dataInput.readUTF();
	        this.qtdContratos = dataInput.readUTF();
	        this.nomLoginResponsavel = dataInput.readUTF();
	        this.detalheRecusaCrivo = dataInput.readUTF();
	        this.loginCancelamentoOrdem = dataInput.readUTF();
	        this.nomeParceiroVenda = dataInput.readUTF();
	        this.tipoOrdem = dataInput.readUTF();
	        this.rowIdDoItemDaOrdem = dataInput.readUTF();
	        this.rowIdDoItemDaOrdemPai = dataInput.readUTF();
	        this.categoriaItemOrdem = dataInput.readUTF();

	    }
	    
	    
	    public void setStep1Result(Step1Result result) {
	    this.clear();
	    this.tipo = TypeStep1Pt2.ITEM;
        this.datRef = result.getDatRef();
        this.codContratoOltp = result.getCodContratoOltp();
        this.codContratoAtivacao = result.getCodContratoAtivacao();
        this.numeroAcesso = result.getNumeroAcesso();
        this.customerId = result.getCustomerId();
        this.tipoProduto = result.getTipoProduto();
        this.planoAtivacaoOferta = result.getPlanoAtivacaoOferta();
        this.motivoChurn = result.getMotivoChurn();
        this.tipoChurn = result.getTipoChurn();
        this.email = result.getEmail();
        this.uf = result.getUf();
        this.tipoLogradouro = result.getTipoLogradouro();
        this.logradouro = result.getLogradouro();
        this.numero = result.getNumero();
        this.complemento = result.getComplemento();
        this.bairro = result.getBairro();
        this.cep = result.getCep();
        this.cidade = result.getCidade();
        this.tecnologia = result.getTecnologia();
        this.formaPagamento = result.getFormaPagamento();
        this.tipoConta = result.getTipoConta();
        this.codBanco = result.getCodBanco();
        this.codAgenciaBanco = result.getCodAgenciaBanco();
        this.codContaCorrente = result.getCodContaCorrente();
        this.codDebitoAutomatico = result.getCodDebitoAutomatico();
        this.diaVencimento = result.getDiaVencimento();
        this.codContaFinanceira = result.getCodContaFinanceira();
        this.numProtocolo = result.getNumProtocolo();
        this.flgOrdemAutomatica = result.getFlgOrdemAutomatica();
        this.dscTxRecorrente = result.getDscTxRecorrente();
        this.dscTxNaoRecorrente = result.getDscTxNaoRecorrente();
        this.dscStatusItem = result.getDscStatusItem();
        this.nomPlanoAtual = result.getNomPlanoAtual();
        this.valPlanoAtualItem = result.getValPlanoAtualItem();
        this.nomDescontoAtualItem = result.getNomDescontoAtualItem();
        this.valDescontoAtualItem = result.getValDescontoAtualItem();
        this.flgPortabilidade = result.getFlgPortabilidade();
        this.dscOperadoraDoadora = result.getDscOperadoraDoadora();
        this.codDdd = result.getCodDdd();
        this.numTelefonePortado = result.getNumTelefonePortado();
        this.datJanelaPortabilidade = result.getDatJanelaPortabilidade();
        this.horJanela = result.getHorJanela();
        this.dscEnderecoFatura = result.getDscEnderecoFatura();
        this.dscAreaVoip = result.getDscAreaVoip();
        this.cpe = result.getCpe();
        this.ont = result.getOnt();
        this.itemRoot = result.getItemRoot();
        this.dominioRoot = result.getDominioRoot();
        this.nroOrdem = result.getNroOrdem();
        this.acessoRowId = result.getAcessoRowId();
        this.acessoRowIdRoot = result.getAcessoRowId();
        this.codigoProduto = result.getCodigoProduto();
        this.rowIdDoItemDaOrdem = result.getRowIdDoItemDaOrdem();
        this.rowIdDoItemDaOrdemPai = result.getRowIdDoItemDaOrdemPai();
        this.categoriaItemOrdem = result.getCategoriaItemOrdem();
    }
	    
	    public void setOrdem(BAT509Order ordem) {
		    this.clear();

	    	this.tipo = TypeStep1Pt2.ORDER;
	        if(StringUtils.isNotEmpty(ordem.getDataCriacaoOrdem())) {
	            this.datCriacaoOrdem = ordem.getDataCriacaoOrdem().substring(0, 10);
	            this.horCriacaoOrdem = ordem.getDataCriacaoOrdem().substring(11, 19);
	        }
	        if(StringUtils.isNotEmpty(ordem.getDataVenda())) {
	            this.datVenda = ordem.getDataVenda().substring(0, 10);
	            this.horaVenda = ordem.getDataVenda().substring(11, 19);
	        }
	        if(StringUtils.isNotEmpty(ordem.getDataStatusOrdem())) {
	            this.datStatusOrdem = ordem.getDataStatusOrdem().substring(0, 10);
	            this.horStatusOrdem = ordem.getDataStatusOrdem().substring(11, 19);
	        }
	        this.numOrdemSiebel = ordem.getNumeroOrdem();
	        if (ordem.getNumeroCliente().length() == 11)
	            this.tipoDocumento = "CPF";
	        else
	            this.tipoDocumento = "CNPJ";
	        this.documento = ordem.getNumeroCliente();
	        this.tipoVenda = ordem.getSubTipoOrdem();
	        this.loginVendedor = ordem.getLoginVendedor();
	        this.canal = ordem.getCanalVenda();
	        this.cnpjParceiro = ordem.getCnpjParceiroVenda();
	        this.custCode = ordem.getCustcodePDV();
	        this.position = ordem.getNomeParceiroVenda();

	        if(ordem.getStatusOrdem().equals("Cancelado") && StringUtils.isEmpty(ordem.getDataVenda()))
	            this.flgCancAntesVenda = "1";
	        else
	            this.flgCancAntesVenda = "0";

	        if(StringUtils.isEmpty(ordem.getDataVenda()))
	            this.flgVendaSubmetida = "0";
	        else
	            this.flgVendaSubmetida = "1";

	        if(ordem.getStatusOrdem().equals("Cancelado") && StringUtils.isNotEmpty(ordem.getDataVenda()))
	            this.flgCancPosVenda = "1";
	        else
	            this.flgCancPosVenda = "0";

	        if(ordem.getStatusOrdem().equals("Cancelado"))
	            this.datCancVenda = ordem.getDatafinalizacaoOrdem();
	        this.motivoCancelamento = ordem.getMotivoCancelamentoOrdem();
	        this.nomeCliente = ordem.getNomeCliente();
	        this.telefone = ordem.getTelefoneContato1();
	        this.statusOrdem = ordem.getStatusOrdem();
	        if(StringUtils.isNotEmpty(ordem.getDataVenda())) {
//	            Matcher m = pattern.matcher(Weeks.weeksBetween(dtf.parseLocalDate(ordem.getDataVenda()), yyyyMMdd.parseLocalDate(context.getConfiguration().get("dat-ref"))).toString());
//	            while (m.find()) {
//	                this.semanaVenda = m.group();
//	            }
	            this.semanaVenda = String.valueOf(dtf.parseLocalDate(ordem.getDataVenda()).getWeekOfWeekyear()).concat("-").concat(String.valueOf(dtf.parseLocalDate(ordem.getDataVenda()).getYear()));
	        } else
	            this.semanaVenda = StringUtils.EMPTY;

	        this.score = ordem.getScoreCliente();
	        this.scoreConsumido = ordem.getScoreConsumido();
	        this.datFinalizacaoOrdem = ordem.getDatafinalizacaoOrdem();
	        this.qtdContratos = ordem.getNumeroContratos();
	        this.nomLoginResponsavel = ordem.getLoginResponsavel();
	        this.detalheRecusaCrivo = ordem.getMotivoRecusaCrivo();
	        this.loginCancelamentoOrdem = ordem.getLoginCancelamentoOrdem();
	        this.nomeParceiroVenda = ordem.getNomeParceiroVenda();
	        this.tipoOrdem = ordem.getTipoOrdem();
	    }

	    public void clear(){
	        this.tipo = null;
	        this.datRef = "";
	        this.codContratoOltp = "";
	        this.codContratoAtivacao = "";
	        this.numeroAcesso = "";
	        this.customerId = "";
	        this.tipoProduto = "";
	        this.planoAtivacaoOferta = "";
	        this.motivoChurn = "";
	        this.tipoChurn = "";
	        this.email = "";
	        this.uf = "";
	        this.tipoLogradouro = "";
	        this.logradouro = "";
	        this.numero = "";
	        this.complemento = "";
	        this.bairro = "";
	        this.cep = "";
	        this.cidade = "";
	        this.tecnologia = "";
	        this.formaPagamento = "";
	        this.tipoConta = "";
	        this.codBanco = "";
	        this.codAgenciaBanco = "";
	        this.codContaCorrente = "";
	        this.codDebitoAutomatico = "";
	        this.diaVencimento = "";
	        this.codContaFinanceira = "";
	        this.numProtocolo = "";
	        this.flgOrdemAutomatica = "";
	        this.dscTxRecorrente = "";
	        this.dscTxNaoRecorrente = "";
	        this.dscStatusItem = "";
	        this.nomPlanoAtual = "";
	        this.valPlanoAtualItem = "";
	        this.nomDescontoAtualItem = "";
	        this.valDescontoAtualItem = "";
	        this.flgPortabilidade = "";
	        this.dscOperadoraDoadora = "";
	        this.codDdd = "";
	        this.numTelefonePortado = "";
	        this.datJanelaPortabilidade = "";
	        this.horJanela = "";
	        this.dscEnderecoFatura = "";
	        this.dscAreaVoip = "";
	        this.cpe = "";
	        this.ont = "";
	        this.itemRoot = "";
	        this.dominioRoot = "";
	        this.nroOrdem = "";
	        this.acessoRowId = "";
	        this.acessoRowIdRoot = "";
	        this.codigoProduto = "";
	        this.datCriacaoOrdem = "";
	        this.horCriacaoOrdem = "";
	        this.datVenda = "";
	        this.horaVenda = "";
	        this.datStatusOrdem = "";
	        this.horStatusOrdem = "";
	        this.numOrdemSiebel = "";
	        this.tipoDocumento = "";
	        this.documento = "";
	        this.tipoVenda = "";
	        this.loginVendedor = "";
	        this.canal = "";
	        this.cnpjParceiro = "";
	        this.custCode = "";
	        this.position = "";
	        this.flgCancAntesVenda = "";
	        this.flgVendaSubmetida = "";
	        this.flgVendaDuplicada = "";
	        this.flgVendaBruta = "";
	        this.flgVendaLiquida = "";
	        this.flgCancPosVenda = "";
	        this.flgCancDupl = "";
	        this.flgCancLiquido = "";
	        this.datCancVenda = "";
	        this.motivoCancelamento = "";
	        this.nomeCliente = "";
	        this.telefone = "";
	        this.statusOrdem = "";
	        this.semanaVenda = "";
	        this.score = "";
	        this.scoreConsumido = "";
	        this.datFinalizacaoOrdem = "";
	        this.qtdContratos = "";
	        this.nomLoginResponsavel = "";
	        this.detalheRecusaCrivo = "";
	        this.loginCancelamentoOrdem = "";
	        this.nomeParceiroVenda = "";
	        this.tipoOrdem = "";
	        this.rowIdDoItemDaOrdem = "";
	        this.rowIdDoItemDaOrdemPai = "";
	        this.categoriaItemOrdem = "";
	    }
	    
	    
	    

	    public Step1Pt2Value() {
	    				
		}

		public String getAcessoRowIdRoot() {
	        return acessoRowIdRoot;
	    }

	    public String getTipoOrdem() {
	        return tipoOrdem;
	    }

	    public TypeStep1Pt2 getTipo() {
	        return tipo;
	    }

	    public String getDatRef() {
	        return datRef;
	    }

	    public String getCodContratoOltp() {
	        return codContratoOltp;
	    }

	    public String getCodContratoAtivacao() {
	        return codContratoAtivacao;
	    }

	    public String getNumeroAcesso() {
	        return numeroAcesso;
	    }

	    public String getCustomerId() {
	        return customerId;
	    }

	    public String getTipoProduto() {
	        return tipoProduto;
	    }

	    public String getPlanoAtivacaoOferta() {
	        return planoAtivacaoOferta;
	    }

	    public String getMotivoChurn() {
	        return motivoChurn;
	    }

	    public String getTipoChurn() {
	        return tipoChurn;
	    }

	    public String getEmail() {
	        return email;
	    }

	    public String getUf() {
	        return uf;
	    }

	    public String getTipoLogradouro() {
	        return tipoLogradouro;
	    }

	    public String getLogradouro() {
	        return logradouro;
	    }

	    public String getNumero() {
	        return numero;
	    }

	    public String getComplemento() {
	        return complemento;
	    }

	    public String getBairro() {
	        return bairro;
	    }

	    public String getCep() {
	        return cep;
	    }

	    public String getCidade() {
	        return cidade;
	    }

	    public String getTecnologia() {
	        return tecnologia;
	    }

	    public String getFormaPagamento() {
	        return formaPagamento;
	    }

	    public String getTipoConta() {
	        return tipoConta;
	    }

	    public String getCodBanco() {
	        return codBanco;
	    }

	    public String getCodAgenciaBanco() {
	        return codAgenciaBanco;
	    }

	    public String getCodContaCorrente() {
	        return codContaCorrente;
	    }

	    public String getCodDebitoAutomatico() {
	        return codDebitoAutomatico;
	    }

	    public String getDiaVencimento() {
	        return diaVencimento;
	    }

	    public String getCodContaFinanceira() {
	        return codContaFinanceira;
	    }

	    public String getNumProtocolo() {
	        return numProtocolo;
	    }

	    public String getFlgOrdemAutomatica() {
	        return flgOrdemAutomatica;
	    }

	    public String getDscTxRecorrente() {
	        return dscTxRecorrente;
	    }

	    public String getDscTxNaoRecorrente() {
	        return dscTxNaoRecorrente;
	    }

	    public String getDscStatusItem() {
	        return dscStatusItem;
	    }

	    public String getNomPlanoAtual() {
	        return nomPlanoAtual;
	    }

	    public String getValPlanoAtualItem() {
	        return valPlanoAtualItem;
	    }

	    public String getNomDescontoAtualItem() {
	        return nomDescontoAtualItem;
	    }

	    public String getValDescontoAtualItem() {
	        return valDescontoAtualItem;
	    }

	    public String getFlgPortabilidade() {
	        return flgPortabilidade;
	    }

	    public String getDscOperadoraDoadora() {
	        return dscOperadoraDoadora;
	    }

	    public String getCodDdd() {
	        return codDdd;
	    }

	    public String getNumTelefonePortado() {
	        return numTelefonePortado;
	    }

	    public String getDatJanelaPortabilidade() {
	        return datJanelaPortabilidade;
	    }

	    public String getHorJanela() {
	        return horJanela;
	    }

	    public String getDscEnderecoFatura() {
	        return dscEnderecoFatura;
	    }

	    public String getDscAreaVoip() {
	        return dscAreaVoip;
	    }

	    public String getCpe() {
	        return cpe;
	    }

	    public String getOnt() {
	        return ont;
	    }

	    public String getItemRoot() {
	        return itemRoot;
	    }

	    public String getDominioRoot() {
	        return dominioRoot;
	    }

	    public String getNroOrdem() {
	        return nroOrdem;
	    }

	    public String getAcessoRowId() {
	        return acessoRowId;
	    }

	    public String getCodigoProduto() {
	        return codigoProduto;
	    }

	    public String getDatCriacaoOrdem() {
	        return datCriacaoOrdem;
	    }

	    public String getHorCriacaoOrdem() {
	        return horCriacaoOrdem;
	    }

	    public String getDatVenda() {
	        return datVenda;
	    }

	    public String getHoraVenda() {
	        return horaVenda;
	    }

	    public String getDatStatusOrdem() {
	        return datStatusOrdem;
	    }

	    public String getHorStatusOrdem() {
	        return horStatusOrdem;
	    }

	    public String getNumOrdemSiebel() {
	        return numOrdemSiebel;
	    }

	    public String getTipoDocumento() {
	        return tipoDocumento;
	    }

	    public String getDocumento() {
	        return documento;
	    }

	    public String getTipoVenda() {
	        return tipoVenda;
	    }

	    public String getLoginVendedor() {
	        return loginVendedor;
	    }

	    public String getCanal() {
	        return canal;
	    }

	    public String getCnpjParceiro() {
	        return cnpjParceiro;
	    }

	    public String getCustCode() {
	        return custCode;
	    }

	    public String getPosition() {
	        return position;
	    }

	    public String getFlgCancAntesVenda() {
	        return flgCancAntesVenda;
	    }

	    public String getFlgVendaDuplicada() {
	        return flgVendaDuplicada;
	    }

	    public String getFlgVendaBruta() {
	        return flgVendaBruta;
	    }

	    public String getFlgVendaLiquida() {
	        return flgVendaLiquida;
	    }

	    public String getFlgCancPosVenda() {
	        return flgCancPosVenda;
	    }

	    public String getDatCancVenda() {
	        return datCancVenda;
	    }

	    public String getMotivoCancelamento() {
	        return motivoCancelamento;
	    }

	    public String getNomeCliente() {
	        return nomeCliente;
	    }

	    public String getTelefone() {
	        return telefone;
	    }

	    public String getStatusOrdem() {
	        return statusOrdem;
	    }

	    public String getSemanaVenda() {
	        return semanaVenda;
	    }

	    public String getScore() {
	        return score;
	    }

	    public String getScoreConsumido() {
	        return scoreConsumido;
	    }

	    public String getDatFinalizacaoOrdem() {
	        return datFinalizacaoOrdem;
	    }

	    public String getQtdContratos() {
	        return qtdContratos;
	    }

	    public String getNomLoginResponsavel() {
	        return nomLoginResponsavel;
	    }

	    public String getDetalheRecusaCrivo() {
	        return detalheRecusaCrivo;
	    }

	    public String getLoginCancelamentoOrdem() {
	        return loginCancelamentoOrdem;
	    }

	    public String getNomeParceiroVenda() {
	        return nomeParceiroVenda;
	    }

	    public String getFlgVendaSubmetida() {
	        return flgVendaSubmetida;
	    }

	    public String getFlgCancDupl() {
	        return flgCancDupl;
	    }

	    public String getFlgCancLiquido() {
	        return flgCancLiquido;
	    }

		public String getRowIdDoItemDaOrdem() {
			return rowIdDoItemDaOrdem;
		}

		public void setRowIdDoItemDaOrdem(String rowIdDoItemDaOrdem) {
			this.rowIdDoItemDaOrdem = rowIdDoItemDaOrdem;
		}

		public String getRowIdDoItemDaOrdemPai() {
			return rowIdDoItemDaOrdemPai;
		}

		public void setRowIdDoItemDaOrdemPai(String rowIdDoItemDaOrdemPai) {
			this.rowIdDoItemDaOrdemPai = rowIdDoItemDaOrdemPai;
		}

		public String getCategoriaItemOrdem() {
			return categoriaItemOrdem;
		}

		public void setCategoriaItemOrdem(String categoriaItemOrdem) {
			this.categoriaItemOrdem = categoriaItemOrdem;
		}


}
