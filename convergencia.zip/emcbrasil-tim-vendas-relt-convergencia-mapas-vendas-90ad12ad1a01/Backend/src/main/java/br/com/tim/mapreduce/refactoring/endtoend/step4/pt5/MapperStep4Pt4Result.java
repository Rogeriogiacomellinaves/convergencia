
package br.com.tim.mapreduce.refactoring.endtoend.step4.pt5;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

import br.com.tim.mapreduce.refactoring.endtoend.step1.pt4.utils.Step1Pt4Counters;
import br.com.tim.mapreduce.refactoring.endtoend.step4.model.Step4;

public class MapperStep4Pt4Result extends org.apache.hadoop.mapreduce.Mapper<Writable,Text,Step4Pt5Key,E2EStep4Pt5Value> {

	private E2EStep4Pt5Value outValue;
	private Step4 input;
	private Step4Pt5Key outkey; 
	@Override
	protected void map(Writable key, Text value, Context context) throws IOException, InterruptedException {
		
		
		input.parseFromText(value);
		outValue.Step1Pt3Result(input);
		outkey.setNroOrdem(outValue.getDocumento());
		outkey.setTipo(TypeStep4Pt5.RELT);
		context.write(outkey, outValue);
		context.getCounter(Step1Pt4Counters.STEP1PT3_MAPPER_WRITE).increment(1l);
	}

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		super.setup(context);
		this.outValue = new E2EStep4Pt5Value();
		this.input = new Step4();
		this.outkey = new Step4Pt5Key();
	}

	@Override
	protected void cleanup(Context context) throws IOException, InterruptedException {
		super.cleanup(context);
		this.clear();
	}

	private void clear(){
	   this.outValue.clear();
	}

}