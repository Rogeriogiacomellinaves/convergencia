package br.com.tim.mapreduce.e2e.step2.model;

import org.apache.commons.lang3.StringUtils;

public class Step1Result {

    private String datRef;
    private String codContratoOltp;
    private String codContratoAtivacao;
    private String numeroAcesso;
    private String customerId;
    private String tipoProduto;
    private String planoAtivacaoOferta;
    private String motivoChurn;
    private String tipoChurn;
    private String email;
    private String uf;
    private String tipoLogradouro;
    private String logradouro;
    private String numero;
    private String complemento;
    private String bairro;
    private String cep;
    private String cidade;
    private String tecnologia;
    private String formaPagamento;
    private String tipoConta;
    private String codBanco;
    private String codAgenciaBanco;
    private String codContaCorrente;
    private String codDebitoAutomatico;
    private String diaVencimento;
    private String codContaFinanceira;
    private String numProtocolo;
    private String flgOrdemAutomatica;
    private String dscTxRecorrente;
    private String dscTxNaoRecorrente;
    private String dscStatusItem;
    private String nomPlanoAtual;
    private String valPlanoAtualItem;
    private String nomDescontoAtualItem;
    private String valDescontoAtualItem;
    private String flgPortabilidade;
    private String dscOperadoraDoadora;
    private String codDdd;
    private String numTelefonePortado;
    private String datJanelaPortabilidade;
    private String horJanela;
    private String dscEnderecoFatura;
    private String dscAreaVoip;
    private String cpe;
    private String ont;
    private String itemRoot;
    private String dominioRoot;
    private String nroOrdem;
    private String acessoRowId;
    private String acessoRowIdRoot;
    private String codigoProduto;

    public Step1Result(){}

    public void setStep1Result(String datRef, String codContratoOltp, String codContratoAtivacao, String numeroAcesso, String customerId, String tipoProduto,
                               String planoAtivacaoOferta, String motivoChurn, String tipoChurn, String email, String uf, String tipoLogradouro, String logradouro,
                               String numero, String complemento, String bairro, String cep, String cidade, String tecnologia, String formaPagamento, String tipoConta,
                               String codBanco, String codAgenciaBanco, String codContaCorrente, String codDebitoAutomatico, String diaVencimento, String codContaFinanceira,
                               String numProtocolo, String flgOrdemAutomatica, String dscTxRecorrente, String dscTxNaoRecorrente, String dscStatusItem, String nomPlanoAtual,
                               String valPlanoAtualItem, String nomDescontoAtualItem, String valDescontoAtualItem, String flgPortabilidade, String dscOperadoraDoadora,
                               String codDdd, String numTelefonePortado, String datJanelaPortabilidade, String horJanela, String dscEnderecoFatura, String dscAreaVoip,
                               String cpe, String ont, String itemRoot, String dominioRoot, String nroOrdem, String acessoRowId, String acessoRowIdRoot, String codigoProduto) {

        this.datRef = datRef;
        this.codContratoOltp = codContratoOltp;
        this.codContratoAtivacao = codContratoAtivacao;
        this.numeroAcesso = numeroAcesso;
        this.customerId = customerId;
        this.tipoProduto = tipoProduto;
        this.planoAtivacaoOferta = planoAtivacaoOferta;
        this.motivoChurn = motivoChurn;
        this.tipoChurn = tipoChurn;
        this.email = email;
        this.uf = uf;
        this.tipoLogradouro = tipoLogradouro;
        this.logradouro = logradouro;
        this.numero = numero;
        this.complemento = complemento;
        this.bairro = bairro;
        this.cep = cep;
        this.cidade = cidade;
        this.tecnologia = tecnologia;
        this.formaPagamento = formaPagamento;
        this.tipoConta = tipoConta;
        this.codBanco = codBanco;
        this.codAgenciaBanco = codAgenciaBanco;
        this.codContaCorrente = codContaCorrente;
        this.codDebitoAutomatico = codDebitoAutomatico;
        this.diaVencimento = diaVencimento;
        this.codContaFinanceira = codContaFinanceira;
        this.numProtocolo = numProtocolo;
        this.flgOrdemAutomatica = flgOrdemAutomatica;
        this.dscTxRecorrente = dscTxRecorrente;
        this.dscTxNaoRecorrente = dscTxNaoRecorrente;
        this.dscStatusItem = dscStatusItem;
        this.nomPlanoAtual = nomPlanoAtual;
        this.valPlanoAtualItem = valPlanoAtualItem;
        this.nomDescontoAtualItem = nomDescontoAtualItem;
        this.valDescontoAtualItem = valDescontoAtualItem;
        this.flgPortabilidade = flgPortabilidade;
        this.dscOperadoraDoadora = dscOperadoraDoadora;
        this.codDdd = codDdd;
        this.numTelefonePortado = numTelefonePortado;
        this.datJanelaPortabilidade = datJanelaPortabilidade;
        this.horJanela = horJanela;
        this.dscEnderecoFatura = dscEnderecoFatura;
        this.dscAreaVoip = dscAreaVoip;
        this.cpe = cpe;
        this.ont = ont;
        this.itemRoot = itemRoot;
        this.dominioRoot = dominioRoot;
        this.nroOrdem = nroOrdem;
        this.acessoRowId = acessoRowId;
        this.acessoRowIdRoot = acessoRowIdRoot;
        this.codigoProduto = codigoProduto;

    }

    public boolean parse(String textString) {
        if (StringUtils.isNotBlank(textString)) {
            String[] cols = textString.split("\\|", -1);
            int i = 0;
            this.setStep1Result(cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                                cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                                cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                                cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                                cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                                cols[i++], cols[i++]);
            return true;
        }
        return false;
    }

    public String getAcessoRowIdRoot() {
        return acessoRowIdRoot;
    }

    public String getDatRef() {
        return datRef;
    }

    public void setDatRef(String datRef) {
        this.datRef = datRef;
    }

    public String getCodContratoOltp() {
        return codContratoOltp;
    }

    public void setCodContratoOltp(String codContratoOltp) {
        this.codContratoOltp = codContratoOltp;
    }

    public String getCodContratoAtivacao() {
        return codContratoAtivacao;
    }

    public void setCodContratoAtivacao(String codContratoAtivacao) {
        this.codContratoAtivacao = codContratoAtivacao;
    }

    public String getNumeroAcesso() {
        return numeroAcesso;
    }

    public void setNumeroAcesso(String numeroAcesso) {
        this.numeroAcesso = numeroAcesso;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getTipoProduto() {
        return tipoProduto;
    }

    public void setTipoProduto(String tipoProduto) {
        this.tipoProduto = tipoProduto;
    }

    public String getPlanoAtivacaoOferta() {
        return planoAtivacaoOferta;
    }

    public void setPlanoAtivacaoOferta(String planoAtivacaoOferta) {
        this.planoAtivacaoOferta = planoAtivacaoOferta;
    }

    public String getMotivoChurn() {
        return motivoChurn;
    }

    public void setMotivoChurn(String motivoChurn) {
        this.motivoChurn = motivoChurn;
    }

    public String getTipoChurn() {
        return tipoChurn;
    }

    public void setTipoChurn(String tipoChurn) {
        this.tipoChurn = tipoChurn;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUf() {
        return uf;
    }

    public void setUf(String uf) {
        this.uf = uf;
    }

    public String getTipoLogradouro() {
        return tipoLogradouro;
    }

    public void setTipoLogradouro(String tipoLogradouro) {
        this.tipoLogradouro = tipoLogradouro;
    }

    public String getLogradouro() {
        return logradouro;
    }

    public void setLogradouro(String logradouro) {
        this.logradouro = logradouro;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getComplemento() {
        return complemento;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getTecnologia() {
        return tecnologia;
    }

    public void setTecnologia(String tecnologia) {
        this.tecnologia = tecnologia;
    }

    public String getFormaPagamento() {
        return formaPagamento;
    }

    public void setFormaPagamento(String formaPagamento) {
        this.formaPagamento = formaPagamento;
    }

    public String getTipoConta() {
        return tipoConta;
    }

    public void setTipoConta(String tipoConta) {
        this.tipoConta = tipoConta;
    }

    public String getCodBanco() {
        return codBanco;
    }

    public void setCodBanco(String codBanco) {
        this.codBanco = codBanco;
    }

    public String getCodAgenciaBanco() {
        return codAgenciaBanco;
    }

    public void setCodAgenciaBanco(String codAgenciaBanco) {
        this.codAgenciaBanco = codAgenciaBanco;
    }

    public String getCodContaCorrente() {
        return codContaCorrente;
    }

    public void setCodContaCorrente(String codContaCorrente) {
        this.codContaCorrente = codContaCorrente;
    }

    public String getCodDebitoAutomatico() {
        return codDebitoAutomatico;
    }

    public void setCodDebitoAutomatico(String codDebitoAutomatico) {
        this.codDebitoAutomatico = codDebitoAutomatico;
    }

    public String getDiaVencimento() {
        return diaVencimento;
    }

    public void setDiaVencimento(String diaVencimento) {
        this.diaVencimento = diaVencimento;
    }

    public String getCodContaFinanceira() {
        return codContaFinanceira;
    }

    public void setCodContaFinanceira(String codContaFinanceira) {
        this.codContaFinanceira = codContaFinanceira;
    }

    public String getNumProtocolo() {
        return numProtocolo;
    }

    public void setNumProtocolo(String numProtocolo) {
        this.numProtocolo = numProtocolo;
    }

    public String getFlgOrdemAutomatica() {
        return flgOrdemAutomatica;
    }

    public void setFlgOrdemAutomatica(String flgOrdemAutomatica) {
        this.flgOrdemAutomatica = flgOrdemAutomatica;
    }

    public String getDscTxRecorrente() {
        return dscTxRecorrente;
    }

    public void setDscTxRecorrente(String dscTxRecorrente) {
        this.dscTxRecorrente = dscTxRecorrente;
    }

    public String getDscTxNaoRecorrente() {
        return dscTxNaoRecorrente;
    }

    public void setDscTxNaoRecorrente(String dscTxNaoRecorrente) {
        this.dscTxNaoRecorrente = dscTxNaoRecorrente;
    }

    public String getDscStatusItem() {
        return dscStatusItem;
    }

    public void setDscStatusItem(String dscStatusItem) {
        this.dscStatusItem = dscStatusItem;
    }

    public String getNomPlanoAtual() {
        return nomPlanoAtual;
    }

    public void setNomPlanoAtual(String nomPlanoAtual) {
        this.nomPlanoAtual = nomPlanoAtual;
    }

    public String getValPlanoAtualItem() {
        return valPlanoAtualItem;
    }

    public void setValPlanoAtualItem(String valPlanoAtualItem) {
        this.valPlanoAtualItem = valPlanoAtualItem;
    }

    public String getNomDescontoAtualItem() {
        return nomDescontoAtualItem;
    }

    public void setNomDescontoAtualItem(String nomDescontoAtualItem) {
        this.nomDescontoAtualItem = nomDescontoAtualItem;
    }

    public String getValDescontoAtualItem() {
        return valDescontoAtualItem;
    }

    public void setValDescontoAtualItem(String valDescontoAtualItem) {
        this.valDescontoAtualItem = valDescontoAtualItem;
    }

    public String getFlgPortabilidade() {
        return flgPortabilidade;
    }

    public void setFlgPortabilidade(String flgPortabilidade) {
        this.flgPortabilidade = flgPortabilidade;
    }

    public String getDscOperadoraDoadora() {
        return dscOperadoraDoadora;
    }

    public void setDscOperadoraDoadora(String dscOperadoraDoadora) {
        this.dscOperadoraDoadora = dscOperadoraDoadora;
    }

    public String getCodDdd() {
        return codDdd;
    }

    public void setCodDdd(String codDdd) {
        this.codDdd = codDdd;
    }

    public String getNumTelefonePortado() {
        return numTelefonePortado;
    }

    public void setNumTelefonePortado(String numTelefonePortado) {
        this.numTelefonePortado = numTelefonePortado;
    }

    public String getDatJanelaPortabilidade() {
        return datJanelaPortabilidade;
    }

    public void setDatJanelaPortabilidade(String datJanelaPortabilidade) {
        this.datJanelaPortabilidade = datJanelaPortabilidade;
    }

    public String getHorJanela() {
        return horJanela;
    }

    public void setHorJanela(String horJanela) {
        this.horJanela = horJanela;
    }

    public String getDscEnderecoFatura() {
        return dscEnderecoFatura;
    }

    public void setDscEnderecoFatura(String dscEnderecoFatura) {
        this.dscEnderecoFatura = dscEnderecoFatura;
    }

    public String getDscAreaVoip() {
        return dscAreaVoip;
    }

    public void setDscAreaVoip(String dscAreaVoip) {
        this.dscAreaVoip = dscAreaVoip;
    }

    public String getCpe() {
        return cpe;
    }

    public void setCpe(String cpe) {
        this.cpe = cpe;
    }

    public String getOnt() {
        return ont;
    }

    public void setOnt(String ont) {
        this.ont = ont;
    }

    public String getItemRoot() {
        return itemRoot;
    }

    public void setItemRoot(String itemRoot) {
        this.itemRoot = itemRoot;
    }

    public String getDominioRoot() {
        return dominioRoot;
    }

    public void setDominioRoot(String dominioRoot) {
        this.dominioRoot = dominioRoot;
    }

    public String getNroOrdem() {
        return nroOrdem;
    }

    public void setNroOrdem(String nroOrdem) {
        this.nroOrdem = nroOrdem;
    }

    public String getAcessoRowId() {
        return acessoRowId;
    }

    public void setAcessoRowId(String acessoRowId) {
        this.acessoRowId = acessoRowId;
    }

    public String getCodigoProduto() {
        return codigoProduto;
    }

    public void setCodigoProduto(String codigoProduto) {
        this.codigoProduto = codigoProduto;
    }
}
