package br.com.tim.mapreduce.tramit.step1;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.log4j.Logger;

import java.io.IOException;

public class TramitStep1Reducer extends org.apache.hadoop.mapreduce.Reducer<TramitStep1Key,TramitStep1Value,NullWritable,Text> {

    protected static final Logger LOG = Logger.getLogger(TramitStep1Reducer.class);
    private TramitStep1OutValue outValue;

    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        super.setup(context);
        outValue = new TramitStep1OutValue();
    }

    @Override
    protected void reduce(TramitStep1Key key, Iterable<TramitStep1Value> values, Context context) throws InterruptedException {

        outValue.clear();

        try {
            for (TramitStep1Value value : values) {
                if (value.getTipo().equals(TypeStep1.ITEM)){
                    outValue.clearItem();
                    outValue.setItem(value);
                    outValue.setTipoErro();
                    context.write(NullWritable.get(), new Text(outValue.toString()));
                }else if (value.getTipo().equals(TypeStep1.ORDEM)){
                    outValue.setOrdem(value);
                }else if(value.getTipo().equals(TypeStep1.WFMTOA)) {
                	outValue.clearWfmtoa();
                	outValue.setWfmtoa(value);
                }
            }


        } catch (Exception e) {
            LOG.error(" ############ ERROR EXECUTION REDUCER ############ ");
            LOG.error(e.getMessage());
            throw new InterruptedException(e.getMessage());
        }
    }

    @Override
    protected void cleanup(Context context) throws IOException, InterruptedException {
        super.cleanup(context);

    }
}


