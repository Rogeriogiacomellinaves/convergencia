package br.com.tim.mapreduce.e2e.step5;

import org.apache.hadoop.mapreduce.Partitioner;

public class JoinPartitioner extends Partitioner<E2EStep5Key, E2EStep5Value> {

    @Override
    public int getPartition(E2EStep5Key taggedKey, E2EStep5Value value, int numPartitions) {
        return Math.abs(taggedKey.hashCodeJoin() % numPartitions);
    }
}