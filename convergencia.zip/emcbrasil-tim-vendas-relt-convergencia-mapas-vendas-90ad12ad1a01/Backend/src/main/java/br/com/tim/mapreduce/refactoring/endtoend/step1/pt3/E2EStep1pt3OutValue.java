
package br.com.tim.mapreduce.refactoring.endtoend.step1.pt3;

import br.com.tim.utils.CommonsConstants;

public class E2EStep1pt3OutValue{
	
	private final static String DELIMITER = CommonsConstants.FILE_FIELD_SEPARATOR;

	
	protected String datRef;
	protected String datCriacaoOrdem;
	protected String horCriacaoOrdem;
	protected String datVenda;
	protected String horaVenda;
	protected String datStatusOrdem;
	protected String horStatusOrdem;
	protected String numOrdemSiebel;
	protected String codContratoOltp;
	protected String codContratoAtivacao;
	protected String numeroAcesso;
	protected String customerId;
	protected String tipoDocumento;
	protected String documento;
	protected String tipoVenda;
	protected String tipoProduto;
	protected String planoAtivacaoOferta;
	protected String loginVendedor;
	protected String canal;
	protected String cnpjParceiro;
	protected String custCode;
	protected String position;
	protected String flgCancAntesVenda;
	protected String flgCancPosVenda;
	protected String datCancVenda;
	protected String motivoCancelamento;
	protected String nomeCliente;
	protected String telefone;
	protected String email;
	protected String uf;
	protected String tipoLogradouro;
	protected String logradouro;
	protected String numero;
	protected String complemento;
	protected String bairro;
	protected String cep;
	protected String cidade;
	protected String statusOrdem;
	protected String tecnologia;
	protected String formaPagamento;
	protected String tipoConta;
	protected String codBanco;
	protected String codAgenciaBanco;
	protected String codContaCorrente;
	protected String codDebitoAutomatico;
	protected String diaVencimento;
	protected String semanaVenda;
	protected String score;
	protected String scoreConsumido;
	protected String datFinalizacaoOrdem;
	protected String qtdContratos;
	protected String numProtocolo;
	protected String flgOrdemAutomatica;
	protected String dscTxRecorrente;
	protected String dscTxNaoRecorrente;
	protected String dscStatusItem;
	protected String nomLoginResponsavel;
	protected String flgPortabilidade;
	protected String dscOperadoraDoadora;
	protected String codDdd;
	protected String numTelefonePortado;
	protected String datJanelaPortabilidade;
	protected String horJanela;
	protected String dscEnderecoFatura;
	protected String dscAreaVoip;
	protected String cpe;
	protected String ont;
	protected String detalheRecusaCrivo;
	protected String itemRoot;
	protected String loginCancelamentoOrdem;
	protected String dominioRoot;
	protected String codContaFinanceira;
	protected String nomPlanoAtual;
	protected String valPlanoAtualItem;
	protected String nomDescontoAtualItem;
	protected String valDescontoAtualItem;
	protected String nroOrdem;
	protected String acessoRowId;
	protected String acessoRowIdRoot;
	protected String codigoProduto;
	protected String datVendaOrig;
	protected String horVendaOrig;
	protected String numOrdemSiebelOrig;
	protected String loginVendedorOrig;
	protected String canalOrig;
	protected String cnpjParceiroOrig;
	protected String custCodeOrig;
	protected String positionOrig;
	protected String flgVendaSubmetida;
	protected String flgVendaDuplicada;
	protected String flgVendaBruta;
	protected String flgVendaLiquida;
	protected String flgCancDupl;
	protected String flgCancLiquido;
	protected String semanaVendaOrig;
	protected String nomeParceiroVenda;
	protected String nomeParceiroVendaOrig;
	protected String rowIdDoItemDaOrdem;
	protected String rowIdDoItemDaOrdemPai;
	protected String categoriaItemOrdem;
	protected String msan_olt_venda;
	protected String dt_conclusao_wfm;
	protected String dscStatusOrdemWfm;
	protected String datStatusWfm;
	protected String horaStatusWfm;
	protected String idRecursoWfm;
	protected String nomRecursoWfm;
	protected String idRecursoPaiWfm;
	protected String datPrimeiroAgend;
	protected String horaPrimeiroAgendamento;
	protected String datAgendAtual;
	protected String horaAgendamentoAtual;
	protected String dscStatusAtivacao;
	
	
	public void setRelt(E2EStep1pt3Value value) {

		this.datRef = value.getDatRef();
		this.datCriacaoOrdem = value.getDatCriacaoOrdem();
		this.horCriacaoOrdem = value.getHorCriacaoOrdem();
		this.datVenda = value.getDatVenda();
		this.horaVenda = value.getHoraVenda();
		this.datStatusOrdem = value.getDatStatusOrdem();
		this.horStatusOrdem = value.getHorStatusOrdem();
		this.numOrdemSiebel = value.getNumOrdemSiebel();
		this.codContratoOltp = value.getCodContratoOltp();
		this.codContratoAtivacao = value.getCodContratoAtivacao();
		this.numeroAcesso = value.getNumeroAcesso();
		this.customerId = value.getCustomerId();
		this.tipoDocumento = value.getTipoDocumento();
		this.documento = value.getDocumento();
		this.tipoVenda = value.getTipoVenda();
		this.tipoProduto = value.getTipoProduto();
		this.planoAtivacaoOferta = value.getPlanoAtivacaoOferta();
		this.loginVendedor = value.getLoginVendedor();
		this.canal = value.getCanal();
		this.cnpjParceiro = value.getCnpjParceiro();
		this.custCode = value.getCustCode();
		this.position = value.getPosition();
		this.flgCancAntesVenda = value.getFlgCancAntesVenda();
		this.flgCancPosVenda = value.getFlgCancPosVenda();
		this.datCancVenda = value.getDatCancVenda();
		this.motivoCancelamento = value.getMotivoCancelamento();
		this.nomeCliente = value.getNomeCliente();
		this.telefone = value.getTelefone();
		this.email = value.getEmail();
		this.uf = value.getUf();
		this.tipoLogradouro = value.getTipoLogradouro();
		this.logradouro = value.getLogradouro();
		this.numero = value.getNumero();
		this.complemento = value.getComplemento();
		this.bairro = value.getBairro();
		this.cep = value.getCep();
		this.cidade = value.getCidade();
		this.statusOrdem = value.getStatusOrdem();
		this.tecnologia = value.getTecnologia();
		this.formaPagamento = value.getFormaPagamento();
		this.tipoConta = value.getTipoConta();
		this.codBanco = value.getCodBanco();
		this.codAgenciaBanco = value.getCodAgenciaBanco();
		this.codContaCorrente = value.getCodContaCorrente();
		this.codDebitoAutomatico = value.getCodDebitoAutomatico();
		this.diaVencimento = value.getDiaVencimento();
		this.semanaVenda = value.getSemanaVenda();
		this.score = value.getScore();
		this.scoreConsumido = value.getScoreConsumido();
		this.datFinalizacaoOrdem = value.getDatFinalizacaoOrdem();
		this.qtdContratos = value.getQtdContratos();
		this.numProtocolo = value.getNumProtocolo();
		this.flgOrdemAutomatica = value.getFlgOrdemAutomatica();
		this.dscTxRecorrente = value.getDscTxRecorrente();
		this.dscTxNaoRecorrente = value.getDscTxNaoRecorrente();
		this.dscStatusItem = value.getDscStatusItem();
		this.nomLoginResponsavel = value.getNomLoginResponsavel();
		this.flgPortabilidade = value.getFlgPortabilidade();
		this.dscOperadoraDoadora = value.getDscOperadoraDoadora();
		this.codDdd = value.getCodDdd();
		this.numTelefonePortado = value.getNumTelefonePortado();
		this.datJanelaPortabilidade = value.getDatJanelaPortabilidade();
		this.horJanela = value.getHorJanela();
		this.dscEnderecoFatura = value.getDscEnderecoFatura();
		this.dscAreaVoip = value.getDscAreaVoip();
		this.cpe = value.getCpe();
		this.ont = value.getOnt();
		this.detalheRecusaCrivo = value.getDetalheRecusaCrivo();
		this.itemRoot = value.getItemRoot();
		this.loginCancelamentoOrdem = value.getLoginCancelamentoOrdem();
		this.dominioRoot = value.getDominioRoot();
		this.codContaFinanceira = value.getCodContaFinanceira();
		this.nomPlanoAtual = value.getNomPlanoAtual();
		this.valPlanoAtualItem = value.getValPlanoAtualItem();
		this.nomDescontoAtualItem = value.getNomDescontoAtualItem();
		this.valDescontoAtualItem = value.getValDescontoAtualItem();
		this.nroOrdem = value.getNroOrdem();
		this.acessoRowId = value.getAcessoRowId();
		this.acessoRowIdRoot = value.getAcessoRowIdRoot();
		this.codigoProduto = value.getCodigoProduto();
		this.datVendaOrig = value.getDatVendaOrig();
		this.horVendaOrig = value.getHorVendaOrig();
		this.numOrdemSiebelOrig = value.getNumOrdemSiebelOrig();
		this.loginVendedorOrig = value.getLoginVendedorOrig();
		this.canalOrig = value.getCanalOrig();
		this.cnpjParceiroOrig = value.getCnpjParceiroOrig();
		this.custCodeOrig = value.getCustCodeOrig();
		this.positionOrig = value.getPositionOrig();
		this.flgVendaSubmetida = value.getFlgVendaSubmetida();
		this.flgVendaDuplicada = value.getFlgVendaDuplicada();
		this.flgVendaBruta = value.getFlgVendaBruta();
		this.flgVendaLiquida = value.getFlgVendaLiquida();
		this.flgCancDupl = value.getFlgCancDupl();
		this.flgCancLiquido = value.getFlgCancLiquido();
		this.semanaVendaOrig = value.getSemanaVendaOrig();
		this.nomeParceiroVenda = value.getNomeParceiroVenda();
		this.nomeParceiroVendaOrig = value.getNomeParceiroVendaOrig();
		this.rowIdDoItemDaOrdem = value.getRowIdDoItemDaOrdem();
		this.rowIdDoItemDaOrdemPai = value.getRowIdDoItemDaOrdemPai();
		this.categoriaItemOrdem = value.getCategoriaItemOrdem();
	}
	
	public void setWfmtoa(E2EStep1pt3Value value) {
		this.msan_olt_venda = value.getMsan_olt_venda();
		this.dt_conclusao_wfm = value.getDt_conclusao_wfm();
		this.dscStatusOrdemWfm = value.getDscStatusOrdemWfm();
		this.datStatusWfm = value.getDatStatusWfm();
		this.horaStatusWfm = value.getHoraStatusWfm();
		this.idRecursoWfm = value.getIdRecursoWfm();
		this.nomRecursoWfm = value.getNomRecursoWfm();
		this.idRecursoPaiWfm = value.getIdRecursoPaiWfm();
		this.datPrimeiroAgend = value.getDatPrimeiroAgend();
		this.horaPrimeiroAgendamento = value.getHoraPrimeiroAgendamento();
		this.datAgendAtual = value.getDatAgendAtual();
		this.horaAgendamentoAtual = value.getHoraAgendamentoAtual();
		this.dscStatusAtivacao = value.getDscStatusAtivacao();
	}
	
	
	public void clearRelt() {
		this.datRef = CommonsConstants.EMPTY;
        this.datCriacaoOrdem = CommonsConstants.EMPTY;
        this.horCriacaoOrdem = CommonsConstants.EMPTY;
        this.datVenda = CommonsConstants.EMPTY;
        this.horaVenda = CommonsConstants.EMPTY;
        this.datStatusOrdem = CommonsConstants.EMPTY;
        this.horStatusOrdem = CommonsConstants.EMPTY;
        this.numOrdemSiebel = CommonsConstants.EMPTY;
        this.codContratoOltp = CommonsConstants.EMPTY;
        this.codContratoAtivacao = CommonsConstants.EMPTY;
        this.numeroAcesso = CommonsConstants.EMPTY;
        this.customerId = CommonsConstants.EMPTY;
        this.tipoDocumento = CommonsConstants.EMPTY;
        this.documento = CommonsConstants.EMPTY;
        this.tipoVenda = CommonsConstants.EMPTY;
        this.tipoProduto = CommonsConstants.EMPTY;
        this.planoAtivacaoOferta = CommonsConstants.EMPTY;
        this.loginVendedor = CommonsConstants.EMPTY;
        this.canal = CommonsConstants.EMPTY;
        this.cnpjParceiro = CommonsConstants.EMPTY;
        this.custCode = CommonsConstants.EMPTY;
        this.position = CommonsConstants.EMPTY;
        this.flgCancAntesVenda = CommonsConstants.EMPTY;
        this.flgCancPosVenda = CommonsConstants.EMPTY;
        this.datCancVenda = CommonsConstants.EMPTY;
        this.motivoCancelamento = CommonsConstants.EMPTY;
        this.nomeCliente = CommonsConstants.EMPTY;
        this.telefone = CommonsConstants.EMPTY;
        this.email = CommonsConstants.EMPTY;
        this.uf = CommonsConstants.EMPTY;
        this.tipoLogradouro = CommonsConstants.EMPTY;
        this.logradouro = CommonsConstants.EMPTY;
        this.numero = CommonsConstants.EMPTY;
        this.complemento = CommonsConstants.EMPTY;
        this.bairro = CommonsConstants.EMPTY;
        this.cep = CommonsConstants.EMPTY;
        this.cidade = CommonsConstants.EMPTY;
        this.statusOrdem = CommonsConstants.EMPTY;
        this.tecnologia = CommonsConstants.EMPTY;
        this.formaPagamento = CommonsConstants.EMPTY;
        this.tipoConta = CommonsConstants.EMPTY;
        this.codBanco = CommonsConstants.EMPTY;
        this.codAgenciaBanco = CommonsConstants.EMPTY;
        this.codContaCorrente = CommonsConstants.EMPTY;
        this.codDebitoAutomatico = CommonsConstants.EMPTY;
        this.diaVencimento = CommonsConstants.EMPTY;
        this.semanaVenda = CommonsConstants.EMPTY;
        this.score = CommonsConstants.EMPTY;
        this.scoreConsumido = CommonsConstants.EMPTY;
        this.datFinalizacaoOrdem = CommonsConstants.EMPTY;
        this.qtdContratos = CommonsConstants.EMPTY;
        this.numProtocolo = CommonsConstants.EMPTY;
        this.flgOrdemAutomatica = CommonsConstants.EMPTY;
        this.dscTxRecorrente = CommonsConstants.EMPTY;
        this.dscTxNaoRecorrente = CommonsConstants.EMPTY;
        this.dscStatusItem = CommonsConstants.EMPTY;
        this.nomLoginResponsavel = CommonsConstants.EMPTY;
        this.flgPortabilidade = CommonsConstants.EMPTY;
        this.dscOperadoraDoadora = CommonsConstants.EMPTY;
        this.codDdd = CommonsConstants.EMPTY;
        this.numTelefonePortado = CommonsConstants.EMPTY;
        this.datJanelaPortabilidade = CommonsConstants.EMPTY;
        this.horJanela = CommonsConstants.EMPTY;
        this.dscEnderecoFatura = CommonsConstants.EMPTY;
        this.dscAreaVoip = CommonsConstants.EMPTY;
        this.cpe = CommonsConstants.EMPTY;
        this.ont = CommonsConstants.EMPTY;
        this.detalheRecusaCrivo = CommonsConstants.EMPTY;
        this.itemRoot = CommonsConstants.EMPTY;
        this.loginCancelamentoOrdem = CommonsConstants.EMPTY;
        this.dominioRoot = CommonsConstants.EMPTY;
        this.codContaFinanceira = CommonsConstants.EMPTY;
        this.nomPlanoAtual = CommonsConstants.EMPTY;
        this.valPlanoAtualItem = CommonsConstants.EMPTY;
        this.nomDescontoAtualItem = CommonsConstants.EMPTY;
        this.valDescontoAtualItem = CommonsConstants.EMPTY;
        this.nroOrdem = CommonsConstants.EMPTY;
        this.acessoRowId = CommonsConstants.EMPTY;
        this.acessoRowIdRoot = CommonsConstants.EMPTY;
        this.codigoProduto = CommonsConstants.EMPTY;
        this.datVendaOrig = CommonsConstants.EMPTY;
        this.horVendaOrig = CommonsConstants.EMPTY;
        this.numOrdemSiebelOrig = CommonsConstants.EMPTY;
        this.loginVendedorOrig = CommonsConstants.EMPTY;
        this.canalOrig = CommonsConstants.EMPTY;
        this.cnpjParceiroOrig = CommonsConstants.EMPTY;
        this.custCodeOrig = CommonsConstants.EMPTY;
        this.positionOrig = CommonsConstants.EMPTY;
        this.flgVendaSubmetida = CommonsConstants.EMPTY;
        this.flgVendaDuplicada = CommonsConstants.EMPTY;
        this.flgVendaBruta = CommonsConstants.EMPTY;
        this.flgVendaLiquida = CommonsConstants.EMPTY;
        this.flgCancDupl = CommonsConstants.EMPTY;
        this.flgCancLiquido = CommonsConstants.EMPTY;
        this.semanaVendaOrig = CommonsConstants.EMPTY;
        this.nomeParceiroVenda = CommonsConstants.EMPTY;
        this.nomeParceiroVendaOrig = CommonsConstants.EMPTY;
        this.rowIdDoItemDaOrdem = CommonsConstants.EMPTY;
        this.rowIdDoItemDaOrdemPai = CommonsConstants.EMPTY;
        this.categoriaItemOrdem = CommonsConstants.EMPTY;

		
	}
	
	public void clearWfmtoa() {
		this.msan_olt_venda = "";
		this.dt_conclusao_wfm = "";
		this.dscStatusOrdemWfm = "";
		this.datStatusWfm = "";
		this.horaStatusWfm = "";
		this.idRecursoWfm = "";
		this.nomRecursoWfm = "";
		this.idRecursoPaiWfm = "";
		this.datPrimeiroAgend = "";
		this.horaPrimeiroAgendamento = "";
		this.datAgendAtual = "";
		this.horaAgendamentoAtual = "";
		this.dscStatusAtivacao = "";
	}
	
	
	
	public void clear(){
		this.datRef = CommonsConstants.EMPTY;
        this.datCriacaoOrdem = CommonsConstants.EMPTY;
        this.horCriacaoOrdem = CommonsConstants.EMPTY;
        this.datVenda = CommonsConstants.EMPTY;
        this.horaVenda = CommonsConstants.EMPTY;
        this.datStatusOrdem = CommonsConstants.EMPTY;
        this.horStatusOrdem = CommonsConstants.EMPTY;
        this.numOrdemSiebel = CommonsConstants.EMPTY;
        this.codContratoOltp = CommonsConstants.EMPTY;
        this.codContratoAtivacao = CommonsConstants.EMPTY;
        this.numeroAcesso = CommonsConstants.EMPTY;
        this.customerId = CommonsConstants.EMPTY;
        this.tipoDocumento = CommonsConstants.EMPTY;
        this.documento = CommonsConstants.EMPTY;
        this.tipoVenda = CommonsConstants.EMPTY;
        this.tipoProduto = CommonsConstants.EMPTY;
        this.planoAtivacaoOferta = CommonsConstants.EMPTY;
        this.loginVendedor = CommonsConstants.EMPTY;
        this.canal = CommonsConstants.EMPTY;
        this.cnpjParceiro = CommonsConstants.EMPTY;
        this.custCode = CommonsConstants.EMPTY;
        this.position = CommonsConstants.EMPTY;
        this.flgCancAntesVenda = CommonsConstants.EMPTY;
        this.flgCancPosVenda = CommonsConstants.EMPTY;
        this.datCancVenda = CommonsConstants.EMPTY;
        this.motivoCancelamento = CommonsConstants.EMPTY;
        this.nomeCliente = CommonsConstants.EMPTY;
        this.telefone = CommonsConstants.EMPTY;
        this.email = CommonsConstants.EMPTY;
        this.uf = CommonsConstants.EMPTY;
        this.tipoLogradouro = CommonsConstants.EMPTY;
        this.logradouro = CommonsConstants.EMPTY;
        this.numero = CommonsConstants.EMPTY;
        this.complemento = CommonsConstants.EMPTY;
        this.bairro = CommonsConstants.EMPTY;
        this.cep = CommonsConstants.EMPTY;
        this.cidade = CommonsConstants.EMPTY;
        this.statusOrdem = CommonsConstants.EMPTY;
        this.tecnologia = CommonsConstants.EMPTY;
        this.formaPagamento = CommonsConstants.EMPTY;
        this.tipoConta = CommonsConstants.EMPTY;
        this.codBanco = CommonsConstants.EMPTY;
        this.codAgenciaBanco = CommonsConstants.EMPTY;
        this.codContaCorrente = CommonsConstants.EMPTY;
        this.codDebitoAutomatico = CommonsConstants.EMPTY;
        this.diaVencimento = CommonsConstants.EMPTY;
        this.semanaVenda = CommonsConstants.EMPTY;
        this.score = CommonsConstants.EMPTY;
        this.scoreConsumido = CommonsConstants.EMPTY;
        this.datFinalizacaoOrdem = CommonsConstants.EMPTY;
        this.qtdContratos = CommonsConstants.EMPTY;
        this.numProtocolo = CommonsConstants.EMPTY;
        this.flgOrdemAutomatica = CommonsConstants.EMPTY;
        this.dscTxRecorrente = CommonsConstants.EMPTY;
        this.dscTxNaoRecorrente = CommonsConstants.EMPTY;
        this.dscStatusItem = CommonsConstants.EMPTY;
        this.nomLoginResponsavel = CommonsConstants.EMPTY;
        this.flgPortabilidade = CommonsConstants.EMPTY;
        this.dscOperadoraDoadora = CommonsConstants.EMPTY;
        this.codDdd = CommonsConstants.EMPTY;
        this.numTelefonePortado = CommonsConstants.EMPTY;
        this.datJanelaPortabilidade = CommonsConstants.EMPTY;
        this.horJanela = CommonsConstants.EMPTY;
        this.dscEnderecoFatura = CommonsConstants.EMPTY;
        this.dscAreaVoip = CommonsConstants.EMPTY;
        this.cpe = CommonsConstants.EMPTY;
        this.ont = CommonsConstants.EMPTY;
        this.detalheRecusaCrivo = CommonsConstants.EMPTY;
        this.itemRoot = CommonsConstants.EMPTY;
        this.loginCancelamentoOrdem = CommonsConstants.EMPTY;
        this.dominioRoot = CommonsConstants.EMPTY;
        this.codContaFinanceira = CommonsConstants.EMPTY;
        this.nomPlanoAtual = CommonsConstants.EMPTY;
        this.valPlanoAtualItem = CommonsConstants.EMPTY;
        this.nomDescontoAtualItem = CommonsConstants.EMPTY;
        this.valDescontoAtualItem = CommonsConstants.EMPTY;
        this.nroOrdem = CommonsConstants.EMPTY;
        this.acessoRowId = CommonsConstants.EMPTY;
        this.acessoRowIdRoot = CommonsConstants.EMPTY;
        this.codigoProduto = CommonsConstants.EMPTY;
        this.datVendaOrig = CommonsConstants.EMPTY;
        this.horVendaOrig = CommonsConstants.EMPTY;
        this.numOrdemSiebelOrig = CommonsConstants.EMPTY;
        this.loginVendedorOrig = CommonsConstants.EMPTY;
        this.canalOrig = CommonsConstants.EMPTY;
        this.cnpjParceiroOrig = CommonsConstants.EMPTY;
        this.custCodeOrig = CommonsConstants.EMPTY;
        this.positionOrig = CommonsConstants.EMPTY;
        this.flgVendaSubmetida = CommonsConstants.EMPTY;
        this.flgVendaDuplicada = CommonsConstants.EMPTY;
        this.flgVendaBruta = CommonsConstants.EMPTY;
        this.flgVendaLiquida = CommonsConstants.EMPTY;
        this.flgCancDupl = CommonsConstants.EMPTY;
        this.flgCancLiquido = CommonsConstants.EMPTY;
        this.semanaVendaOrig = CommonsConstants.EMPTY;
        this.nomeParceiroVenda = CommonsConstants.EMPTY;
        this.nomeParceiroVendaOrig = CommonsConstants.EMPTY;
        this.rowIdDoItemDaOrdem = CommonsConstants.EMPTY;
        this.rowIdDoItemDaOrdemPai = CommonsConstants.EMPTY;
        this.categoriaItemOrdem = CommonsConstants.EMPTY;
        this.msan_olt_venda = CommonsConstants.EMPTY;
        this.dt_conclusao_wfm = CommonsConstants.EMPTY;
        this.dscStatusOrdemWfm = CommonsConstants.EMPTY;
        this.datStatusWfm = CommonsConstants.EMPTY;
        this.horaStatusWfm = CommonsConstants.EMPTY;
        this.idRecursoWfm = CommonsConstants.EMPTY;
        this.nomRecursoWfm = CommonsConstants.EMPTY;
        this.idRecursoPaiWfm = CommonsConstants.EMPTY;
        this.datPrimeiroAgend = CommonsConstants.EMPTY;
        this.horaPrimeiroAgendamento = CommonsConstants.EMPTY;
        this.datAgendAtual = CommonsConstants.EMPTY;
        this.horaAgendamentoAtual = CommonsConstants.EMPTY;
        this.dscStatusAtivacao = CommonsConstants.EMPTY;
	}



	public String getDatRef() {
		return datRef;
	}

	public void setDatRef(String datRef) {
		this.datRef = datRef;
	}

	public String getDatCriacaoOrdem() {
		return datCriacaoOrdem;
	}

	public void setDatCriacaoOrdem(String datCriacaoOrdem) {
		this.datCriacaoOrdem = datCriacaoOrdem;
	}

	public String getHorCriacaoOrdem() {
		return horCriacaoOrdem;
	}

	public void setHorCriacaoOrdem(String horCriacaoOrdem) {
		this.horCriacaoOrdem = horCriacaoOrdem;
	}

	public String getDatVenda() {
		return datVenda;
	}

	public void setDatVenda(String datVenda) {
		this.datVenda = datVenda;
	}

	public String getHoraVenda() {
		return horaVenda;
	}

	public void setHoraVenda(String horaVenda) {
		this.horaVenda = horaVenda;
	}

	public String getDatStatusOrdem() {
		return datStatusOrdem;
	}

	public void setDatStatusOrdem(String datStatusOrdem) {
		this.datStatusOrdem = datStatusOrdem;
	}

	public String getHorStatusOrdem() {
		return horStatusOrdem;
	}

	public void setHorStatusOrdem(String horStatusOrdem) {
		this.horStatusOrdem = horStatusOrdem;
	}

	public String getCodContratoOltp() {
		return codContratoOltp;
	}

	public void setCodContratoOltp(String codContratoOltp) {
		this.codContratoOltp = codContratoOltp;
	}

	public String getCodContratoAtivacao() {
		return codContratoAtivacao;
	}

	public void setCodContratoAtivacao(String codContratoAtivacao) {
		this.codContratoAtivacao = codContratoAtivacao;
	}

	public String getNumeroAcesso() {
		return numeroAcesso;
	}

	public void setNumeroAcesso(String numeroAcesso) {
		this.numeroAcesso = numeroAcesso;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public String getDocumento() {
		return documento;
	}

	public void setDocumento(String documento) {
		this.documento = documento;
	}

	public String getTipoVenda() {
		return tipoVenda;
	}

	public void setTipoVenda(String tipoVenda) {
		this.tipoVenda = tipoVenda;
	}

	public String getTipoProduto() {
		return tipoProduto;
	}

	public void setTipoProduto(String tipoProduto) {
		this.tipoProduto = tipoProduto;
	}

	public String getPlanoAtivacaoOferta() {
		return planoAtivacaoOferta;
	}

	public void setPlanoAtivacaoOferta(String planoAtivacaoOferta) {
		this.planoAtivacaoOferta = planoAtivacaoOferta;
	}

	public String getLoginVendedor() {
		return loginVendedor;
	}

	public void setLoginVendedor(String loginVendedor) {
		this.loginVendedor = loginVendedor;
	}

	public String getCanal() {
		return canal;
	}

	public void setCanal(String canal) {
		this.canal = canal;
	}

	public String getCnpjParceiro() {
		return cnpjParceiro;
	}

	public void setCnpjParceiro(String cnpjParceiro) {
		this.cnpjParceiro = cnpjParceiro;
	}

	public String getCustCode() {
		return custCode;
	}

	public void setCustCode(String custCode) {
		this.custCode = custCode;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getFlgCancAntesVenda() {
		return flgCancAntesVenda;
	}

	public void setFlgCancAntesVenda(String flgCancAntesVenda) {
		this.flgCancAntesVenda = flgCancAntesVenda;
	}

	public String getFlgCancPosVenda() {
		return flgCancPosVenda;
	}

	public void setFlgCancPosVenda(String flgCancPosVenda) {
		this.flgCancPosVenda = flgCancPosVenda;
	}

	public String getDatCancVenda() {
		return datCancVenda;
	}

	public void setDatCancVenda(String datCancVenda) {
		this.datCancVenda = datCancVenda;
	}

	public String getMotivoCancelamento() {
		return motivoCancelamento;
	}

	public void setMotivoCancelamento(String motivoCancelamento) {
		this.motivoCancelamento = motivoCancelamento;
	}

	public String getNomeCliente() {
		return nomeCliente;
	}

	public void setNomeCliente(String nomeCliente) {
		this.nomeCliente = nomeCliente;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	public String getTipoLogradouro() {
		return tipoLogradouro;
	}

	public void setTipoLogradouro(String tipoLogradouro) {
		this.tipoLogradouro = tipoLogradouro;
	}

	public String getLogradouro() {
		return logradouro;
	}

	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getComplemento() {
		return complemento;
	}

	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getStatusOrdem() {
		return statusOrdem;
	}

	public void setStatusOrdem(String statusOrdem) {
		this.statusOrdem = statusOrdem;
	}

	public String getTecnologia() {
		return tecnologia;
	}

	public void setTecnologia(String tecnologia) {
		this.tecnologia = tecnologia;
	}

	public String getFormaPagamento() {
		return formaPagamento;
	}

	public void setFormaPagamento(String formaPagamento) {
		this.formaPagamento = formaPagamento;
	}

	public String getTipoConta() {
		return tipoConta;
	}

	public void setTipoConta(String tipoConta) {
		this.tipoConta = tipoConta;
	}

	public String getCodBanco() {
		return codBanco;
	}

	public void setCodBanco(String codBanco) {
		this.codBanco = codBanco;
	}

	public String getCodAgenciaBanco() {
		return codAgenciaBanco;
	}

	public void setCodAgenciaBanco(String codAgenciaBanco) {
		this.codAgenciaBanco = codAgenciaBanco;
	}

	public String getCodContaCorrente() {
		return codContaCorrente;
	}

	public void setCodContaCorrente(String codContaCorrente) {
		this.codContaCorrente = codContaCorrente;
	}

	public String getCodDebitoAutomatico() {
		return codDebitoAutomatico;
	}

	public void setCodDebitoAutomatico(String codDebitoAutomatico) {
		this.codDebitoAutomatico = codDebitoAutomatico;
	}

	public String getDiaVencimento() {
		return diaVencimento;
	}

	public void setDiaVencimento(String diaVencimento) {
		this.diaVencimento = diaVencimento;
	}

	public String getSemanaVenda() {
		return semanaVenda;
	}

	public void setSemanaVenda(String semanaVenda) {
		this.semanaVenda = semanaVenda;
	}

	public String getScore() {
		return score;
	}

	public void setScore(String score) {
		this.score = score;
	}

	public String getScoreConsumido() {
		return scoreConsumido;
	}

	public void setScoreConsumido(String scoreConsumido) {
		this.scoreConsumido = scoreConsumido;
	}

	public String getDatFinalizacaoOrdem() {
		return datFinalizacaoOrdem;
	}

	public void setDatFinalizacaoOrdem(String datFinalizacaoOrdem) {
		this.datFinalizacaoOrdem = datFinalizacaoOrdem;
	}

	public String getQtdContratos() {
		return qtdContratos;
	}

	public void setQtdContratos(String qtdContratos) {
		this.qtdContratos = qtdContratos;
	}

	public String getNumProtocolo() {
		return numProtocolo;
	}

	public void setNumProtocolo(String numProtocolo) {
		this.numProtocolo = numProtocolo;
	}

	public String getFlgOrdemAutomatica() {
		return flgOrdemAutomatica;
	}

	public void setFlgOrdemAutomatica(String flgOrdemAutomatica) {
		this.flgOrdemAutomatica = flgOrdemAutomatica;
	}

	public String getDscTxRecorrente() {
		return dscTxRecorrente;
	}

	public void setDscTxRecorrente(String dscTxRecorrente) {
		this.dscTxRecorrente = dscTxRecorrente;
	}

	public String getDscTxNaoRecorrente() {
		return dscTxNaoRecorrente;
	}

	public void setDscTxNaoRecorrente(String dscTxNaoRecorrente) {
		this.dscTxNaoRecorrente = dscTxNaoRecorrente;
	}

	public String getDscStatusItem() {
		return dscStatusItem;
	}

	public void setDscStatusItem(String dscStatusItem) {
		this.dscStatusItem = dscStatusItem;
	}

	public String getNomLoginResponsavel() {
		return nomLoginResponsavel;
	}

	public void setNomLoginResponsavel(String nomLoginResponsavel) {
		this.nomLoginResponsavel = nomLoginResponsavel;
	}

	public String getFlgPortabilidade() {
		return flgPortabilidade;
	}

	public void setFlgPortabilidade(String flgPortabilidade) {
		this.flgPortabilidade = flgPortabilidade;
	}

	public String getDscOperadoraDoadora() {
		return dscOperadoraDoadora;
	}

	public void setDscOperadoraDoadora(String dscOperadoraDoadora) {
		this.dscOperadoraDoadora = dscOperadoraDoadora;
	}

	public String getCodDdd() {
		return codDdd;
	}

	public void setCodDdd(String codDdd) {
		this.codDdd = codDdd;
	}

	public String getNumTelefonePortado() {
		return numTelefonePortado;
	}

	public void setNumTelefonePortado(String numTelefonePortado) {
		this.numTelefonePortado = numTelefonePortado;
	}

	public String getDatJanelaPortabilidade() {
		return datJanelaPortabilidade;
	}

	public void setDatJanelaPortabilidade(String datJanelaPortabilidade) {
		this.datJanelaPortabilidade = datJanelaPortabilidade;
	}

	public String getHorJanela() {
		return horJanela;
	}

	public void setHorJanela(String horJanela) {
		this.horJanela = horJanela;
	}

	public String getDscEnderecoFatura() {
		return dscEnderecoFatura;
	}

	public void setDscEnderecoFatura(String dscEnderecoFatura) {
		this.dscEnderecoFatura = dscEnderecoFatura;
	}

	public String getDscAreaVoip() {
		return dscAreaVoip;
	}

	public void setDscAreaVoip(String dscAreaVoip) {
		this.dscAreaVoip = dscAreaVoip;
	}

	public String getCpe() {
		return cpe;
	}

	public void setCpe(String cpe) {
		this.cpe = cpe;
	}

	public String getOnt() {
		return ont;
	}

	public void setOnt(String ont) {
		this.ont = ont;
	}

	public String getDetalheRecusaCrivo() {
		return detalheRecusaCrivo;
	}

	public void setDetalheRecusaCrivo(String detalheRecusaCrivo) {
		this.detalheRecusaCrivo = detalheRecusaCrivo;
	}

	public String getItemRoot() {
		return itemRoot;
	}

	public void setItemRoot(String itemRoot) {
		this.itemRoot = itemRoot;
	}

	public String getLoginCancelamentoOrdem() {
		return loginCancelamentoOrdem;
	}

	public void setLoginCancelamentoOrdem(String loginCancelamentoOrdem) {
		this.loginCancelamentoOrdem = loginCancelamentoOrdem;
	}

	public String getDominioRoot() {
		return dominioRoot;
	}

	public void setDominioRoot(String dominioRoot) {
		this.dominioRoot = dominioRoot;
	}

	public String getCodContaFinanceira() {
		return codContaFinanceira;
	}

	public void setCodContaFinanceira(String codContaFinanceira) {
		this.codContaFinanceira = codContaFinanceira;
	}

	public String getNomPlanoAtual() {
		return nomPlanoAtual;
	}

	public void setNomPlanoAtual(String nomPlanoAtual) {
		this.nomPlanoAtual = nomPlanoAtual;
	}

	public String getValPlanoAtualItem() {
		return valPlanoAtualItem;
	}

	public void setValPlanoAtualItem(String valPlanoAtualItem) {
		this.valPlanoAtualItem = valPlanoAtualItem;
	}

	public String getNomDescontoAtualItem() {
		return nomDescontoAtualItem;
	}

	public void setNomDescontoAtualItem(String nomDescontoAtualItem) {
		this.nomDescontoAtualItem = nomDescontoAtualItem;
	}

	public String getValDescontoAtualItem() {
		return valDescontoAtualItem;
	}

	public void setValDescontoAtualItem(String valDescontoAtualItem) {
		this.valDescontoAtualItem = valDescontoAtualItem;
	}

	public String getNroOrdem() {
		return nroOrdem;
	}

	public void setNroOrdem(String nroOrdem) {
		this.nroOrdem = nroOrdem;
	}

	public String getAcessoRowId() {
		return acessoRowId;
	}

	public void setAcessoRowId(String acessoRowId) {
		this.acessoRowId = acessoRowId;
	}

	public String getAcessoRowIdRoot() {
		return acessoRowIdRoot;
	}

	public void setAcessoRowIdRoot(String acessoRowIdRoot) {
		this.acessoRowIdRoot = acessoRowIdRoot;
	}

	public String getCodigoProduto() {
		return codigoProduto;
	}

	public void setCodigoProduto(String codigoProduto) {
		this.codigoProduto = codigoProduto;
	}

	public String getDatVendaOrig() {
		return datVendaOrig;
	}

	public void setDatVendaOrig(String datVendaOrig) {
		this.datVendaOrig = datVendaOrig;
	}

	public String getHorVendaOrig() {
		return horVendaOrig;
	}

	public void setHorVendaOrig(String horVendaOrig) {
		this.horVendaOrig = horVendaOrig;
	}

	public String getNumOrdemSiebelOrig() {
		return numOrdemSiebelOrig;
	}

	public void setNumOrdemSiebelOrig(String numOrdemSiebelOrig) {
		this.numOrdemSiebelOrig = numOrdemSiebelOrig;
	}

	public String getLoginVendedorOrig() {
		return loginVendedorOrig;
	}

	public void setLoginVendedorOrig(String loginVendedorOrig) {
		this.loginVendedorOrig = loginVendedorOrig;
	}

	public String getCanalOrig() {
		return canalOrig;
	}

	public void setCanalOrig(String canalOrig) {
		this.canalOrig = canalOrig;
	}

	public String getCnpjParceiroOrig() {
		return cnpjParceiroOrig;
	}

	public void setCnpjParceiroOrig(String cnpjParceiroOrig) {
		this.cnpjParceiroOrig = cnpjParceiroOrig;
	}

	public String getCustCodeOrig() {
		return custCodeOrig;
	}

	public void setCustCodeOrig(String custCodeOrig) {
		this.custCodeOrig = custCodeOrig;
	}

	public String getPositionOrig() {
		return positionOrig;
	}

	public void setPositionOrig(String positionOrig) {
		this.positionOrig = positionOrig;
	}

	public String getFlgVendaSubmetida() {
		return flgVendaSubmetida;
	}

	public void setFlgVendaSubmetida(String flgVendaSubmetida) {
		this.flgVendaSubmetida = flgVendaSubmetida;
	}

	public String getFlgVendaDuplicada() {
		return flgVendaDuplicada;
	}

	public void setFlgVendaDuplicada(String flgVendaDuplicada) {
		this.flgVendaDuplicada = flgVendaDuplicada;
	}

	public String getFlgVendaBruta() {
		return flgVendaBruta;
	}

	public void setFlgVendaBruta(String flgVendaBruta) {
		this.flgVendaBruta = flgVendaBruta;
	}

	public String getFlgVendaLiquida() {
		return flgVendaLiquida;
	}

	public void setFlgVendaLiquida(String flgVendaLiquida) {
		this.flgVendaLiquida = flgVendaLiquida;
	}

	public String getFlgCancDupl() {
		return flgCancDupl;
	}

	public void setFlgCancDupl(String flgCancDupl) {
		this.flgCancDupl = flgCancDupl;
	}

	public String getFlgCancLiquido() {
		return flgCancLiquido;
	}

	public void setFlgCancLiquido(String flgCancLiquido) {
		this.flgCancLiquido = flgCancLiquido;
	}

	public String getSemanaVendaOrig() {
		return semanaVendaOrig;
	}

	public void setSemanaVendaOrig(String semanaVendaOrig) {
		this.semanaVendaOrig = semanaVendaOrig;
	}

	public String getNomeParceiroVenda() {
		return nomeParceiroVenda;
	}

	public void setNomeParceiroVenda(String nomeParceiroVenda) {
		this.nomeParceiroVenda = nomeParceiroVenda;
	}

	public String getNomeParceiroVendaOrig() {
		return nomeParceiroVendaOrig;
	}

	public void setNomeParceiroVendaOrig(String nomeParceiroVendaOrig) {
		this.nomeParceiroVendaOrig = nomeParceiroVendaOrig;
	}

	public String getRowIdDoItemDaOrdem() {
		return rowIdDoItemDaOrdem;
	}

	public void setRowIdDoItemDaOrdem(String rowIdDoItemDaOrdem) {
		this.rowIdDoItemDaOrdem = rowIdDoItemDaOrdem;
	}

	public String getRowIdDoItemDaOrdemPai() {
		return rowIdDoItemDaOrdemPai;
	}

	public void setRowIdDoItemDaOrdemPai(String rowIdDoItemDaOrdemPai) {
		this.rowIdDoItemDaOrdemPai = rowIdDoItemDaOrdemPai;
	}

	public String getCategoriaItemOrdem() {
		return categoriaItemOrdem;
	}

	public void setCategoriaItemOrdem(String categoriaItemOrdem) {
		this.categoriaItemOrdem = categoriaItemOrdem;
	}

	public String getMsan_olt_venda() {
		return msan_olt_venda;
	}

	public void setMsan_olt_venda(String msan_olt_venda) {
		this.msan_olt_venda = msan_olt_venda;
	}

	public String getDt_conclusao_wfm() {
		return dt_conclusao_wfm;
	}

	public void setDt_conclusao_wfm(String dt_conclusao_wfm) {
		this.dt_conclusao_wfm = dt_conclusao_wfm;
	}

	public String getDscStatusOrdemWfm() {
		return dscStatusOrdemWfm;
	}

	public void setDscStatusOrdemWfm(String dscStatusOrdemWfm) {
		this.dscStatusOrdemWfm = dscStatusOrdemWfm;
	}

	public String getDatStatusWfm() {
		return datStatusWfm;
	}

	public void setDatStatusWfm(String datStatusWfm) {
		this.datStatusWfm = datStatusWfm;
	}

	public String getHoraStatusWfm() {
		return horaStatusWfm;
	}

	public void setHoraStatusWfm(String horaStatusWfm) {
		this.horaStatusWfm = horaStatusWfm;
	}

	public String getIdRecursoWfm() {
		return idRecursoWfm;
	}

	public void setIdRecursoWfm(String idRecursoWfm) {
		this.idRecursoWfm = idRecursoWfm;
	}

	public String getNomRecursoWfm() {
		return nomRecursoWfm;
	}

	public void setNomRecursoWfm(String nomRecursoWfm) {
		this.nomRecursoWfm = nomRecursoWfm;
	}

	public String getIdRecursoPaiWfm() {
		return idRecursoPaiWfm;
	}

	public void setIdRecursoPaiWfm(String idRecursoPaiWfm) {
		this.idRecursoPaiWfm = idRecursoPaiWfm;
	}

	public String getDatPrimeiroAgend() {
		return datPrimeiroAgend;
	}

	public void setDatPrimeiroAgend(String datPrimeiroAgend) {
		this.datPrimeiroAgend = datPrimeiroAgend;
	}

	public String getHoraPrimeiroAgendamento() {
		return horaPrimeiroAgendamento;
	}

	public void setHoraPrimeiroAgendamento(String horaPrimeiroAgendamento) {
		this.horaPrimeiroAgendamento = horaPrimeiroAgendamento;
	}

	public String getDatAgendAtual() {
		return datAgendAtual;
	}

	public void setDatAgendAtual(String datAgendAtual) {
		this.datAgendAtual = datAgendAtual;
	}

	public String getHoraAgendamentoAtual() {
		return horaAgendamentoAtual;
	}

	public void setHoraAgendamentoAtual(String horaAgendamentoAtual) {
		this.horaAgendamentoAtual = horaAgendamentoAtual;
	}

	public String getDscStatusAtivacao() {
		return dscStatusAtivacao;
	}

	public void setDscStatusAtivacao(String dscStatusAtivacao) {
		this.dscStatusAtivacao = dscStatusAtivacao;
	}

	@Override
	public String toString(){
		
		StringBuffer sb = new StringBuffer();
		sb.setLength(0);
		sb.append(this.datRef).append(DELIMITER);
		sb.append(this.datCriacaoOrdem).append(DELIMITER);
		sb.append(this.horCriacaoOrdem).append(DELIMITER);
		sb.append(this.datVenda).append(DELIMITER);
		sb.append(this.horaVenda).append(DELIMITER);
		sb.append(this.datStatusOrdem).append(DELIMITER);
		sb.append(this.horStatusOrdem).append(DELIMITER);
		sb.append(this.numOrdemSiebel).append(DELIMITER);
		sb.append(this.codContratoOltp).append(DELIMITER);
		sb.append(this.codContratoAtivacao).append(DELIMITER);
		sb.append(this.numeroAcesso).append(DELIMITER);
		sb.append(this.customerId).append(DELIMITER);
		sb.append(this.tipoDocumento).append(DELIMITER);
		sb.append(this.documento).append(DELIMITER);
		sb.append(this.tipoVenda).append(DELIMITER);
		sb.append(this.tipoProduto).append(DELIMITER);
		sb.append(this.planoAtivacaoOferta).append(DELIMITER);
		sb.append(this.loginVendedor).append(DELIMITER);
		sb.append(this.canal).append(DELIMITER);
		sb.append(this.cnpjParceiro).append(DELIMITER);
		sb.append(this.custCode).append(DELIMITER);
		sb.append(this.position).append(DELIMITER);
		sb.append(this.flgCancAntesVenda).append(DELIMITER);
		sb.append(this.flgCancPosVenda).append(DELIMITER);
		sb.append(this.datCancVenda).append(DELIMITER);
		sb.append(this.motivoCancelamento).append(DELIMITER);
		sb.append(this.nomeCliente).append(DELIMITER);
		sb.append(this.telefone).append(DELIMITER);
		sb.append(this.email).append(DELIMITER);
		sb.append(this.uf).append(DELIMITER);
		sb.append(this.tipoLogradouro).append(DELIMITER);
		sb.append(this.logradouro).append(DELIMITER);
		sb.append(this.numero).append(DELIMITER);
		sb.append(this.complemento).append(DELIMITER);
		sb.append(this.bairro).append(DELIMITER);
		sb.append(this.cep).append(DELIMITER);
		sb.append(this.cidade).append(DELIMITER);
		sb.append(this.statusOrdem).append(DELIMITER);
		sb.append(this.tecnologia).append(DELIMITER);
		sb.append(this.formaPagamento).append(DELIMITER);
		sb.append(this.tipoConta).append(DELIMITER);
		sb.append(this.codBanco).append(DELIMITER);
		sb.append(this.codAgenciaBanco).append(DELIMITER);
		sb.append(this.codContaCorrente).append(DELIMITER);
		sb.append(this.codDebitoAutomatico).append(DELIMITER);
		sb.append(this.diaVencimento).append(DELIMITER);
		sb.append(this.semanaVenda).append(DELIMITER);
		sb.append(this.score).append(DELIMITER);
		sb.append(this.scoreConsumido).append(DELIMITER);
		sb.append(this.datFinalizacaoOrdem).append(DELIMITER);
		sb.append(this.qtdContratos).append(DELIMITER);
		sb.append(this.numProtocolo).append(DELIMITER);
		sb.append(this.flgOrdemAutomatica).append(DELIMITER);
		sb.append(this.dscTxRecorrente).append(DELIMITER);
		sb.append(this.dscTxNaoRecorrente).append(DELIMITER);
		sb.append(this.dscStatusItem).append(DELIMITER);
		sb.append(this.nomLoginResponsavel).append(DELIMITER);
		sb.append(this.flgPortabilidade).append(DELIMITER);
		sb.append(this.dscOperadoraDoadora).append(DELIMITER);
		sb.append(this.codDdd).append(DELIMITER);
		sb.append(this.numTelefonePortado).append(DELIMITER);
		sb.append(this.datJanelaPortabilidade).append(DELIMITER);
		sb.append(this.horJanela).append(DELIMITER);
		sb.append(this.dscEnderecoFatura).append(DELIMITER);
		sb.append(this.dscAreaVoip).append(DELIMITER);
		sb.append(this.cpe).append(DELIMITER);
		sb.append(this.ont).append(DELIMITER);
		sb.append(this.detalheRecusaCrivo).append(DELIMITER);
		sb.append(this.itemRoot).append(DELIMITER);
		sb.append(this.loginCancelamentoOrdem).append(DELIMITER);
		sb.append(this.dominioRoot).append(DELIMITER);
		sb.append(this.codContaFinanceira).append(DELIMITER);
		sb.append(this.nomPlanoAtual).append(DELIMITER);
		sb.append(this.valPlanoAtualItem).append(DELIMITER);
		sb.append(this.nomDescontoAtualItem).append(DELIMITER);
		sb.append(this.valDescontoAtualItem).append(DELIMITER);
		sb.append(this.nroOrdem).append(DELIMITER);
		sb.append(this.acessoRowId).append(DELIMITER);
		sb.append(this.acessoRowIdRoot).append(DELIMITER);
		sb.append(this.codigoProduto).append(DELIMITER);
		sb.append(this.datVendaOrig).append(DELIMITER);
		sb.append(this.horVendaOrig).append(DELIMITER);
		sb.append(this.numOrdemSiebelOrig).append(DELIMITER);
		sb.append(this.loginVendedorOrig).append(DELIMITER);
		sb.append(this.canalOrig).append(DELIMITER);
		sb.append(this.cnpjParceiroOrig).append(DELIMITER);
		sb.append(this.custCodeOrig).append(DELIMITER);
		sb.append(this.positionOrig).append(DELIMITER);
		sb.append(this.flgVendaSubmetida).append(DELIMITER);
		sb.append(this.flgVendaDuplicada).append(DELIMITER);
		sb.append(this.flgVendaBruta).append(DELIMITER);
		sb.append(this.flgVendaLiquida).append(DELIMITER);
		sb.append(this.flgCancDupl).append(DELIMITER);
		sb.append(this.flgCancLiquido).append(DELIMITER);
		sb.append(this.semanaVendaOrig).append(DELIMITER);
		sb.append(this.nomeParceiroVenda).append(DELIMITER);
		sb.append(this.nomeParceiroVendaOrig).append(DELIMITER);
		sb.append(this.rowIdDoItemDaOrdem).append(DELIMITER);
		sb.append(this.rowIdDoItemDaOrdemPai).append(DELIMITER);
		sb.append(this.categoriaItemOrdem).append(DELIMITER);
		sb.append(this.msan_olt_venda).append(DELIMITER);
		sb.append(this.dt_conclusao_wfm).append(DELIMITER);
		sb.append(this.dscStatusOrdemWfm).append(DELIMITER);
		sb.append(this.datStatusWfm).append(DELIMITER);
		sb.append(this.horaStatusWfm).append(DELIMITER);
		sb.append(this.idRecursoWfm).append(DELIMITER);
		sb.append(this.nomRecursoWfm).append(DELIMITER);
		sb.append(this.idRecursoPaiWfm).append(DELIMITER);
		sb.append(this.datPrimeiroAgend).append(DELIMITER);
		sb.append(this.horaPrimeiroAgendamento).append(DELIMITER);
		sb.append(this.datAgendAtual).append(DELIMITER);
		sb.append(this.horaAgendamentoAtual).append(DELIMITER);
		sb.append(this.dscStatusAtivacao);
		
		return sb.toString();
	}

	public String getNumOrdemSiebel() {
		return numOrdemSiebel;
	}

	public void setNumOrdemSiebel(String numOrdemSiebel) {
		this.numOrdemSiebel = numOrdemSiebel;
	}
	
}
