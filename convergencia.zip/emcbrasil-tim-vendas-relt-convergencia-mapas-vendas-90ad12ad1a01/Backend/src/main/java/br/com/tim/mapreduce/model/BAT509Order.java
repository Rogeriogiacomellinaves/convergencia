package br.com.tim.mapreduce.model;

import org.apache.commons.lang3.StringUtils;

public class BAT509Order {
    private String rowId;
    private String loteId;
    private String arquivo;
    private String arquivoTs;
    private String currentDate;
    private String numeroOrdem;
    private String numeroCliente;
    private String statusOrdem;
    private String dataCriacaoOrdem;
    private String dataVenda;
    private String dataStatusOrdem;
    private String tipoOrdem;
    private String subTipoOrdem;
    private String flagVendaLiquida;
    private String codigoOrdemOriginal;
    private String dataVendaOriginal;
    private String procurador;
    private String nomeContato;
    private String cpf;
    private String scoreCliente;
    private String scoreConsumido;
    private String saldoScore;
    private String scoreConsumidoOrdem;
    private String totalTaxasRecorrentes;
    private String totalTaxasNaoRecorrentes;
    private String totalTaxas;
    private String numeroContratos;
    private String loginResponsavel;
    private String canalCriacaoOrdem;
    private String loginVendedor;
    private String canalVenda;
    private String cnpjParceiroVenda;
    private String nomeParceiroVenda;
    private String msanReserva;
    private String msanInstalacao;
    private String motivoCancelamentoOrdem;
    private String loginCancelamentoOrdem;
    private String motivoRecusaCrivo;
    private String motivoRecusaSGF;
    private String usuarioLinha;
    private String statusOrdemWFM;
    private String nomeCliente;
    private String codigoContrato;
    private String datafinalizacaoOrdem;
    private String telefoneContato1;
    private String telefoneContato2;
    private String telefoneContato3;
    private String numeroOrdemAMDOCS;
    private String statusAlcada;
    private String dataStatusAlcada;
    private String chaveCrivo;
    private String limiteAparelho;
    private String limiteAparelhoConsumido;
    private String valorAparelhoOrdem;
    private String saldoLimiteAparelho;
    private String custcodePDV;
    private String canalEntrada;
    private String numeroBpTim;
    private String customerId;
    private String campanha;
    private String perfilLogin;
    private String ruaEntrega;
    private String numeroEntrega;
    private String complementoEntrega;
    private String cepEntrega;
    private String bairroEntrega;
    private String estadoEntrega;
    private String cidadeEntrega;
    private String alteracaoEndereco;
    private String pessoaAutorizada1;
    private String pessoaAutorizada2;
    private String pessoaAutorizada3;
    private String idContrato;
    private String matriculaResponsavel;
    private String cpfVendedor;
    private String codDsf;
    private String canal;
    private String regional;
    private String uf;
    private String nomeFantasia;
    private String tipoOrdemOrigem;
    private String ufEnderecoWttx;
    private String cidadeEnderecoWttx;
    private String cepEnderecoWttx;
    private String bairroEnderecoWttx;
    private String tipoLogEnderecoWttx;
    private String logEnderecoWttx;
    private String numLogEnderecoWttx;
    private String complementoLogEnderecoWttx;
    private String flgConvergente;
    private String dscMelhorOferta;
    private String accntId;

    public BAT509Order() {
        this.rowId = null;
        this.loteId = null;
        this.arquivo = null;
        this.arquivoTs = null;
        this.currentDate = null;
        this.numeroOrdem = null;
        this.numeroCliente = null;
        this.statusOrdem = null;
        this.dataCriacaoOrdem = null;
        this.dataVenda = null;
        this.dataStatusOrdem = null;
        this.tipoOrdem = null;
        this.subTipoOrdem = null;
        this.flagVendaLiquida = null;
        this.codigoOrdemOriginal = null;
        this.dataVendaOriginal = null;
        this.procurador = null;
        this.nomeContato = null;
        this.cpf = null;
        this.scoreCliente = null;
        this.scoreConsumido = null;
        this.saldoScore = null;
        this.scoreConsumidoOrdem = null;
        this.totalTaxasRecorrentes = null;
        this.totalTaxasNaoRecorrentes = null;
        this.totalTaxas = null;
        this.numeroContratos = null;
        this.loginResponsavel = null;
        this.canalCriacaoOrdem = null;
        this.loginVendedor = null;
        this.canalVenda = null;
        this.cnpjParceiroVenda = null;
        this.nomeParceiroVenda = null;
        this.msanReserva = null;
        this.msanInstalacao = null;
        this.motivoCancelamentoOrdem = null;
        this.loginCancelamentoOrdem = null;
        this.motivoRecusaCrivo = null;
        this.motivoRecusaSGF = null;
        this.usuarioLinha = null;
        this.statusOrdemWFM = null;
        this.nomeCliente = null;
        this.codigoContrato = null;
        this.datafinalizacaoOrdem = null;
        this.telefoneContato1 = null;
        this.telefoneContato2 = null;
        this.telefoneContato3 = null;
        this.numeroOrdemAMDOCS = null;
        this.statusAlcada = null;
        this.dataStatusAlcada = null;
        this.chaveCrivo = null;
        this.limiteAparelho = null;
        this.limiteAparelhoConsumido = null;
        this.valorAparelhoOrdem = null;
        this.saldoLimiteAparelho = null;
        this.custcodePDV = null;
        this.canalEntrada = null;
        this.numeroBpTim = null;
        this.customerId = null;
        this.campanha = null;
        this.perfilLogin = null;
        this.ruaEntrega = null;
        this.numeroEntrega = null;
        this.complementoEntrega = null;
        this.cepEntrega = null;
        this.bairroEntrega = null;
        this.estadoEntrega = null;
        this.cidadeEntrega = null;
        this.alteracaoEndereco = null;
        this.pessoaAutorizada1 = null;
        this.pessoaAutorizada2 = null;
        this.pessoaAutorizada3 = null;
        this.idContrato = null;
        this.matriculaResponsavel = null;
        this.cpfVendedor = null;
        this.codDsf = null;
        this.canal = null;
        this.regional = null;
        this.uf = null;
        this.nomeFantasia = null;
        this.tipoOrdemOrigem = null;
        this.ufEnderecoWttx = null;
        this.cidadeEnderecoWttx = null;
        this.cepEnderecoWttx = null;
        this.bairroEnderecoWttx = null;
        this.tipoLogEnderecoWttx = null;
        this.logEnderecoWttx = null;
        this.numLogEnderecoWttx = null;
        this.complementoLogEnderecoWttx = null;
        this.flgConvergente = null;
        this.dscMelhorOferta = null;
        this.accntId = null;
    }

    public void setBAT509Order(String rowId, String loteId, String arquivo, String arquivoTs, String currentDate, String numeroOrdem, String numeroCliente, String statusOrdem, String dataCriacaoOrdem, String dataVenda, String dataStatusOrdem, String tipoOrdem, String subTipoOrdem, String flagVendaLiquida, String codigoOrdemOriginal, String dataVendaOriginal, String procurador, String nomeContato, String cpf, String scoreCliente, String scoreConsumido, String saldoScore, String scoreConsumidoOrdem, String totalTaxasRecorrentes, String totalTaxasNaoRecorrentes, String totalTaxas, String numeroContratos, String loginResponsavel, String canalCriacaoOrdem, String loginVendedor, String canalVenda, String cnpjParceiroVenda, String nomeParceiroVenda, String msanReserva, String msanInstalacao, String motivoCancelamentoOrdem, String loginCancelamentoOrdem, String motivoRecusaCrivo, String motivoRecusaSGF, String usuarioLinha, String statusOrdemWFM, String nomeCliente, String codigoContrato, String datafinalizacaoOrdem, String telefoneContato1, String telefoneContato2, String telefoneContato3, String numeroOrdemAMDOCS, String statusAlcada, String dataStatusAlcada, String chaveCrivo, String limiteAparelho, String limiteAparelhoConsumido, String valorAparelhoOrdem, String saldoLimiteAparelho, String custcodePDV, String canalEntrada, String numeroBpTim, String customerId, String campanha, String perfilLogin, String ruaEntrega, String numeroEntrega, String complementoEntrega, String cepEntrega, String bairroEntrega, String estadoEntrega, String cidadeEntrega, String alteracaoEndereco, String pessoaAutorizada1, String pessoaAutorizada2, String pessoaAutorizada3, String idContrato, String matriculaResponsavel, String cpfVendedor, String codDsf, String canal, String regional, String uf, String nomeFantasia, String tipoOrdemOrigem, String ufEnderecoWttx, String cidadeEnderecoWttx, String cepEnderecoWttx, String bairroEnderecoWttx, String tipoLogEnderecoWttx, String logEnderecoWttx, String numLogEnderecoWttx, String complementoLogEnderecoWttx, String flgConvergente, String dscMelhorOferta, String accntId) {
        this.rowId = rowId;
        this.loteId = loteId;
        this.arquivo = arquivo;
        this.arquivoTs = arquivoTs;
        this.currentDate = currentDate;
        this.numeroOrdem = numeroOrdem;
        this.numeroCliente = numeroCliente;
        this.statusOrdem = statusOrdem;
        this.dataCriacaoOrdem = dataCriacaoOrdem;
        this.dataVenda = dataVenda;
        this.dataStatusOrdem = dataStatusOrdem;
        this.tipoOrdem = tipoOrdem;
        this.subTipoOrdem = subTipoOrdem;
        this.flagVendaLiquida = flagVendaLiquida;
        this.codigoOrdemOriginal = codigoOrdemOriginal;
        this.dataVendaOriginal = dataVendaOriginal;
        this.procurador = procurador;
        this.nomeContato = nomeContato;
        this.cpf = cpf;
        this.scoreCliente = scoreCliente;
        this.scoreConsumido = scoreConsumido;
        this.saldoScore = saldoScore;
        this.scoreConsumidoOrdem = scoreConsumidoOrdem;
        this.totalTaxasRecorrentes = totalTaxasRecorrentes;
        this.totalTaxasNaoRecorrentes = totalTaxasNaoRecorrentes;
        this.totalTaxas = totalTaxas;
        this.numeroContratos = numeroContratos;
        this.loginResponsavel = loginResponsavel;
        this.canalCriacaoOrdem = canalCriacaoOrdem;
        this.loginVendedor = loginVendedor;
        this.canalVenda = canalVenda;
        this.cnpjParceiroVenda = cnpjParceiroVenda;
        this.nomeParceiroVenda = nomeParceiroVenda;
        this.msanReserva = msanReserva;
        this.msanInstalacao = msanInstalacao;
        this.motivoCancelamentoOrdem = motivoCancelamentoOrdem;
        this.loginCancelamentoOrdem = loginCancelamentoOrdem;
        this.motivoRecusaCrivo = motivoRecusaCrivo;
        this.motivoRecusaSGF = motivoRecusaSGF;
        this.usuarioLinha = usuarioLinha;
        this.statusOrdemWFM = statusOrdemWFM;
        this.nomeCliente = nomeCliente;
        this.codigoContrato = codigoContrato;
        this.datafinalizacaoOrdem = datafinalizacaoOrdem;
        this.telefoneContato1 = telefoneContato1;
        this.telefoneContato2 = telefoneContato2;
        this.telefoneContato3 = telefoneContato3;
        this.numeroOrdemAMDOCS = numeroOrdemAMDOCS;
        this.statusAlcada = statusAlcada;
        this.dataStatusAlcada = dataStatusAlcada;
        this.chaveCrivo = chaveCrivo;
        this.limiteAparelho = limiteAparelho;
        this.limiteAparelhoConsumido = limiteAparelhoConsumido;
        this.valorAparelhoOrdem = valorAparelhoOrdem;
        this.saldoLimiteAparelho = saldoLimiteAparelho;
        this.custcodePDV = custcodePDV;
        this.canalEntrada = canalEntrada;
        this.numeroBpTim = numeroBpTim;
        this.customerId = customerId;
        this.campanha = campanha;
        this.perfilLogin = perfilLogin;
        this.ruaEntrega = ruaEntrega;
        this.numeroEntrega = numeroEntrega;
        this.complementoEntrega = complementoEntrega;
        this.cepEntrega = cepEntrega;
        this.bairroEntrega = bairroEntrega;
        this.estadoEntrega = estadoEntrega;
        this.cidadeEntrega = cidadeEntrega;
        this.alteracaoEndereco = alteracaoEndereco;
        this.pessoaAutorizada1 = pessoaAutorizada1;
        this.pessoaAutorizada2 = pessoaAutorizada2;
        this.pessoaAutorizada3 = pessoaAutorizada3;
        this.idContrato = idContrato;
        this.matriculaResponsavel = matriculaResponsavel;
        this.cpfVendedor = cpfVendedor;
        this.codDsf = codDsf;
        this.canal = canal;
        this.regional = regional;
        this.uf = uf;
        this.nomeFantasia = nomeFantasia;
        this.tipoOrdemOrigem = tipoOrdemOrigem;
        this.ufEnderecoWttx = ufEnderecoWttx;
        this.cidadeEnderecoWttx = cidadeEnderecoWttx;
        this.cepEnderecoWttx = cepEnderecoWttx;
        this.bairroEnderecoWttx = bairroEnderecoWttx;
        this.tipoLogEnderecoWttx = tipoLogEnderecoWttx;
        this.logEnderecoWttx = logEnderecoWttx;
        this.numLogEnderecoWttx = numLogEnderecoWttx;
        this.complementoLogEnderecoWttx = complementoLogEnderecoWttx;
        this.flgConvergente = flgConvergente;
        this.dscMelhorOferta = dscMelhorOferta;
        this.accntId = accntId;
    }

    public boolean parse(String textString) {
        if (StringUtils.isNotBlank(textString)) {
            String[] cols = textString.split("\\|", -1);
            if(cols.length != 18) {
                int i = 0;
                this.setBAT509Order(cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                        cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                        cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                        cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                        cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                        cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                        cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                        cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                        cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                        cols[i++], cols[i++], cols[i++]
                );
                return true;
            }
        }
        return false;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        String delimiter = "|";
        sb.append(numeroOrdem).append(delimiter)
          .append(numeroCliente).append(delimiter)
          .append(statusOrdem).append(delimiter)
          .append(dataCriacaoOrdem).append(delimiter)
          .append(dataVenda).append(delimiter)
          .append(dataStatusOrdem).append(delimiter)
          .append(tipoOrdem).append(delimiter)
          .append(subTipoOrdem).append(delimiter)
          .append(flagVendaLiquida).append(delimiter)
          .append(codigoOrdemOriginal).append(delimiter)
          .append(dataVendaOriginal).append(delimiter)
          .append(procurador).append(delimiter)
          .append(nomeContato).append(delimiter)
          .append(cpf).append(delimiter)
          .append(scoreCliente).append(delimiter)
          .append(scoreConsumido).append(delimiter)
          .append(saldoScore).append(delimiter)
          .append(scoreConsumidoOrdem).append(delimiter)
          .append(totalTaxasRecorrentes).append(delimiter)
          .append(totalTaxasNaoRecorrentes).append(delimiter)
          .append(totalTaxas).append(delimiter)
          .append(numeroContratos).append(delimiter)
          .append(loginResponsavel).append(delimiter)
          .append(canalCriacaoOrdem).append(delimiter)
          .append(loginVendedor).append(delimiter)
          .append(canalVenda).append(delimiter)
          .append(cnpjParceiroVenda).append(delimiter)
          .append(nomeParceiroVenda).append(delimiter)
          .append(msanReserva).append(delimiter)
          .append(msanInstalacao).append(delimiter)
          .append(motivoCancelamentoOrdem).append(delimiter)
          .append(loginCancelamentoOrdem).append(delimiter)
          .append(motivoRecusaCrivo).append(delimiter)
          .append(motivoRecusaSGF).append(delimiter)
          .append(usuarioLinha).append(delimiter)
          .append(statusOrdemWFM).append(delimiter)
          .append(nomeCliente).append(delimiter)
          .append(codigoContrato).append(delimiter)
          .append(datafinalizacaoOrdem).append(delimiter)
          .append(telefoneContato1).append(delimiter)
          .append(telefoneContato2).append(delimiter)
          .append(telefoneContato3).append(delimiter)
          .append(numeroOrdemAMDOCS).append(delimiter)
          .append(statusAlcada).append(delimiter)
          .append(dataStatusAlcada).append(delimiter)
          .append(chaveCrivo).append(delimiter)
          .append(limiteAparelho).append(delimiter)
          .append(limiteAparelhoConsumido).append(delimiter)
          .append(valorAparelhoOrdem).append(delimiter)
          .append(saldoLimiteAparelho).append(delimiter)
          .append(custcodePDV).append(delimiter)
          .append(canalEntrada).append(delimiter)
          .append(numeroBpTim).append(delimiter)
          .append(customerId).append(delimiter)
          .append(campanha).append(delimiter)
          .append(perfilLogin).append(delimiter)
          .append(ruaEntrega).append(delimiter)
          .append(numeroEntrega).append(delimiter)
          .append(complementoEntrega).append(delimiter)
          .append(cepEntrega).append(delimiter)
          .append(bairroEntrega).append(delimiter)
          .append(estadoEntrega).append(delimiter)
          .append(cidadeEntrega).append(delimiter)
          .append(alteracaoEndereco).append(delimiter)
          .append(pessoaAutorizada1).append(delimiter)
          .append(pessoaAutorizada2).append(delimiter)
          .append(pessoaAutorizada3).append(delimiter)
          .append(idContrato).append(delimiter)
          .append(matriculaResponsavel).append(delimiter)
          .append(cpfVendedor).append(delimiter)
          .append(rowId).append(delimiter)
          .append(loteId).append(delimiter)
          .append(arquivo).append(delimiter)
          .append(arquivoTs).append(delimiter)
          .append(currentDate).append(delimiter)
          .append(canal).append(delimiter)
          .append(regional).append(delimiter)
          .append(uf).append(delimiter)
          .append(nomeFantasia).append(delimiter)
          .append(tipoOrdemOrigem).append(delimiter)
          .append(ufEnderecoWttx).append(delimiter)
          .append(cidadeEnderecoWttx).append(delimiter)
          .append(cepEnderecoWttx).append(delimiter)
          .append(bairroEnderecoWttx).append(delimiter)
          .append(tipoLogEnderecoWttx).append(delimiter)
          .append(logEnderecoWttx).append(delimiter)
          .append(numLogEnderecoWttx).append(delimiter)
          .append(complementoLogEnderecoWttx).append(delimiter)
          .append(flgConvergente);

        return sb.toString();

    }

    public String getRowId() {
        return rowId;
    }

    public void setRowId(String rowId) {
        this.rowId = rowId;
    }

    public String getLoteId() {
        return loteId;
    }

    public void setLoteId(String loteId) {
        this.loteId = loteId;
    }

    public String getArquivo() {
        return arquivo;
    }

    public void setArquivo(String arquivo) {
        this.arquivo = arquivo;
    }

    public String getArquivoTs() {
        return arquivoTs;
    }

    public void setArquivoTs(String arquivoTs) {
        this.arquivoTs = arquivoTs;
    }

    public String getCurrentDate() {
        return currentDate;
    }

    public void setCurrentDate(String currentDate) {
        this.currentDate = currentDate;
    }

    public String getNumeroOrdem() {
        return numeroOrdem;
    }

    public void setNumeroOrdem(String numeroOrdem) {
        this.numeroOrdem = numeroOrdem;
    }

    public String getNumeroCliente() {
        return numeroCliente;
    }

    public void setNumeroCliente(String numeroCliente) {
        this.numeroCliente = numeroCliente;
    }

    public String getStatusOrdem() {
        return statusOrdem;
    }

    public void setStatusOrdem(String statusOrdem) {
        this.statusOrdem = statusOrdem;
    }

    public String getDataCriacaoOrdem() {
        return dataCriacaoOrdem;
    }

    public void setDataCriacaoOrdem(String dataCriacaoOrdem) {
        this.dataCriacaoOrdem = dataCriacaoOrdem;
    }

    public String getDataVenda() {
        return dataVenda;
    }

    public void setDataVenda(String dataVenda) {
        this.dataVenda = dataVenda;
    }

    public String getDataStatusOrdem() {
        return dataStatusOrdem;
    }

    public void setDataStatusOrdem(String dataStatusOrdem) {
        this.dataStatusOrdem = dataStatusOrdem;
    }

    public String getTipoOrdem() {
        return tipoOrdem;
    }

    public void setTipoOrdem(String tipoOrdem) {
        this.tipoOrdem = tipoOrdem;
    }

    public String getSubTipoOrdem() {
        return subTipoOrdem;
    }

    public void setSubTipoOrdem(String subTipoOrdem) {
        this.subTipoOrdem = subTipoOrdem;
    }

    public String getFlagVendaLiquida() {
        return flagVendaLiquida;
    }

    public void setFlagVendaLiquida(String flagVendaLiquida) {
        this.flagVendaLiquida = flagVendaLiquida;
    }

    public String getCodigoOrdemOriginal() {
        return codigoOrdemOriginal;
    }

    public void setCodigoOrdemOriginal(String codigoOrdemOriginal) {
        this.codigoOrdemOriginal = codigoOrdemOriginal;
    }

    public String getDataVendaOriginal() {
        return dataVendaOriginal;
    }

    public void setDataVendaOriginal(String dataVendaOriginal) {
        this.dataVendaOriginal = dataVendaOriginal;
    }

    public String getProcurador() {
        return procurador;
    }

    public void setProcurador(String procurador) {
        this.procurador = procurador;
    }

    public String getNomeContato() {
        return nomeContato;
    }

    public void setNomeContato(String nomeContato) {
        this.nomeContato = nomeContato;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getScoreCliente() {
        return scoreCliente;
    }

    public void setScoreCliente(String scoreCliente) {
        this.scoreCliente = scoreCliente;
    }

    public String getScoreConsumido() {
        return scoreConsumido;
    }

    public void setScoreConsumido(String scoreConsumido) {
        this.scoreConsumido = scoreConsumido;
    }

    public String getSaldoScore() {
        return saldoScore;
    }

    public void setSaldoScore(String saldoScore) {
        this.saldoScore = saldoScore;
    }

    public String getScoreConsumidoOrdem() {
        return scoreConsumidoOrdem;
    }

    public void setScoreConsumidoOrdem(String scoreConsumidoOrdem) {
        this.scoreConsumidoOrdem = scoreConsumidoOrdem;
    }

    public String getTotalTaxasRecorrentes() {
        return totalTaxasRecorrentes;
    }

    public void setTotalTaxasRecorrentes(String totalTaxasRecorrentes) {
        this.totalTaxasRecorrentes = totalTaxasRecorrentes;
    }

    public String getTotalTaxasNaoRecorrentes() {
        return totalTaxasNaoRecorrentes;
    }

    public void setTotalTaxasNaoRecorrentes(String totalTaxasNaoRecorrentes) {
        this.totalTaxasNaoRecorrentes = totalTaxasNaoRecorrentes;
    }

    public String getTotalTaxas() {
        return totalTaxas;
    }

    public void setTotalTaxas(String totalTaxas) {
        this.totalTaxas = totalTaxas;
    }

    public String getNumeroContratos() {
        return numeroContratos;
    }

    public void setNumeroContratos(String numeroContratos) {
        this.numeroContratos = numeroContratos;
    }

    public String getLoginResponsavel() {
        return loginResponsavel;
    }

    public void setLoginResponsavel(String loginResponsavel) {
        this.loginResponsavel = loginResponsavel;
    }

    public String getCanalCriacaoOrdem() {
        return canalCriacaoOrdem;
    }

    public void setCanalCriacaoOrdem(String canalCriacaoOrdem) {
        this.canalCriacaoOrdem = canalCriacaoOrdem;
    }

    public String getLoginVendedor() {
        return loginVendedor;
    }

    public void setLoginVendedor(String loginVendedor) {
        this.loginVendedor = loginVendedor;
    }

    public String getCanalVenda() {
        return canalVenda;
    }

    public void setCanalVenda(String canalVenda) {
        this.canalVenda = canalVenda;
    }

    public String getCnpjParceiroVenda() {
        return cnpjParceiroVenda;
    }

    public void setCnpjParceiroVenda(String cnpjParceiroVenda) {
        this.cnpjParceiroVenda = cnpjParceiroVenda;
    }

    public String getNomeParceiroVenda() {
        return nomeParceiroVenda;
    }

    public void setNomeParceiroVenda(String nomeParceiroVenda) {
        this.nomeParceiroVenda = nomeParceiroVenda;
    }

    public String getMsanReserva() {
        return msanReserva;
    }

    public void setMsanReserva(String msanReserva) {
        this.msanReserva = msanReserva;
    }

    public String getMsanInstalacao() {
        return msanInstalacao;
    }

    public void setMsanInstalacao(String msanInstalacao) {
        this.msanInstalacao = msanInstalacao;
    }

    public String getMotivoCancelamentoOrdem() {
        return motivoCancelamentoOrdem;
    }

    public void setMotivoCancelamentoOrdem(String motivoCancelamentoOrdem) {
        this.motivoCancelamentoOrdem = motivoCancelamentoOrdem;
    }

    public String getLoginCancelamentoOrdem() {
        return loginCancelamentoOrdem;
    }

    public void setLoginCancelamentoOrdem(String loginCancelamentoOrdem) {
        this.loginCancelamentoOrdem = loginCancelamentoOrdem;
    }

    public String getMotivoRecusaCrivo() {
        return motivoRecusaCrivo;
    }

    public void setMotivoRecusaCrivo(String motivoRecusaCrivo) {
        this.motivoRecusaCrivo = motivoRecusaCrivo;
    }

    public String getMotivoRecusaSGF() {
        return motivoRecusaSGF;
    }

    public void setMotivoRecusaSGF(String motivoRecusaSGF) {
        this.motivoRecusaSGF = motivoRecusaSGF;
    }

    public String getUsuarioLinha() {
        return usuarioLinha;
    }

    public void setUsuarioLinha(String usuarioLinha) {
        this.usuarioLinha = usuarioLinha;
    }

    public String getStatusOrdemWFM() {
        return statusOrdemWFM;
    }

    public void setStatusOrdemWFM(String statusOrdemWFM) {
        this.statusOrdemWFM = statusOrdemWFM;
    }

    public String getNomeCliente() {
        return nomeCliente;
    }

    public void setNomeCliente(String nomeCliente) {
        this.nomeCliente = nomeCliente;
    }

    public String getCodigoContrato() {
        return codigoContrato;
    }

    public void setCodigoContrato(String codigoContrato) {
        this.codigoContrato = codigoContrato;
    }

    public String getDatafinalizacaoOrdem() {
        return datafinalizacaoOrdem;
    }

    public void setDatafinalizacaoOrdem(String datafinalizacaoOrdem) {
        this.datafinalizacaoOrdem = datafinalizacaoOrdem;
    }

    public String getTelefoneContato1() {
        return telefoneContato1;
    }

    public void setTelefoneContato1(String telefoneContato1) {
        this.telefoneContato1 = telefoneContato1;
    }

    public String getTelefoneContato2() {
        return telefoneContato2;
    }

    public void setTelefoneContato2(String telefoneContato2) {
        this.telefoneContato2 = telefoneContato2;
    }

    public String getTelefoneContato3() {
        return telefoneContato3;
    }

    public void setTelefoneContato3(String telefoneContato3) {
        this.telefoneContato3 = telefoneContato3;
    }

    public String getNumeroOrdemAMDOCS() {
        return numeroOrdemAMDOCS;
    }

    public void setNumeroOrdemAMDOCS(String numeroOrdemAMDOCS) {
        this.numeroOrdemAMDOCS = numeroOrdemAMDOCS;
    }

    public String getStatusAlcada() {
        return statusAlcada;
    }

    public void setStatusAlcada(String statusAlcada) {
        this.statusAlcada = statusAlcada;
    }

    public String getDataStatusAlcada() {
        return dataStatusAlcada;
    }

    public void setDataStatusAlcada(String dataStatusAlcada) {
        this.dataStatusAlcada = dataStatusAlcada;
    }

    public String getChaveCrivo() {
        return chaveCrivo;
    }

    public void setChaveCrivo(String chaveCrivo) {
        this.chaveCrivo = chaveCrivo;
    }

    public String getLimiteAparelho() {
        return limiteAparelho;
    }

    public void setLimiteAparelho(String limiteAparelho) {
        this.limiteAparelho = limiteAparelho;
    }

    public String getLimiteAparelhoConsumido() {
        return limiteAparelhoConsumido;
    }

    public void setLimiteAparelhoConsumido(String limiteAparelhoConsumido) {
        this.limiteAparelhoConsumido = limiteAparelhoConsumido;
    }

    public String getValorAparelhoOrdem() {
        return valorAparelhoOrdem;
    }

    public void setValorAparelhoOrdem(String valorAparelhoOrdem) {
        this.valorAparelhoOrdem = valorAparelhoOrdem;
    }

    public String getSaldoLimiteAparelho() {
        return saldoLimiteAparelho;
    }

    public void setSaldoLimiteAparelho(String saldoLimiteAparelho) {
        this.saldoLimiteAparelho = saldoLimiteAparelho;
    }

    public String getCustcodePDV() {
        return custcodePDV;
    }

    public void setCustcodePDV(String custcodePDV) {
        this.custcodePDV = custcodePDV;
    }

    public String getCanalEntrada() {
        return canalEntrada;
    }

    public void setCanalEntrada(String canalEntrada) {
        this.canalEntrada = canalEntrada;
    }

    public String getNumeroBpTim() {
        return numeroBpTim;
    }

    public void setNumeroBpTim(String numeroBpTim) {
        this.numeroBpTim = numeroBpTim;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getCampanha() {
        return campanha;
    }

    public void setCampanha(String campanha) {
        this.campanha = campanha;
    }

    public String getPerfilLogin() {
        return perfilLogin;
    }

    public void setPerfilLogin(String perfilLogin) {
        this.perfilLogin = perfilLogin;
    }

    public String getRuaEntrega() {
        return ruaEntrega;
    }

    public void setRuaEntrega(String ruaEntrega) {
        this.ruaEntrega = ruaEntrega;
    }

    public String getNumeroEntrega() {
        return numeroEntrega;
    }

    public void setNumeroEntrega(String numeroEntrega) {
        this.numeroEntrega = numeroEntrega;
    }

    public String getComplementoEntrega() {
        return complementoEntrega;
    }

    public void setComplementoEntrega(String complementoEntrega) {
        this.complementoEntrega = complementoEntrega;
    }

    public String getCepEntrega() {
        return cepEntrega;
    }

    public void setCepEntrega(String cepEntrega) {
        this.cepEntrega = cepEntrega;
    }

    public String getBairroEntrega() {
        return bairroEntrega;
    }

    public void setBairroEntrega(String bairroEntrega) {
        this.bairroEntrega = bairroEntrega;
    }

    public String getEstadoEntrega() {
        return estadoEntrega;
    }

    public void setEstadoEntrega(String estadoEntrega) {
        this.estadoEntrega = estadoEntrega;
    }

    public String getCidadeEntrega() {
        return cidadeEntrega;
    }

    public void setCidadeEntrega(String cidadeEntrega) {
        this.cidadeEntrega = cidadeEntrega;
    }

    public String getAlteracaoEndereco() {
        return alteracaoEndereco;
    }

    public void setAlteracaoEndereco(String alteracaoEndereco) {
        this.alteracaoEndereco = alteracaoEndereco;
    }

    public String getPessoaAutorizada1() {
        return pessoaAutorizada1;
    }

    public void setPessoaAutorizada1(String pessoaAutorizada1) {
        this.pessoaAutorizada1 = pessoaAutorizada1;
    }

    public String getPessoaAutorizada2() {
        return pessoaAutorizada2;
    }

    public void setPessoaAutorizada2(String pessoaAutorizada2) {
        this.pessoaAutorizada2 = pessoaAutorizada2;
    }

    public String getPessoaAutorizada3() {
        return pessoaAutorizada3;
    }

    public void setPessoaAutorizada3(String pessoaAutorizada3) {
        this.pessoaAutorizada3 = pessoaAutorizada3;
    }

    public String getIdContrato() {
        return idContrato;
    }

    public void setIdContrato(String idContrato) {
        this.idContrato = idContrato;
    }

    public String getMatriculaResponsavel() {
        return matriculaResponsavel;
    }

    public void setMatriculaResponsavel(String matriculaResponsavel) {
        this.matriculaResponsavel = matriculaResponsavel;
    }

    public String getCpfVendedor() {
        return cpfVendedor;
    }

    public void setCpfVendedor(String cpfVendedor) {
        this.cpfVendedor = cpfVendedor;
    }

    public String getCodDsf() {
        return codDsf;
    }

    public void setCodDsf(String codDsf) {
        this.codDsf = codDsf;
    }

    public String getCanal() {
        return canal;
    }

    public void setCanal(String canal) {
        this.canal = canal;
    }

    public String getRegional() {
        return regional;
    }

    public void setRegional(String regional) {
        this.regional = regional;
    }

    public String getUf() {
        return uf;
    }

    public void setUf(String uf) {
        this.uf = uf;
    }

    public String getNomeFantasia() {
        return nomeFantasia;
    }

    public void setNomeFantasia(String nomeFantasia) {
        this.nomeFantasia = nomeFantasia;
    }

    public String getTipoOrdemOrigem() {
        return tipoOrdemOrigem;
    }

    public void setTipoOrdemOrigem(String tipoOrdemOrigem) {
        this.tipoOrdemOrigem = tipoOrdemOrigem;
    }

    public String getUfEnderecoWttx() {
        return ufEnderecoWttx;
    }

    public void setUfEnderecoWttx(String ufEnderecoWttx) {
        this.ufEnderecoWttx = ufEnderecoWttx;
    }

    public String getCidadeEnderecoWttx() {
        return cidadeEnderecoWttx;
    }

    public void setCidadeEnderecoWttx(String cidadeEnderecoWttx) {
        this.cidadeEnderecoWttx = cidadeEnderecoWttx;
    }

    public String getCepEnderecoWttx() {
        return cepEnderecoWttx;
    }

    public void setCepEnderecoWttx(String cepEnderecoWttx) {
        this.cepEnderecoWttx = cepEnderecoWttx;
    }

    public String getBairroEnderecoWttx() {
        return bairroEnderecoWttx;
    }

    public void setBairroEnderecoWttx(String bairroEnderecoWttx) {
        this.bairroEnderecoWttx = bairroEnderecoWttx;
    }

    public String getTipoLogEnderecoWttx() {
        return tipoLogEnderecoWttx;
    }

    public void setTipoLogEnderecoWttx(String tipoLogEnderecoWttx) {
        this.tipoLogEnderecoWttx = tipoLogEnderecoWttx;
    }

    public String getLogEnderecoWttx() {
        return logEnderecoWttx;
    }

    public void setLogEnderecoWttx(String logEnderecoWttx) {
        this.logEnderecoWttx = logEnderecoWttx;
    }

    public String getNumLogEnderecoWttx() {
        return numLogEnderecoWttx;
    }

    public void setNumLogEnderecoWttx(String numLogEnderecoWttx) {
        this.numLogEnderecoWttx = numLogEnderecoWttx;
    }

    public String getComplementoLogEnderecoWttx() {
        return complementoLogEnderecoWttx;
    }

    public void setComplementoLogEnderecoWttx(String complementoLogEnderecoWttx) {
        this.complementoLogEnderecoWttx = complementoLogEnderecoWttx;
    }

    public String getFlgConvergente() {
        return flgConvergente;
    }

    public void setFlgConvergente(String flgConvergente) {
        this.flgConvergente = flgConvergente;
    }

    public String getDscMelhorOferta() {
        return dscMelhorOferta;
    }

    public void setDscMelhorOferta(String dscMelhorOferta) {
        this.dscMelhorOferta = dscMelhorOferta;
    }

    public String getAccntId() {
        return accntId;
    }

    public void setAccntId(String accntId) {
        this.accntId = accntId;
    }
}
