package br.com.tim.mapreduce.tramit.step2.model;

import org.apache.commons.lang3.StringUtils;

public class Step1Result {

    protected String ordemSiebel;
    protected String cpfCNPJ;
    protected String contrato;
    protected String datCriacaoOrdem;
    protected String login;
    protected String statusSiebel;
    protected String motivoCancelamento;
    protected String tipoOrdem;
    protected String subtipoOrdem;
    protected String parceiroVendaSiebel;
    protected String tipoErro;
    protected String aging;
    protected String agingFaixa;
    protected String tecnologia;
    protected String cpe;
    protected String ont;
    protected String produto;
    protected String uf;
    protected String statusWfmToa;
    protected String resourceWfmToa; 
    protected String dateWfmToa;
    protected String stepErro;
	protected String msan;

    public Step1Result(){
        this.ordemSiebel = null;
        this.cpfCNPJ = null;
        this.contrato = null;
        this.datCriacaoOrdem = null;
        this.login = null;
        this.statusSiebel = null;
        this.motivoCancelamento = null;
        this.tipoOrdem = null;
        this.subtipoOrdem = null;
        this.parceiroVendaSiebel = null;
        this.tipoErro = null;
        this.aging = null;
        this.agingFaixa = null;
        this.tecnologia = null;
        this.cpe = null;
        this.ont = null;
        this.produto = null;
        this.uf = null;
        this.statusWfmToa = null;
        this.resourceWfmToa = null;
        this.dateWfmToa = null;
        this.stepErro = null;
        this.msan = null;
    }

    public void setStep1Result(String ordemSiebel, String cpfCNPJ, String contrato, String datCriacaoOrdem, String login, String statusSiebel, String motivoCancelamento,
                               String tipoOrdem, String subtipoOrdem, String parceiroVendaSiebel, String tipoErro, String aging, String agingFaixa, String tecnologia, String cpe, String ont,
                               String produto, String uf, String statusWfmToa, String resourceWfmToa, String dateWfmToa, String stepErro, String msan){
        this.ordemSiebel = ordemSiebel;
        this.cpfCNPJ = cpfCNPJ;
        this.contrato = contrato;
        this.datCriacaoOrdem = datCriacaoOrdem;
        this.login = login;
        this.statusSiebel = statusSiebel;
        this.motivoCancelamento = motivoCancelamento;
        this.tipoOrdem = tipoOrdem;
        this.subtipoOrdem = subtipoOrdem;
        this.parceiroVendaSiebel = parceiroVendaSiebel;
        this.tipoErro = tipoErro;
        this.aging = aging;
        this.agingFaixa = agingFaixa;
        this.tecnologia = tecnologia;
        this.cpe = cpe;
        this.ont = ont;
        this.produto = produto;
        this.uf = uf;
        this.statusWfmToa = statusWfmToa;
        this.resourceWfmToa = resourceWfmToa;
        this.dateWfmToa = dateWfmToa;
        this.stepErro = stepErro;
        this.msan = msan;
    }

    public boolean parse(String textString) {
        if (StringUtils.isNotBlank(textString)) {
            String[] cols = textString.split("\\|", -1);
            int i = 0;
            this.setStep1Result(cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                                cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], 
                                cols[i++], cols[i++], cols[i++]);
            return true;
        }
        return false;
    }

    public String getStatusWfmToa() {
		return statusWfmToa;
	}

	public void setStatusWfmToa(String statusWfmToa) {
		this.statusWfmToa = statusWfmToa;
	}

	public String getResourceWfmToa() {
		return resourceWfmToa;
	}

	public void setResourceWfmToa(String resourceWfmToa) {
		this.resourceWfmToa = resourceWfmToa;
	}

	public String getDateWfmToa() {
		return dateWfmToa;
	}

	public void setDateWfmToa(String dateWfmToa) {
		this.dateWfmToa = dateWfmToa;
	}

	public String getStepErro() {
		return stepErro;
	}

	public void setStepErro(String stepErro) {
		this.stepErro = stepErro;
	}

	public String getMsan() {
		return msan;
	}

	public void setMsan(String msan) {
		this.msan = msan;
	}

	public String getOrdemSiebel() {
        return ordemSiebel;
    }

    public void setOrdemSiebel(String ordemSiebel) {
        this.ordemSiebel = ordemSiebel;
    }

    public String getCpfCNPJ() {
        return cpfCNPJ;
    }

    public void setCpfCNPJ(String cpfCNPJ) {
        this.cpfCNPJ = cpfCNPJ;
    }

    public String getContrato() {
        return contrato;
    }

    public void setContrato(String contrato) {
        this.contrato = contrato;
    }

    public String getDatCriacaoOrdem() {
        return datCriacaoOrdem;
    }

    public void setDatCriacaoOrdem(String datCriacaoOrdem) {
        this.datCriacaoOrdem = datCriacaoOrdem;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getStatusSiebel() {
        return statusSiebel;
    }

    public void setStatusSiebel(String statusSiebel) {
        this.statusSiebel = statusSiebel;
    }

    public String getMotivoCancelamento() {
        return motivoCancelamento;
    }

    public void setMotivoCancelamento(String motivoCancelamento) {
        this.motivoCancelamento = motivoCancelamento;
    }

    public String getTipoOrdem() {
        return tipoOrdem;
    }

    public void setTipoOrdem(String tipoOrdem) {
        this.tipoOrdem = tipoOrdem;
    }

    public String getSubtipoOrdem() {
        return subtipoOrdem;
    }

    public void setSubtipoOrdem(String subtipoOrdem) {
        this.subtipoOrdem = subtipoOrdem;
    }

    public String getParceiroVendaSiebel() {
        return parceiroVendaSiebel;
    }

    public void setParceiroVendaSiebel(String parceiroVendaSiebel) {
        this.parceiroVendaSiebel = parceiroVendaSiebel;
    }

    public String getTipoErro() {
        return tipoErro;
    }

    public void setTipoErro(String tipoErro) {
        this.tipoErro = tipoErro;
    }

    public String getAging() {
        return aging;
    }

    public void setAging(String aging) {
        this.aging = aging;
    }

    public String getAgingFaixa() {
        return agingFaixa;
    }

    public void setAgingFaixa(String agingFaixa) {
        this.agingFaixa = agingFaixa;
    }

    public String getTecnologia() {
        return tecnologia;
    }

    public void setTecnologia(String tecnologia) {
        this.tecnologia = tecnologia;
    }

    public String getCpe() {
        return cpe;
    }

    public void setCpe(String cpe) {
        this.cpe = cpe;
    }

    public String getOnt() {
        return ont;
    }

    public void setOnt(String ont) {
        this.ont = ont;
    }

    public String getProduto() {
        return produto;
    }

    public void setProduto(String produto) {
        this.produto = produto;
    }

    public String getUf() {
        return uf;
    }

    public void setUf(String uf) {
        this.uf = uf;
    }
}
