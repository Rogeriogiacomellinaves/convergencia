package br.com.tim.mapreduce.refactoring.endtoend.step4.pt1;

public class Step4Combiner {

}
