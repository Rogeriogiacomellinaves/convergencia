package br.com.tim.mapreduce.e2e.step6.pt2;

import br.com.tim.mapreduce.e2e.step6.E2EStep6Key;
import br.com.tim.mapreduce.e2e.step6.TypeStep6;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.log4j.Logger;

import java.io.IOException;

public class E2EStep6PT2Reducer extends org.apache.hadoop.mapreduce.Reducer<E2EStep6Key,E2EStep6PT2Value,NullWritable,Text> {

    protected static final Logger LOG = Logger.getLogger(E2EStep6PT2Reducer.class);
    private E2EStep6PT2OutValue outValue;


    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        super.setup(context);
        outValue = new E2EStep6PT2OutValue();
    }

    @Override
    protected void reduce(E2EStep6Key key, Iterable<E2EStep6PT2Value> values, Context context) throws InterruptedException {

        outValue.clear();

        try {
            for (E2EStep6PT2Value value : values) {
                if (value.getTipo().equals(TypeStep6.RELT)){
                    outValue.clearRelt();
                    outValue.setRelt(value);
                    context.write(NullWritable.get(), new Text(outValue.toString()));
                }else if (value.getTipo().equals(TypeStep6.BAT223)){
                    outValue.setBat223(value);
                }
            }

        } catch (Exception e) {
            LOG.error(" ############ ERROR EXECUTION REDUCER ############ ");
            LOG.error(e.getMessage());
            throw new InterruptedException(e.getMessage());
        }
    }



    @Override
    protected void cleanup(Context context) throws IOException, InterruptedException {
        super.cleanup(context);

    }
}


