package br.com.tim.mapreduce.e2e.step3;

import org.apache.hadoop.mapreduce.Partitioner;

public class JoinPartitioner extends Partitioner<E2EStep3Key, E2EStep3Value> {

    @Override
    public int getPartition(E2EStep3Key taggedKey, E2EStep3Value value, int numPartitions) {
        return Math.abs(taggedKey.hashCodeJoin() % numPartitions);
    }
}