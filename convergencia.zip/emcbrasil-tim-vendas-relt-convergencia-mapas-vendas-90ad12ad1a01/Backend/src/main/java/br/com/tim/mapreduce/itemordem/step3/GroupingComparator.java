package br.com.tim.mapreduce.itemordem.step3;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

public class GroupingComparator extends WritableComparator {

    public GroupingComparator() {
        super(IOStep3Key.class, true);
    }

    @SuppressWarnings({"rawtypes"})
    @Override
    public int compare(WritableComparable a, WritableComparable b) {
        IOStep3Key keyA = (IOStep3Key) a;
        IOStep3Key keyB = (IOStep3Key) b;

        return keyA.compareToGrouping(keyB);
    }

}
