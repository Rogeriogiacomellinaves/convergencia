package br.com.tim.mapreduce.e2e.step1;

import br.com.tim.mapreduce.e2e.GroupComparable;
import com.google.common.collect.ComparisonChain;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Objects;


public class E2EStep1Key implements GroupComparable<E2EStep1Key> {

	private String rowIdItem;
	private String datRef;
	private TypeStep1 tipo;

	@Override
	public void write(DataOutput output) throws IOException {
		output.writeInt(tipo.ordinal());
		output.writeUTF(this.rowIdItem);
		output.writeUTF(this.datRef);
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		this.tipo = TypeStep1.values()[in.readInt()];
		this.rowIdItem = in.readUTF();
		this.datRef = in.readUTF();
	}

	public void clear(){
		rowIdItem = null;
		tipo = null;
	}

	public void setRowIdItem(String rowIdItem) {
		this.rowIdItem = rowIdItem;
	}

	public void setDatRef(String arquivo){
		this.datRef = arquivo.substring(23,31);
	}

	public String getDatRef() {
		return datRef;
	}

	public void setTipo(TypeStep1 tipo) {
		this.tipo = tipo;
	}

	@Override
	public int compareTo(E2EStep1Key o) {
		return ComparisonChain.start().compare(this.rowIdItem, o.rowIdItem).compare(this.tipo, o.tipo).compare(o.datRef, this.datRef).result();
	}

	@Override
	public int compareToGrouping(E2EStep1Key o) {
		return ComparisonChain.start().compare(this.rowIdItem, o.rowIdItem).result();
	}

	public int hashCodeJoin() {

		return Objects.hash(rowIdItem);
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		E2EStep1Key key = (E2EStep1Key) o;
		return Objects.equals(rowIdItem, key.rowIdItem);
	}

	@Override
	public int hashCode() {

		return Objects.hash(rowIdItem);
	}
}