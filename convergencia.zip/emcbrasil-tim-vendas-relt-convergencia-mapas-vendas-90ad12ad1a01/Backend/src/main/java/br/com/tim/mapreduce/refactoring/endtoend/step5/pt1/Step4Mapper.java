package br.com.tim.mapreduce.refactoring.endtoend.step5.pt1;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.parquet.Strings;

import br.com.tim.mapreduce.refactoring.endtoend.step5.model.Step4;
import br.com.tim.mapreduce.refactoring.endtoend.step5.utils.Step5Counters;

public class Step4Mapper extends Mapper<LongWritable, Text, Step5Key, Step5Value>{
	
	Step5Value outValue;
	Step4 step4;
	private Step5Key outKey;
	
	
	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
	
		this.outValue = new Step5Value();
		this.step4 = new Step4();
		this.outKey = new Step5Key();
	}
	
	@Override
	protected void map(LongWritable key, Text value, Mapper<LongWritable, Text, Step5Key, Step5Value>.Context context) throws IOException, InterruptedException{
		
		outValue.reset();
		step4.clean();
		step4.parseFromText(value);
		
		
		if (!Strings.isNullOrEmpty(step4.getNumOrdemSiebelOrig()) && !step4.getNumOrdemSiebelOrig().equals("\\N")) {
			
			
			outValue.update(TypeStep5.ORDEM, step4);
			
			outKey.setDatRef(step4.getDatref());
			outKey.setnumOrderSiebelOrig(step4.getNumOrdemSiebelOrig());
			outKey.setTipo(TypeStep5.ORDEM);
			
			context.write(outKey, outValue);
			context.getCounter(Step5Counters.STEP2_MAPPER_NUMSIEBEL_OK).increment(1l);
			context.getCounter(Step5Counters.STEP2_MAPPER_WRITE).increment(1l);

			
		}else {
			
			outValue.update(TypeStep5.ORDEM, step4);
			
			outKey.setDatRef(step4.getDatref());
			outKey.setnumOrderSiebelOrig("EMPTY");
			outKey.setTipo(TypeStep5.ORDEM);
			
			context.write(outKey, outValue);
			context.getCounter(Step5Counters.STEP2_MAPPER_WRITE).increment(1l);
			context.getCounter(Step5Counters.STEP2_MAPPER_EMPTY).increment(1l);
		}
		
	}
	

}
