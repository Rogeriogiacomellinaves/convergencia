package br.com.tim.mapreduce.refactoring.endtoend.step1.pt2.model;

import br.com.tim.mapreduce.refactoring.endtoend.step1.pt2.enums.Step1Pt1;
import br.com.tim.utils.CommonsConstants;
import com.google.common.base.Strings;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public class Step1Result implements Writable {
	
	private String datRef;
	private String codContratoOltp;
	private String codContratoAtivacao;
	private String numeroAcesso;
	private String customerId;
	private String tipoProduto;
	private String planoAtivacaoOferta;
	private String motivoChurn;
	private String tipoChurn;
	private String email;
	private String uf;
	private String tipoLogradouro;
	private String logradouro;
	private String numero;
	private String complemento;
	private String bairro;
	private String cep;
	private String cidade;
	private String tecnologia;
	private String formaPagamento;
	private String tipoConta;
	private String codBanco;
	private String codAgenciaBanco;
	private String codContaCorrente;
	private String codDebitoAutomatico;
	private String diaVencimento;
	private String codContaFinanceira;
	private String numProtocolo;
	private String flgOrdemAutomatica;
	private String dscTxRecorrente;
	private String dscTxNaoRecorrente;
	private String dscStatusItem;
	private String nomPlanoAtual;
	private String valPlanoAtualItem;
	private String nomDescontoAtualItem;
	private String valDescontoAtualItem;
	private String flgPortabilidade;
	private String dscOperadoraDoadora;
	private String codDdd;
	private String numTelefonePortado;
	private String datJanelaPortabilidade;
	private String horJanela;
	private String dscEnderecoFatura;
	private String dscAreaVoip;
	private String cpe;
	private String ont;
	private String itemRoot;
	private String dominioRoot;
	private String nroOrdem;
	private String acessoRowId;
	private String rowIdDoItemDaOrdem;
	private String codigoProduto;
	private String rowIdDoItemDaOrdemPai;
	private String categoriaItemOrdem;
	
	public Step1Result () {
		this.clean();
	}
	
	
	public void clean() {
		this.datRef= CommonsConstants.EMPTY;
		this.codContratoOltp= CommonsConstants.EMPTY;
		this.codContratoAtivacao= CommonsConstants.EMPTY;
		this.numeroAcesso= CommonsConstants.EMPTY;
		this.customerId= CommonsConstants.EMPTY;
		this.tipoProduto= CommonsConstants.EMPTY;
		this.planoAtivacaoOferta= CommonsConstants.EMPTY;
		this.motivoChurn= CommonsConstants.EMPTY;
		this.tipoChurn= CommonsConstants.EMPTY;
		this.email= CommonsConstants.EMPTY;
		this.uf= CommonsConstants.EMPTY;
		this.tipoLogradouro= CommonsConstants.EMPTY;
		this.logradouro= CommonsConstants.EMPTY;
		this.numero= CommonsConstants.EMPTY;
		this.complemento= CommonsConstants.EMPTY;
		this.bairro= CommonsConstants.EMPTY;
		this.cep= CommonsConstants.EMPTY;
		this.cidade= CommonsConstants.EMPTY;
		this.tecnologia= CommonsConstants.EMPTY;
		this.formaPagamento= CommonsConstants.EMPTY;
		this.tipoConta= CommonsConstants.EMPTY;
		this.codBanco= CommonsConstants.EMPTY;
		this.codAgenciaBanco= CommonsConstants.EMPTY;
		this.codContaCorrente= CommonsConstants.EMPTY;
		this.codDebitoAutomatico= CommonsConstants.EMPTY;
		this.diaVencimento= CommonsConstants.EMPTY;
		this.codContaFinanceira= CommonsConstants.EMPTY;
		this.numProtocolo= CommonsConstants.EMPTY;
		this.flgOrdemAutomatica= CommonsConstants.EMPTY;
		this.dscTxRecorrente= CommonsConstants.EMPTY;
		this.dscTxNaoRecorrente= CommonsConstants.EMPTY;
		this.dscStatusItem= CommonsConstants.EMPTY;
		this.nomPlanoAtual= CommonsConstants.EMPTY;
		this.valPlanoAtualItem= CommonsConstants.EMPTY;
		this.nomDescontoAtualItem= CommonsConstants.EMPTY;
		this.valDescontoAtualItem= CommonsConstants.EMPTY;
		this.flgPortabilidade= CommonsConstants.EMPTY;
		this.dscOperadoraDoadora= CommonsConstants.EMPTY;
		this.codDdd= CommonsConstants.EMPTY;
		this.numTelefonePortado= CommonsConstants.EMPTY;
		this.datJanelaPortabilidade= CommonsConstants.EMPTY;
		this.horJanela= CommonsConstants.EMPTY;
		this.dscEnderecoFatura= CommonsConstants.EMPTY;
		this.dscAreaVoip= CommonsConstants.EMPTY;
		this.cpe= CommonsConstants.EMPTY;
		this.ont= CommonsConstants.EMPTY;
		this.itemRoot= CommonsConstants.EMPTY;
		this.dominioRoot= CommonsConstants.EMPTY;
		this.nroOrdem= CommonsConstants.EMPTY;
		this.acessoRowId= CommonsConstants.EMPTY;
		this.rowIdDoItemDaOrdem= CommonsConstants.EMPTY;
		this.codigoProduto= CommonsConstants.EMPTY;
		this.rowIdDoItemDaOrdemPai= CommonsConstants.EMPTY;
		this.categoriaItemOrdem= CommonsConstants.EMPTY;
	}
	
	
	public void parseFromText(Text text) {
        this.clean();

        if(!Strings.isNullOrEmpty(text.toString())){

            String[] line = text.toString().split(CommonsConstants.FILE_SPLIT_REGEX, -1);

            if(line.length > 0){
            	
            	this.datRef = line[Step1Pt1.datRef.ordinal()].trim();
            	this.codContratoOltp  = line[Step1Pt1.codContratoOltp.ordinal()].trim();
            	this.codContratoAtivacao  = line[Step1Pt1.codContratoAtivacao.ordinal()].trim();
            	this.numeroAcesso  = line[Step1Pt1.numeroAcesso.ordinal()].trim();
            	this.customerId  = line[Step1Pt1.customerId.ordinal()].trim();
            	this.tipoProduto  = line[Step1Pt1.tipoProduto.ordinal()].trim();
            	this.planoAtivacaoOferta  = line[Step1Pt1.planoAtivacaoOferta.ordinal()].trim();
            	this.motivoChurn  = line[Step1Pt1.motivoChurn.ordinal()].trim();
            	this.tipoChurn  = line[Step1Pt1.tipoChurn.ordinal()].trim();
            	this.email  = line[Step1Pt1.email.ordinal()].trim();
            	this.uf  = line[Step1Pt1.uf.ordinal()].trim();
            	this.tipoLogradouro  = line[Step1Pt1.tipoLogradouro.ordinal()].trim();
            	this.logradouro  = line[Step1Pt1.logradouro.ordinal()].trim();
            	this.numero  = line[Step1Pt1.numero.ordinal()].trim();
            	this.complemento  = line[Step1Pt1.complemento.ordinal()].trim();
            	this.bairro  = line[Step1Pt1.bairro.ordinal()].trim();
            	this.cep  = line[Step1Pt1.cep.ordinal()].trim();
            	this.cidade  = line[Step1Pt1.cidade.ordinal()].trim();
            	this.tecnologia  = line[Step1Pt1.tecnologia.ordinal()].trim();
            	this.formaPagamento  = line[Step1Pt1.formaPagamento.ordinal()].trim();
            	this.tipoConta  = line[Step1Pt1.tipoConta.ordinal()].trim();
            	this.codBanco  = line[Step1Pt1.codBanco.ordinal()].trim();
            	this.codAgenciaBanco  = line[Step1Pt1.codAgenciaBanco.ordinal()].trim();
            	this.codContaCorrente  = line[Step1Pt1.codContaCorrente.ordinal()].trim();
            	this.codDebitoAutomatico  = line[Step1Pt1.codDebitoAutomatico.ordinal()].trim();
            	this.diaVencimento  = line[Step1Pt1.diaVencimento.ordinal()].trim();
            	this.codContaFinanceira  = line[Step1Pt1.codContaFinanceira.ordinal()].trim();
            	this.numProtocolo  = line[Step1Pt1.numProtocolo.ordinal()].trim();
            	this.flgOrdemAutomatica  = line[Step1Pt1.flgOrdemAutomatica.ordinal()].trim();
            	this.dscTxRecorrente  = line[Step1Pt1.dscTxRecorrente.ordinal()].trim();
            	this.dscTxNaoRecorrente  = line[Step1Pt1.dscTxNaoRecorrente.ordinal()].trim();
            	this.dscStatusItem  = line[Step1Pt1.dscStatusItem.ordinal()].trim();
            	this.nomPlanoAtual  = line[Step1Pt1.nomPlanoAtual.ordinal()].trim();
            	this.valPlanoAtualItem  = line[Step1Pt1.valPlanoAtualItem.ordinal()].trim();
            	this.nomDescontoAtualItem  = line[Step1Pt1.nomDescontoAtualItem.ordinal()].trim();
            	this.valDescontoAtualItem  = line[Step1Pt1.valDescontoAtualItem.ordinal()].trim();
            	this.flgPortabilidade  = line[Step1Pt1.flgPortabilidade.ordinal()].trim();
            	this.dscOperadoraDoadora  = line[Step1Pt1.dscOperadoraDoadora.ordinal()].trim();
            	this.codDdd  = line[Step1Pt1.codDdd.ordinal()].trim();
            	this.numTelefonePortado  = line[Step1Pt1.numTelefonePortado.ordinal()].trim();
            	this.datJanelaPortabilidade  = line[Step1Pt1.datJanelaPortabilidade.ordinal()].trim();
            	this.horJanela  = line[Step1Pt1.horJanela.ordinal()].trim();
            	this.dscEnderecoFatura  = line[Step1Pt1.dscEnderecoFatura.ordinal()].trim();
            	this.dscAreaVoip  = line[Step1Pt1.dscAreaVoip.ordinal()].trim();
            	this.cpe  = line[Step1Pt1.cpe.ordinal()].trim();
            	this.ont  = line[Step1Pt1.ont.ordinal()].trim();
            	this.itemRoot  = line[Step1Pt1.itemRoot.ordinal()].trim();
            	this.dominioRoot  = line[Step1Pt1.dominioRoot.ordinal()].trim();
            	this.nroOrdem  = line[Step1Pt1.nroOrdem.ordinal()].trim();
            	this.acessoRowId  = line[Step1Pt1.acessoRowId.ordinal()].trim();
            	this.rowIdDoItemDaOrdem  = line[Step1Pt1.rowIdDoItemDaOrdem.ordinal()].trim();
            	this.codigoProduto  = line[Step1Pt1.codigoProduto.ordinal()].trim();
            	this.rowIdDoItemDaOrdemPai  = line[Step1Pt1.rowIdDoItemDaOrdemPai.ordinal()].trim();
            	this.categoriaItemOrdem  = line[Step1Pt1.categoriaItemOrdem.ordinal()].trim();
            	
            }
        }
	}
            


	@Override
	public void write(DataOutput out) throws IOException {
		
		out.writeUTF(this.datRef);
		out.writeUTF(this.codContratoOltp);
		out.writeUTF(this.codContratoAtivacao);
		out.writeUTF(this.numeroAcesso);
		out.writeUTF(this.customerId);
		out.writeUTF(this.tipoProduto);
		out.writeUTF(this.planoAtivacaoOferta);
		out.writeUTF(this.motivoChurn);
		out.writeUTF(this.tipoChurn);
		out.writeUTF(this.email);
		out.writeUTF(this.uf);
		out.writeUTF(this.tipoLogradouro);
		out.writeUTF(this.logradouro);
		out.writeUTF(this.numero);
		out.writeUTF(this.complemento);
		out.writeUTF(this.bairro);
		out.writeUTF(this.cep);
		out.writeUTF(this.cidade);
		out.writeUTF(this.tecnologia);
		out.writeUTF(this.formaPagamento);
		out.writeUTF(this.tipoConta);
		out.writeUTF(this.codBanco);
		out.writeUTF(this.codAgenciaBanco);
		out.writeUTF(this.codContaCorrente);
		out.writeUTF(this.codDebitoAutomatico);
		out.writeUTF(this.diaVencimento);
		out.writeUTF(this.codContaFinanceira);
		out.writeUTF(this.numProtocolo);
		out.writeUTF(this.flgOrdemAutomatica);
		out.writeUTF(this.dscTxRecorrente);
		out.writeUTF(this.dscTxNaoRecorrente);
		out.writeUTF(this.dscStatusItem);
		out.writeUTF(this.nomPlanoAtual);
		out.writeUTF(this.valPlanoAtualItem);
		out.writeUTF(this.nomDescontoAtualItem);
		out.writeUTF(this.valDescontoAtualItem);
		out.writeUTF(this.flgPortabilidade);
		out.writeUTF(this.dscOperadoraDoadora);
		out.writeUTF(this.codDdd);
		out.writeUTF(this.numTelefonePortado);
		out.writeUTF(this.datJanelaPortabilidade);
		out.writeUTF(this.horJanela);
		out.writeUTF(this.dscEnderecoFatura);
		out.writeUTF(this.dscAreaVoip);
		out.writeUTF(this.cpe);
		out.writeUTF(this.ont);
		out.writeUTF(this.itemRoot);
		out.writeUTF(this.dominioRoot);
		out.writeUTF(this.nroOrdem);
		out.writeUTF(this.acessoRowId);
		out.writeUTF(this.rowIdDoItemDaOrdem);
		out.writeUTF(this.codigoProduto);
		out.writeUTF(this.rowIdDoItemDaOrdemPai);
		out.writeUTF(this.categoriaItemOrdem);
		
	}


	@Override
	public void readFields(DataInput in) throws IOException {
		
		this.datRef = in.readUTF();
		this.codContratoOltp = in.readUTF();
		this.codContratoAtivacao = in.readUTF();
		this.numeroAcesso = in.readUTF();
		this.customerId = in.readUTF();
		this.tipoProduto = in.readUTF();
		this.planoAtivacaoOferta = in.readUTF();
		this.motivoChurn = in.readUTF();
		this.tipoChurn = in.readUTF();
		this.email = in.readUTF();
		this.uf = in.readUTF();
		this.tipoLogradouro = in.readUTF();
		this.logradouro = in.readUTF();
		this.numero = in.readUTF();
		this.complemento = in.readUTF();
		this.bairro = in.readUTF();
		this.cep = in.readUTF();
		this.cidade = in.readUTF();
		this.tecnologia = in.readUTF();
		this.formaPagamento = in.readUTF();
		this.tipoConta = in.readUTF();
		this.codBanco = in.readUTF();
		this.codAgenciaBanco = in.readUTF();
		this.codContaCorrente = in.readUTF();
		this.codDebitoAutomatico = in.readUTF();
		this.diaVencimento = in.readUTF();
		this.codContaFinanceira = in.readUTF();
		this.numProtocolo = in.readUTF();
		this.flgOrdemAutomatica = in.readUTF();
		this.dscTxRecorrente = in.readUTF();
		this.dscTxNaoRecorrente = in.readUTF();
		this.dscStatusItem = in.readUTF();
		this.nomPlanoAtual = in.readUTF();
		this.valPlanoAtualItem = in.readUTF();
		this.nomDescontoAtualItem = in.readUTF();
		this.valDescontoAtualItem = in.readUTF();
		this.flgPortabilidade = in.readUTF();
		this.dscOperadoraDoadora = in.readUTF();
		this.codDdd = in.readUTF();
		this.numTelefonePortado = in.readUTF();
		this.datJanelaPortabilidade = in.readUTF();
		this.horJanela = in.readUTF();
		this.dscEnderecoFatura = in.readUTF();
		this.dscAreaVoip = in.readUTF();
		this.cpe = in.readUTF();
		this.ont = in.readUTF();
		this.itemRoot = in.readUTF();
		this.dominioRoot = in.readUTF();
		this.nroOrdem = in.readUTF();
		this.acessoRowId = in.readUTF();
		this.rowIdDoItemDaOrdem = in.readUTF();
		this.codigoProduto = in.readUTF();
		this.rowIdDoItemDaOrdemPai = in.readUTF();
		this.categoriaItemOrdem = in.readUTF();
		
	}


	public String getDatRef() {
		return datRef;
	}


	public void setDatRef(String datRef) {
		this.datRef = datRef;
	}


	public String getCodContratoOltp() {
		return codContratoOltp;
	}


	public void setCodContratoOltp(String codContratoOltp) {
		this.codContratoOltp = codContratoOltp;
	}


	public String getCodContratoAtivacao() {
		return codContratoAtivacao;
	}


	public void setCodContratoAtivacao(String codContratoAtivacao) {
		this.codContratoAtivacao = codContratoAtivacao;
	}


	public String getNumeroAcesso() {
		return numeroAcesso;
	}


	public void setNumeroAcesso(String numeroAcesso) {
		this.numeroAcesso = numeroAcesso;
	}


	public String getCustomerId() {
		return customerId;
	}


	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}


	public String getTipoProduto() {
		return tipoProduto;
	}


	public void setTipoProduto(String tipoProduto) {
		this.tipoProduto = tipoProduto;
	}


	public String getPlanoAtivacaoOferta() {
		return planoAtivacaoOferta;
	}


	public void setPlanoAtivacaoOferta(String planoAtivacaoOferta) {
		this.planoAtivacaoOferta = planoAtivacaoOferta;
	}


	public String getMotivoChurn() {
		return motivoChurn;
	}


	public void setMotivoChurn(String motivoChurn) {
		this.motivoChurn = motivoChurn;
	}


	public String getTipoChurn() {
		return tipoChurn;
	}


	public void setTipoChurn(String tipoChurn) {
		this.tipoChurn = tipoChurn;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getUf() {
		return uf;
	}


	public void setUf(String uf) {
		this.uf = uf;
	}


	public String getTipoLogradouro() {
		return tipoLogradouro;
	}


	public void setTipoLogradouro(String tipoLogradouro) {
		this.tipoLogradouro = tipoLogradouro;
	}


	public String getLogradouro() {
		return logradouro;
	}


	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}


	public String getNumero() {
		return numero;
	}


	public void setNumero(String numero) {
		this.numero = numero;
	}


	public String getComplemento() {
		return complemento;
	}


	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}


	public String getBairro() {
		return bairro;
	}


	public void setBairro(String bairro) {
		this.bairro = bairro;
	}


	public String getCep() {
		return cep;
	}


	public void setCep(String cep) {
		this.cep = cep;
	}


	public String getCidade() {
		return cidade;
	}


	public void setCidade(String cidade) {
		this.cidade = cidade;
	}


	public String getTecnologia() {
		return tecnologia;
	}


	public void setTecnologia(String tecnologia) {
		this.tecnologia = tecnologia;
	}


	public String getFormaPagamento() {
		return formaPagamento;
	}


	public void setFormaPagamento(String formaPagamento) {
		this.formaPagamento = formaPagamento;
	}


	public String getTipoConta() {
		return tipoConta;
	}


	public void setTipoConta(String tipoConta) {
		this.tipoConta = tipoConta;
	}


	public String getCodBanco() {
		return codBanco;
	}


	public void setCodBanco(String codBanco) {
		this.codBanco = codBanco;
	}


	public String getCodAgenciaBanco() {
		return codAgenciaBanco;
	}


	public void setCodAgenciaBanco(String codAgenciaBanco) {
		this.codAgenciaBanco = codAgenciaBanco;
	}


	public String getCodContaCorrente() {
		return codContaCorrente;
	}


	public void setCodContaCorrente(String codContaCorrente) {
		this.codContaCorrente = codContaCorrente;
	}


	public String getCodDebitoAutomatico() {
		return codDebitoAutomatico;
	}


	public void setCodDebitoAutomatico(String codDebitoAutomatico) {
		this.codDebitoAutomatico = codDebitoAutomatico;
	}


	public String getDiaVencimento() {
		return diaVencimento;
	}


	public void setDiaVencimento(String diaVencimento) {
		this.diaVencimento = diaVencimento;
	}


	public String getCodContaFinanceira() {
		return codContaFinanceira;
	}


	public void setCodContaFinanceira(String codContaFinanceira) {
		this.codContaFinanceira = codContaFinanceira;
	}


	public String getNumProtocolo() {
		return numProtocolo;
	}


	public void setNumProtocolo(String numProtocolo) {
		this.numProtocolo = numProtocolo;
	}


	public String getFlgOrdemAutomatica() {
		return flgOrdemAutomatica;
	}


	public void setFlgOrdemAutomatica(String flgOrdemAutomatica) {
		this.flgOrdemAutomatica = flgOrdemAutomatica;
	}


	public String getDscTxRecorrente() {
		return dscTxRecorrente;
	}


	public void setDscTxRecorrente(String dscTxRecorrente) {
		this.dscTxRecorrente = dscTxRecorrente;
	}


	public String getDscTxNaoRecorrente() {
		return dscTxNaoRecorrente;
	}


	public void setDscTxNaoRecorrente(String dscTxNaoRecorrente) {
		this.dscTxNaoRecorrente = dscTxNaoRecorrente;
	}


	public String getDscStatusItem() {
		return dscStatusItem;
	}


	public void setDscStatusItem(String dscStatusItem) {
		this.dscStatusItem = dscStatusItem;
	}


	public String getNomPlanoAtual() {
		return nomPlanoAtual;
	}


	public void setNomPlanoAtual(String nomPlanoAtual) {
		this.nomPlanoAtual = nomPlanoAtual;
	}


	public String getValPlanoAtualItem() {
		return valPlanoAtualItem;
	}


	public void setValPlanoAtualItem(String valPlanoAtualItem) {
		this.valPlanoAtualItem = valPlanoAtualItem;
	}


	public String getNomDescontoAtualItem() {
		return nomDescontoAtualItem;
	}


	public void setNomDescontoAtualItem(String nomDescontoAtualItem) {
		this.nomDescontoAtualItem = nomDescontoAtualItem;
	}


	public String getValDescontoAtualItem() {
		return valDescontoAtualItem;
	}


	public void setValDescontoAtualItem(String valDescontoAtualItem) {
		this.valDescontoAtualItem = valDescontoAtualItem;
	}


	public String getFlgPortabilidade() {
		return flgPortabilidade;
	}


	public void setFlgPortabilidade(String flgPortabilidade) {
		this.flgPortabilidade = flgPortabilidade;
	}


	public String getDscOperadoraDoadora() {
		return dscOperadoraDoadora;
	}


	public void setDscOperadoraDoadora(String dscOperadoraDoadora) {
		this.dscOperadoraDoadora = dscOperadoraDoadora;
	}


	public String getCodDdd() {
		return codDdd;
	}


	public void setCodDdd(String codDdd) {
		this.codDdd = codDdd;
	}


	public String getNumTelefonePortado() {
		return numTelefonePortado;
	}


	public void setNumTelefonePortado(String numTelefonePortado) {
		this.numTelefonePortado = numTelefonePortado;
	}


	public String getDatJanelaPortabilidade() {
		return datJanelaPortabilidade;
	}


	public void setDatJanelaPortabilidade(String datJanelaPortabilidade) {
		this.datJanelaPortabilidade = datJanelaPortabilidade;
	}


	public String getHorJanela() {
		return horJanela;
	}


	public void setHorJanela(String horJanela) {
		this.horJanela = horJanela;
	}


	public String getDscEnderecoFatura() {
		return dscEnderecoFatura;
	}


	public void setDscEnderecoFatura(String dscEnderecoFatura) {
		this.dscEnderecoFatura = dscEnderecoFatura;
	}


	public String getDscAreaVoip() {
		return dscAreaVoip;
	}


	public void setDscAreaVoip(String dscAreaVoip) {
		this.dscAreaVoip = dscAreaVoip;
	}


	public String getCpe() {
		return cpe;
	}


	public void setCpe(String cpe) {
		this.cpe = cpe;
	}


	public String getOnt() {
		return ont;
	}


	public void setOnt(String ont) {
		this.ont = ont;
	}


	public String getItemRoot() {
		return itemRoot;
	}


	public void setItemRoot(String itemRoot) {
		this.itemRoot = itemRoot;
	}


	public String getDominioRoot() {
		return dominioRoot;
	}


	public void setDominioRoot(String dominioRoot) {
		this.dominioRoot = dominioRoot;
	}


	public String getNroOrdem() {
		return nroOrdem;
	}


	public void setNroOrdem(String nroOrdem) {
		this.nroOrdem = nroOrdem;
	}


	public String getAcessoRowId() {
		return acessoRowId;
	}


	public void setAcessoRowId(String acessoRowId) {
		this.acessoRowId = acessoRowId;
	}


	public String getRowIdDoItemDaOrdem() {
		return rowIdDoItemDaOrdem;
	}


	public void setRowIdDoItemDaOrdem(String rowIdDoItemDaOrdem) {
		this.rowIdDoItemDaOrdem = rowIdDoItemDaOrdem;
	}


	public String getCodigoProduto() {
		return codigoProduto;
	}


	public void setCodigoProduto(String codigoProduto) {
		this.codigoProduto = codigoProduto;
	}


	public String getRowIdDoItemDaOrdemPai() {
		return rowIdDoItemDaOrdemPai;
	}


	public void setRowIdDoItemDaOrdemPai(String rowIdDoItemDaOrdemPai) {
		this.rowIdDoItemDaOrdemPai = rowIdDoItemDaOrdemPai;
	}


	public String getCategoriaItemOrdem() {
		return categoriaItemOrdem;
	}


	public void setCategoriaItemOrdem(String categoriaItemOrdem) {
		this.categoriaItemOrdem = categoriaItemOrdem;
	}
	
	

}
