package br.com.tim.mapreduce.refactoring.endtoend.step4.pt1;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Objects;

import com.google.common.collect.ComparisonChain;

import br.com.tim.mapreduce.refactoring.endtoend.GroupComparable;

public class Step4Key implements GroupComparable<Step4Key>{
	
	private String rowIdOrdem;
	private String datRef;
	private TypeStep4 tipo;
	
	@Override
	public void write(DataOutput out) throws IOException {
		
		out.writeInt(tipo.ordinal());
		out.writeUTF(this.rowIdOrdem);
		out.writeUTF(this.datRef);
		
	}
	@Override
	public void readFields(DataInput in) throws IOException {
		// TODO Auto-generated method stub
		this.tipo  = TypeStep4.values()[in.readInt()];
		this.rowIdOrdem = in.readUTF();
		this.datRef = in.readUTF();
	}
	
	
	public String getRowIdOrdem() {
		return rowIdOrdem;
	}
	public void setRowIdOrdem(String rowIdOrdem) {
		this.rowIdOrdem = rowIdOrdem;
	}
	public String getDatRef() {
		return datRef;
	}
	public void setDatRef(String datRef) {
		this.datRef = datRef;
	}
	public TypeStep4 getTipo() {
		return tipo;
	}
	public void setTipo(TypeStep4 tipo) {
		this.tipo = tipo;
	}
	
	@Override
	public int compareTo(Step4Key o) {
		return ComparisonChain.start().compare(this.rowIdOrdem, o.rowIdOrdem).compare(this.tipo, o.tipo).compare(this.datRef, o.datRef)
				.result();
	}
	@Override
	public int compareToGrouping(Step4Key o) {
		return ComparisonChain.start().compare(this.rowIdOrdem, o.rowIdOrdem).result();
	}
	
	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		Step4Key key = (Step4Key) o;
		return Objects.equals(rowIdOrdem, key.rowIdOrdem);
	}


	public int hashCodeJoin() {

		return Objects.hash(rowIdOrdem);
	}

	@Override
	public int hashCode() {

		return Objects.hash(rowIdOrdem);
	}
	
}
