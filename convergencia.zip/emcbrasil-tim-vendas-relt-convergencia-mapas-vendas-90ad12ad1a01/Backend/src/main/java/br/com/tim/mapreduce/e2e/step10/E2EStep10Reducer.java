package br.com.tim.mapreduce.e2e.step10;

import java.io.IOException;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.log4j.Logger;

public class E2EStep10Reducer extends org.apache.hadoop.mapreduce.Reducer<E2EStep10Key,E2EStep10Value,NullWritable,Text>{
	protected static final Logger LOG = Logger.getLogger(E2EStep10Reducer.class);
    private E2EStep10OutValue outValue;
    
    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        super.setup(context);
        outValue = new E2EStep10OutValue();
    }

    @Override
    protected void reduce(E2EStep10Key key, Iterable<E2EStep10Value> values, Context context) throws InterruptedException {
    	outValue.clear();
    	
    	try {
    		
    		for(E2EStep10Value value : values) {
    			
    			if (value.getTipo().equals(TypeStep10.RELT)) {
    				
    				outValue.clearRelt();
    				outValue.setRelt(value);
    				   				
    				context.write(NullWritable.get(), new Text(outValue.toString()));
    			}else if(value.getTipo().equals(TypeStep10.WFMTOA)) {
    				
    				outValue.clearWfmtoa();
    				outValue.setWfmtoa(value);
    				
    			}
    		}
    		
    	}catch (Exception e) {
            LOG.error(" ############ ERROR EXECUTION REDUCER ############ ");
            LOG.error(e.getMessage());
            throw new InterruptedException(e.getMessage());
        }
    }
    
    @Override
    protected void cleanup(Context context) throws IOException, InterruptedException {
        super.cleanup(context);

    }

}
