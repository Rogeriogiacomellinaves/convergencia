package br.com.tim.mapreduce.e2e.step1;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class E2EStep1Reducer
		extends org.apache.hadoop.mapreduce.Reducer<E2EStep1Key, E2EStep1Value, NullWritable, Text> {

	protected static final Logger LOG = Logger.getLogger(E2EStep1Reducer.class);
	private E2EStep1OutValue outValue;
	private List<String> codigos;
	private boolean isLive;
	private List<String> rootList;
	private List<E2EStep1PlanoValue> planoList;
	private List<E2EStep1DescontoValue> descontoList;
	private List<E2EStep1OutValue> saidas;
	private List<E2EStep1OutValue> churnList;
	private double tx_recorrente;
	private double tx_nao_recorrente;
	
	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		super.setup(context);
		outValue = new E2EStep1OutValue();
		outValue.clear();
		this.codigos = Arrays.asList("DSC165", "DSC166", "DSC167", "DSC169", "FDL002", "FDL003", "FDL004", "PCT366",
				"PLN451", "PLN452", "PLN453", "PLN457", "PLN458", "PLN459", "PLN220", "PLN221", "DSC110", "DSC111",
				"PLN454", "PLN455", "PLN456");
		rootList = new ArrayList<String>();
		planoList = new ArrayList<E2EStep1PlanoValue>();
		saidas = new ArrayList<E2EStep1OutValue>();
		churnList = new ArrayList<E2EStep1OutValue>();
		descontoList = new ArrayList<E2EStep1DescontoValue>();
		tx_recorrente = 0;
		tx_nao_recorrente = 0;
	}

	@Override
	protected void reduce(E2EStep1Key key, Iterable<E2EStep1Value> values, Context context)
			throws InterruptedException {

		isLive = false;
		clear();
		
		try {
			
			for (E2EStep1Value value : values) {

				if (value.getTipo().equals(TypeStep1.HIST)) {
					outValue.setItem(value);
					
					churnList.add(outValue);
					outValue = new E2EStep1OutValue();
					outValue.clear();
					
				} else if (value.getTipo().equals(TypeStep1.ROOT)) {
					
					rootList.add(value.getRowIdDoItemDaOrdem());
					
				} else if (value.getTipo().equals(TypeStep1.PLANO)) {
					
					planoList.add(new E2EStep1PlanoValue(value));
					
				} else if (value.getTipo().equals(TypeStep1.DESCONTO)) {
					
					descontoList.add(new E2EStep1DescontoValue(value));

				} else if (value.getTipo().equals(TypeStep1.LIVE)) {
					if(isLive) {
						outValue = new E2EStep1OutValue();
						outValue.clear();
					}
					
					if (value.getMotivoStatus().toUpperCase().trim().equals("ATIVAÇÃO") 
							|| (rootList.contains(value.getRowIdDoItemDaOrdemRoot()))
							|| (value.getMotivoStatus().trim().equals(""))) {
						
						outValue.clearItem();
						outValue.setItem(value);
						
						for(E2EStep1PlanoValue plan : planoList) {
							if(plan.getRowIdDoItemDaOrdemPai().equals(value.getRowIdDoItemDaOrdem())) {
								outValue.clearPlanoAtivacaoOferta();
								outValue.setPlanoAtivacaoOferta(plan);
							}
						}
						
						for(E2EStep1OutValue churn : churnList) {
							if(outValue.getNumeroAcesso().equals(churn.getNumeroAcesso())) {
								outValue.setMotivoChurn(churn.getMotivoChurn());
								outValue.setTipoChurn(churn.getMotivoChurn());
							}
						}
						
						for(E2EStep1DescontoValue des : descontoList) {
							if(des.getRowIdDoItemDaOrdemPai().equals(value.getRowIdDoItemDaOrdem())) {
								if(outValue.getValDescontoAtualItem().trim().equals("")) {
									outValue.setValDescontoAtualItem(des.getValDescontoAtual());
								}else {
									outValue.setValDescontoAtualItem(outValue.getValDescontoAtualItem() + "\\" + des.getValDescontoAtual());
								}
								
								
								if(outValue.getNomDescontoAtualItem().trim().equals("")) {
									outValue.setNomDescontoAtualItem(des.getNomDescontoAtual());
								}else {
									outValue.setNomDescontoAtualItem(outValue.getNomDescontoAtualItem() + "\\" + des.getNomDescontoAtual());
								}
							}
						}
						
						try {
							tx_recorrente += Double.parseDouble(value.getDscTxRecorrente());
							tx_nao_recorrente += Double.parseDouble(value.getDscTxNaoRecorrente());
						}catch(Exception ex) {
							
						}
						
						
						saidas.add(outValue);
						isLive = true;
					}

				} else if (value.getTipo().equals(TypeStep1.MOVEL)) {
					if (isLive) {
						outValue.clearItem();
						outValue.setItem(value);
						
						for(E2EStep1PlanoValue plan : planoList) {
							if(plan.getRowIdDoItemDaOrdemPai().equals(value.getRowIdDoItemDaOrdem())) {
								outValue.clearPlanoAtivacaoOferta();
								outValue.setPlanoAtivacaoOferta(plan);
							}
						}
						
						for(E2EStep1OutValue churn : churnList) {
							if(outValue.getNumeroAcesso().equals(churn.getNumeroAcesso())) {
								outValue.setMotivoChurn(churn.getMotivoChurn());
								outValue.setTipoChurn(churn.getMotivoChurn());
							}
						}
						
						for(E2EStep1DescontoValue des : descontoList) {
							if(des.getRowIdDoItemDaOrdemPai().equals(value.getRowIdDoItemDaOrdem())) {
								if(outValue.getValDescontoAtualItem().trim().equals("")) {
									outValue.setValDescontoAtualItem(des.getValDescontoAtual());
								}else {
									outValue.setValDescontoAtualItem(outValue.getValDescontoAtualItem() + "\\" + des.getValDescontoAtual());
								}
								
								
								if(outValue.getValDescontoAtualItem().trim().equals("")) {
									outValue.setNomDescontoAtualItem(des.getNomDescontoAtual());
								}else {
									outValue.setNomDescontoAtualItem(outValue.getNomDescontoAtualItem() + "\\" + des.getNomDescontoAtual());
								}
							}
						}
						
						try {
							tx_recorrente += Double.parseDouble(value.getDscTxRecorrente());
							tx_nao_recorrente += Double.parseDouble(value.getDscTxNaoRecorrente());
						}catch(Exception ex) {
							
						}
						
						saidas.add(outValue);
						outValue = new E2EStep1OutValue();
						outValue.clear();
					}else {
						for(E2EStep1PlanoValue plan : planoList) {
							if(codigos.contains(plan.getCodigoProduto().toUpperCase().trim())
									&& plan.getRowIdDoItemDaOrdemPai().equals(value.getRowIdDoItemDaOrdem())) {
								outValue.clearItem();
								outValue.setItem(value);
								
								outValue.clearPlanoAtivacaoOferta();
								outValue.setPlanoAtivacaoOferta(plan);
								
								for(E2EStep1OutValue churn : churnList) {
									if(outValue.getNumeroAcesso().equals(churn.getNumeroAcesso())) {
										outValue.setMotivoChurn(churn.getMotivoChurn());
										outValue.setTipoChurn(churn.getMotivoChurn());
									}
								}
								
								for(E2EStep1DescontoValue des : descontoList) {
									if(des.getRowIdDoItemDaOrdemPai().equals(value.getRowIdDoItemDaOrdem())) {
										if(outValue.getValDescontoAtualItem().trim().equals("")) {
											outValue.setValDescontoAtualItem(des.getValDescontoAtual());
										}else {
											outValue.setValDescontoAtualItem(outValue.getValDescontoAtualItem() + "\\" + des.getValDescontoAtual());
										}
										
										
										if(outValue.getValDescontoAtualItem().trim().equals("")) {
											outValue.setNomDescontoAtualItem(des.getNomDescontoAtual());
										}else {
											outValue.setNomDescontoAtualItem(outValue.getNomDescontoAtualItem() + "\\" + des.getNomDescontoAtual());
										}
									}
								}
								
								try {
									tx_recorrente += Double.parseDouble(value.getDscTxRecorrente());
									tx_nao_recorrente += Double.parseDouble(value.getDscTxNaoRecorrente());
								}catch(Exception ex) {
									
								}
								
								saidas.add(outValue);
								outValue = new E2EStep1OutValue();
								outValue.clear();
							}
						}
					}
				}

				
			}
			
			for(E2EStep1OutValue saida :saidas ) {
				saida.setDscTxRecorrente(String.valueOf(tx_recorrente));
				saida.setDscTxNaoRecorrente(String.valueOf(tx_nao_recorrente));
				context.write(NullWritable.get(), new Text(saida.toString()));
			}

		} catch (Exception e) {
			LOG.error(" ############ ERROR EXECUTION REDUCER ############ ");
			e.printStackTrace();
			throw new InterruptedException(e.getMessage());
		}
	}
	

	@Override
	protected void cleanup(Context context) throws IOException, InterruptedException {
		super.cleanup(context);

	}
	
	protected void clear() {
		outValue.clear();
		rootList.clear();
		planoList.clear();
		saidas.clear();
		churnList.clear();
		descontoList.clear();
		tx_recorrente = 0;
		tx_nao_recorrente = 0;
		isLive = false;
	}
}
