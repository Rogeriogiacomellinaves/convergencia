package br.com.tim.mapreduce.refactoring.endtoend.step4.utils;

import java.text.SimpleDateFormat;

public class Step4Constants {

	
	public static final String STEP4 = "STEP4";
	public static final String ORDEM = "ORDEM";
	public static final String STEP4PT1 = "STEP4PT1";

	
	public static final String DAT_REF = "DAT_REF";
	
	/**
	 * yyyy-MM-dd hh:mm:ss
	 */
	public static final String YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
	/**
	 * yyyy-MM-dd hh:mm:ss.s
	 *
	 */
	public static final String YYYY_MM_DD_HH_MM_SS_S = "yyyy-MM-dd HH:mm:ss.s";
	/**
	 * yyyyMMddHHmmss
	 */
	public static final String YYYYMMDD_HHMMSS = "yyyyMMddHHmmss";
	/**
	 * yyMMdd
	 */
	public static final String YYMMDD = "yyMMdd";
	/**
	 * yyyyMM
	 */
	public static final String YYYYMM = "yyyyMM";
	/**
	 * yyyyMMdd
	 */
	public static final String YYYYMMDD = "yyyyMMdd";
	/**
	 * yyMMddHHmmss
	 */
	public static final String YYMMDD_HHMMSS = "yyMMddHHmmss";
	/**
	 * yyyy-MM-dd
	 */
	public static final String YYYY_MM_DD = "yyyy-MM-dd";
	/**
	 * MM/DD/YYYY
	 */
	public static final SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	public static final String MM_DD_YYYY = "MM/DD/YYYY";

	public static final String YY_MM_DD = "yyMMdd";
	
	
	public static final String STEP4_PROCESS_ID = "process-id";
	public static final String MAPA_HIST_FACT_INPUT = "mapa-hist-fact-input";
	public static final String MAPA_HIST_FACT_PARTITION = "mapa-hist-fact-partition";
	
	
	public static final String STEP4_STAGING_OUTPUT = "output-path-step4";
	
	
	public static final String STEP4PT2_PROCESS_ID = "process-id";
	public static final String STEP4PT2_FACT_INPUT = "step4pt1-fact-input";
	
	public static final String ORDEM_FACT_INPUT = "ordem-fact-input";
	public static final String ORDEM_FACT_PARTITION = "ordem-fact-partition";
	
	
	public static final String STEP4PT2_STAGING_OUTPUT = "output-path-step4pt2";
	
	
	
	
}
