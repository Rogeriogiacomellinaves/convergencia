package br.com.tim.mapreduce.e2e.step2;

import br.com.tim.mapreduce.e2e.GroupComparable;
import com.google.common.collect.ComparisonChain;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Objects;


public class E2EStep2Key implements GroupComparable<E2EStep2Key> {

	private String nroOrdem;
	private String datRef;
	private TypeStep2 tipo;

	@Override
	public void write(DataOutput output) throws IOException {
		output.writeInt(tipo.ordinal());
		output.writeUTF(this.nroOrdem);
		output.writeUTF(this.datRef);
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		this.tipo = TypeStep2.values()[in.readInt()];
		this.nroOrdem = in.readUTF();
		this.datRef = in.readUTF();
	}

	public String getNroOrdem() {
		return nroOrdem;
	}

	public void setNroOrdem(String nroOrdem) {
		this.nroOrdem = nroOrdem;
	}

	public void setDatRef(String datRef){this.datRef = datRef;}

	public void setTipo(TypeStep2 tipo) {
		this.tipo = tipo;
	}

	@Override
	public int compareTo(E2EStep2Key o) {
		return ComparisonChain.start().compare(this.nroOrdem, o.nroOrdem).compare(this.tipo, o.tipo).compare(this.datRef, o.datRef)
				.result();
	}

	@Override
	public int compareToGrouping(E2EStep2Key o) {
		return ComparisonChain.start().compare(this.nroOrdem, o.nroOrdem).result();
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		E2EStep2Key key = (E2EStep2Key) o;
		return Objects.equals(nroOrdem, key.nroOrdem);
	}

	public int hashCodeJoin() {

		return Objects.hash(nroOrdem);
	}

	@Override
	public int hashCode() {

		return Objects.hash(nroOrdem);
	}
}