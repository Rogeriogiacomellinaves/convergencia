package br.com.tim.mapreduce.refactoring.endtoend.step4.pt2;


import java.util.TreeSet;

import org.apache.parquet.Strings;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import br.com.tim.utils.CommonsConstants;

public class Step4Pt2OutValue {
	
	/**
	 * BAT509Order
	 * Step4Pt1Result
	 */

	public static final String DELIMITER = CommonsConstants.FILE_FIELD_SEPARATOR;
	
	private String datref;
	private String datCriacaoOrdem;
	private String horaCriacaoDaOrdem;
	private String datVenda;
	private String horaDaVenda;
	private String datStatusOrdem;
	private String hrStatusOrdem;
	private String numOrdemSiebel;
	private String numOrdemSiebelOrig;
	private String codContratoOltp;
	private String codContratoAtivacao;
	private String numeroAcesso;
	private String customerId;
	private String tipoDocumento;
	private String documento;
	private String tipoVenda;
	private String tipoProduto;
	private String velocidadeDownload;
	private String velocidadeUpload;
	private String planoAtivacaoOferta;
	private String loginVendedor;
	private String canal;
	private String cnpjParceiro;
	private String custcode;
	private String position;
	private String flgCancAntesVenda;
	private String flgCancPosVenda;
	private String dtCancVenda;
	private String motivoCancelamento;
	private String nomeCliente;
	private String telefone;
	private String emailFatura;
	private String uf;
	private String tipoLogradouro;
	private String logradouro;
	private String numero;
	private String complemento;
	private String bairro;
	private String cep;
	private String cidade;
	private String statusOrdem;
	private String tecnologia;
	private String formaPagamento;
	private String tipoConta;
	private String codBanco;
	private String codAgengiaBco;
	private String codContaCorrente;
	private String codDebitoAutomatico;
	private String diaVencimento;
	private String semanaVenda;
	private String score;
	private String scoreConsumido;
	private String dtFinalizacaoOrdem;
	private String qdeContratos;
	private String numProtocolo;
	private String flgOrdemAutomatica;
	private String dscTxRecorrente;
	private String dscTxNaoRecorrente;
	private String dscStatusItem;
	private String nomLoginResponsavel;
	private String flgPortabilidade;
	private String dscOperadoraDoadora;
	private String codDdd;
	private String numTelefonePortado;
	private String datJanelaPortabilidade;
	private String horaDaJanela;
	private String dscEnderecoFatura;
	private String dscAreaVoip;
	private String cpe;
	private String ont;
	private String codigoConvergente;
	private String detalheRecusaCrivo;
	private String itemRoot;
	private String loginCancelamentoOrdem;
	private String custcodeCliente;
	private String dominioRoot;
	private String codContFinanceira;
	private String valPlanoAtualItem;
	private String nomDescontoAtualItem;
	private String valDescontoAtualItem;
	private String nroOrdem;
	private String acessoRowId;
	private String acessoRowIdRoot;
	private String codigoProduto;
	private String flgVendaSubmetida;
	private String flgVendaDuplicada;
	private String flgVendaBruta;
	private String flgVendaLiquida;
	private String flgCancDupl;
	private String flgCancLiquido;
	private String nomeParceiroVenda;
	private String nomeParceiroVendaOrig;
	private String rowIdItemOrdem;
	private String rowIdItemOrdemPai;
	private String categoriaItemOrder;
	private String msanOltVenda;
	private String dtConclusaoWfm;
	private String dscStatusOrdemWfm;
	private String datStatusWfm;
	private String horaStatusWfm;
	private String idRecursoWfm;
	private String nomRecursoWfm;
	private String idRecursoPaiWfm;
	private String datPrimeiroAgend;
	private String horaPrimeiroAgendamento;
	private String datAgendAtual;
	private String horaAgendamentoAtual;
	private String dscStatusAtivacao;
	private String msanOltTrafego;
	private String datVendaOrig;
	private String horaVendaOrig;
	private String loginVendedorOrig;
	private String canalOrig;
	private String cnpjParceiroOrig;
	private String custcodeOrig;
	private String positionOrig;
	private String semanaVendaOrig;
	private String codContratoAtual;
	private String nomPlanoAtual;
	private String nomeVendedorOrig;
	private String flVendaDuplicada;
	private String flGross;
	private String dtGross;
	private String flChurn;
	private String dtChurn;
	private String motivoChurn;
	private String codOrdemChurn;
	private String tipoChurn;
	private String dtCriacaoOrdemChurn;
	private String dtConclusaoOrdemChurn;
	private String nomeVendedor;
	private String nomeUsuarioCancOrdem;
	private String emailCliente;


    private TreeSet<String> dupl = new TreeSet<String>();
    private TreeSet<String> brut = new TreeSet<String>();
    private boolean definido;
    private int contflg0;
    private int contflg1;

    DateTimeFormatter dtf = DateTimeFormat.forPattern("MM/dd/yyyy HH:mm:ss");

    public void clear(){
    	this.datref = CommonsConstants.EMPTY;
		this.datCriacaoOrdem = CommonsConstants.EMPTY;
		this.horaCriacaoDaOrdem = CommonsConstants.EMPTY;
		this.datVenda = CommonsConstants.EMPTY;
		this.horaDaVenda = CommonsConstants.EMPTY;
		this.datStatusOrdem = CommonsConstants.EMPTY;
		this.hrStatusOrdem = CommonsConstants.EMPTY;
		this.numOrdemSiebel = CommonsConstants.EMPTY;
		this.numOrdemSiebelOrig = CommonsConstants.EMPTY;
		this.codContratoOltp = CommonsConstants.EMPTY;
		this.codContratoAtivacao = CommonsConstants.EMPTY;
		this.numeroAcesso = CommonsConstants.EMPTY;
		this.customerId = CommonsConstants.EMPTY;
		this.tipoDocumento = CommonsConstants.EMPTY;
		this.documento = CommonsConstants.EMPTY;
		this.tipoVenda = CommonsConstants.EMPTY;
		this.tipoProduto = CommonsConstants.EMPTY;
		this.velocidadeDownload = CommonsConstants.EMPTY;
		this.velocidadeUpload = CommonsConstants.EMPTY;
		this.planoAtivacaoOferta = CommonsConstants.EMPTY;
		this.loginVendedor = CommonsConstants.EMPTY;
		this.canal = CommonsConstants.EMPTY;
		this.cnpjParceiro = CommonsConstants.EMPTY;
		this.custcode = CommonsConstants.EMPTY;
		this.position = CommonsConstants.EMPTY;
		this.flgCancAntesVenda = CommonsConstants.EMPTY;
		this.flgCancPosVenda = CommonsConstants.EMPTY;
		this.dtCancVenda = CommonsConstants.EMPTY;
		this.motivoCancelamento = CommonsConstants.EMPTY;
		this.nomeCliente = CommonsConstants.EMPTY;
		this.telefone = CommonsConstants.EMPTY;
		this.emailFatura = CommonsConstants.EMPTY;
		this.uf = CommonsConstants.EMPTY;
		this.tipoLogradouro = CommonsConstants.EMPTY;
		this.logradouro = CommonsConstants.EMPTY;
		this.numero = CommonsConstants.EMPTY;
		this.complemento = CommonsConstants.EMPTY;
		this.bairro = CommonsConstants.EMPTY;
		this.cep = CommonsConstants.EMPTY;
		this.cidade = CommonsConstants.EMPTY;
		this.statusOrdem = CommonsConstants.EMPTY;
		this.tecnologia = CommonsConstants.EMPTY;
		this.formaPagamento = CommonsConstants.EMPTY;
		this.tipoConta = CommonsConstants.EMPTY;
		this.codBanco = CommonsConstants.EMPTY;
		this.codAgengiaBco = CommonsConstants.EMPTY;
		this.codContaCorrente = CommonsConstants.EMPTY;
		this.codDebitoAutomatico = CommonsConstants.EMPTY;
		this.diaVencimento = CommonsConstants.EMPTY;
		this.semanaVenda = CommonsConstants.EMPTY;
		this.score = CommonsConstants.EMPTY;
		this.scoreConsumido = CommonsConstants.EMPTY;
		this.dtFinalizacaoOrdem = CommonsConstants.EMPTY;
		this.qdeContratos = CommonsConstants.EMPTY;
		this.numProtocolo = CommonsConstants.EMPTY;
		this.flgOrdemAutomatica = CommonsConstants.EMPTY;
		this.dscTxRecorrente = CommonsConstants.EMPTY;
		this.dscTxNaoRecorrente = CommonsConstants.EMPTY;
		this.dscStatusItem = CommonsConstants.EMPTY;
		this.nomLoginResponsavel = CommonsConstants.EMPTY;
		this.flgPortabilidade = CommonsConstants.EMPTY;
		this.dscOperadoraDoadora = CommonsConstants.EMPTY;
		this.codDdd = CommonsConstants.EMPTY;
		this.numTelefonePortado = CommonsConstants.EMPTY;
		this.datJanelaPortabilidade = CommonsConstants.EMPTY;
		this.horaDaJanela = CommonsConstants.EMPTY;
		this.dscEnderecoFatura = CommonsConstants.EMPTY;
		this.dscAreaVoip = CommonsConstants.EMPTY;
		this.cpe = CommonsConstants.EMPTY;
		this.ont = CommonsConstants.EMPTY;
		this.codigoConvergente = CommonsConstants.EMPTY;
		this.detalheRecusaCrivo = CommonsConstants.EMPTY;
		this.itemRoot = CommonsConstants.EMPTY;
		this.loginCancelamentoOrdem = CommonsConstants.EMPTY;
		this.custcodeCliente = CommonsConstants.EMPTY;
		this.dominioRoot = CommonsConstants.EMPTY;
		this.codContFinanceira = CommonsConstants.EMPTY;
		this.valPlanoAtualItem = CommonsConstants.EMPTY;
		this.nomDescontoAtualItem = CommonsConstants.EMPTY;
		this.valDescontoAtualItem = CommonsConstants.EMPTY;
		this.nroOrdem = CommonsConstants.EMPTY;
		this.acessoRowId = CommonsConstants.EMPTY;
		this.acessoRowIdRoot = CommonsConstants.EMPTY;
		this.codigoProduto = CommonsConstants.EMPTY;
		this.flgVendaSubmetida = CommonsConstants.EMPTY;
		this.flgVendaDuplicada = CommonsConstants.EMPTY;
		this.flgVendaBruta = CommonsConstants.EMPTY;
		this.flgVendaLiquida = CommonsConstants.EMPTY;
		this.flgCancDupl = CommonsConstants.EMPTY;
		this.flgCancLiquido = CommonsConstants.EMPTY;
		this.nomeParceiroVenda = CommonsConstants.EMPTY;
		this.nomeParceiroVendaOrig = CommonsConstants.EMPTY;
		this.rowIdItemOrdem = CommonsConstants.EMPTY;
		this.rowIdItemOrdemPai = CommonsConstants.EMPTY;
		this.categoriaItemOrder = CommonsConstants.EMPTY;
		this.datVendaOrig = CommonsConstants.EMPTY;
		this.horaVendaOrig = CommonsConstants.EMPTY;
		this.loginVendedorOrig = CommonsConstants.EMPTY;
		this.canalOrig = CommonsConstants.EMPTY;
		this.cnpjParceiroOrig = CommonsConstants.EMPTY;
		this.custcodeOrig = CommonsConstants.EMPTY;
		this.positionOrig = CommonsConstants.EMPTY;
		this.semanaVendaOrig = CommonsConstants.EMPTY;
		this.codContratoAtual = CommonsConstants.EMPTY;
		this.nomPlanoAtual = CommonsConstants.EMPTY;
		this.nomeVendedorOrig = CommonsConstants.EMPTY;
		this.flVendaDuplicada = CommonsConstants.EMPTY;
		this.flGross = CommonsConstants.EMPTY;
		this.dtGross = CommonsConstants.EMPTY;
		this.flChurn = CommonsConstants.EMPTY;
		this.dtChurn = CommonsConstants.EMPTY;
		this.motivoChurn = CommonsConstants.EMPTY;
		this.codOrdemChurn = CommonsConstants.EMPTY;
		this.tipoChurn = CommonsConstants.EMPTY;
		this.dtCriacaoOrdemChurn = CommonsConstants.EMPTY;
		this.dtConclusaoOrdemChurn = CommonsConstants.EMPTY;
		this.msanOltVenda = CommonsConstants.EMPTY;
		this.dtConclusaoWfm = CommonsConstants.EMPTY;
		this.dscStatusOrdemWfm = CommonsConstants.EMPTY;
		this.datStatusWfm = CommonsConstants.EMPTY;
		this.horaStatusWfm = CommonsConstants.EMPTY;
		this.idRecursoWfm = CommonsConstants.EMPTY;
		this.nomRecursoWfm = CommonsConstants.EMPTY;
		this.idRecursoPaiWfm = CommonsConstants.EMPTY;
		this.datPrimeiroAgend = CommonsConstants.EMPTY;
		this.horaPrimeiroAgendamento = CommonsConstants.EMPTY;
		this.datAgendAtual = CommonsConstants.EMPTY;
		this.horaAgendamentoAtual = CommonsConstants.EMPTY;
		this.dscStatusAtivacao = CommonsConstants.EMPTY;
		this.msanOltTrafego = CommonsConstants.EMPTY;
		this.nomeVendedor = CommonsConstants.EMPTY;
		this.nomeUsuarioCancOrdem = CommonsConstants.EMPTY;
		this.emailCliente = CommonsConstants.EMPTY;
        dupl.clear();
        brut.clear();
        definido = false;
        contflg0 = 0;
        contflg1 = 1;

    }

    public void clearRelt(){
    	this.datref = CommonsConstants.EMPTY;
		this.numOrdemSiebel = CommonsConstants.EMPTY;
		this.numOrdemSiebelOrig = CommonsConstants.EMPTY;
		this.codContratoOltp = CommonsConstants.EMPTY;
		this.codContratoAtivacao = CommonsConstants.EMPTY;
		this.numeroAcesso = CommonsConstants.EMPTY;
		this.customerId = CommonsConstants.EMPTY;
		this.tipoProduto = CommonsConstants.EMPTY;
		this.velocidadeDownload = CommonsConstants.EMPTY;
		this.velocidadeUpload = CommonsConstants.EMPTY;
		this.planoAtivacaoOferta = CommonsConstants.EMPTY;
		this.emailFatura = CommonsConstants.EMPTY;
		this.uf = CommonsConstants.EMPTY;
		this.tipoLogradouro = CommonsConstants.EMPTY;
		this.logradouro = CommonsConstants.EMPTY;
		this.numero = CommonsConstants.EMPTY;
		this.complemento = CommonsConstants.EMPTY;
		this.bairro = CommonsConstants.EMPTY;
		this.cep = CommonsConstants.EMPTY;
		this.cidade = CommonsConstants.EMPTY;
		this.tecnologia = CommonsConstants.EMPTY;
		this.formaPagamento = CommonsConstants.EMPTY;
		this.tipoConta = CommonsConstants.EMPTY;
		this.codBanco = CommonsConstants.EMPTY;
		this.codAgengiaBco = CommonsConstants.EMPTY;
		this.codContaCorrente = CommonsConstants.EMPTY;
		this.codDebitoAutomatico = CommonsConstants.EMPTY;
		this.diaVencimento = CommonsConstants.EMPTY;
		this.numProtocolo = CommonsConstants.EMPTY;
		this.flgOrdemAutomatica = CommonsConstants.EMPTY;
		this.dscTxRecorrente = CommonsConstants.EMPTY;
		this.dscTxNaoRecorrente = CommonsConstants.EMPTY;
		this.dscStatusItem = CommonsConstants.EMPTY;
		this.flgPortabilidade = CommonsConstants.EMPTY;
		this.dscOperadoraDoadora = CommonsConstants.EMPTY;
		this.codDdd = CommonsConstants.EMPTY;
		this.numTelefonePortado = CommonsConstants.EMPTY;
		this.datJanelaPortabilidade = CommonsConstants.EMPTY;
		this.horaDaJanela = CommonsConstants.EMPTY;
		this.dscEnderecoFatura = CommonsConstants.EMPTY;
		this.dscAreaVoip = CommonsConstants.EMPTY;
		this.cpe = CommonsConstants.EMPTY;
		this.ont = CommonsConstants.EMPTY;
		this.codigoConvergente = CommonsConstants.EMPTY;
		this.itemRoot = CommonsConstants.EMPTY;
		this.custcodeCliente = CommonsConstants.EMPTY;
		this.dominioRoot = CommonsConstants.EMPTY;
		this.codContFinanceira = CommonsConstants.EMPTY;
		this.valPlanoAtualItem = CommonsConstants.EMPTY;
		this.nomDescontoAtualItem = CommonsConstants.EMPTY;
		this.valDescontoAtualItem = CommonsConstants.EMPTY;
		this.nroOrdem = CommonsConstants.EMPTY;
		this.acessoRowId = CommonsConstants.EMPTY;
		this.acessoRowIdRoot = CommonsConstants.EMPTY;
		this.codigoProduto = CommonsConstants.EMPTY;
		this.flgVendaDuplicada = CommonsConstants.EMPTY;
		this.flgVendaBruta = CommonsConstants.EMPTY;
		this.flgVendaLiquida = CommonsConstants.EMPTY;
		this.flgCancDupl = CommonsConstants.EMPTY;
		this.flgCancLiquido = CommonsConstants.EMPTY;
		this.nomeParceiroVendaOrig = CommonsConstants.EMPTY;
		this.rowIdItemOrdem = CommonsConstants.EMPTY;
		this.rowIdItemOrdemPai = CommonsConstants.EMPTY;
		this.categoriaItemOrder = CommonsConstants.EMPTY;
		this.datVendaOrig = CommonsConstants.EMPTY;
		this.horaVendaOrig = CommonsConstants.EMPTY;
		this.loginVendedorOrig = CommonsConstants.EMPTY;
		this.canalOrig = CommonsConstants.EMPTY;
		this.cnpjParceiroOrig = CommonsConstants.EMPTY;
		this.custcodeOrig = CommonsConstants.EMPTY;
		this.positionOrig = CommonsConstants.EMPTY;
		this.semanaVendaOrig = CommonsConstants.EMPTY;
		this.codContratoAtual = CommonsConstants.EMPTY;
		this.nomPlanoAtual = CommonsConstants.EMPTY;
		this.nomeVendedorOrig = CommonsConstants.EMPTY;
		this.flVendaDuplicada = CommonsConstants.EMPTY;
		this.flGross = CommonsConstants.EMPTY;
		this.dtGross = CommonsConstants.EMPTY;
		this.flChurn = CommonsConstants.EMPTY;
		this.dtChurn = CommonsConstants.EMPTY;
		this.motivoChurn = CommonsConstants.EMPTY;
		this.codOrdemChurn = CommonsConstants.EMPTY;
		this.tipoChurn = CommonsConstants.EMPTY;
		this.dtCriacaoOrdemChurn = CommonsConstants.EMPTY;
		this.dtConclusaoOrdemChurn = CommonsConstants.EMPTY;
		this.msanOltVenda = CommonsConstants.EMPTY;
		this.dtConclusaoWfm = CommonsConstants.EMPTY;
		this.dscStatusOrdemWfm = CommonsConstants.EMPTY;
		this.datStatusWfm = CommonsConstants.EMPTY;
		this.horaStatusWfm = CommonsConstants.EMPTY;
		this.idRecursoWfm = CommonsConstants.EMPTY;
		this.nomRecursoWfm = CommonsConstants.EMPTY;
		this.idRecursoPaiWfm = CommonsConstants.EMPTY;
		this.datPrimeiroAgend = CommonsConstants.EMPTY;
		this.horaPrimeiroAgendamento = CommonsConstants.EMPTY;
		this.datAgendAtual = CommonsConstants.EMPTY;
		this.horaAgendamentoAtual = CommonsConstants.EMPTY;
		this.dscStatusAtivacao = CommonsConstants.EMPTY;
		this.msanOltTrafego = CommonsConstants.EMPTY;
		this.nomeVendedor = CommonsConstants.EMPTY;
		this.nomeUsuarioCancOrdem = CommonsConstants.EMPTY;
		this.emailCliente = CommonsConstants.EMPTY;
    }

    public void setRelt(Step4Pt2Value v) {
    	this.datref = v.getDatref();
		this.datCriacaoOrdem = Strings.isNullOrEmpty(this.datCriacaoOrdem) ? v.getDatCriacaoOrdem(): this.datCriacaoOrdem;
        this.horaCriacaoDaOrdem = Strings.isNullOrEmpty(this.horaCriacaoDaOrdem) ? v.getHoraCriacaoDaOrdem():this.horaCriacaoDaOrdem;
        this.datVenda = Strings.isNullOrEmpty(this.datVenda) ? v.getDatVenda():this.datVenda;
        this.horaDaVenda = Strings.isNullOrEmpty(this.horaDaVenda) ? v.getHoraDaVenda():this.horaDaVenda;
        this.datStatusOrdem = Strings.isNullOrEmpty(this.datStatusOrdem) ? v.getDatStatusOrdem():this.datStatusOrdem;
        this.hrStatusOrdem = Strings.isNullOrEmpty(this.hrStatusOrdem) ? v.getHrStatusOrdem():this.hrStatusOrdem;
		this.numOrdemSiebel = v.getNumOrdemSiebel();
		this.numOrdemSiebelOrig = v.getNumOrdemSiebelOrig();
		this.codContratoOltp = v.getCodContratoOltp();
		this.codContratoAtivacao = v.getCodContratoAtivacao();
		this.numeroAcesso = v.getNumeroAcesso();
		this.customerId = v.getCustomerId();
        this.tipoDocumento = Strings.isNullOrEmpty(this.tipoDocumento) ? v.getTipoDocumento():this.tipoDocumento;
        this.documento = Strings.isNullOrEmpty(this.documento) ? v.getDocumento():this.documento;
        this.tipoVenda = Strings.isNullOrEmpty(this.tipoVenda) ? v.getTipoVenda():this.tipoVenda;
		this.tipoProduto = v.getTipoProduto();
		this.velocidadeDownload = v.getVelocidadeDownload();
		this.velocidadeUpload = v.getVelocidadeUpload();
		this.planoAtivacaoOferta = v.getPlanoAtivacaoOferta();
        this.loginVendedor = Strings.isNullOrEmpty(this.loginVendedor) ? v.getLoginVendedor():this.loginVendedor;
        this.canal = Strings.isNullOrEmpty(this.canal) ? v.getCanal():this.canal;
        this.cnpjParceiro = Strings.isNullOrEmpty(this.cnpjParceiro) ? v.getCnpjParceiro():this.cnpjParceiro;
        this.custcode = Strings.isNullOrEmpty(this.custcode) ? v.getCustcode():this.custcode;
        this.position = Strings.isNullOrEmpty(this.position) ? v.getPosition():this.position;
        this.flgCancAntesVenda = Strings.isNullOrEmpty(this.flgCancAntesVenda) ? v.getFlgCancAntesVenda():this.flgCancAntesVenda;
        this.statusOrdem = Strings.isNullOrEmpty(this.statusOrdem) ? v.getStatusOrdem():this.statusOrdem;
        if (this.statusOrdem.equals("Cancelado") && !Strings.isNullOrEmpty(this.datVenda)) {
        	this.flgCancPosVenda = "1";
        }else {
            this.flgCancPosVenda = "0";
        }
        this.dtCancVenda = Strings.isNullOrEmpty(this.dtCancVenda) ? v.getDtCancVenda():this.dtCancVenda;
        this.motivoCancelamento = Strings.isNullOrEmpty(this.motivoCancelamento) ? v.getMotivoCancelamento():this.motivoCancelamento;
        this.nomeCliente = Strings.isNullOrEmpty(this.nomeCliente) ? v.getNomeCliente():this.nomeCliente;
        this.telefone = Strings.isNullOrEmpty(this.telefone) ? v.getTelefone():this.telefone;
		this.emailFatura = v.getEmailFatura();
		this.uf = v.getUf();
		this.tipoLogradouro = v.getTipoLogradouro();
		this.logradouro = v.getLogradouro();
		this.numero = v.getNumero();
		this.complemento = v.getComplemento();
		this.bairro = v.getBairro();
		this.cep = v.getCep();
		this.cidade = v.getCidade();
		this.tecnologia = v.getTecnologia();
		this.formaPagamento = v.getFormaPagamento();
		this.tipoConta = v.getTipoConta();
		this.codBanco = v.getCodBanco();
		this.codAgengiaBco = v.getCodAgengiaBco();
		this.codContaCorrente = v.getCodContaCorrente();
		this.codDebitoAutomatico = v.getCodDebitoAutomatico();
		this.diaVencimento = v.getDiaVencimento();
        this.semanaVenda = Strings.isNullOrEmpty(this.semanaVenda) ? v.getSemanaVenda():this.semanaVenda;
        this.score = Strings.isNullOrEmpty(this.score) ? v.getScore():this.score;
        this.scoreConsumido = Strings.isNullOrEmpty(this.scoreConsumido) ? v.getScoreConsumido():this.scoreConsumido;
        this.dtFinalizacaoOrdem = Strings.isNullOrEmpty(this.dtFinalizacaoOrdem) ? v.getDtFinalizacaoOrdem():this.dtFinalizacaoOrdem;
        this.qdeContratos = Strings.isNullOrEmpty(this.qdeContratos) ? v.getQdeContratos():this.qdeContratos;
		this.numProtocolo = v.getNumProtocolo();
		this.flgOrdemAutomatica = v.getFlgOrdemAutomatica();
		this.dscTxRecorrente = v.getDscTxRecorrente();
		this.dscTxNaoRecorrente = v.getDscTxNaoRecorrente();
		this.dscStatusItem = v.getDscStatusItem();
        this.nomLoginResponsavel = Strings.isNullOrEmpty(this.nomLoginResponsavel) ? v.getNomLoginResponsavel():this.nomLoginResponsavel;
		this.flgPortabilidade = v.getFlgPortabilidade();
		this.dscOperadoraDoadora = v.getDscOperadoraDoadora();
		this.codDdd = v.getCodDdd();
		this.numTelefonePortado = v.getNumTelefonePortado();
		this.datJanelaPortabilidade = v.getDatJanelaPortabilidade();
		this.horaDaJanela = v.getHoraDaJanela();
		this.dscEnderecoFatura = v.getDscEnderecoFatura();
		this.dscAreaVoip = v.getDscAreaVoip();
		this.cpe = v.getCpe();
		this.ont = v.getOnt();
		this.codigoConvergente = v.getCodigoConvergente();
        this.detalheRecusaCrivo = Strings.isNullOrEmpty(this.detalheRecusaCrivo) ? v.getDetalheRecusaCrivo():this.detalheRecusaCrivo;
		this.itemRoot = v.getItemRoot();
        this.loginCancelamentoOrdem = Strings.isNullOrEmpty(this.loginCancelamentoOrdem) ? v.getLoginCancelamentoOrdem():this.loginCancelamentoOrdem;
		this.custcodeCliente = v.getCustcodeCliente();
		this.dominioRoot = v.getDominioRoot();
		this.codContFinanceira = v.getCodContFinanceira();
		this.valPlanoAtualItem = v.getValPlanoAtualItem();
		this.nomDescontoAtualItem = v.getNomDescontoAtualItem();
		this.valDescontoAtualItem = v.getValDescontoAtualItem();
		this.nroOrdem = v.getNroOrdem();
		this.acessoRowId = v.getAcessoRowId();
		this.acessoRowIdRoot = v.getAcessoRowIdRoot();
		this.codigoProduto = v.getCodigoProduto();
		this.flgVendaSubmetida = Strings.isNullOrEmpty(this.flgVendaSubmetida) ? v.getFlgVendaSubmetida() : this.flgVendaSubmetida;
		this.flgVendaDuplicada = v.getFlgVendaDuplicada();
		this.flgVendaBruta = v.getFlgVendaBruta();
		this.flgVendaLiquida = v.getFlgVendaLiquida();
		this.flgCancDupl = v.getFlgCancDupl();
		this.flgCancLiquido = v.getFlgCancLiquido();
        this.nomeParceiroVenda = Strings.isNullOrEmpty(this.nomeParceiroVenda) ? v.getNomeParceiroVenda():this.nomeParceiroVenda;
        this.nomeParceiroVendaOrig = v.getNomeParceiroVendaOrig();
		this.rowIdItemOrdem = v.getRowIdItemOrdem();
		this.rowIdItemOrdemPai = v.getRowIdItemOrdemPai();
		this.categoriaItemOrder = v.getCategoriaItemOrder();
		this.msanOltVenda = v.getMsanOltVenda();
		this.dtConclusaoWfm = v.getDtConclusaoWfm();
		this.dscStatusOrdemWfm = v.getDscStatusOrdemWfm();
		this.datStatusWfm = v.getDatStatusWfm();
		this.horaStatusWfm = v.getHoraStatusWfm();
		this.idRecursoWfm = v.getIdRecursoWfm();
		this.nomRecursoWfm = v.getNomRecursoWfm();
		this.idRecursoPaiWfm = v.getIdRecursoPaiWfm();
		this.datPrimeiroAgend = v.getDatPrimeiroAgend();
		this.horaPrimeiroAgendamento = v.getHoraPrimeiroAgendamento();
		this.datAgendAtual = v.getDatAgendAtual();
		this.horaAgendamentoAtual = v.getHoraAgendamentoAtual();
		this.dscStatusAtivacao = v.getDscStatusAtivacao();
		this.msanOltTrafego = v.getMsanOltTrafego();
		this.datVendaOrig = v.getDatVendaOrig();
		this.horaVendaOrig = v.getHoraVendaOrig();
		this.loginVendedorOrig = v.getLoginVendedorOrig();
		this.canalOrig = v.getCanalOrig();
		this.cnpjParceiroOrig = v.getCnpjParceiroOrig();
		this.custcodeOrig = v.getCustcodeOrig();
		this.positionOrig = v.getPositionOrig();
		this.semanaVendaOrig = v.getSemanaVendaOrig();
		this.codContratoAtual = v.getCodContratoAtual();
		this.nomPlanoAtual = v.getNomPlanoAtual();
		this.nomeVendedorOrig = v.getNomeVendedorOrig();
		this.flVendaDuplicada = v.getFlVendaDuplicada();
		this.flGross = v.getFlGross();
		this.dtGross = v.getDtGross();
		this.flChurn = v.getFlChurn();
		this.dtChurn = v.getDtChurn();
		this.motivoChurn = v.getMotivoChurn();
		this.codOrdemChurn = v.getCodOrdemChurn();
		this.tipoChurn = v.getTipoChurn();
		this.dtCriacaoOrdemChurn = v.getDtCriacaoOrdemChurn();
		this.dtConclusaoOrdemChurn = v.getDtConclusaoOrdemChurn();
		this.nomeVendedor = v.getNomeVendedor();
		this.nomeUsuarioCancOrdem = v.getNomeUsuarioCancOrdem();
		this.emailCliente = v.getEmailCliente();
    }

    public void setOrdem(Step4Pt2Value ordem) {
        this.datCriacaoOrdem = ordem.getDatCriacaoOrdem();
        this.horaCriacaoDaOrdem = ordem.getHoraCriacaoDaOrdem();
        this.datVenda = ordem.getDatVenda();
        this.horaDaVenda = ordem.getHoraDaVenda();
        this.datStatusOrdem = ordem.getDatStatusOrdem();
        this.hrStatusOrdem = ordem.getHrStatusOrdem();
        this.numOrdemSiebel = ordem.getNumOrdemSiebel();
        this.tipoDocumento = ordem.getTipoDocumento();
        this.documento = ordem.getDocumento();
        this.tipoVenda = ordem.getTipoVenda();
        this.loginVendedor = ordem.getLoginVendedor();
        this.canal = ordem.getCanal();
        this.cnpjParceiro = ordem.getCnpjParceiro();
        this.custcode = ordem.getCustcode();
        this.position = ordem.getPosition();
        this.flgCancAntesVenda = ordem.getFlgCancAntesVenda();
        this.flgVendaSubmetida = ordem.getFlgVendaSubmetida();
        this.flgCancPosVenda = ordem.getFlgCancPosVenda();
        this.dtCancVenda = ordem.getDtCancVenda();
        this.motivoCancelamento = ordem.getMotivoCancelamento();
        this.nomeCliente = ordem.getNomeCliente();
        this.telefone = ordem.getTelefone();
        this.statusOrdem = ordem.getStatusOrdem();
        this.semanaVenda = ordem.getSemanaVenda();
        this.score = ordem.getScore();
        this.scoreConsumido = ordem.getScoreConsumido();
        this.dtFinalizacaoOrdem = ordem.getDtFinalizacaoOrdem();
        this.qdeContratos = ordem.getQdeContratos();
        this.nomLoginResponsavel = ordem.getNomLoginResponsavel();
        this.detalheRecusaCrivo = ordem.getDetalheRecusaCrivo();
        this.loginCancelamentoOrdem = ordem.getLoginCancelamentoOrdem();
        this.nomeParceiroVenda = ordem.getNomeParceiroVenda();
    }

	public String getDatref() {
		return datref;
	}

	public void setDatref(String datref) {
		this.datref = datref;
	}

	public String getDatCriacaoOrdem() {
		return datCriacaoOrdem;
	}

	public void setDatCriacaoOrdem(String datCriacaoOrdem) {
		this.datCriacaoOrdem = datCriacaoOrdem;
	}

	public String getHoraCriacaoDaOrdem() {
		return horaCriacaoDaOrdem;
	}

	public void setHoraCriacaoDaOrdem(String horaCriacaoDaOrdem) {
		this.horaCriacaoDaOrdem = horaCriacaoDaOrdem;
	}

	public String getDatVenda() {
		return datVenda;
	}

	public void setDatVenda(String datVenda) {
		this.datVenda = datVenda;
	}

	public String getHoraDaVenda() {
		return horaDaVenda;
	}

	public void setHoraDaVenda(String horaDaVenda) {
		this.horaDaVenda = horaDaVenda;
	}

	public String getDatStatusOrdem() {
		return datStatusOrdem;
	}

	public void setDatStatusOrdem(String datStatusOrdem) {
		this.datStatusOrdem = datStatusOrdem;
	}

	public String getHrStatusOrdem() {
		return hrStatusOrdem;
	}

	public void setHrStatusOrdem(String hrStatusOrdem) {
		this.hrStatusOrdem = hrStatusOrdem;
	}

	public String getNumOrdemSiebel() {
		return numOrdemSiebel;
	}

	public void setNumOrdemSiebel(String numOrdemSiebel) {
		this.numOrdemSiebel = numOrdemSiebel;
	}

	public String getNumOrdemSiebelOrig() {
		return numOrdemSiebelOrig;
	}

	public void setNumOrdemSiebelOrig(String numOrdemSiebelOrig) {
		this.numOrdemSiebelOrig = numOrdemSiebelOrig;
	}

	public String getCodContratoOltp() {
		return codContratoOltp;
	}

	public void setCodContratoOltp(String codContratoOltp) {
		this.codContratoOltp = codContratoOltp;
	}

	public String getCodContratoAtivacao() {
		return codContratoAtivacao;
	}

	public void setCodContratoAtivacao(String codContratoAtivacao) {
		this.codContratoAtivacao = codContratoAtivacao;
	}

	public String getNumeroAcesso() {
		return numeroAcesso;
	}

	public void setNumeroAcesso(String numeroAcesso) {
		this.numeroAcesso = numeroAcesso;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public String getDocumento() {
		return documento;
	}

	public void setDocumento(String documento) {
		this.documento = documento;
	}

	public String getTipoVenda() {
		return tipoVenda;
	}

	public void setTipoVenda(String tipoVenda) {
		this.tipoVenda = tipoVenda;
	}

	public String getTipoProduto() {
		return tipoProduto;
	}

	public void setTipoProduto(String tipoProduto) {
		this.tipoProduto = tipoProduto;
	}

	public String getVelocidadeDownload() {
		return velocidadeDownload;
	}

	public void setVelocidadeDownload(String velocidadeDownload) {
		this.velocidadeDownload = velocidadeDownload;
	}

	public String getVelocidadeUpload() {
		return velocidadeUpload;
	}

	public void setVelocidadeUpload(String velocidadeUpload) {
		this.velocidadeUpload = velocidadeUpload;
	}

	public String getPlanoAtivacaoOferta() {
		return planoAtivacaoOferta;
	}

	public void setPlanoAtivacaoOferta(String planoAtivacaoOferta) {
		this.planoAtivacaoOferta = planoAtivacaoOferta;
	}

	public String getLoginVendedor() {
		return loginVendedor;
	}

	public void setLoginVendedor(String loginVendedor) {
		this.loginVendedor = loginVendedor;
	}

	public String getCanal() {
		return canal;
	}

	public void setCanal(String canal) {
		this.canal = canal;
	}

	public String getCnpjParceiro() {
		return cnpjParceiro;
	}

	public void setCnpjParceiro(String cnpjParceiro) {
		this.cnpjParceiro = cnpjParceiro;
	}

	public String getCustcode() {
		return custcode;
	}

	public void setCustcode(String custcode) {
		this.custcode = custcode;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getFlgCancAntesVenda() {
		return flgCancAntesVenda;
	}

	public void setFlgCancAntesVenda(String flgCancAntesVenda) {
		this.flgCancAntesVenda = flgCancAntesVenda;
	}

	public String getFlgCancPosVenda() {
		return flgCancPosVenda;
	}

	public void setFlgCancPosVenda(String flgCancPosVenda) {
		this.flgCancPosVenda = flgCancPosVenda;
	}

	public String getDtCancVenda() {
		return dtCancVenda;
	}

	public void setDtCancVenda(String dtCancVenda) {
		this.dtCancVenda = dtCancVenda;
	}

	public String getMotivoCancelamento() {
		return motivoCancelamento;
	}

	public void setMotivoCancelamento(String motivoCancelamento) {
		this.motivoCancelamento = motivoCancelamento;
	}

	public String getNomeCliente() {
		return nomeCliente;
	}

	public void setNomeCliente(String nomeCliente) {
		this.nomeCliente = nomeCliente;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getEmailFatura() {
		return emailFatura;
	}

	public void setEmailFatura(String emailFatura) {
		this.emailFatura = emailFatura;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	public String getTipoLogradouro() {
		return tipoLogradouro;
	}

	public void setTipoLogradouro(String tipoLogradouro) {
		this.tipoLogradouro = tipoLogradouro;
	}

	public String getLogradouro() {
		return logradouro;
	}

	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getComplemento() {
		return complemento;
	}

	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getStatusOrdem() {
		return statusOrdem;
	}

	public void setStatusOrdem(String statusOrdem) {
		this.statusOrdem = statusOrdem;
	}

	public String getTecnologia() {
		return tecnologia;
	}

	public void setTecnologia(String tecnologia) {
		this.tecnologia = tecnologia;
	}

	public String getFormaPagamento() {
		return formaPagamento;
	}

	public void setFormaPagamento(String formaPagamento) {
		this.formaPagamento = formaPagamento;
	}

	public String getTipoConta() {
		return tipoConta;
	}

	public void setTipoConta(String tipoConta) {
		this.tipoConta = tipoConta;
	}

	public String getCodBanco() {
		return codBanco;
	}

	public void setCodBanco(String codBanco) {
		this.codBanco = codBanco;
	}

	public String getCodAgengiaBco() {
		return codAgengiaBco;
	}

	public void setCodAgengiaBco(String codAgengiaBco) {
		this.codAgengiaBco = codAgengiaBco;
	}

	public String getCodContaCorrente() {
		return codContaCorrente;
	}

	public void setCodContaCorrente(String codContaCorrente) {
		this.codContaCorrente = codContaCorrente;
	}

	public String getCodDebitoAutomatico() {
		return codDebitoAutomatico;
	}

	public void setCodDebitoAutomatico(String codDebitoAutomatico) {
		this.codDebitoAutomatico = codDebitoAutomatico;
	}

	public String getDiaVencimento() {
		return diaVencimento;
	}

	public void setDiaVencimento(String diaVencimento) {
		this.diaVencimento = diaVencimento;
	}

	public String getSemanaVenda() {
		return semanaVenda;
	}

	public void setSemanaVenda(String semanaVenda) {
		this.semanaVenda = semanaVenda;
	}

	public String getScore() {
		return score;
	}

	public void setScore(String score) {
		this.score = score;
	}

	public String getScoreConsumido() {
		return scoreConsumido;
	}

	public void setScoreConsumido(String scoreConsumido) {
		this.scoreConsumido = scoreConsumido;
	}

	public String getDtFinalizacaoOrdem() {
		return dtFinalizacaoOrdem;
	}

	public void setDtFinalizacaoOrdem(String dtFinalizacaoOrdem) {
		this.dtFinalizacaoOrdem = dtFinalizacaoOrdem;
	}

	public String getQdeContratos() {
		return qdeContratos;
	}

	public void setQdeContratos(String qdeContratos) {
		this.qdeContratos = qdeContratos;
	}

	public String getNumProtocolo() {
		return numProtocolo;
	}

	public void setNumProtocolo(String numProtocolo) {
		this.numProtocolo = numProtocolo;
	}

	public String getFlgOrdemAutomatica() {
		return flgOrdemAutomatica;
	}

	public void setFlgOrdemAutomatica(String flgOrdemAutomatica) {
		this.flgOrdemAutomatica = flgOrdemAutomatica;
	}

	public String getDscTxRecorrente() {
		return dscTxRecorrente;
	}

	public void setDscTxRecorrente(String dscTxRecorrente) {
		this.dscTxRecorrente = dscTxRecorrente;
	}

	public String getDscTxNaoRecorrente() {
		return dscTxNaoRecorrente;
	}

	public void setDscTxNaoRecorrente(String dscTxNaoRecorrente) {
		this.dscTxNaoRecorrente = dscTxNaoRecorrente;
	}

	public String getDscStatusItem() {
		return dscStatusItem;
	}

	public void setDscStatusItem(String dscStatusItem) {
		this.dscStatusItem = dscStatusItem;
	}

	public String getNomLoginResponsavel() {
		return nomLoginResponsavel;
	}

	public void setNomLoginResponsavel(String nomLoginResponsavel) {
		this.nomLoginResponsavel = nomLoginResponsavel;
	}

	public String getFlgPortabilidade() {
		return flgPortabilidade;
	}

	public void setFlgPortabilidade(String flgPortabilidade) {
		this.flgPortabilidade = flgPortabilidade;
	}

	public String getDscOperadoraDoadora() {
		return dscOperadoraDoadora;
	}

	public void setDscOperadoraDoadora(String dscOperadoraDoadora) {
		this.dscOperadoraDoadora = dscOperadoraDoadora;
	}

	public String getCodDdd() {
		return codDdd;
	}

	public void setCodDdd(String codDdd) {
		this.codDdd = codDdd;
	}

	public String getNumTelefonePortado() {
		return numTelefonePortado;
	}

	public void setNumTelefonePortado(String numTelefonePortado) {
		this.numTelefonePortado = numTelefonePortado;
	}

	public String getDatJanelaPortabilidade() {
		return datJanelaPortabilidade;
	}

	public void setDatJanelaPortabilidade(String datJanelaPortabilidade) {
		this.datJanelaPortabilidade = datJanelaPortabilidade;
	}

	public String getHoraDaJanela() {
		return horaDaJanela;
	}

	public void setHoraDaJanela(String horaDaJanela) {
		this.horaDaJanela = horaDaJanela;
	}

	public String getDscEnderecoFatura() {
		return dscEnderecoFatura;
	}

	public void setDscEnderecoFatura(String dscEnderecoFatura) {
		this.dscEnderecoFatura = dscEnderecoFatura;
	}

	public String getDscAreaVoip() {
		return dscAreaVoip;
	}

	public void setDscAreaVoip(String dscAreaVoip) {
		this.dscAreaVoip = dscAreaVoip;
	}

	public String getCpe() {
		return cpe;
	}

	public void setCpe(String cpe) {
		this.cpe = cpe;
	}

	public String getOnt() {
		return ont;
	}

	public void setOnt(String ont) {
		this.ont = ont;
	}

	public String getCodigoConvergente() {
		return codigoConvergente;
	}

	public void setCodigoConvergente(String codigoConvergente) {
		this.codigoConvergente = codigoConvergente;
	}

	public String getDetalheRecusaCrivo() {
		return detalheRecusaCrivo;
	}

	public void setDetalheRecusaCrivo(String detalheRecusaCrivo) {
		this.detalheRecusaCrivo = detalheRecusaCrivo;
	}

	public String getItemRoot() {
		return itemRoot;
	}

	public void setItemRoot(String itemRoot) {
		this.itemRoot = itemRoot;
	}

	public String getLoginCancelamentoOrdem() {
		return loginCancelamentoOrdem;
	}

	public void setLoginCancelamentoOrdem(String loginCancelamentoOrdem) {
		this.loginCancelamentoOrdem = loginCancelamentoOrdem;
	}

	public String getCustcodeCliente() {
		return custcodeCliente;
	}

	public void setCustcodeCliente(String custcodeCliente) {
		this.custcodeCliente = custcodeCliente;
	}

	public String getDominioRoot() {
		return dominioRoot;
	}

	public void setDominioRoot(String dominioRoot) {
		this.dominioRoot = dominioRoot;
	}

	public String getCodContFinanceira() {
		return codContFinanceira;
	}

	public void setCodContFinanceira(String codContFinanceira) {
		this.codContFinanceira = codContFinanceira;
	}

	public String getValPlanoAtualItem() {
		return valPlanoAtualItem;
	}

	public void setValPlanoAtualItem(String valPlanoAtualItem) {
		this.valPlanoAtualItem = valPlanoAtualItem;
	}

	public String getNomDescontoAtualItem() {
		return nomDescontoAtualItem;
	}

	public void setNomDescontoAtualItem(String nomDescontoAtualItem) {
		this.nomDescontoAtualItem = nomDescontoAtualItem;
	}

	public String getValDescontoAtualItem() {
		return valDescontoAtualItem;
	}

	public void setValDescontoAtualItem(String valDescontoAtualItem) {
		this.valDescontoAtualItem = valDescontoAtualItem;
	}

	public String getNroOrdem() {
		return nroOrdem;
	}

	public void setNroOrdem(String nroOrdem) {
		this.nroOrdem = nroOrdem;
	}

	public String getAcessoRowId() {
		return acessoRowId;
	}

	public void setAcessoRowId(String acessoRowId) {
		this.acessoRowId = acessoRowId;
	}

	public String getAcessoRowIdRoot() {
		return acessoRowIdRoot;
	}

	public void setAcessoRowIdRoot(String acessoRowIdRoot) {
		this.acessoRowIdRoot = acessoRowIdRoot;
	}

	public String getCodigoProduto() {
		return codigoProduto;
	}

	public void setCodigoProduto(String codigoProduto) {
		this.codigoProduto = codigoProduto;
	}

	public String getFlgVendaSubmetida() {
		return flgVendaSubmetida;
	}

	public void setFlgVendaSubmetida(String flgVendaSubmetida) {
		this.flgVendaSubmetida = flgVendaSubmetida;
	}

	public String getFlgVendaDuplicada() {
		return flgVendaDuplicada;
	}

	public void setFlgVendaDuplicada(String flgVendaDuplicada) {
		this.flgVendaDuplicada = flgVendaDuplicada;
	}

	public String getFlgVendaBruta() {
		return flgVendaBruta;
	}

	public void setFlgVendaBruta(String flgVendaBruta) {
		this.flgVendaBruta = flgVendaBruta;
	}

	public String getFlgVendaLiquida() {
		return flgVendaLiquida;
	}

	public void setFlgVendaLiquida(String flgVendaLiquida) {
		this.flgVendaLiquida = flgVendaLiquida;
	}

	public String getFlgCancDupl() {
		return flgCancDupl;
	}

	public void setFlgCancDupl(String flgCancDupl) {
		this.flgCancDupl = flgCancDupl;
	}

	public String getFlgCancLiquido() {
		return flgCancLiquido;
	}

	public void setFlgCancLiquido(String flgCancLiquido) {
		this.flgCancLiquido = flgCancLiquido;
	}

	public String getNomeParceiroVenda() {
		return nomeParceiroVenda;
	}

	public void setNomeParceiroVenda(String nomeParceiroVenda) {
		this.nomeParceiroVenda = nomeParceiroVenda;
	}

	public String getNomeParceiroVendaOrig() {
		return nomeParceiroVendaOrig;
	}

	public void setNomeParceiroVendaOrig(String nomeParceiroVendaOrig) {
		this.nomeParceiroVendaOrig = nomeParceiroVendaOrig;
	}

	public String getRowIdItemOrdem() {
		return rowIdItemOrdem;
	}

	public void setRowIdItemOrdem(String rowIdItemOrdem) {
		this.rowIdItemOrdem = rowIdItemOrdem;
	}

	public String getRowIdItemOrdemPai() {
		return rowIdItemOrdemPai;
	}

	public void setRowIdItemOrdemPai(String rowIdItemOrdemPai) {
		this.rowIdItemOrdemPai = rowIdItemOrdemPai;
	}

	public String getCategoriaItemOrder() {
		return categoriaItemOrder;
	}

	public void setCategoriaItemOrder(String categoriaItemOrder) {
		this.categoriaItemOrder = categoriaItemOrder;
	}

	public String getMsanOltVenda() {
		return msanOltVenda;
	}

	public void setMsanOltVenda(String msanOltVenda) {
		this.msanOltVenda = msanOltVenda;
	}

	public String getDtConclusaoWfm() {
		return dtConclusaoWfm;
	}

	public void setDtConclusaoWfm(String dtConclusaoWfm) {
		this.dtConclusaoWfm = dtConclusaoWfm;
	}

	public String getDscStatusOrdemWfm() {
		return dscStatusOrdemWfm;
	}

	public void setDscStatusOrdemWfm(String dscStatusOrdemWfm) {
		this.dscStatusOrdemWfm = dscStatusOrdemWfm;
	}

	public String getDatStatusWfm() {
		return datStatusWfm;
	}

	public void setDatStatusWfm(String datStatusWfm) {
		this.datStatusWfm = datStatusWfm;
	}

	public String getHoraStatusWfm() {
		return horaStatusWfm;
	}

	public void setHoraStatusWfm(String horaStatusWfm) {
		this.horaStatusWfm = horaStatusWfm;
	}

	public String getIdRecursoWfm() {
		return idRecursoWfm;
	}

	public void setIdRecursoWfm(String idRecursoWfm) {
		this.idRecursoWfm = idRecursoWfm;
	}

	public String getNomRecursoWfm() {
		return nomRecursoWfm;
	}

	public void setNomRecursoWfm(String nomRecursoWfm) {
		this.nomRecursoWfm = nomRecursoWfm;
	}

	public String getIdRecursoPaiWfm() {
		return idRecursoPaiWfm;
	}

	public void setIdRecursoPaiWfm(String idRecursoPaiWfm) {
		this.idRecursoPaiWfm = idRecursoPaiWfm;
	}

	public String getDatPrimeiroAgend() {
		return datPrimeiroAgend;
	}

	public void setDatPrimeiroAgend(String datPrimeiroAgend) {
		this.datPrimeiroAgend = datPrimeiroAgend;
	}

	public String getHoraPrimeiroAgendamento() {
		return horaPrimeiroAgendamento;
	}

	public void setHoraPrimeiroAgendamento(String horaPrimeiroAgendamento) {
		this.horaPrimeiroAgendamento = horaPrimeiroAgendamento;
	}

	public String getDatAgendAtual() {
		return datAgendAtual;
	}

	public void setDatAgendAtual(String datAgendAtual) {
		this.datAgendAtual = datAgendAtual;
	}

	public String getHoraAgendamentoAtual() {
		return horaAgendamentoAtual;
	}

	public void setHoraAgendamentoAtual(String horaAgendamentoAtual) {
		this.horaAgendamentoAtual = horaAgendamentoAtual;
	}

	public String getDscStatusAtivacao() {
		return dscStatusAtivacao;
	}

	public void setDscStatusAtivacao(String dscStatusAtivacao) {
		this.dscStatusAtivacao = dscStatusAtivacao;
	}

	public String getMsanOltTrafego() {
		return msanOltTrafego;
	}

	public void setMsanOltTrafego(String msanOltTrafego) {
		this.msanOltTrafego = msanOltTrafego;
	}

	public String getDatVendaOrig() {
		return datVendaOrig;
	}

	public void setDatVendaOrig(String datVendaOrig) {
		this.datVendaOrig = datVendaOrig;
	}

	public String getHoraVendaOrig() {
		return horaVendaOrig;
	}

	public void setHoraVendaOrig(String horaVendaOrig) {
		this.horaVendaOrig = horaVendaOrig;
	}

	public String getLoginVendedorOrig() {
		return loginVendedorOrig;
	}

	public void setLoginVendedorOrig(String loginVendedorOrig) {
		this.loginVendedorOrig = loginVendedorOrig;
	}

	public String getCanalOrig() {
		return canalOrig;
	}

	public void setCanalOrig(String canalOrig) {
		this.canalOrig = canalOrig;
	}

	public String getCnpjParceiroOrig() {
		return cnpjParceiroOrig;
	}

	public void setCnpjParceiroOrig(String cnpjParceiroOrig) {
		this.cnpjParceiroOrig = cnpjParceiroOrig;
	}

	public String getCustcodeOrig() {
		return custcodeOrig;
	}

	public void setCustcodeOrig(String custcodeOrig) {
		this.custcodeOrig = custcodeOrig;
	}

	public String getPositionOrig() {
		return positionOrig;
	}

	public void setPositionOrig(String positionOrig) {
		this.positionOrig = positionOrig;
	}

	public String getSemanaVendaOrig() {
		return semanaVendaOrig;
	}

	public void setSemanaVendaOrig(String semanaVendaOrig) {
		this.semanaVendaOrig = semanaVendaOrig;
	}

	public String getCodContratoAtual() {
		return codContratoAtual;
	}

	public void setCodContratoAtual(String codContratoAtual) {
		this.codContratoAtual = codContratoAtual;
	}

	public String getNomPlanoAtual() {
		return nomPlanoAtual;
	}

	public void setNomPlanoAtual(String nomPlanoAtual) {
		this.nomPlanoAtual = nomPlanoAtual;
	}

	public String getNomeVendedorOrig() {
		return nomeVendedorOrig;
	}

	public void setNomeVendedorOrig(String nomeVendedorOrig) {
		this.nomeVendedorOrig = nomeVendedorOrig;
	}

	public String getFlVendaDuplicada() {
		return flVendaDuplicada;
	}

	public void setFlVendaDuplicada(String flVendaDuplicada) {
		this.flVendaDuplicada = flVendaDuplicada;
	}

	public String getFlGross() {
		return flGross;
	}

	public void setFlGross(String flGross) {
		this.flGross = flGross;
	}

	public String getDtGross() {
		return dtGross;
	}

	public void setDtGross(String dtGross) {
		this.dtGross = dtGross;
	}

	public String getFlChurn() {
		return flChurn;
	}

	public void setFlChurn(String flChurn) {
		this.flChurn = flChurn;
	}

	public String getDtChurn() {
		return dtChurn;
	}

	public void setDtChurn(String dtChurn) {
		this.dtChurn = dtChurn;
	}

	public String getMotivoChurn() {
		return motivoChurn;
	}

	public void setMotivoChurn(String motivoChurn) {
		this.motivoChurn = motivoChurn;
	}

	public String getCodOrdemChurn() {
		return codOrdemChurn;
	}

	public void setCodOrdemChurn(String codOrdemChurn) {
		this.codOrdemChurn = codOrdemChurn;
	}

	public String getTipoChurn() {
		return tipoChurn;
	}

	public void setTipoChurn(String tipoChurn) {
		this.tipoChurn = tipoChurn;
	}

	public String getDtCriacaoOrdemChurn() {
		return dtCriacaoOrdemChurn;
	}

	public void setDtCriacaoOrdemChurn(String dtCriacaoOrdemChurn) {
		this.dtCriacaoOrdemChurn = dtCriacaoOrdemChurn;
	}

	public String getDtConclusaoOrdemChurn() {
		return dtConclusaoOrdemChurn;
	}

	public void setDtConclusaoOrdemChurn(String dtConclusaoOrdemChurn) {
		this.dtConclusaoOrdemChurn = dtConclusaoOrdemChurn;
	}

	public String getNomeVendedor() {
		return nomeVendedor;
	}

	public void setNomeVendedor(String nomeVendedor) {
		this.nomeVendedor = nomeVendedor;
	}

	public String getNomeUsuarioCancOrdem() {
		return nomeUsuarioCancOrdem;
	}

	public void setNomeUsuarioCancOrdem(String nomeUsuarioCancOrdem) {
		this.nomeUsuarioCancOrdem = nomeUsuarioCancOrdem;
	}

	public String getEmailCliente() {
		return emailCliente;
	}

	public void setEmailCliente(String emailCliente) {
		this.emailCliente = emailCliente;
	}

	public TreeSet<String> getDupl() {
		return dupl;
	}

	public void setDupl(TreeSet<String> dupl) {
		this.dupl = dupl;
	}

	public TreeSet<String> getBrut() {
		return brut;
	}

	public void setBrut(TreeSet<String> brut) {
		this.brut = brut;
	}

	public boolean isDefinido() {
		return definido;
	}

	public void setDefinido(boolean definido) {
		this.definido = definido;
	}

	public int getContflg0() {
		return contflg0;
	}

	public void setContflg0(int contflg0) {
		this.contflg0 = contflg0;
	}

	public int getContflg1() {
		return contflg1;
	}

	public void setContflg1(int contflg1) {
		this.contflg1 = contflg1;
	}

	public DateTimeFormatter getDtf() {
		return dtf;
	}

	public void setDtf(DateTimeFormatter dtf) {
		this.dtf = dtf;
	}

	public static String getDelimiter() {
		return DELIMITER;
	}

    @Override
    public String toString() {
    	
    	StringBuffer sb = new StringBuffer();
		sb.setLength(0);
		sb.append(getDatref()).append(DELIMITER);
		sb.append(getDatCriacaoOrdem()).append(DELIMITER);
		sb.append(getHoraCriacaoDaOrdem()).append(DELIMITER);
		sb.append(getDatVenda()).append(DELIMITER);
		sb.append(getHoraDaVenda()).append(DELIMITER);
		sb.append(getDatStatusOrdem()).append(DELIMITER);
		sb.append(getHrStatusOrdem()).append(DELIMITER);
		sb.append(getNumOrdemSiebel()).append(DELIMITER);
		sb.append(getNumOrdemSiebelOrig()).append(DELIMITER);
		sb.append(getCodContratoOltp()).append(DELIMITER);
		sb.append(getCodContratoAtivacao()).append(DELIMITER);
		sb.append(getNumeroAcesso()).append(DELIMITER);
		sb.append(getCustomerId()).append(DELIMITER);
		sb.append(getTipoDocumento()).append(DELIMITER);
		sb.append(getDocumento()).append(DELIMITER);
		sb.append(getTipoVenda()).append(DELIMITER);
		sb.append(getTipoProduto()).append(DELIMITER);
		sb.append(getVelocidadeDownload()).append(DELIMITER);
		sb.append(getVelocidadeUpload()).append(DELIMITER);
		sb.append(getPlanoAtivacaoOferta()).append(DELIMITER);
		sb.append(getLoginVendedor()).append(DELIMITER);
		sb.append(getCanal()).append(DELIMITER);
		sb.append(getCnpjParceiro()).append(DELIMITER);
		sb.append(getCustcode()).append(DELIMITER);
		sb.append(getPosition()).append(DELIMITER);
		sb.append(getFlgCancAntesVenda()).append(DELIMITER);
		sb.append(getFlgCancPosVenda()).append(DELIMITER);
		sb.append(getDtCancVenda()).append(DELIMITER);
		sb.append(getMotivoCancelamento()).append(DELIMITER);
		sb.append(getNomeCliente()).append(DELIMITER);
		sb.append(getTelefone()).append(DELIMITER);
		sb.append(getEmailFatura()).append(DELIMITER);
		sb.append(getUf()).append(DELIMITER);
		sb.append(getTipoLogradouro()).append(DELIMITER);
		sb.append(getLogradouro()).append(DELIMITER);
		sb.append(getNumero()).append(DELIMITER);
		sb.append(getComplemento()).append(DELIMITER);
		sb.append(getBairro()).append(DELIMITER);
		sb.append(getCep()).append(DELIMITER);
		sb.append(getCidade()).append(DELIMITER);
		sb.append(getStatusOrdem()).append(DELIMITER);
		sb.append(getTecnologia()).append(DELIMITER);
		sb.append(getFormaPagamento()).append(DELIMITER);
		sb.append(getTipoConta()).append(DELIMITER);
		sb.append(getCodBanco()).append(DELIMITER);
		sb.append(getCodAgengiaBco()).append(DELIMITER);
		sb.append(getCodContaCorrente()).append(DELIMITER);
		sb.append(getCodDebitoAutomatico()).append(DELIMITER);
		sb.append(getDiaVencimento()).append(DELIMITER);
		sb.append(getSemanaVenda()).append(DELIMITER);
		sb.append(getScore()).append(DELIMITER);
		sb.append(getScoreConsumido()).append(DELIMITER);
		sb.append(getDtFinalizacaoOrdem()).append(DELIMITER);
		sb.append(getQdeContratos()).append(DELIMITER);
		sb.append(getNumProtocolo()).append(DELIMITER);
		sb.append(getFlgOrdemAutomatica()).append(DELIMITER);
		sb.append(getDscTxRecorrente()).append(DELIMITER);
		sb.append(getDscTxNaoRecorrente()).append(DELIMITER);
		sb.append(getDscStatusItem()).append(DELIMITER);
		sb.append(getNomLoginResponsavel()).append(DELIMITER);
		sb.append(getFlgPortabilidade()).append(DELIMITER);
		sb.append(getDscOperadoraDoadora()).append(DELIMITER);
		sb.append(getCodDdd()).append(DELIMITER);
		sb.append(getNumTelefonePortado()).append(DELIMITER);
		sb.append(getDatJanelaPortabilidade()).append(DELIMITER);
		sb.append(getHoraDaJanela()).append(DELIMITER);
		sb.append(getDscEnderecoFatura()).append(DELIMITER);
		sb.append(getDscAreaVoip()).append(DELIMITER);
		sb.append(getCpe()).append(DELIMITER);
		sb.append(getOnt()).append(DELIMITER);
		sb.append(getCodigoConvergente()).append(DELIMITER);
		sb.append(getDetalheRecusaCrivo()).append(DELIMITER);
		sb.append(getItemRoot()).append(DELIMITER);
		sb.append(getLoginCancelamentoOrdem()).append(DELIMITER);
		sb.append(getCustcodeCliente()).append(DELIMITER);
		sb.append(getDominioRoot()).append(DELIMITER);
		sb.append(getCodContFinanceira()).append(DELIMITER);
		sb.append(getValPlanoAtualItem()).append(DELIMITER);
		sb.append(getNomDescontoAtualItem()).append(DELIMITER);
		sb.append(getValDescontoAtualItem()).append(DELIMITER);
		sb.append(getNroOrdem()).append(DELIMITER);
		sb.append(getAcessoRowId()).append(DELIMITER);
		sb.append(getAcessoRowIdRoot()).append(DELIMITER);
		sb.append(getCodigoProduto()).append(DELIMITER);
		sb.append(getFlgVendaSubmetida()).append(DELIMITER);
		sb.append(getFlgVendaDuplicada()).append(DELIMITER);
		sb.append(getFlgVendaBruta()).append(DELIMITER);
		sb.append(getFlgVendaLiquida()).append(DELIMITER);
		sb.append(getFlgCancDupl()).append(DELIMITER);
		sb.append(getFlgCancLiquido()).append(DELIMITER);
		sb.append(getNomeParceiroVenda()).append(DELIMITER);
		sb.append(getNomeParceiroVendaOrig()).append(DELIMITER);
		sb.append(getRowIdItemOrdem()).append(DELIMITER);
		sb.append(getRowIdItemOrdemPai()).append(DELIMITER);
		sb.append(getCategoriaItemOrder()).append(DELIMITER);
		sb.append(getMsanOltVenda()).append(DELIMITER);
		sb.append(getDtConclusaoWfm()).append(DELIMITER);
		sb.append(getDscStatusOrdemWfm()).append(DELIMITER);
		sb.append(getDatStatusWfm()).append(DELIMITER);
		sb.append(getHoraStatusWfm()).append(DELIMITER);
		sb.append(getIdRecursoWfm()).append(DELIMITER);
		sb.append(getNomRecursoWfm()).append(DELIMITER);
		sb.append(getIdRecursoPaiWfm()).append(DELIMITER);
		sb.append(getDatPrimeiroAgend()).append(DELIMITER);
		sb.append(getHoraPrimeiroAgendamento()).append(DELIMITER);
		sb.append(getDatAgendAtual()).append(DELIMITER);
		sb.append(getHoraAgendamentoAtual()).append(DELIMITER);
		sb.append(getDscStatusAtivacao()).append(DELIMITER);
		sb.append(getMsanOltTrafego()).append(DELIMITER);
		sb.append(getDatVendaOrig()).append(DELIMITER);
		sb.append(getHoraVendaOrig()).append(DELIMITER);
		sb.append(getLoginVendedorOrig()).append(DELIMITER);
		sb.append(getCanalOrig()).append(DELIMITER);
		sb.append(getCnpjParceiroOrig()).append(DELIMITER);
		sb.append(getCustcodeOrig()).append(DELIMITER);
		sb.append(getPositionOrig()).append(DELIMITER);
		sb.append(getSemanaVendaOrig()).append(DELIMITER);
		sb.append(getCodContratoAtual()).append(DELIMITER);
		sb.append(getNomPlanoAtual()).append(DELIMITER);
		sb.append(getNomeVendedorOrig()).append(DELIMITER);
		sb.append(getFlVendaDuplicada()).append(DELIMITER);
		sb.append(getFlGross()).append(DELIMITER);
		sb.append(getDtGross()).append(DELIMITER);
		sb.append(getFlChurn()).append(DELIMITER);
		sb.append(getDtChurn()).append(DELIMITER);
		sb.append(getMotivoChurn()).append(DELIMITER);
		sb.append(getCodOrdemChurn()).append(DELIMITER);
		sb.append(getTipoChurn()).append(DELIMITER);
		sb.append(getDtCriacaoOrdemChurn()).append(DELIMITER);
		sb.append(getDtConclusaoOrdemChurn()).append(DELIMITER);
		sb.append(getNomeVendedor()).append(DELIMITER);
		sb.append(getNomeUsuarioCancOrdem()).append(DELIMITER);
		sb.append(getEmailCliente());
		return sb.toString();
    }
    
}
