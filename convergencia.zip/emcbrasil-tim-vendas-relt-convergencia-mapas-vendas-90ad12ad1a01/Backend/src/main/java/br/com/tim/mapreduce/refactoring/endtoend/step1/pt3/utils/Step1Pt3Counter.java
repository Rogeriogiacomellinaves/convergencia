package br.com.tim.mapreduce.refactoring.endtoend.step1.pt3.utils;

public enum Step1Pt3Counter {
	
	WFMTOA_MAPPER_WRITE, WFMTOA_MAPPER_READ, WFMTOA_REDUCER_WRITE, STEP1PT2_MAPPER_WRITE, STEP1PT3_REDUCER_WRITE 
	

}
