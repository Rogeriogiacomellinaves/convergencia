package br.com.tim.mapreduce.tramit.step1;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

import br.com.tim.mapreduce.model.Wfmtoa;

public class MapperWfmtoa extends org.apache.hadoop.mapreduce.Mapper<Writable,Text,TramitStep1Key,TramitStep1Value> {

	
	private TramitStep1Key outkey;
	private TramitStep1Value outValue;
	private Wfmtoa input;
	
	@Override
	protected void map(Writable key, Text value, Context context) throws IOException, InterruptedException {
		input.parseLineFromTable(value.toString());
		outkey.setNroOrdem(input.getApptNumber());
		outkey.setTipo(TypeStep1.WFMTOA);
		outValue.setWfmtoa(input);
		context.write(outkey,outValue);
	}
	
	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		super.setup(context);
		this.outkey = new TramitStep1Key();
		this.outValue = new TramitStep1Value();
		this.input = new Wfmtoa();
	}

	@Override
	protected void cleanup(Context context) throws IOException, InterruptedException {
		super.cleanup(context);
		this.clear();
	}

	private void clear(){
	   this.outValue.clear();
	}
	
}
