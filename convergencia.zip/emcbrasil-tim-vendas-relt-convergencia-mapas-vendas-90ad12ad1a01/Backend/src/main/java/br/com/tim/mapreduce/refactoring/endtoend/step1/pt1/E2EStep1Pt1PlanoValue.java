package br.com.tim.mapreduce.refactoring.endtoend.step1.pt1;

public class E2EStep1Pt1PlanoValue {
	private String planoAtivacaoOferta;
	private String tecnologia;
	private String nomPlanoAtual;
	private String valPlanoAtualItem;
	private String cpe;
	private String ont;
	private String rowIdDoItemDaOrdem;
	private String rowIdDoItemDaOrdemPai;

	private String codigoProduto;
	
	public E2EStep1Pt1PlanoValue(E2EStep1Pt1Value value) {
        this.planoAtivacaoOferta = value.getNomeProduto();
    	this.tecnologia = value.getTecnologia();
    	this.nomPlanoAtual = value.getNomPlanoAtual();
    	this.valPlanoAtualItem = value.getValPlanoAtualItem();
    	this.cpe = value.getCpe();
    	this.ont = value.getOnt();
    	this.rowIdDoItemDaOrdem = value.getRowIdDoItemDaOrdem();
    	this.rowIdDoItemDaOrdemPai = value.getRowIdDoItemDaOrdemPai();
    	this.codigoProduto = value.getCodigoProduto();
	}
	
	public String getCodigoProduto() {
		return codigoProduto;
	}

	public void setCodigoProduto(String codigoProduto) {
		this.codigoProduto = codigoProduto;
	}

	

	public String getRowIdDoItemDaOrdem() {
		return rowIdDoItemDaOrdem;
	}

	public void setRowIdDoItemDaOrdem(String rowIdDoItemDaOrdem) {
		this.rowIdDoItemDaOrdem = rowIdDoItemDaOrdem;
	}

	public String getRowIdDoItemDaOrdemPai() {
		return rowIdDoItemDaOrdemPai;
	}

	public void setRowIdDoItemDaOrdemPai(String rowIdDoItemDaOrdemPai) {
		this.rowIdDoItemDaOrdemPai = rowIdDoItemDaOrdemPai;
	}

	public E2EStep1Pt1PlanoValue() {
		
	}

	public String getPlanoAtivacaoOferta() {
		return planoAtivacaoOferta;
	}

	public void setPlanoAtivacaoOferta(String planoAtivacaoOferta) {
		this.planoAtivacaoOferta = planoAtivacaoOferta;
	}

	public String getTecnologia() {
		return tecnologia;
	}

	public void setTecnologia(String tecnologia) {
		this.tecnologia = tecnologia;
	}

	public String getNomPlanoAtual() {
		return nomPlanoAtual;
	}

	public void setNomPlanoAtual(String nomPlanoAtual) {
		this.nomPlanoAtual = nomPlanoAtual;
	}

	public String getValPlanoAtualItem() {
		return valPlanoAtualItem;
	}

	public void setValPlanoAtualItem(String valPlanoAtualItem) {
		this.valPlanoAtualItem = valPlanoAtualItem;
	}

	public String getCpe() {
		return cpe;
	}

	public void setCpe(String cpe) {
		this.cpe = cpe;
	}

	public String getOnt() {
		return ont;
	}

	public void setOnt(String ont) {
		this.ont = ont;
	}
	
}
