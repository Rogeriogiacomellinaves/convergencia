package br.com.tim.mapreduce.model;

import org.apache.commons.lang3.StringUtils;

public class BAT230 {

    private String idPublico;
    private String socialsecno;
    private String custcode;
    private String status;
    private String email;
    private String area;
    private String flagIsencaoIcms;
    private String diaVencimento;
    private String dataModifVencimento;
    private String tipoFatura;
    private String dataModifTipoFatura;
    private String metodoPagamento;
    private String codigoBanco;
    private String banco;
    private String agencia;
    private String contaCorrente;
    private String codigoOperacao;
    private String dataModifMetodo;
    private String tipoLogradouro;
    private String logradouro;
    private String numeroEndereco;
    private String complemento;
    private String bairro;
    private String cidade;
    private String uf;
    private String cep;
    private String caixaPostal;
    private String rowidEndereco;
    private String dataCriacaoCrm;
    private String loginRespAtivacao;
    private String perfilLoginRespAtivacao;
    private String pdvRespAtivacao;
    private String dataModificacao;
    private String loginRespModificacao;
    private String perfilLoginRespModificacao;
    private String pdvRespModificacao;
    private String rowid;
    private String loteid;
    private String arquivo;
    private String arquivots;
    private String currentDate;
    private String flgConvergente;
    private String rowidPerfilFatura;
    private String rowidCliente;

    public BAT230() {

        this.idPublico = null;
        this.socialsecno = null;
        this.custcode = null;
        this.status = null;
        this.email = null;
        this.area = null;
        this.flagIsencaoIcms = null;
        this.diaVencimento = null;
        this.dataModifVencimento = null;
        this.tipoFatura = null;
        this.dataModifTipoFatura = null;
        this.metodoPagamento = null;
        this.codigoBanco = null;
        this.banco = null;
        this.agencia = null;
        this.contaCorrente = null;
        this.codigoOperacao = null;
        this.dataModifMetodo = null;
        this.tipoLogradouro = null;
        this.logradouro = null;
        this.numeroEndereco = null;
        this.complemento = null;
        this.bairro = null;
        this.cidade = null;
        this.uf = null;
        this.cep = null;
        this.caixaPostal = null;
        this.rowidEndereco = null;
        this.dataCriacaoCrm = null;
        this.loginRespAtivacao = null;
        this.perfilLoginRespAtivacao = null;
        this.pdvRespAtivacao = null;
        this.dataModificacao = null;
        this.loginRespModificacao = null;
        this.perfilLoginRespModificacao = null;
        this.pdvRespModificacao = null;
        this.rowid = null;
        this.loteid = null;
        this.arquivo = null;
        this.arquivots = null;
        this.currentDate = null;
        this.flgConvergente = null;
        this.rowidPerfilFatura = null;
        this.rowidCliente = null;

    }

    public void setBAT230(String idPublico, String socialsecno, String custcode, String status, String email, String area, String flagIsencaoIcms, String diaVencimento, String dataModifVencimento,
                          String tipoFatura, String dataModifTipoFatura, String metodoPagamento, String codigoBanco, String banco, String agencia, String contaCorrente, String codigoOperacao,
                          String dataModifMetodo, String tipoLogradouro, String logradouro, String numeroEndereco, String complemento, String bairro, String cidade, String uf, String cep,
                          String caixaPostal, String rowidEndereco, String dataCriacaoCrm, String loginRespAtivacao, String perfilLoginRespAtivacao, String pdvRespAtivacao, String dataModificacao,
                          String loginRespModificacao, String perfilLoginRespModificacao, String pdvRespModificacao, String rowid, String loteid, String arquivo, String arquivots, String currentDate,
                          String flgConvergente, String rowidPerfilFatura, String rowidCliente) {
        this.idPublico = idPublico;
        this.socialsecno = socialsecno;
        this.custcode = custcode;
        this.status = status;
        this.email = email;
        this.area = area;
        this.flagIsencaoIcms = flagIsencaoIcms;
        this.diaVencimento = diaVencimento;
        this.dataModifVencimento = dataModifVencimento;
        this.tipoFatura = tipoFatura;
        this.dataModifTipoFatura = dataModifTipoFatura;
        this.metodoPagamento = metodoPagamento;
        this.codigoBanco = codigoBanco;
        this.banco = banco;
        this.agencia = agencia;
        this.contaCorrente = contaCorrente;
        this.codigoOperacao = codigoOperacao;
        this.dataModifMetodo = dataModifMetodo;
        this.tipoLogradouro = tipoLogradouro;
        this.logradouro = logradouro;
        this.numeroEndereco = numeroEndereco;
        this.complemento = complemento;
        this.bairro = bairro;
        this.cidade = cidade;
        this.uf = uf;
        this.cep = cep;
        this.caixaPostal = caixaPostal;
        this.rowidEndereco = rowidEndereco;
        this.dataCriacaoCrm = dataCriacaoCrm;
        this.loginRespAtivacao = loginRespAtivacao;
        this.perfilLoginRespAtivacao = perfilLoginRespAtivacao;
        this.pdvRespAtivacao = pdvRespAtivacao;
        this.dataModificacao = dataModificacao;
        this.loginRespModificacao = loginRespModificacao;
        this.perfilLoginRespModificacao = perfilLoginRespModificacao;
        this.pdvRespModificacao = pdvRespModificacao;
        this.rowid = rowid;
        this.loteid = loteid;
        this.arquivo = arquivo;
        this.arquivots = arquivots;
        this.currentDate = currentDate;
        this.flgConvergente = flgConvergente;
        this.rowidPerfilFatura = rowidPerfilFatura;
        this.rowidCliente = rowidCliente;
    }

    public boolean parse(String textString) {
        if (StringUtils.isNotBlank(textString)) {
            String[] cols = textString.split("\\|", -1);
            int i = 0;
            this.setBAT230(cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                           cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                           cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                           cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                           cols[i++], cols[i++], cols[i++], cols[i++]);
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        String delimiter = "|";

        sb.append(idPublico).append(delimiter)
          .append(socialsecno).append(delimiter)
          .append(custcode).append(delimiter)
          .append(status).append(delimiter)
          .append(email).append(delimiter)
          .append(area).append(delimiter)
          .append(flagIsencaoIcms).append(delimiter)
          .append(diaVencimento).append(delimiter)
          .append(dataModifVencimento).append(delimiter)
          .append(tipoFatura).append(delimiter)
          .append(dataModifTipoFatura).append(delimiter)
          .append(metodoPagamento).append(delimiter)
          .append(codigoBanco).append(delimiter)
          .append(banco).append(delimiter)
          .append(agencia).append(delimiter)
          .append(contaCorrente).append(delimiter)
          .append(codigoOperacao).append(delimiter)
          .append(dataModifMetodo).append(delimiter)
          .append(tipoLogradouro).append(delimiter)
          .append(logradouro).append(delimiter)
          .append(numeroEndereco).append(delimiter)
          .append(complemento).append(delimiter)
          .append(bairro).append(delimiter)
          .append(cidade).append(delimiter)
          .append(uf).append(delimiter)
          .append(cep).append(delimiter)
          .append(caixaPostal).append(delimiter)
          .append(rowidEndereco).append(delimiter)
          .append(dataCriacaoCrm).append(delimiter)
          .append(loginRespAtivacao).append(delimiter)
          .append(perfilLoginRespAtivacao).append(delimiter)
          .append(pdvRespAtivacao).append(delimiter)
          .append(dataModificacao).append(delimiter)
          .append(loginRespModificacao).append(delimiter)
          .append(perfilLoginRespModificacao).append(delimiter)
          .append(pdvRespModificacao).append(delimiter)
          .append(rowid).append(delimiter)
          .append(loteid).append(delimiter)
          .append(arquivo).append(delimiter)
          .append(arquivots).append(delimiter)
          .append(currentDate).append(delimiter)
          .append(flgConvergente).append(delimiter)
          .append(rowidPerfilFatura).append(delimiter)
          .append(rowidCliente);

        return sb.toString();

    }

    public String getIdPublico() {
        return idPublico;
    }

    public void setIdPublico(String idPublico) {
        this.idPublico = idPublico;
    }

    public String getSocialsecno() {
        return socialsecno;
    }

    public void setSocialsecno(String socialsecno) {
        this.socialsecno = socialsecno;
    }

    public String getCustcode() {
        return custcode;
    }

    public void setCustcode(String custcode) {
        this.custcode = custcode;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getFlagIsencaoIcms() {
        return flagIsencaoIcms;
    }

    public void setFlagIsencaoIcms(String flagIsencaoIcms) {
        this.flagIsencaoIcms = flagIsencaoIcms;
    }

    public String getDiaVencimento() {
        return diaVencimento;
    }

    public void setDiaVencimento(String diaVencimento) {
        this.diaVencimento = diaVencimento;
    }

    public String getDataModifVencimento() {
        return dataModifVencimento;
    }

    public void setDataModifVencimento(String dataModifVencimento) {
        this.dataModifVencimento = dataModifVencimento;
    }

    public String getTipoFatura() {
        return tipoFatura;
    }

    public void setTipoFatura(String tipoFatura) {
        this.tipoFatura = tipoFatura;
    }

    public String getDataModifTipoFatura() {
        return dataModifTipoFatura;
    }

    public void setDataModifTipoFatura(String dataModifTipoFatura) {
        this.dataModifTipoFatura = dataModifTipoFatura;
    }

    public String getMetodoPagamento() {
        return metodoPagamento;
    }

    public void setMetodoPagamento(String metodoPagamento) {
        this.metodoPagamento = metodoPagamento;
    }

    public String getCodigoBanco() {
        return codigoBanco;
    }

    public void setCodigoBanco(String codigoBanco) {
        this.codigoBanco = codigoBanco;
    }

    public String getBanco() {
        return banco;
    }

    public void setBanco(String banco) {
        this.banco = banco;
    }

    public String getAgencia() {
        return agencia;
    }

    public void setAgencia(String agencia) {
        this.agencia = agencia;
    }

    public String getContaCorrente() {
        return contaCorrente;
    }

    public void setContaCorrente(String contaCorrente) {
        this.contaCorrente = contaCorrente;
    }

    public String getCodigoOperacao() {
        return codigoOperacao;
    }

    public void setCodigoOperacao(String codigoOperacao) {
        this.codigoOperacao = codigoOperacao;
    }

    public String getDataModifMetodo() {
        return dataModifMetodo;
    }

    public void setDataModifMetodo(String dataModifMetodo) {
        this.dataModifMetodo = dataModifMetodo;
    }

    public String getTipoLogradouro() {
        return tipoLogradouro;
    }

    public void setTipoLogradouro(String tipoLogradouro) {
        this.tipoLogradouro = tipoLogradouro;
    }

    public String getLogradouro() {
        return logradouro;
    }

    public void setLogradouro(String logradouro) {
        this.logradouro = logradouro;
    }

    public String getNumeroEndereco() {
        return numeroEndereco;
    }

    public void setNumeroEndereco(String numeroEndereco) {
        this.numeroEndereco = numeroEndereco;
    }

    public String getComplemento() {
        return complemento;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getUf() {
        return uf;
    }

    public void setUf(String uf) {
        this.uf = uf;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getCaixaPostal() {
        return caixaPostal;
    }

    public void setCaixaPostal(String caixaPostal) {
        this.caixaPostal = caixaPostal;
    }

    public String getRowidEndereco() {
        return rowidEndereco;
    }

    public void setRowidEndereco(String rowidEndereco) {
        this.rowidEndereco = rowidEndereco;
    }

    public String getDataCriacaoCrm() {
        return dataCriacaoCrm;
    }

    public void setDataCriacaoCrm(String dataCriacaoCrm) {
        this.dataCriacaoCrm = dataCriacaoCrm;
    }

    public String getLoginRespAtivacao() {
        return loginRespAtivacao;
    }

    public void setLoginRespAtivacao(String loginRespAtivacao) {
        this.loginRespAtivacao = loginRespAtivacao;
    }

    public String getPerfilLoginRespAtivacao() {
        return perfilLoginRespAtivacao;
    }

    public void setPerfilLoginRespAtivacao(String perfilLoginRespAtivacao) {
        this.perfilLoginRespAtivacao = perfilLoginRespAtivacao;
    }

    public String getPdvRespAtivacao() {
        return pdvRespAtivacao;
    }

    public void setPdvRespAtivacao(String pdvRespAtivacao) {
        this.pdvRespAtivacao = pdvRespAtivacao;
    }

    public String getDataModificacao() {
        return dataModificacao;
    }

    public void setDataModificacao(String dataModificacao) {
        this.dataModificacao = dataModificacao;
    }

    public String getLoginRespModificacao() {
        return loginRespModificacao;
    }

    public void setLoginRespModificacao(String loginRespModificacao) {
        this.loginRespModificacao = loginRespModificacao;
    }

    public String getPerfilLoginRespModificacao() {
        return perfilLoginRespModificacao;
    }

    public void setPerfilLoginRespModificacao(String perfilLoginRespModificacao) {
        this.perfilLoginRespModificacao = perfilLoginRespModificacao;
    }

    public String getPdvRespModificacao() {
        return pdvRespModificacao;
    }

    public void setPdvRespModificacao(String pdvRespModificacao) {
        this.pdvRespModificacao = pdvRespModificacao;
    }

    public String getRowid() {
        return rowid;
    }

    public void setRowid(String rowid) {
        this.rowid = rowid;
    }

    public String getLoteid() {
        return loteid;
    }

    public void setLoteid(String loteid) {
        this.loteid = loteid;
    }

    public String getArquivo() {
        return arquivo;
    }

    public void setArquivo(String arquivo) {
        this.arquivo = arquivo;
    }

    public String getArquivots() {
        return arquivots;
    }

    public void setArquivots(String arquivots) {
        this.arquivots = arquivots;
    }

    public String getCurrentDate() {
        return currentDate;
    }

    public void setCurrentDate(String currentDate) {
        this.currentDate = currentDate;
    }

    public String getFlgConvergente() {
        return flgConvergente;
    }

    public void setFlgConvergente(String flgConvergente) {
        this.flgConvergente = flgConvergente;
    }

    public String getRowidPerfilFatura() {
        return rowidPerfilFatura;
    }

    public void setRowidPerfilFatura(String rowidPerfilFatura) {
        this.rowidPerfilFatura = rowidPerfilFatura;
    }

    public String getRowidCliente() {
        return rowidCliente;
    }

    public void setRowidCliente(String rowidCliente) {
        this.rowidCliente = rowidCliente;
    }
}
