package br.com.tim.mapreduce.refactoring.endtoend.step6.utils;

public enum Step6Counters {
	
	STEP5_MAPPER_WRITE, STEP5_MAPPER_DISCART, STEP6_REDUCER_WRITE, STEP6_REDUCER_DISCART 

}
