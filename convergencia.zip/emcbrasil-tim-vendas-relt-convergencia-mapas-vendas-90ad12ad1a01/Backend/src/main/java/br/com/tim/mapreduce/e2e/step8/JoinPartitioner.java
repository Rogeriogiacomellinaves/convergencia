package br.com.tim.mapreduce.e2e.step8;

import org.apache.hadoop.mapreduce.Partitioner;

public class JoinPartitioner extends Partitioner<E2EStep8Key, E2EStep8Value> {

    @Override
    public int getPartition(E2EStep8Key taggedKey, E2EStep8Value value, int numPartitions) {
        return Math.abs(taggedKey.hashCodeJoin() % numPartitions);
    }
}