package br.com.tim.mapreduce.model;

import org.apache.commons.lang3.StringUtils;

public class BAT509Item {
    private String rowidProcArq;
    private String loteid;
    private String arquivo;
    private String arquivots;
    private String currentDate;
    private String numeroOrdem;
    private String numeroProtocolo;
    private String nomeProduto;
    private String flgOrdemAut;
    private String dataInstalacao;
    private String dataDesconexao;
    private String dataSuspensao;
    private String dataPrevista;
    private String dataReativacao;
    private String tipoMotivo;
    private String flgVendaLiquida;
    private String codigoOrdemOriginal;
    private String dataVendaOriginal;
    private String numeroAcesso;
    private String serviceId;
    private String numeroAcao;
    private String idAcessoBi;
    private String codigoContaFinanceira;
    private String ufInstalacao;
    private String taxaRecorrente;
    private String taxaNaoRecorrente;
    private String tipoLogradouro;
    private String logradouroInstalacao;
    private String numeroLogradouro;
    private String complemento;
    private String bairro;
    private String cep;
    private String cidade;
    private String flgReligaConfianca;
    private String alcada;
    private String statusItem;
    private String motivoStatus;
    private String loginCancelamento;
    private String msanReserva;
    private String msanWfm;
    private String msanInstalacao;
    private String modeloCpeReserva;
    private String serialReserva;
    private String modeloCpeInstalacao;
    private String serialInstalacao;
    private String planoAtual;
    private String precoPlanoAtual;
    private String descontoAtual;
    private String precoDescontoAtual;
    private String plano;
    private String precoPlano;
    private String desconto;
    private String precoDesconto;
    private String flgPortabilidade;
    private String operadoraDoadora;
    private String ddd;
    private String numeroASerPortado;
    private String dataJanela;
    private String estorno;
    private String bilheteASerEstornado;
    private String motivoEstorno;
    private String dataStatusWfm;
    private String idRecursoWfm;
    private String nomeRecursoWfm;
    private String idRecursoPaiWfm;
    private String primeiroAgendamento;
    private String agendamentoAtual;
    private String statusEsteiraAtivacao;
    private String motivoRecusaSgf;
    private String diaVencimento;
    private String codigoCiclo;
    private String tipoConta;
    private String email;
    private String enderecoRecebimentoFatura;
    private String area;
    private String metodoPagamento;
    private String banco;
    private String agencia;
    private String conta;
    private String dataModalidade;
    private String codDebitoAutomatico;
    private String canal;
    private String itensOrdem;
    private String scoreConsumido;
    private String acaoItemOrdem;
    private String labelComplemento1;
    private String valorComplemento1;
    private String labelComplemento2;
    private String valorComplemento2;
    private String labelComplemento3;
    private String valorComplemento3;
    private String labelComplemento4;
    private String valorComplemento4;
    private String labelComplemento5;
    private String valorComplemento5;
    private String rowidItemOrdem;
    private String rowidItemOrdemPai;
    private String rowidItemOrdemRoot;
    private String categoriaItemOrdem;
    private String tipoItemOrdem;
    private String novoNumero;
    private String motivo1;
    private String motivo2;
    private String motivo3;
    private String rowid;
    private String aparelhoSolicitado;
    private String valorAparelho;
    private String valorAparelhoComDesconto;
    private String callId;
    private String custcodePDV;
    private String codigoProduto;
    private String numeroSap;
    private String numeroPedidoLogistica;
    private String dataPrevistaEntrega;
    private String observacao;
    private String imei;
    private String period;
    private String tipoVendaAparelho;
    private String dscVendaAparelho;
    private String statusEntrega;
    private String dscTecnologia;
    private String cpe;
    private String ont;
    private String acessoRowid;
    private String dominioRoot;
    private String xGrupoId;
    private String xGrupoPr;
    private String xIccd;
    private String xIccdNew;

    public BAT509Item() {
        this.rowidProcArq = null;
        this.loteid = null;
        this.arquivo = null;
        this.arquivots = null;
        this.currentDate = null;
        this.numeroOrdem = null;
        this.numeroProtocolo = null;
        this.nomeProduto = null;
        this.flgOrdemAut = null;
        this.dataInstalacao = null;
        this.dataDesconexao = null;
        this.dataSuspensao = null;
        this.dataPrevista = null;
        this.dataReativacao = null;
        this.tipoMotivo = null;
        this.flgVendaLiquida = null;
        this.codigoOrdemOriginal = null;
        this.dataVendaOriginal = null;
        this.numeroAcesso = null;
        this.serviceId = null;
        this.numeroAcao = null;
        this.idAcessoBi = null;
        this.codigoContaFinanceira = null;
        this.ufInstalacao = null;
        this.taxaRecorrente = null;
        this.taxaNaoRecorrente = null;
        this.tipoLogradouro = null;
        this.logradouroInstalacao = null;
        this.numeroLogradouro = null;
        this.complemento = null;
        this.bairro = null;
        this.cep = null;
        this.cidade = null;
        this.flgReligaConfianca = null;
        this.alcada = null;
        this.statusItem = null;
        this.motivoStatus = null;
        this.loginCancelamento = null;
        this.msanReserva = null;
        this.msanWfm = null;
        this.msanInstalacao = null;
        this.modeloCpeReserva = null;
        this.serialReserva = null;
        this.modeloCpeInstalacao = null;
        this.serialInstalacao = null;
        this.planoAtual = null;
        this.precoPlanoAtual = null;
        this.descontoAtual = null;
        this.precoDescontoAtual = null;
        this.plano = null;
        this.precoPlano = null;
        this.desconto = null;
        this.precoDesconto = null;
        this.flgPortabilidade = null;
        this.operadoraDoadora = null;
        this.ddd = null;
        this.numeroASerPortado = null;
        this.dataJanela = null;
        this.estorno = null;
        this.bilheteASerEstornado = null;
        this.motivoEstorno = null;
        this.dataStatusWfm = null;
        this.idRecursoWfm = null;
        this.nomeRecursoWfm = null;
        this.idRecursoPaiWfm = null;
        this.primeiroAgendamento = null;
        this.agendamentoAtual = null;
        this.statusEsteiraAtivacao = null;
        this.motivoRecusaSgf = null;
        this.diaVencimento = null;
        this.codigoCiclo = null;
        this.tipoConta = null;
        this.email = null;
        this.enderecoRecebimentoFatura = null;
        this.area = null;
        this.metodoPagamento = null;
        this.banco = null;
        this.agencia = null;
        this.conta = null;
        this.dataModalidade = null;
        this.codDebitoAutomatico = null;
        this.canal = null;
        this.itensOrdem = null;
        this.scoreConsumido = null;
        this.acaoItemOrdem = null;
        this.labelComplemento1 = null;
        this.valorComplemento1 = null;
        this.labelComplemento2 = null;
        this.valorComplemento2 = null;
        this.labelComplemento3 = null;
        this.valorComplemento3 = null;
        this.labelComplemento4 = null;
        this.valorComplemento4 = null;
        this.labelComplemento5 = null;
        this.valorComplemento5 = null;
        this.rowidItemOrdem = null;
        this.rowidItemOrdemPai = null;
        this.rowidItemOrdemRoot = null;
        this.categoriaItemOrdem = null;
        this.tipoItemOrdem = null;
        this.novoNumero = null;
        this.motivo1 = null;
        this.motivo2 = null;
        this.motivo3 = null;
        this.rowid = null;
        this.aparelhoSolicitado = null;
        this.valorAparelho = null;
        this.valorAparelhoComDesconto = null;
        this.callId = null;
        this.custcodePDV = null;
        this.codigoProduto = null;
        this.numeroSap = null;
        this.numeroPedidoLogistica = null;
        this.dataPrevistaEntrega = null;
        this.observacao = null;
        this.imei = null;
        this.period = null;
        this.tipoVendaAparelho = null;
        this.dscVendaAparelho = null;
        this.statusEntrega = null;
        this.dscTecnologia = null;
        this.cpe = null;
        this.ont = null;
        this.acessoRowid = null;
        this.dominioRoot = null;
        this.xGrupoId = null;
        this.xGrupoPr= null;
        this.xIccd= null;
        this.xIccdNew= null;
    }

    public void setBAT509Item(String rowidProcArq, String loteid, String arquivo, String arquivots, String currentDate, String numeroOrdem, String numeroProtocolo, String nomeProduto,
                              String flgOrdemAut, String dataInstalacao, String dataDesconexao, String dataSuspensao,
                              String dataPrevista, String dataReativacao, String tipoMotivo, String flgVendaLiquida, String codigoOrdemOriginal, String dataVendaOriginal,
                              String numeroAcesso, String serviceId, String numeroAcao, String idAcessoBi, String codigoContaFinanceira, String ufInstalacao, String taxaRecorrente,
                              String taxaNaoRecorrente, String tipoLogradouro, String logradouroInstalacao, String numeroLogradouro, String complemento, String bairro, String cep,
                              String cidade, String flgReligaConfianca, String alcada, String statusItem, String motivoStatus, String loginCancelamento, String msanReserva,
                              String msanWfm, String msanInstalacao, String modeloCpeReserva, String serialReserva, String modeloCpeInstalacao, String serialInstalacao,
                              String planoAtual, String precoPlanoAtual, String descontoAtual, String precoDescontoAtual, String plano, String precoPlano, String desconto,
                              String precoDesconto, String flgPortabilidade, String operadoraDoadora, String ddd, String numeroASerPortado, String dataJanela, String estorno,
                              String bilheteASerEstornado, String motivoEstorno, String dataStatusWfm, String idRecursoWfm, String nomeRecursoWfm, String idRecursoPaiWfm,
                              String primeiroAgendamento, String agendamentoAtual, String statusEsteiraAtivacao, String motivoRecusaSgf, String diaVencimento, String codigoCiclo,
                              String tipoConta, String email, String enderecoRecebimentoFatura, String area, String metodoPagamento, String banco, String agencia, String conta,
                              String dataModalidade, String codDebitoAutomatico, String canal, String itensOrdem, String scoreConsumido, String acaoItemOrdem, String labelComplemento1,
                              String valorComplemento1, String labelComplemento2, String valorComplemento2, String labelComplemento3, String valorComplemento3, String labelComplemento4,
                              String valorComplemento4, String labelComplemento5, String valorComplemento5, String rowidItemOrdem, String rowidItemOrdemPai, String rowidItemOrdemRoot,
                              String categoriaItemOrdem, String tipoItemOrdem, String novoNumero, String motivo1, String motivo2, String motivo3, String rowid, String aparelhoSolicitado,
                              String valorAparelho, String valorAparelhoComDesconto, String callId, String custcodePDV, String codigoProduto, String numeroSap, String numeroPedidoLogistica,
                              String dataPrevistaEntrega, String observacao, String imei, String period, String tipoVendaAparelho, String dscVendaAparelho, String statusEntrega, String dscTecnologia, String cpe, String ont,
                              String acessoRowid, String dominioRoot, String xGrupoId, String xGrupoPr, String xIccd, String xIccdNew) {

        this.rowidProcArq = rowidProcArq;
        this.loteid = loteid;
        this.arquivo = arquivo;
        this.arquivots = arquivots;
        this.currentDate = currentDate;
        this.numeroOrdem = numeroOrdem;
        this.numeroProtocolo = numeroProtocolo;
        this.nomeProduto = nomeProduto;
        this.flgOrdemAut = flgOrdemAut;
        this.dataInstalacao = dataInstalacao;
        this.dataDesconexao = dataDesconexao;
        this.dataSuspensao = dataSuspensao;
        this.dataPrevista = dataPrevista;
        this.dataReativacao = dataReativacao;
        this.tipoMotivo = tipoMotivo;
        this.flgVendaLiquida = flgVendaLiquida;
        this.codigoOrdemOriginal = codigoOrdemOriginal;
        this.dataVendaOriginal = dataVendaOriginal;
        this.numeroAcesso = numeroAcesso;
        this.serviceId = serviceId;
        this.numeroAcao = numeroAcao;
        this.idAcessoBi = idAcessoBi;
        this.codigoContaFinanceira = codigoContaFinanceira;
        this.ufInstalacao = ufInstalacao;
        this.taxaRecorrente = taxaRecorrente;
        this.taxaNaoRecorrente = taxaNaoRecorrente;
        this.tipoLogradouro = tipoLogradouro;
        this.logradouroInstalacao = logradouroInstalacao;
        this.numeroLogradouro = numeroLogradouro;
        this.complemento = complemento;
        this.bairro = bairro;
        this.cep = cep;
        this.cidade = cidade;
        this.flgReligaConfianca = flgReligaConfianca;
        this.alcada = alcada;
        this.statusItem = statusItem;
        this.motivoStatus = motivoStatus;
        this.loginCancelamento = loginCancelamento;
        this.msanReserva = msanReserva;
        this.msanWfm = msanWfm;
        this.msanInstalacao = msanInstalacao;
        this.modeloCpeReserva = modeloCpeReserva;
        this.serialReserva = serialReserva;
        this.modeloCpeInstalacao = modeloCpeInstalacao;
        this.serialInstalacao = serialInstalacao;
        this.planoAtual = planoAtual;
        this.precoPlanoAtual = precoPlanoAtual;
        this.descontoAtual = descontoAtual;
        this.precoDescontoAtual = precoDescontoAtual;
        this.plano = plano;
        this.precoPlano = precoPlano;
        this.desconto = desconto;
        this.precoDesconto = precoDesconto;
        this.flgPortabilidade = flgPortabilidade;
        this.operadoraDoadora = operadoraDoadora;
        this.ddd = ddd;
        this.numeroASerPortado = numeroASerPortado;
        this.dataJanela = dataJanela;
        this.estorno = estorno;
        this.bilheteASerEstornado = bilheteASerEstornado;
        this.motivoEstorno = motivoEstorno;
        this.dataStatusWfm = dataStatusWfm;
        this.idRecursoWfm = idRecursoWfm;
        this.nomeRecursoWfm = nomeRecursoWfm;
        this.idRecursoPaiWfm = idRecursoPaiWfm;
        this.primeiroAgendamento = primeiroAgendamento;
        this.agendamentoAtual = agendamentoAtual;
        this.statusEsteiraAtivacao = statusEsteiraAtivacao;
        this.motivoRecusaSgf = motivoRecusaSgf;
        this.diaVencimento = diaVencimento;
        this.codigoCiclo = codigoCiclo;
        this.tipoConta = tipoConta;
        this.email = email;
        this.enderecoRecebimentoFatura = enderecoRecebimentoFatura;
        this.area = area;
        this.metodoPagamento = metodoPagamento;
        this.banco = banco;
        this.agencia = agencia;
        this.conta = conta;
        this.dataModalidade = dataModalidade;
        this.codDebitoAutomatico = codDebitoAutomatico;
        this.canal = canal;
        this.itensOrdem = itensOrdem;
        this.scoreConsumido = scoreConsumido;
        this.acaoItemOrdem = acaoItemOrdem;
        this.labelComplemento1 = labelComplemento1;
        this.valorComplemento1 = valorComplemento1;
        this.labelComplemento2 = labelComplemento2;
        this.valorComplemento2 = valorComplemento2;
        this.labelComplemento3 = labelComplemento3;
        this.valorComplemento3 = valorComplemento3;
        this.labelComplemento4 = labelComplemento4;
        this.valorComplemento4 = valorComplemento4;
        this.labelComplemento5 = labelComplemento5;
        this.valorComplemento5 = valorComplemento5;
        this.rowidItemOrdem = rowidItemOrdem;
        this.rowidItemOrdemPai = rowidItemOrdemPai;
        this.rowidItemOrdemRoot = rowidItemOrdemRoot;
        this.categoriaItemOrdem = categoriaItemOrdem;
        this.tipoItemOrdem = tipoItemOrdem;
        this.novoNumero = novoNumero;
        this.motivo1 = motivo1;
        this.motivo2 = motivo2;
        this.motivo3 = motivo3;
        this.rowid = rowid;
        this.aparelhoSolicitado = aparelhoSolicitado;
        this.valorAparelho = valorAparelho;
        this.valorAparelhoComDesconto = valorAparelhoComDesconto;
        this.callId = callId;
        this.custcodePDV = custcodePDV;
        this.codigoProduto = codigoProduto;
        this.numeroSap = numeroSap;
        this.numeroPedidoLogistica = numeroPedidoLogistica;
        this.dataPrevistaEntrega = dataPrevistaEntrega;
        this.observacao = observacao;
        this.imei = imei;
        this.period = period;
        this.tipoVendaAparelho = tipoVendaAparelho;
        this.dscVendaAparelho = dscVendaAparelho;
        this.statusEntrega = statusEntrega;
        this.dscTecnologia = dscTecnologia;
        this.cpe = cpe;
        this.ont = ont;
        this.acessoRowid = acessoRowid;
        this.dominioRoot = dominioRoot;
        this.xGrupoId = xGrupoId;
        this.xGrupoPr= xGrupoPr;
        this.xIccd= xIccd;
        this.xIccdNew= xIccdNew;
    }

    public boolean parse(String textString) {
        if (StringUtils.isNotBlank(textString)) {
            String[] cols = textString.split("\\|", -1);
            int i = 0;
            this.setBAT509Item(cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                               cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                               cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                               cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                               cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                               cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                               cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                               cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                               cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                               cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                               cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                               cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
                               cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++]);
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        String delimiter = "|";
        sb .append(numeroOrdem).append(delimiter)
           .append(numeroProtocolo).append(delimiter)
           .append(nomeProduto).append(delimiter)
           .append(flgOrdemAut).append(delimiter)
           .append(dataInstalacao).append(delimiter)
           .append(dataDesconexao).append(delimiter)
           .append(dataSuspensao).append(delimiter)
           .append(dataPrevista).append(delimiter)
           .append(dataReativacao).append(delimiter)
           .append(tipoMotivo).append(delimiter)
           .append(flgVendaLiquida).append(delimiter)
           .append(codigoOrdemOriginal).append(delimiter)
           .append(dataVendaOriginal).append(delimiter)
           .append(numeroAcesso).append(delimiter)
           .append(serviceId).append(delimiter)
           .append(numeroAcao).append(delimiter)
           .append(idAcessoBi).append(delimiter)
           .append(codigoContaFinanceira).append(delimiter)
           .append(ufInstalacao).append(delimiter)
           .append(taxaRecorrente).append(delimiter)
           .append(taxaNaoRecorrente).append(delimiter)
           .append(tipoLogradouro).append(delimiter)
           .append(logradouroInstalacao).append(delimiter)
           .append(numeroLogradouro).append(delimiter)
           .append(complemento).append(delimiter)
           .append(bairro).append(delimiter)
           .append(cep).append(delimiter)
           .append(cidade).append(delimiter)
           .append(flgReligaConfianca).append(delimiter)
           .append(alcada).append(delimiter)
           .append(statusItem).append(delimiter)
           .append(motivoStatus).append(delimiter)
           .append(loginCancelamento).append(delimiter)
           .append(msanReserva).append(delimiter)
           .append(msanWfm).append(delimiter)
           .append(msanInstalacao).append(delimiter)
           .append(modeloCpeReserva).append(delimiter)
           .append(serialReserva).append(delimiter)
           .append(modeloCpeInstalacao).append(delimiter)
           .append(serialInstalacao).append(delimiter)
           .append(planoAtual).append(delimiter)
           .append(precoPlanoAtual).append(delimiter)
           .append(descontoAtual).append(delimiter)
           .append(precoDescontoAtual).append(delimiter)
           .append(plano).append(delimiter)
           .append(precoPlano).append(delimiter)
           .append(desconto).append(delimiter)
           .append(precoDesconto).append(delimiter)
           .append(flgPortabilidade).append(delimiter)
           .append(operadoraDoadora).append(delimiter)
           .append(ddd).append(delimiter)
           .append(numeroASerPortado).append(delimiter)
           .append(dataJanela).append(delimiter)
           .append(estorno).append(delimiter)
           .append(bilheteASerEstornado).append(delimiter)
           .append(motivoEstorno).append(delimiter)
           .append(dataStatusWfm).append(delimiter)
           .append(idRecursoWfm).append(delimiter)
           .append(nomeRecursoWfm).append(delimiter)
           .append(idRecursoPaiWfm).append(delimiter)
           .append(primeiroAgendamento).append(delimiter)
           .append(agendamentoAtual).append(delimiter)
           .append(statusEsteiraAtivacao).append(delimiter)
           .append(motivoRecusaSgf).append(delimiter)
           .append(diaVencimento).append(delimiter)
           .append(codigoCiclo).append(delimiter)
           .append(tipoConta).append(delimiter)
           .append(email).append(delimiter)
           .append(enderecoRecebimentoFatura).append(delimiter)
           .append(area).append(delimiter)
           .append(metodoPagamento).append(delimiter)
           .append(banco).append(delimiter)
           .append(agencia).append(delimiter)
           .append(conta).append(delimiter)
           .append(dataModalidade).append(delimiter)
           .append(codDebitoAutomatico).append(delimiter)
           .append(canal).append(delimiter)
           .append(itensOrdem).append(delimiter)
           .append(scoreConsumido).append(delimiter)
           .append(acaoItemOrdem).append(delimiter)
           .append(labelComplemento1).append(delimiter)
           .append(valorComplemento1).append(delimiter)
           .append(labelComplemento2).append(delimiter)
           .append(valorComplemento2).append(delimiter)
           .append(labelComplemento3).append(delimiter)
           .append(valorComplemento3).append(delimiter)
           .append(labelComplemento4).append(delimiter)
           .append(valorComplemento4).append(delimiter)
           .append(labelComplemento5).append(delimiter)
           .append(valorComplemento5).append(delimiter)
           .append(rowidItemOrdem).append(delimiter)
           .append(rowidItemOrdemPai).append(delimiter)
           .append(rowidItemOrdemRoot).append(delimiter)
           .append(categoriaItemOrdem).append(delimiter)
           .append(tipoItemOrdem).append(delimiter)
           .append(novoNumero).append(delimiter)
           .append(motivo1).append(delimiter)
           .append(motivo2).append(delimiter)
           .append(motivo3).append(delimiter)
           .append(rowid).append(delimiter)
           .append(aparelhoSolicitado).append(delimiter)
           .append(valorAparelho).append(delimiter)
           .append(valorAparelhoComDesconto).append(delimiter)
           .append(callId).append(delimiter)
           .append(custcodePDV).append(delimiter)
           .append(codigoProduto).append(delimiter)
           .append(numeroSap).append(delimiter)
           .append(numeroPedidoLogistica).append(delimiter)
           .append(dataPrevistaEntrega).append(delimiter)
           .append(observacao).append(delimiter)
           .append(imei).append(delimiter)
           .append(period).append(delimiter)
           .append(rowidProcArq).append(delimiter)
           .append(loteid).append(delimiter)
           .append(arquivo).append(delimiter)
           .append(arquivots).append(delimiter)
           .append(currentDate).append(delimiter)
           .append(tipoVendaAparelho).append(delimiter)
           .append(dscVendaAparelho).append(delimiter)
           .append(statusEntrega).append(delimiter)
           .append(dscTecnologia).append(delimiter)
           .append(cpe).append(delimiter)
           .append(ont).append(delimiter)
           .append(acessoRowid).append(delimiter)
           .append(dominioRoot);

        return sb.toString();

    }

    public String getRowidProcArq() {
        return rowidProcArq;
    }

    public void setRowidProcArq(String rowidProcArq) {
        this.rowidProcArq = rowidProcArq;
    }

    public String getLoteid() {
        return loteid;
    }

    public void setLoteid(String loteid) {
        this.loteid = loteid;
    }

    public String getArquivo() {
        return arquivo;
    }

    public void setArquivo(String arquivo) {
        this.arquivo = arquivo;
    }

    public String getArquivots() {
        return arquivots;
    }

    public void setArquivots(String arquivots) {
        this.arquivots = arquivots;
    }

    public String getCurrentDate() {
        return currentDate;
    }

    public void setCurrentDate(String currentDate) {
        this.currentDate = currentDate;
    }

    public String getNumeroOrdem() {
        return numeroOrdem;
    }

    public void setNumeroOrdem(String numeroOrdem) {
        this.numeroOrdem = numeroOrdem;
    }

    public String getNumeroProtocolo() {
        return numeroProtocolo;
    }

    public void setNumeroProtocolo(String numeroProtocolo) {
        this.numeroProtocolo = numeroProtocolo;
    }

    public String getNomeProduto() {
        return nomeProduto;
    }

    public void setNomeProduto(String nomeProduto) {
        this.nomeProduto = nomeProduto;
    }

    public String getFlgOrdemAut() {
        return flgOrdemAut;
    }

    public void setFlgOrdemAut(String flgOrdemAut) {
        this.flgOrdemAut = flgOrdemAut;
    }

    public String getDataInstalacao() {
        return dataInstalacao;
    }

    public void setDataInstalacao(String dataInstalacao) {
        this.dataInstalacao = dataInstalacao;
    }

    public String getDataDesconexao() {
        return dataDesconexao;
    }

    public void setDataDesconexao(String dataDesconexao) {
        this.dataDesconexao = dataDesconexao;
    }

    public String getDataSuspensao() {
        return dataSuspensao;
    }

    public void setDataSuspensao(String dataSuspensao) {
        this.dataSuspensao = dataSuspensao;
    }

    public String getDataPrevista() {
        return dataPrevista;
    }

    public void setDataPrevista(String dataPrevista) {
        this.dataPrevista = dataPrevista;
    }

    public String getDataReativacao() {
        return dataReativacao;
    }

    public void setDataReativacao(String dataReativacao) {
        this.dataReativacao = dataReativacao;
    }

    public String getTipoMotivo() {
        return tipoMotivo;
    }

    public void setTipoMotivo(String tipoMotivo) {
        this.tipoMotivo = tipoMotivo;
    }

    public String getFlgVendaLiquida() {
        return flgVendaLiquida;
    }

    public void setFlgVendaLiquida(String flgVendaLiquida) {
        this.flgVendaLiquida = flgVendaLiquida;
    }

    public String getCodigoOrdemOriginal() {
        return codigoOrdemOriginal;
    }

    public void setCodigoOrdemOriginal(String codigoOrdemOriginal) {
        this.codigoOrdemOriginal = codigoOrdemOriginal;
    }

    public String getDataVendaOriginal() {
        return dataVendaOriginal;
    }

    public void setDataVendaOriginal(String dataVendaOriginal) {
        this.dataVendaOriginal = dataVendaOriginal;
    }

    public String getNumeroAcesso() {
        return numeroAcesso;
    }

    public void setNumeroAcesso(String numeroAcesso) {
        this.numeroAcesso = numeroAcesso;
    }

    public String getServiceId() {
        return serviceId;
    }

    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }

    public String getNumeroAcao() {
        return numeroAcao;
    }

    public void setNumeroAcao(String numeroAcao) {
        this.numeroAcao = numeroAcao;
    }

    public String getIdAcessoBi() {
        return idAcessoBi;
    }

    public void setIdAcessoBi(String idAcessoBi) {
        this.idAcessoBi = idAcessoBi;
    }

    public String getCodigoContaFinanceira() {
        return codigoContaFinanceira;
    }

    public void setCodigoContaFinanceira(String codigoContaFinanceira) {
        this.codigoContaFinanceira = codigoContaFinanceira;
    }

    public String getUfInstalacao() {
        return ufInstalacao;
    }

    public void setUfInstalacao(String ufInstalacao) {
        this.ufInstalacao = ufInstalacao;
    }

    public String getTaxaRecorrente() {
        return taxaRecorrente;
    }

    public void setTaxaRecorrente(String taxaRecorrente) {
        this.taxaRecorrente = taxaRecorrente;
    }

    public String getTaxaNaoRecorrente() {
        return taxaNaoRecorrente;
    }

    public void setTaxaNaoRecorrente(String taxaNaoRecorrente) {
        this.taxaNaoRecorrente = taxaNaoRecorrente;
    }

    public String getTipoLogradouro() {
        return tipoLogradouro;
    }

    public void setTipoLogradouro(String tipoLogradouro) {
        this.tipoLogradouro = tipoLogradouro;
    }

    public String getLogradouroInstalacao() {
        return logradouroInstalacao;
    }

    public void setLogradouroInstalacao(String logradouroInstalacao) {
        this.logradouroInstalacao = logradouroInstalacao;
    }

    public String getNumeroLogradouro() {
        return numeroLogradouro;
    }

    public void setNumeroLogradouro(String numeroLogradouro) {
        this.numeroLogradouro = numeroLogradouro;
    }

    public String getComplemento() {
        return complemento;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getFlgReligaConfianca() {
        return flgReligaConfianca;
    }

    public void setFlgReligaConfianca(String flgReligaConfianca) {
        this.flgReligaConfianca = flgReligaConfianca;
    }

    public String getAlcada() {
        return alcada;
    }

    public void setAlcada(String alcada) {
        this.alcada = alcada;
    }

    public String getStatusItem() {
        return statusItem;
    }

    public void setStatusItem(String statusItem) {
        this.statusItem = statusItem;
    }

    public String getMotivoStatus() {
        return motivoStatus;
    }

    public void setMotivoStatus(String motivoStatus) {
        this.motivoStatus = motivoStatus;
    }

    public String getLoginCancelamento() {
        return loginCancelamento;
    }

    public void setLoginCancelamento(String loginCancelamento) {
        this.loginCancelamento = loginCancelamento;
    }

    public String getMsanReserva() {
        return msanReserva;
    }

    public void setMsanReserva(String msanReserva) {
        this.msanReserva = msanReserva;
    }

    public String getMsanWfm() {
        return msanWfm;
    }

    public void setMsanWfm(String msanWfm) {
        this.msanWfm = msanWfm;
    }

    public String getMsanInstalacao() {
        return msanInstalacao;
    }

    public void setMsanInstalacao(String msanInstalacao) {
        this.msanInstalacao = msanInstalacao;
    }

    public String getModeloCpeReserva() {
        return modeloCpeReserva;
    }

    public void setModeloCpeReserva(String modeloCpeReserva) {
        this.modeloCpeReserva = modeloCpeReserva;
    }

    public String getSerialReserva() {
        return serialReserva;
    }

    public void setSerialReserva(String serialReserva) {
        this.serialReserva = serialReserva;
    }

    public String getModeloCpeInstalacao() {
        return modeloCpeInstalacao;
    }

    public void setModeloCpeInstalacao(String modeloCpeInstalacao) {
        this.modeloCpeInstalacao = modeloCpeInstalacao;
    }

    public String getSerialInstalacao() {
        return serialInstalacao;
    }

    public void setSerialInstalacao(String serialInstalacao) {
        this.serialInstalacao = serialInstalacao;
    }

    public String getPlanoAtual() {
        return planoAtual;
    }

    public void setPlanoAtual(String planoAtual) {
        this.planoAtual = planoAtual;
    }

    public String getPrecoPlanoAtual() {
        return precoPlanoAtual;
    }

    public void setPrecoPlanoAtual(String precoPlanoAtual) {
        this.precoPlanoAtual = precoPlanoAtual;
    }

    public String getDescontoAtual() {
        return descontoAtual;
    }

    public void setDescontoAtual(String descontoAtual) {
        this.descontoAtual = descontoAtual;
    }

    public String getPrecoDescontoAtual() {
        return precoDescontoAtual;
    }

    public void setPrecoDescontoAtual(String precoDescontoAtual) {
        this.precoDescontoAtual = precoDescontoAtual;
    }

    public String getPlano() {
        return plano;
    }

    public void setPlano(String plano) {
        this.plano = plano;
    }

    public String getPrecoPlano() {
        return precoPlano;
    }

    public void setPrecoPlano(String precoPlano) {
        this.precoPlano = precoPlano;
    }

    public String getDesconto() {
        return desconto;
    }

    public void setDesconto(String desconto) {
        this.desconto = desconto;
    }

    public String getPrecoDesconto() {
        return precoDesconto;
    }

    public void setPrecoDesconto(String precoDesconto) {
        this.precoDesconto = precoDesconto;
    }

    public String getFlgPortabilidade() {
        return flgPortabilidade;
    }

    public void setFlgPortabilidade(String flgPortabilidade) {
        this.flgPortabilidade = flgPortabilidade;
    }

    public String getOperadoraDoadora() {
        return operadoraDoadora;
    }

    public void setOperadoraDoadora(String operadoraDoadora) {
        this.operadoraDoadora = operadoraDoadora;
    }

    public String getDdd() {
        return ddd;
    }

    public void setDdd(String ddd) {
        this.ddd = ddd;
    }

    public String getNumeroASerPortado() {
        return numeroASerPortado;
    }

    public void setNumeroASerPortado(String numeroASerPortado) {
        this.numeroASerPortado = numeroASerPortado;
    }

    public String getDataJanela() {
        return dataJanela;
    }

    public void setDataJanela(String dataJanela) {
        this.dataJanela = dataJanela;
    }

    public String getEstorno() {
        return estorno;
    }

    public void setEstorno(String estorno) {
        this.estorno = estorno;
    }

    public String getBilheteASerEstornado() {
        return bilheteASerEstornado;
    }

    public void setBilheteASerEstornado(String bilheteASerEstornado) {
        this.bilheteASerEstornado = bilheteASerEstornado;
    }

    public String getMotivoEstorno() {
        return motivoEstorno;
    }

    public void setMotivoEstorno(String motivoEstorno) {
        this.motivoEstorno = motivoEstorno;
    }

    public String getDataStatusWfm() {
        return dataStatusWfm;
    }

    public void setDataStatusWfm(String dataStatusWfm) {
        this.dataStatusWfm = dataStatusWfm;
    }

    public String getIdRecursoWfm() {
        return idRecursoWfm;
    }

    public void setIdRecursoWfm(String idRecursoWfm) {
        this.idRecursoWfm = idRecursoWfm;
    }

    public String getNomeRecursoWfm() {
        return nomeRecursoWfm;
    }

    public void setNomeRecursoWfm(String nomeRecursoWfm) {
        this.nomeRecursoWfm = nomeRecursoWfm;
    }

    public String getIdRecursoPaiWfm() {
        return idRecursoPaiWfm;
    }

    public void setIdRecursoPaiWfm(String idRecursoPaiWfm) {
        this.idRecursoPaiWfm = idRecursoPaiWfm;
    }

    public String getPrimeiroAgendamento() {
        return primeiroAgendamento;
    }

    public void setPrimeiroAgendamento(String primeiroAgendamento) {
        this.primeiroAgendamento = primeiroAgendamento;
    }

    public String getAgendamentoAtual() {
        return agendamentoAtual;
    }

    public void setAgendamentoAtual(String agendamentoAtual) {
        this.agendamentoAtual = agendamentoAtual;
    }

    public String getStatusEsteiraAtivacao() {
        return statusEsteiraAtivacao;
    }

    public void setStatusEsteiraAtivacao(String statusEsteiraAtivacao) {
        this.statusEsteiraAtivacao = statusEsteiraAtivacao;
    }

    public String getMotivoRecusaSgf() {
        return motivoRecusaSgf;
    }

    public void setMotivoRecusaSgf(String motivoRecusaSgf) {
        this.motivoRecusaSgf = motivoRecusaSgf;
    }

    public String getDiaVencimento() {
        return diaVencimento;
    }

    public void setDiaVencimento(String diaVencimento) {
        this.diaVencimento = diaVencimento;
    }

    public String getCodigoCiclo() {
        return codigoCiclo;
    }

    public void setCodigoCiclo(String codigoCiclo) {
        this.codigoCiclo = codigoCiclo;
    }

    public String getTipoConta() {
        return tipoConta;
    }

    public void setTipoConta(String tipoConta) {
        this.tipoConta = tipoConta;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEnderecoRecebimentoFatura() {
        return enderecoRecebimentoFatura;
    }

    public void setEnderecoRecebimentoFatura(String enderecoRecebimentoFatura) {
        this.enderecoRecebimentoFatura = enderecoRecebimentoFatura;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getMetodoPagamento() {
        return metodoPagamento;
    }

    public void setMetodoPagamento(String metodoPagamento) {
        this.metodoPagamento = metodoPagamento;
    }

    public String getBanco() {
        return banco;
    }

    public void setBanco(String banco) {
        this.banco = banco;
    }

    public String getAgencia() {
        return agencia;
    }

    public void setAgencia(String agencia) {
        this.agencia = agencia;
    }

    public String getConta() {
        return conta;
    }

    public void setConta(String conta) {
        this.conta = conta;
    }

    public String getDataModalidade() {
        return dataModalidade;
    }

    public void setDataModalidade(String dataModalidade) {
        this.dataModalidade = dataModalidade;
    }

    public String getCodDebitoAutomatico() {
        return codDebitoAutomatico;
    }

    public void setCodDebitoAutomatico(String codDebitoAutomatico) {
        this.codDebitoAutomatico = codDebitoAutomatico;
    }

    public String getCanal() {
        return canal;
    }

    public void setCanal(String canal) {
        this.canal = canal;
    }

    public String getItensOrdem() {
        return itensOrdem;
    }

    public void setItensOrdem(String itensOrdem) {
        this.itensOrdem = itensOrdem;
    }

    public String getScoreConsumido() {
        return scoreConsumido;
    }

    public void setScoreConsumido(String scoreConsumido) {
        this.scoreConsumido = scoreConsumido;
    }

    public String getAcaoItemOrdem() {
        return acaoItemOrdem;
    }

    public void setAcaoItemOrdem(String acaoItemOrdem) {
        this.acaoItemOrdem = acaoItemOrdem;
    }

    public String getLabelComplemento1() {
        return labelComplemento1;
    }

    public void setLabelComplemento1(String labelComplemento1) {
        this.labelComplemento1 = labelComplemento1;
    }

    public String getValorComplemento1() {
        return valorComplemento1;
    }

    public void setValorComplemento1(String valorComplemento1) {
        this.valorComplemento1 = valorComplemento1;
    }

    public String getLabelComplemento2() {
        return labelComplemento2;
    }

    public void setLabelComplemento2(String labelComplemento2) {
        this.labelComplemento2 = labelComplemento2;
    }

    public String getValorComplemento2() {
        return valorComplemento2;
    }

    public void setValorComplemento2(String valorComplemento2) {
        this.valorComplemento2 = valorComplemento2;
    }

    public String getLabelComplemento3() {
        return labelComplemento3;
    }

    public void setLabelComplemento3(String labelComplemento3) {
        this.labelComplemento3 = labelComplemento3;
    }

    public String getValorComplemento3() {
        return valorComplemento3;
    }

    public void setValorComplemento3(String valorComplemento3) {
        this.valorComplemento3 = valorComplemento3;
    }

    public String getLabelComplemento4() {
        return labelComplemento4;
    }

    public void setLabelComplemento4(String labelComplemento4) {
        this.labelComplemento4 = labelComplemento4;
    }

    public String getValorComplemento4() {
        return valorComplemento4;
    }

    public void setValorComplemento4(String valorComplemento4) {
        this.valorComplemento4 = valorComplemento4;
    }

    public String getLabelComplemento5() {
        return labelComplemento5;
    }

    public void setLabelComplemento5(String labelComplemento5) {
        this.labelComplemento5 = labelComplemento5;
    }

    public String getValorComplemento5() {
        return valorComplemento5;
    }

    public void setValorComplemento5(String valorComplemento5) {
        this.valorComplemento5 = valorComplemento5;
    }

    public String getRowidItemOrdem() {
        return rowidItemOrdem;
    }

    public void setRowidItemOrdem(String rowidItemOrdem) {
        this.rowidItemOrdem = rowidItemOrdem;
    }

    public String getRowidItemOrdemPai() {
        return rowidItemOrdemPai;
    }

    public void setRowidItemOrdemPai(String rowidItemOrdemPai) {
        this.rowidItemOrdemPai = rowidItemOrdemPai;
    }

    public String getRowidItemOrdemRoot() {
        return rowidItemOrdemRoot;
    }

    public void setRowidItemOrdemRoot(String rowidItemOrdemRoot) {
        this.rowidItemOrdemRoot = rowidItemOrdemRoot;
    }

    public String getCategoriaItemOrdem() {
        return categoriaItemOrdem;
    }

    public void setCategoriaItemOrdem(String categoriaItemOrdem) {
        this.categoriaItemOrdem = categoriaItemOrdem;
    }

    public String getTipoItemOrdem() {
        return tipoItemOrdem;
    }

    public void setTipoItemOrdem(String tipoItemOrdem) {
        this.tipoItemOrdem = tipoItemOrdem;
    }

    public String getNovoNumero() {
        return novoNumero;
    }

    public void setNovoNumero(String novoNumero) {
        this.novoNumero = novoNumero;
    }

    public String getMotivo1() {
        return motivo1;
    }

    public void setMotivo1(String motivo1) {
        this.motivo1 = motivo1;
    }

    public String getMotivo2() {
        return motivo2;
    }

    public void setMotivo2(String motivo2) {
        this.motivo2 = motivo2;
    }

    public String getMotivo3() {
        return motivo3;
    }

    public void setMotivo3(String motivo3) {
        this.motivo3 = motivo3;
    }

    public String getRowid() {
        return rowid;
    }

    public void setRowid(String rowid) {
        this.rowid = rowid;
    }

    public String getAparelhoSolicitado() {
        return aparelhoSolicitado;
    }

    public void setAparelhoSolicitado(String aparelhoSolicitado) {
        this.aparelhoSolicitado = aparelhoSolicitado;
    }

    public String getValorAparelho() {
        return valorAparelho;
    }

    public void setValorAparelho(String valorAparelho) {
        this.valorAparelho = valorAparelho;
    }

    public String getValorAparelhoComDesconto() {
        return valorAparelhoComDesconto;
    }

    public void setValorAparelhoComDesconto(String valorAparelhoComDesconto) {
        this.valorAparelhoComDesconto = valorAparelhoComDesconto;
    }

    public String getCallId() {
        return callId;
    }

    public void setCallId(String callId) {
        this.callId = callId;
    }

    public String getCustcodePDV() {
        return custcodePDV;
    }

    public void setCustcodePDV(String custcodePDV) {
        this.custcodePDV = custcodePDV;
    }

    public String getCodigoProduto() {
        return codigoProduto;
    }

    public void setCodigoProduto(String codigoProduto) {
        this.codigoProduto = codigoProduto;
    }

    public String getNumeroSap() {
        return numeroSap;
    }

    public void setNumeroSap(String numeroSap) {
        this.numeroSap = numeroSap;
    }

    public String getNumeroPedidoLogistica() {
        return numeroPedidoLogistica;
    }

    public void setNumeroPedidoLogistica(String numeroPedidoLogistica) {
        this.numeroPedidoLogistica = numeroPedidoLogistica;
    }

    public String getDataPrevistaEntrega() {
        return dataPrevistaEntrega;
    }

    public void setDataPrevistaEntrega(String dataPrevistaEntrega) {
        this.dataPrevistaEntrega = dataPrevistaEntrega;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public String getPeriod() {
        return period;
    }

    public void setPeriod(String period) {
        this.period = period;
    }

    public String getTipoVendaAparelho() {
        return tipoVendaAparelho;
    }

    public void setTipoVendaAparelho(String tipoVendaAparelho) {
        this.tipoVendaAparelho = tipoVendaAparelho;
    }

    public String getDscVendaAparelho() {
        return dscVendaAparelho;
    }

    public void setDscVendaAparelho(String dscVendaAparelho) {
        this.dscVendaAparelho = dscVendaAparelho;
    }

    public String getStatusEntrega() {
        return statusEntrega;
    }

    public void setStatusEntrega(String statusEntrega) {
        this.statusEntrega = statusEntrega;
    }

    public String getDscTecnologia() {
        return dscTecnologia;
    }

    public void setDscTecnologia(String dscTecnologia) {
        this.dscTecnologia = dscTecnologia;
    }

    public String getCpe() {
        return cpe;
    }

    public void setCpe(String cpe) {
        this.cpe = cpe;
    }

    public String getOnt() {
        return ont;
    }

    public void setOnt(String ont) {
        this.ont = ont;
    }

    public String getAcessoRowid() {
        return acessoRowid;
    }

    public void setAcessoRowid(String acessoRowid) {
        this.acessoRowid = acessoRowid;
    }

    public String getDominioRoot() {
        return dominioRoot;
    }

    public void setDominioRoot(String dominioRoot) {
        this.dominioRoot = dominioRoot;
    }

    public String getxGrupoId() {
        return xGrupoId;
    }

    public void setxGrupoId(String xGrupoId) {
        this.xGrupoId = xGrupoId;
    }

    public String getxGrupoPr() {
        return xGrupoPr;
    }

    public void setxGrupoPr(String xGrupoPr) {
        this.xGrupoPr = xGrupoPr;
    }

    public String getxIccd() {
        return xIccd;
    }

    public void setxIccd(String xIccd) {
        this.xIccd = xIccd;
    }

    public String getxIccdNew() {
        return xIccdNew;
    }

    public void setxIccdNew(String xIccdNew) {
        this.xIccdNew = xIccdNew;
    }
}
