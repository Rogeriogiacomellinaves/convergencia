package br.com.tim.mapreduce.refactoring.endtoend.step4.pt5;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

public class GroupingComparator extends WritableComparator {

    public GroupingComparator() {
        super(Step4Pt5Key.class, true);
    }

    @SuppressWarnings({"rawtypes"})
    @Override
    public int compare(WritableComparable a, WritableComparable b) {
    	Step4Pt5Key keyA = (Step4Pt5Key) a;
    	Step4Pt5Key keyB = (Step4Pt5Key) b;

        return keyA.compareToGrouping(keyB);
    }

}
