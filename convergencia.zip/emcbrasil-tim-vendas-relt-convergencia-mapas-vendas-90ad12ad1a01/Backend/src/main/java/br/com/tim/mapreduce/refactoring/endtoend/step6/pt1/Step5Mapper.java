package br.com.tim.mapreduce.refactoring.endtoend.step6.pt1;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.parquet.Strings;

import br.com.tim.mapreduce.refactoring.endtoend.step6.model.Step5;
import br.com.tim.mapreduce.refactoring.endtoend.step6.pt1.Step6Value;
import br.com.tim.mapreduce.refactoring.endtoend.step6.utils.Step6Counters;

public class Step5Mapper extends Mapper<LongWritable,Text, Text, Step6Value>{
	
	Step6Value outValue;
	private Step5 step5;
	
	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		
		this.outValue = new Step6Value();
		this.step5 =  new Step5();
		
	}

	
	protected void map(LongWritable key, Text value,  Mapper<LongWritable, Text, Text, Step6Value>.Context context) throws IOException, InterruptedException{
		
		outValue.reset();
		step5.clean();
		
		step5.parseFromText(value);

		if(!Strings.isNullOrEmpty(step5.getRowIdItemOrdem())) {
			
			
			outValue.update(TypeStep6.STEP5, outValue);
			
			context.write(new Text(step5.getRowIdItemOrdem()), outValue);
			context.getCounter(Step6Counters.STEP5_MAPPER_WRITE).increment(1l);
			
		}else {
			
			context.getCounter(Step6Counters.STEP5_MAPPER_DISCART).increment(1l);

			
		}
		
	}
	
}
