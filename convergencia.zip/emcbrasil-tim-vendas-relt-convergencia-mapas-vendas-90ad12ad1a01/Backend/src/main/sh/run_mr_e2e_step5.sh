#!/bin/bash

source /data/apps/env/setup.sh
logging_configuration=$HOME/resources/e2e-step5-log4j.properties
project_configuration=$HOME/resources/e2e-step5-configuration.xml
proc_conf=" -Dconfiguration=$project_configuration "

SYSTEM_PROPERTIES="$SYSTEM_PROPERTIES -Dlog4j=$logging_configuration -Dconfiguration=$project_configuration "

java $JAVA_OPTS $SYSTEM_PROPERTIES -cp $CM_CLASSPATH br.com.tim.mapreduce.e2e.step5.E2EStep5Driver $1

EXIT_CODE=$?

exit $EXIT_CODE