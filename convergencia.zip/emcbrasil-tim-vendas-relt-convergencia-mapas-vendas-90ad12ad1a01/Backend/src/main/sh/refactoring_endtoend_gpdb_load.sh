#!/bin/bash

source /data/apps/env/setup.sh

CONFIG="$HOME/resources/refactoring/e2e_refactoring_gpdb_cofiguration.xml"
SYSTEM_PROPERTIES=$SYSTEM_PROPERTIES" -Dconfiguration=$CONFIG"

java $JAVA_OPTS $SYSTEM_PROPERTIES -cp $CM_CLASSPATH br.com.tim.gpdb.GpdbIngestion