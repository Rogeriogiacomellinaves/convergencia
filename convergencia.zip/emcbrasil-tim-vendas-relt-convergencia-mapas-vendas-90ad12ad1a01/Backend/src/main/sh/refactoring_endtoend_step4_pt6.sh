#!/bin/bash

source /data/apps/env/setup.sh

project_configuration=$HOME/resources/refactoring/refactoring-endtoend-step4Pt6-configuration.xml
logging_configuration=$HOME/resources/refactoring/refactoring-endtoend-step4Pt6-log4j.properties
custom_metrics=$HOME/resources/custom_metrics.xml

proc_conf=" -Dcustom_metrics=$custom_metrics -Dlog4j=$logging_configuration -Dconfiguration=$project_configuration "
java $JAVA_OPTS $SYSTEM_PROPERTIES $proc_conf -cp $CM_CLASSPATH br.com.tim.mapreduce.refactoring.endtoend.step4.pt6.E2EStep4Pt6Driver $1

. ${LIBSH}/sh/exit-if-ne-0.sh