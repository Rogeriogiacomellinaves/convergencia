#!/bin/bash

source /data/apps/env/setup.sh

resource_xml=$1

CONFIG="$HOME/resources/${resource_xml}_gpdb_configuration.xml"

SYSTEM_PROPERTIES="$SYSTEM_PROPERTIES -Dconfiguration=$CONFIG -Dlog4j=$NADA"

java $JAVA_OPTS $SYSTEM_PROPERTIES -cp $CM_CLASSPATH br.com.tim.gpdb.GpdbIngestion

EXIT_CODE=$?

exit $EXIT_CODE