#!/bin/bash

source /data/apps/env/setup.sh
logging_configuration=$HOME/resources/e2e-step9-pt2-log4j.properties
project_configuration=$HOME/resources/e2e-step9-pt2-configuration.xml
proc_conf=" -Dconfiguration=$project_configuration "

SYSTEM_PROPERTIES="$SYSTEM_PROPERTIES -Dlog4j=$logging_configuration -Dconfiguration=$project_configuration "

java $JAVA_OPTS $SYSTEM_PROPERTIES -cp $CM_CLASSPATH br.com.tim.mapreduce.e2e.step9.pt2.E2EStep9PT2Driver $1

EXIT_CODE=$?

exit $EXIT_CODE