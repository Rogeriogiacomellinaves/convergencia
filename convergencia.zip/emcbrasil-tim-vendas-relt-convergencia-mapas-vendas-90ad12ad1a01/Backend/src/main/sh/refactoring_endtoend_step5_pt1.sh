#!/bin/bash

source /data/apps/env/setup.sh

project_configuration=$HOME/resources/refactoring/refactoring-endtoend-step5-configuration.xml
logging_configuration=$HOME/resources/refactoring/refactoring-endtoend-step5-log4j.properties
custom_metrics=$HOME/resources/custom_metrics.xml

proc_conf=" -Dcustom_metrics=$custom_metrics -Dlog4j=$logging_configuration -Dconfiguration=$project_configuration "
java $JAVA_OPTS $SYSTEM_PROPERTIES $proc_conf -cp $CM_CLASSPATH br.com.tim.mapreduce.refactoring.endtoend.step5.pt1.Step5Driver $1

. ${LIBSH}/sh/exit-if-ne-0.sh