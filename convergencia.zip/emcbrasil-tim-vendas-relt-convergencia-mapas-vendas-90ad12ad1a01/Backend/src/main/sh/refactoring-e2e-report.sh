#!/bin/bash

Date="$1"

echo ""
echo "##################################################################################"
echo "processamento: $Date"
cd "/data/apps/relt/tim-vendas-relt-convergencia-mapas-vendas/sh"
pwd


                echo " "
                echo "############# Processando Step 1 PT 1: $Date ####################"

                echo "=====> executando step1 pt1 <====="
                ./refactoring_endtoend_step1_pt1.sh $Date
                if [ $? -ne 0 ]
                then
                        echo "#################################  ERRO script 1 data: $Date #############################"
                        exit 1

                fi

                echo " "
                echo "############# Processando Step 1 PT 2: $ts ####################"
                echo "=====> executando step 1 pt 2<====="
                ./refactoring_endtoend_step1_pt2.sh $Date
                if [ $? -ne 0 ]
                then
                        echo "#################################  ERRO script 2 data: $Date #############################"
                        exit 1

                fi
                
                echo " "
                echo "############# Processando Step 1 PT 3: $ts ####################"
                echo "=====> executando step 1 pt 3<====="
                ./refactoring_endtoend_step1_pt3.sh $Date
                if [ $? -ne 0 ]
                then
                        echo "#################################  ERRO script 3 data: $Date #############################"
                        exit 1

                fi

                echo " "
                echo "############# Processando Step 1 PT 4: $ts ####################"
                echo "=====> executando step 1 pt 4<====="
                ./refactoring_endtoend_step1_pt4.sh $Date
                if [ $? -ne 0 ]
                then
                        echo "#################################  ERRO script 4 data: $Date #############################"
                        exit 1

                fi
                  
                                echo " "
                echo "############# Processando Step 2 HQL: $ts ####################"
                echo "=====> executando Step 2 HQL<====="
                ./refactoring_endtoend_step2_hql.sh $Date
                if [ $? -ne 0 ]
                then
                        echo "#################################  ERRO script 4 data: $Date #############################"
                        exit 1

                fi
                
                                echo " "
                echo "############# Processando Step 4 PT 1: $ts ####################"
                echo "=====> executando step 4 pt 1<====="
                ./refactoring_endtoend_step4_pt1.sh $Date
                if [ $? -ne 0 ]
                then
                        echo "#################################  ERRO script 4 data: $Date #############################"
                        exit 1

                fi
                
                                echo " "
                echo "############# Processando Step 4 PT 2: $ts ####################"
                echo "=====> executando step 4 pt 2<====="
                ./refactoring_endtoend_step4_pt2.sh $Date
                if [ $? -ne 0 ]
                then
                        echo "#################################  ERRO script 4 data: $Date #############################"
                        exit 1

                fi
                
                                echo " "
                echo "############# Processando Step 4 PT 3: $ts ####################"
                echo "=====> executando step 4 pt 3<====="
                ./refactoring_endtoend_step4_pt3.sh $Date
                if [ $? -ne 0 ]
                then
                        echo "#################################  ERRO script 4 data: $Date #############################"
                        exit 1

                fi
                
                                echo " "
                echo "############# Processando Step 4 PT 4: $ts ####################"
                echo "=====> executando step 4 pt 3<====="
                ./refactoring_endtoend_step4_pt4.sh $Date
                if [ $? -ne 0 ]
                then
                        echo "#################################  ERRO script 4 data: $Date #############################"
                        exit 1

                fi
                
                                echo " "
                echo "############# Processando Step 4 PT 5: $ts ####################"
                echo "=====> executando step 4 pt 5<====="
                ./refactoring_endtoend_step4_pt5.sh
                if [ $? -ne 0 ]
                then
                        echo "#################################  ERRO script 4 data: $Date #############################"
                        exit 1

                fi
                
                                echo " "
                echo "############# Processando Step 4 PT 6: $ts ####################"
                echo "=====> executando step 4 pt 6<====="
                ./refactoring_endtoend_step4_pt6.sh
                if [ $? -ne 0 ]
                then
                        echo "#################################  ERRO script 4 data: $Date #############################"
                        exit 1

                fi
                
                                echo " "
                echo "############# Processando Step5 : $ts ####################"
                echo "=====> executando step 5 <====="
                ./refactoring_endtoend_step5_pt1.sh
                if [ $? -ne 0 ]
                then
                        echo "#################################  ERRO script 4 data: $Date #############################"
                        exit 1

                fi
                
                                echo " "
                echo "############# Processando FINAL: $ts ####################"
                echo "=====> executando step final <====="
                ./refactoring_endtoend_stepfinal.sh $Date
                if [ $? -ne 0 ]
                then
                        echo "#################################  ERRO script 4 data: $Date #############################"
                        exit 1

                fi

        
        echo " "
        echo "############# FIM REPROCESSO ####################"
EXIT_CODE=$?

exit $EXIT_CODE​