#!/bin/bash

listDate=""

echo "2020-02-16 2020-02-17 2020-02-18"
echo "##################################################################################"
echo "Listando datas para processamento: $listDate"

if [ ! -z "$listDate" ]
then

        for ts in $listDate
        do

                echo " "
                echo "############# Processando Step 1 PT 1: $ts ####################"

                echo "=====> executando step1 pt1 <====="
                ./refactoring_endtoend_step1_pt1.sh reprocess-day=$ts
                if [ $? -ne 0 ]
                then
                        echo "#################################  ERRO script 1 data: $ts #############################"
                        exit 1

                fi

                echo " "
                echo "############# Processando Step 1 PT 2: $ts ####################"
                echo "=====> executando step 1 pt 2<====="
                ./refactoring_endtoend_step1_pt2.sh reprocess-day=$ts
                if [ $? -ne 0 ]
                then
                        echo "#################################  ERRO script 2 data: $ts #############################"
                        exit 1

                fi
                
                echo " "
                echo "############# Processando Step 1 PT 3: $ts ####################"
                echo "=====> executando step 1 pt 3<====="
                ./refactoring_endtoend_step1_pt3.sh reprocess-day=$ts
                if [ $? -ne 0 ]
                then
                        echo "#################################  ERRO script 3 data: $ts #############################"
                        exit 1

                fi

                echo " "
                echo "############# Processando Step 1 PT 4: $ts ####################"
                echo "=====> executando step 1 pt 4<====="
                ./refactoring_endtoend_step1_pt4.sh reprocess-day=$ts
                if [ $? -ne 0 ]
                then
                        echo "#################################  ERRO script 4 data: $ts #############################"
                        exit 1

                fi
                
                echo " "
                echo "############# Processando Step 2 HQL: $ts ####################"
                echo "=====> executando Step 2 HQL<====="
                ./refactoring_endtoend_step2_hql.sh reprocess-day=$ts
                if [ $? -ne 0 ]
                then
                        echo "#################################  ERRO Step 2 HQL data: $ts #############################"
                        exit 1

                fi
                
                echo " "
                echo "############# Processando Step 4: $ts ####################"
                echo "=====> executando Step 4<====="
                ./refactoring_endtoend_step4_pt1.sh reprocess-day=$ts
                if [ $? -ne 0 ]
                then
                        echo "#################################  ERRO Step 4 data: $ts #############################"
                        exit 1

                fi
                
                echo " "
                echo "############# Processando Step HQL FINAL: $ts ####################"
                echo "=====> executando HQL FINAL<====="
                ./refactoring_endtoend_stepfinal.sh reprocess-day=$ts
                if [ $? -ne 0 ]
                then
                        echo "#################################  ERRO HQL FINAL data: $ts #############################"
                        exit 1

                fi
                
                echo " "
                echo "############# Processando Step GPDB LOAD: $ts ####################"
                echo "=====> executando GPDB LOAD<====="
                ./refactoring_endtoend_gpdb_load.sh
                if [ $? -ne 0 ]
                then
                        echo "#################################  ERRO GPDB LOAD data: $ts #############################"
                        exit 1

                fi

        done
        echo " "
        echo "############# FIM REPROCESSO ####################"
fi
