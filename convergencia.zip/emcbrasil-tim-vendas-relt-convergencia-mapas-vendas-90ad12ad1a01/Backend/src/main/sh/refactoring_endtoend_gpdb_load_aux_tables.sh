#!/bin/bash

source /data/apps/env/setup.sh

CONFIG="$HOME/resources/refactoring/gpdb-load-aux-refactoring.xml"
SYSTEM_PROPERTIES=$SYSTEM_PROPERTIES" -Dconfiguration=$CONFIG"

java $JAVA_OPTS $SYSTEM_PROPERTIES -cp $CM_CLASSPATH br.com.tim.gpdb.GpdbIngestion