#!/bin/bash

source /data/apps/env/setup.sh

for file in `ls ${HOME}/jars/`
do
PATH_JAR="${HOME}/jars/$file"
done

CONFIG="$HOME/resources/refactoring/step-final-hive-query.xml"
LOG=file:$HOME/resources/refactoring/refactoring-endtoend-hivequery-stepfinal-log4j.properties
SYSTEM_PROPERTIES=$SYSTEM_PROPERTIES" -Dlog4j= -Dlog4j.configuration=$LOG -Dconfiguration=$CONFIG -Dpath.jar=$PATH_JAR"

java $JAVA_OPTS $SYSTEM_PROPERTIES -cp $CM_CLASSPATH br.com.tim.hive.query.HiveQueryDriver $1

EXIT_CODE=$?

exit $EXIT_CODE