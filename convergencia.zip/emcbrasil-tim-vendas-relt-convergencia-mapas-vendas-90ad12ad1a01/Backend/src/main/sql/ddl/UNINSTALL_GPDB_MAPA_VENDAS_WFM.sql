--==============================================================================
-- Projeto       : Convergencia - Mapa de Vendas
-- Responsavel   : Eliab Bueno / Everton Araujo
-- Solicitante   : Claudio Silva
-- Funcao        : Script de desinstalacao da estrutura da tabelas no GPDB
-- Criacao       : 18/12/2019
-- =============================================================================
-- Historico de Alteracoes
-- =============================================================================
-- Data          :
-- Solicitante   :
-- Alteracao     :
--==============================================================================

\echo
\echo INICIO DO SCRIPT UNINSTALL_GPDB_MAPA_VENDAS_WFM.SQL

\echo
\echo **************************************************************************
\echo               **** ATENCAO ****
\echo ESSE PROCEDIMENTO DEVERA SER EXECUTADO NO GPDB
\echo #BASE# WAREHOUSE
\echo **************************************************************************

\echo ALTERANDO ENCODING PARA UTF8
\encoding UTF-8;

---------------------------------------------------------
-- SECAO DE ALTERACAO DOS OBJETOS DE BANCO
---------------------------------------------------------

\echo APAGA ESTRUTURA DA TABELA COM ITENS DE ORDENS ... ...
drop view reports.vw_r_conv_item_ordem;
drop table reports.dw_r_conv_item_ordem;
alter table reports.dw_r_conv_item_ordem_bkp_wfm rename to dw_r_conv_item_ordem;
drop external table ext.dw_r_conv_item_ordem;
alter table ext.dw_r_conv_item_ordem_bkp_wfm rename to dw_r_conv_item_ordem;

create or replace view reports.vw_r_conv_item_ordem
as
select * from reports.dw_r_conv_item_ordem;

ALTER TABLE reports.vw_r_conv_item_ordem OWNER TO sas_va_loader;
GRANT ALL ON TABLE reports.vw_r_conv_item_ordem TO udbd_load;
GRANT SELECT ON TABLE reports.vw_r_conv_item_ordem TO sdx_bigdata;
GRANT SELECT ON TABLE reports.vw_r_conv_item_ordem TO sdx_it;

\echo APAGA ESTRUTURA DA TABELA DE TRAMITACAO DE ORDEM ... ...
drop view reports.vw_r_conv_tramit_ordem;
drop table reports.dw_r_conv_tramit_ordem;
alter table reports.dw_r_conv_tramit_ordem_bkp_wfm rename to dw_r_conv_tramit_ordem;
drop external table ext.dw_r_conv_tramit_ordem;
alter table ext.dw_r_conv_tramit_ordem_bkp_wfm rename to dw_r_conv_tramit_ordem;

create or replace view reports.vw_r_conv_tramit_ordem
as
select * from reports.dw_r_conv_tramit_ordem;

alter table reports.vw_r_conv_tramit_ordem owner to sas_va_loader;
grant all on table reports.vw_r_conv_tramit_ordem to udbd_load;
grant select on table reports.vw_r_conv_tramit_ordem to sdx_bigdata;

\echo APAGA ESTRUTURA DA TABELA DE VENDA E2E ... ...
drop view reports.vw_r_conv_venda_e2e;
drop table reports.dw_r_conv_venda_e2e;
alter table reports.dw_r_conv_venda_e2e_bkp_wfm rename to dw_r_conv_venda_e2e;
drop external table ext.dw_r_conv_venda_e2e;
alter table ext.dw_r_conv_venda_e2e_bkp_wfm rename to dw_r_conv_venda_e2e;

create or replace view reports.vw_r_conv_venda_e2e
as
select * from reports.dw_r_conv_venda_e2e;

alter table reports.vw_r_conv_venda_e2e owner to sas_va_loader;
grant all on table reports.vw_r_conv_venda_e2e to udbd_load;
grant select on table reports.vw_r_conv_venda_e2e to sdx_bigdata;

---------------------------------------------------------
-- FIM DA SECAO DE ALTERACAO DOS OBJETOS DE BANCO
---------------------------------------------------------
\echo
\echo FIM DO SCRIPT UNINSTALL_GPDB_MAPA_VENDAS_WFM.SQL

--###############################################################################
-- FIM DO INSTALL UNINSTALL_GPDB_MAPA_VENDAS_WFM.SQL
