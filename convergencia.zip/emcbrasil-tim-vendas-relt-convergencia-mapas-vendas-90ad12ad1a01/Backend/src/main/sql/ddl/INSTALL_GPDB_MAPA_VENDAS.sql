--==============================================================================
-- Projeto       : Convergencia - Mapas de Vendas
-- Responsavel   : Pedro Ortelani
-- Solicitante   : Claudio Silva
-- Funcao        : Script de criacao da estrutura da tabelas no GPDB
-- Criacao       : 05/08/2019
-- =============================================================================
-- Historico de Alteracoes
-- =============================================================================
-- Data          :
-- Solicitante   :
-- Alteracao     :
--==============================================================================

\echo
\echo INICIO DO SCRIPT INSTALL_GPDB_CONV_MAPAS_VENDAS.SQL

\echo
\echo **************************************************************************
\echo               **** ATENCAO ****
\echo ESSE PROCEDIMENTO DEVERA SER EXECUTADO NO GPDB
\echo #BASE# WAREHOUSE
\echo **************************************************************************

\echo ALTERANDO ENCODING PARA UTF8
\encoding UTF-8;

---------------------------------------------------------
-- SECAO DE ALTERACAO DOS OBJETOS DE BANCO
---------------------------------------------------------

\echo ALTERA ESTRUTURA DA TABELA COM ITENS DE ORDENS ... ...
\i create_dw_r_conv_item_ordem.sql

\echo ALTERA ESTRUTURA DA TABELA DE TRAMITACAO DE ORDEM ... ...
\i create_dw_r_conv_tramit_ordem.sql

\echo ALTERA ESTRUTURA DA TABELA DE VENDAS E2E ... ...
\i create_dw_r_conv_venda_e2e.sql

\echo ALTERA ESTRUTURA DAS TABELAS AUXILIARES ... ...
\i create_aux_tables.sql

---------------------------------------------------------
-- FIM DA SECAO DE ALTERACAO DOS OBJETOS DE BANCO
---------------------------------------------------------
\echo
\echo FIM DO SCRIPT INSTALL_GPDB_CONV_MAPAS_VENDAS.SQL

--###############################################################################
-- FIM DO INSTALL INSTALL_GPDB_CONV_MAPAS_VENDAS.SQL
