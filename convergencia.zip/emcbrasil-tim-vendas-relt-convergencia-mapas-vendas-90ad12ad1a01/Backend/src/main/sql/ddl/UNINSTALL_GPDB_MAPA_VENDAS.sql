--==============================================================================
-- Projeto       : Convergencia - Mapa de Vendas
-- Responsavel   : Pedro Ortelani
-- Solicitante   : Claudio Silva
-- Funcao        : Script de desinstalacao da estrutura da tabelas no GPDB
-- Criacao       : 05/08/2019
-- =============================================================================
-- Historico de Alteracoes
-- =============================================================================
-- Data          :
-- Solicitante   :
-- Alteracao     :
--==============================================================================

\echo
\echo INICIO DO SCRIPT UNINSTALL_GPDB_MAPA_VENDAS.SQL

\echo
\echo **************************************************************************
\echo               **** ATENCAO ****
\echo ESSE PROCEDIMENTO DEVERA SER EXECUTADO NO GPDB
\echo #BASE# WAREHOUSE
\echo **************************************************************************

\echo ALTERANDO ENCODING PARA UTF8
\encoding UTF-8;

---------------------------------------------------------
-- SECAO DE ALTERACAO DOS OBJETOS DE BANCO
---------------------------------------------------------

\echo APAGA ESTRUTURA DA TABELA COM ITENS DE ORDENS ... ...
drop table reports.dw_r_conv_item_ordem;
drop external table ext.dw_r_conv_item_ordem;

\echo APAGA ESTRUTURA DA TABELA DE TRAMITACAO DE ORDEM ... ...
drop table reports.dw_r_conv_tramit_ordem;
drop external table ext.dw_r_conv_tramit_ordem;

\echo APAGA ESTRUTURA DA TABELA DE VENDA E2E ... ...
drop table reports.dw_r_conv_venda_e2e;
drop external table ext.dw_r_conv_venda_e2e;

\echo APAGA ESTRUTURA DAS TABELAS AUXILIARES ... ...
drop table aux.dw_d_conv_item_ordem_dat_ref;
drop table aux.dw_d_conv_tramit_ordem_dat_ref;
drop table aux.dw_d_conv_venda_e2e_dat_ref;
drop table aux.dw_d_conv_item_ordem_dat_cri;
drop table aux.dw_d_conv_tramit_ordem_dat_cri;
drop table aux.dw_d_conv_venda_e2e_dat_cri;

---------------------------------------------------------
-- FIM DA SECAO DE ALTERACAO DOS OBJETOS DE BANCO
---------------------------------------------------------
\echo
\echo FIM DO SCRIPT UNINSTALL_GPDB_MAPA_VENDAS.SQL

--###############################################################################
-- FIM DO INSTALL UNINSTALL_GPDB_MAPA_VENDAS.SQL
