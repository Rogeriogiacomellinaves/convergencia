-- ALTERAÇÃO DATATYPE DA TABELA ITEM ORDEM - CAMPO COD_CTA_FINANCEIRA - DE BIGINT PARA CHARACTER VARYING(50)

drop view if exists reports.vw_r_conv_item_ordem;

alter table reports.dw_r_conv_item_ordem alter column cod_cta_financeira type character varying(50);

create or replace view reports.vw_r_conv_item_ordem
as
select * from reports.dw_r_conv_item_ordem;
